﻿<?php
/**
 * Quokka Meento - Distributed URL & Server Mesh Tool
 * =====================================================
 * Sends all URLs in files.txt to all servers in servers.txt
 * and can receive both via GET requests.
 *
 * Every file access (read AND write) uses fopen() + flock() so that
 * concurrent HTTP requests never produce torn reads, duplicate lines,
 * or clobbered JSON files.
 *
 * GET params (max 2000 chars each):
 *   ?action=get_files                 -> returns contents of files.txt
 *   ?action=get_servers               -> returns contents of servers.txt
 *   ?action=add_url&url=...           -> adds a URL to files.txt
 *   ?action=add_server&server=...     -> adds a server to servers.txt
 *   ?action=sync                      -> pushes all URLs to all servers
 *   ?action=receive&url=...           -> receives a URL from another node
 *   ?action=receive_server&server=... -> receives a server from another node
 */

// -----------------------------------------------------------------------------
// CONFIGURATION
// -----------------------------------------------------------------------------

/**
 * VERIFY_URL_ONLINE
 * When TRUE: before adding a URL to files.txt the script will:
 *   1. Verify the URL is reachable (HTTP 2xx/3xx).
 *   2. Resolve the URL host to an IP address.
 *   3. Save the IP inside server_ip/<sha256(ip+salt)>.txt using fopen().
 *      If that file already exists the URL is silently skipped (dedup).
 *   4. Save any query-string parameters to the two JSON side-car files.
 * Default: FALSE  (disabled)
 */
define('VERIFY_URL_ONLINE', false);

/** Salt mixed into the IP hash that names the deduplication sentinel file. */
define('IP_SALT', 'quokka_meento_salt_2024');

/** Maximum allowed byte-length for any single GET parameter value. */
define('MAX_INPUT_LENGTH', 2000);

// -----------------------------------------------------------------------------
// FILE PATHS
// -----------------------------------------------------------------------------
define('FILES_TXT',       __DIR__ . '/files.txt');
define('SERVERS_TXT',     __DIR__ . '/servers.txt');
define('PUBLIC_KEY_TXT',  __DIR__ . '/public_key.txt');
define('USER_TXT',        __DIR__ . '/user.txt');
define('BTC_TXT',         __DIR__ . '/btc.txt');
define('SERVER_IP_DIR',   __DIR__ . '/server_ip');
define('URL_HASH_DIR',    __DIR__ . '/url_hash');
define('SRV_IP_HASH_DIR', __DIR__ . '/server_ip_hash');

// -----------------------------------------------------------------------------
// BOOTSTRAP - create missing files / directories on first run
// -----------------------------------------------------------------------------

// fopen mode 'x' (O_CREAT|O_EXCL) is atomic: only one process creates
// the file even when many race simultaneously on the same path.
foreach ([FILES_TXT, SERVERS_TXT, PUBLIC_KEY_TXT, USER_TXT, BTC_TXT] as $_f) {
    if (!file_exists($_f)) {
        $fh = fopen($_f, 'x');
        if ($fh !== false) {
            fclose($fh);
        }
    }
}
unset($_f, $fh);

foreach ([SERVER_IP_DIR, URL_HASH_DIR, SRV_IP_HASH_DIR] as $_d) {
    if (!is_dir($_d)) {
        mkdir($_d, 0755, true);
    }
}
unset($_d);

// -----------------------------------------------------------------------------
// CORE FILE I/O PRIMITIVES
// All disk access flows through exactly these four functions.
// No file_get_contents(), file_put_contents(), or file() anywhere.
// -----------------------------------------------------------------------------

/**
 * Read the entire content of a file under a SHARED lock.
 *
 * LOCK_SH blocks if another process currently holds LOCK_EX, so this
 * function will never return a partially-written file.
 *
 * Returns the raw string content, or '' when the file is absent/unreadable.
 */
function file_read_locked(string $path): string
{
    if (!file_exists($path)) {
        return '';
    }

    $fh = fopen($path, 'r');
    if ($fh === false) {
        return '';
    }

    if (!flock($fh, LOCK_SH)) {        // wait for any active writer to finish
        fclose($fh);
        return '';
    }

    $content = '';
    while (!feof($fh)) {
        $chunk = fread($fh, 65536);
        if ($chunk === false) {
            break;
        }
        $content .= $chunk;
    }

    flock($fh, LOCK_UN);
    fclose($fh);
    return $content;
}

/**
 * Overwrite a file with $content under an EXCLUSIVE lock.
 *
 * Mode 'c': open (create if missing), do NOT truncate yet, pointer at byte 0.
 * Truncation happens AFTER the lock is granted, closing the TOCTOU window
 * that mode 'w' creates (mode 'w' truncates at open-time, before any lock
 * is acquired, so another reader could see an empty file mid-operation).
 *
 * Returns true on success, false on any I/O failure.
 */
function file_write_locked(string $path, string $content): bool
{
    $fh = fopen($path, 'c');
    if ($fh === false) {
        return false;
    }

    if (!flock($fh, LOCK_EX)) {
        fclose($fh);
        return false;
    }

    ftruncate($fh, 0);
    rewind($fh);

    $ok = (fwrite($fh, $content) !== false);
    fflush($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
    return $ok;
}

/**
 * Append a unique line to a text file under a single EXCLUSIVE lock.
 *
 * The lock is acquired BEFORE the duplicate check and released AFTER the
 * write, making the read-check-write sequence atomic with respect to every
 * other process using this function on the same file.
 *
 * This prevents the race where two concurrent requests both pass the
 * duplicate check and both append the same value.
 *
 * Algorithm:
 *   1. fopen 'c'  - create if absent, pointer at byte 0, no early truncate.
 *   2. flock EX   - block until we are the sole accessor.
 *   3. Read the entire file while holding the lock.
 *   4. Split into lines; if $line already exists -> release and return false.
 *   5. fseek to end; ensure prior content ends with a newline.
 *   6. fwrite the new line + newline.
 *   7. flock UN + fclose.
 *
 * Returns true if appended, false if duplicate or on I/O error.
 */
function file_append_unique_locked(string $path, string $line): bool
{
    $line = trim($line);
    if ($line === '') {
        return false;
    }

    $fh = fopen($path, 'c');
    if ($fh === false) {
        return false;
    }

    if (!flock($fh, LOCK_EX)) {
        fclose($fh);
        return false;
    }

    // Read current contents while the lock is held.
    $content = '';
    while (!feof($fh)) {
        $chunk = fread($fh, 65536);
        if ($chunk === false) {
            break;
        }
        $content .= $chunk;
    }

    // Whole-line duplicate check (case-sensitive, trimmed).
    $existing = array_map('trim', explode("\n", $content));
    if (in_array($line, $existing, true)) {
        flock($fh, LOCK_UN);
        fclose($fh);
        return false;
    }

    // Move pointer to end; ensure prior content is newline-terminated.
    fseek($fh, 0, SEEK_END);
    if ($content !== '' && substr($content, -1) !== "\n") {
        fwrite($fh, "\n");
    }

    $ok = (fwrite($fh, $line . "\n") !== false);
    fflush($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
    return $ok;
}

/**
 * Atomically create a new file and write $content to it.
 *
 * fopen mode 'x' maps to O_CREAT|O_EXCL at the OS level.
 * On POSIX systems this open is itself atomic: if N processes race on the
 * same path, exactly one receives a valid handle; all others get false.
 * No external lock is needed for the existence check.
 *
 * LOCK_EX is still acquired so that readers using LOCK_SH wait for the
 * write to complete before reading the newly created file.
 *
 * Returns true  -> file created and written (this process "won" the race).
 * Returns false -> file already existed (duplicate) or I/O error.
 */
function file_create_exclusive(string $path, string $content): bool
{
    $fh = fopen($path, 'x');           // fails immediately if path exists
    if ($fh === false) {
        return false;                  // file already exists -> duplicate
    }

    if (!flock($fh, LOCK_EX)) {
        fclose($fh);
        return false;
    }

    $ok = (fwrite($fh, $content) !== false);
    fflush($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
    return $ok;
}

/**
 * Read-modify-write a JSON file under a single EXCLUSIVE lock.
 *
 * The lock is held for the complete read -> transform -> write cycle, making
 * the operation atomic with respect to other processes calling this function
 * on the same file. No process can read stale data or overwrite an
 * in-progress update.
 *
 * $callback receives the current decoded array ([] for new/empty files)
 * and must return the updated array to be persisted.
 *
 * Uses fopen mode 'c': create if absent, no early truncation, pointer at 0.
 * Truncation happens after the lock is granted (same rationale as
 * file_write_locked).
 *
 * Returns true on success, false on any I/O failure.
 */
function json_update_locked(string $path, callable $callback): bool
{
    $fh = fopen($path, 'c');
    if ($fh === false) {
        return false;
    }

    if (!flock($fh, LOCK_EX)) {
        fclose($fh);
        return false;
    }

    // Read while holding the lock.
    $raw = '';
    while (!feof($fh)) {
        $chunk = fread($fh, 65536);
        if ($chunk === false) {
            break;
        }
        $raw .= $chunk;
    }

    $data    = ($raw !== '') ? (json_decode($raw, true) ?: []) : [];
    $updated = $callback($data);
    $encoded = json_encode(
        $updated,
        JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
    );

    ftruncate($fh, 0);
    rewind($fh);
    $ok = (fwrite($fh, $encoded) !== false);
    fflush($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
    return $ok;
}

// -----------------------------------------------------------------------------
// HIGHER-LEVEL HELPERS
// -----------------------------------------------------------------------------

/**
 * Return all non-empty, trimmed lines from a text file.
 * Uses file_read_locked() for safe concurrent access.
 */
function read_lines(string $path): array
{
    $content = file_read_locked($path);
    if ($content === '') {
        return [];
    }
    $lines = explode("\n", $content);
    $lines = array_map('trim', $lines);
    return array_values(array_filter($lines, fn($l) => $l !== ''));
}

/**
 * Read and trim a single-value credential file.
 * Uses file_read_locked() so reads block while a write is in progress.
 */
function read_credential(string $path): string
{
    return trim(file_read_locked($path));
}

/**
 * Validate and return a GET parameter, aborting with HTTP 400 if it exceeds
 * MAX_INPUT_LENGTH. Returns null when the parameter is absent.
 */
function get_param(string $key): ?string
{
    if (!isset($_GET[$key])) {
        return null;
    }
    $val = (string) $_GET[$key];
    if (strlen($val) > MAX_INPUT_LENGTH) {
        json_response(
            ['error' => "Parameter '$key' exceeds the maximum allowed length of " . MAX_INPUT_LENGTH . " bytes."],
            400
        );
    }
    return $val;
}

/**
 * Encode $data as JSON, set appropriate headers, and exit.
 */
function json_response(array $data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Strip the query string from a URL, returning only the base URL.
 * Example: "https://example.com/p?foo=bar" -> "https://example.com/p"
 */
function base_url(string $url): string
{
    $pos = strpos($url, '?');
    return ($pos !== false) ? substr($url, 0, $pos) : $url;
}

/**
 * Return the raw query string of a URL (everything after '?'), or '' if none.
 */
function query_string_of(string $url): string
{
    $pos = strpos($url, '?');
    return ($pos !== false) ? substr($url, $pos + 1) : '';
}

/**
 * Resolve the hostname of a URL to an IPv4/IPv6 address.
 * Returns the IP string, or null on failure.
 */
function resolve_ip(string $url): ?string
{
    $host = parse_url($url, PHP_URL_HOST);
    if (!$host) {
        return null;
    }
    $host = trim($host, '[]');                          // strip IPv6 brackets
    if (filter_var($host, FILTER_VALIDATE_IP)) {
        return $host;                                   // already a bare IP literal
    }
    $ip = gethostbyname($host);
    return ($ip !== $host) ? $ip : null;                // gethostbyname returns host on failure
}

/**
 * Return true when the URL replies with an HTTP 2xx or 3xx status code.
 */
function is_url_online(string $url): bool
{
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_NOBODY         => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT        => 8,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT      => 'QuokkaMeento/1.0',
    ]);
    curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ($code >= 200 && $code < 400);
}

/**
 * Write the IP sentinel file used for deduplication.
 *
 * file_create_exclusive() uses fopen('x') which maps to O_CREAT|O_EXCL and
 * is atomic at the OS level. If N concurrent requests resolve the same IP,
 * exactly one wins and gets the file handle; the rest get false immediately.
 *
 * Returns the file path on success (new IP entry).
 * Returns null when the IP was already known (duplicate) or on error.
 */
function save_server_ip(string $ip): ?string
{
    $filename = hash('sha256', $ip . IP_SALT) . '.txt';
    $path     = SERVER_IP_DIR . '/' . $filename;
    return file_create_exclusive($path, $ip) ? $path : null;
}

/**
 * Persist the query-string parameters of a URL into two JSON side-car files.
 *
 * Both files are updated via json_update_locked(), which holds LOCK_EX for
 * the full read-modify-write cycle, preventing concurrent overwrites.
 *
 *   url_hash/<sha256(base_url)>.json    keyed by URL identity
 *   server_ip_hash/<sha256(ip)>.json    keyed by resolved server IP
 *
 * @param string $clean_url  Base URL without query string
 * @param string $qs         Raw query string (part after '?')
 * @param string $ip         Resolved IP of the URL host
 */
function save_url_extras(string $clean_url, string $qs, string $ip): void
{
    if ($qs === '') {
        return;
    }
    parse_str($qs, $params);
    if (empty($params)) {
        return;
    }

    // url_hash/<sha256(base_url)>.json
    $url_json = URL_HASH_DIR . '/' . hash('sha256', $clean_url) . '.json';
    json_update_locked($url_json, function (array $existing) use ($params): array {
        return array_merge($existing, $params);
    });

    // server_ip_hash/<sha256(ip)>.json
    $ip_json = SRV_IP_HASH_DIR . '/' . hash('sha256', $ip) . '.json';
    json_update_locked($ip_json, function (array $existing) use ($params): array {
        return array_merge($existing, $params);
    });
}

/**
 * Build the credential query-string suffix appended to outgoing sync URLs.
 *
 * Each credential file is read with file_read_locked() so reads are
 * consistent even if another request is concurrently updating the file.
 *
 * Produces zero or more of: &user=... &public_key=... &btc=...
 */
function credential_suffix(): string
{
    $suffix     = '';
    $user       = read_credential(USER_TXT);
    $public_key = read_credential(PUBLIC_KEY_TXT);
    $btc        = read_credential(BTC_TXT);

    if ($user !== '')       $suffix .= '&user='       . urlencode($user);
    if ($public_key !== '') $suffix .= '&public_key=' . urlencode($public_key);
    if ($btc !== '')        $suffix .= '&btc='        . urlencode($btc);

    return $suffix;
}

// -----------------------------------------------------------------------------
// BUSINESS LOGIC
// -----------------------------------------------------------------------------

/**
 * Add a URL to files.txt with full race-condition protection.
 *
 * Race-condition guarantees:
 *
 *   Duplicate line prevention
 *     file_append_unique_locked() holds LOCK_EX across the entire
 *     read-check-write sequence. Two simultaneous requests for the same
 *     URL cannot both pass the duplicate check and both append.
 *
 *   IP deduplication (VERIFY_URL_ONLINE only)
 *     save_server_ip() uses fopen('x') = O_CREAT|O_EXCL, which is atomic
 *     at the filesystem level. Exactly one process creates the sentinel
 *     file; all others get false immediately without blocking.
 *
 *   JSON side-car updates (VERIFY_URL_ONLINE only)
 *     json_update_locked() holds LOCK_EX for the full read-modify-write
 *     cycle on each JSON file, preventing torn or interleaved updates.
 *
 * @param string $raw_url  Full URL as provided (may include a query string)
 * @return array           Result array suitable for json_response()
 */
function add_url_to_list(string $raw_url): array
{
    $raw_url   = trim($raw_url);
    $clean_url = base_url($raw_url);
    $qs        = query_string_of($raw_url);

    if ($clean_url === '') {
        return ['status' => 'error', 'message' => 'Empty URL.'];
    }

    if (VERIFY_URL_ONLINE) {
        // 1. Connectivity check.
        if (!is_url_online($raw_url)) {
            return ['status' => 'error', 'message' => 'URL is not reachable online.', 'url' => $clean_url];
        }

        // 2. IP resolution.
        $ip = resolve_ip($raw_url);
        if ($ip === null) {
            return ['status' => 'error', 'message' => 'Could not resolve IP for URL.', 'url' => $clean_url];
        }

        // 3. Atomic IP deduplication via O_CREAT|O_EXCL sentinel file.
        $sentinel = save_server_ip($ip);
        if ($sentinel === null) {
            return [
                'status'  => 'skipped',
                'message' => 'IP already known; URL not added.',
                'url'     => $clean_url,
                'ip'      => $ip,
            ];
        }

        // 4. Persist query-string extras to locked JSON side-cars.
        save_url_extras($clean_url, $qs, $ip);
    }

    // 5. Append the base URL (no query string) to files.txt.
    //    Lock is held for the full read-then-write to prevent duplicates.
    $added = file_append_unique_locked(FILES_TXT, $clean_url);
    if (!$added) {
        return ['status' => 'exists', 'message' => 'URL already in files.txt.', 'url' => $clean_url];
    }

    return ['status' => 'added', 'message' => 'URL added to files.txt.', 'url' => $clean_url];
}

/**
 * Add a server endpoint to servers.txt (unique lines only).
 * Uses file_append_unique_locked() for the same atomic guarantee.
 */
function add_server_to_list(string $server): array
{
    $server = trim($server);
    if ($server === '') {
        return ['status' => 'error', 'message' => 'Empty server address.'];
    }
    $added = file_append_unique_locked(SERVERS_TXT, $server);
    return $added
        ? ['status' => 'added',  'message' => 'Server added to servers.txt.', 'server' => $server]
        : ['status' => 'exists', 'message' => 'Server already in list.',      'server' => $server];
}

/**
 * Push every URL in files.txt to every server in servers.txt via HTTP GET.
 *
 * Both lists are read with file_read_locked() -> consistent snapshot even if
 * another request is simultaneously appending entries.
 *
 * Request format per (server, url) pair:
 *   <server>?action=receive&url=<encoded_url>[&user=...][&public_key=...][&btc=...]
 */
function sync_urls_to_servers(): array
{
    $urls    = read_lines(FILES_TXT);
    $servers = read_lines(SERVERS_TXT);
    $suffix  = credential_suffix();
    $results = [];

    foreach ($servers as $server) {
        $server = rtrim($server, '/');
        foreach ($urls as $url) {
            $endpoint = $server . '?action=receive&url=' . urlencode($url) . $suffix;

            $ch = curl_init($endpoint);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 10,
                CURLOPT_CONNECTTIMEOUT => 5,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_USERAGENT      => 'QuokkaMeento/1.0',
                CURLOPT_FOLLOWLOCATION => true,
            ]);
            $body = curl_exec($ch);
            $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $err  = curl_error($ch);
            curl_close($ch);

            $results[] = [
                'server'   => $server,
                'url'      => $url,
                'http'     => $code,
                'error'    => ($err !== '') ? $err : null,
                'response' => ($body !== false && $body !== '') ? substr($body, 0, 200) : null,
            ];
        }
    }

    return ['status' => 'sync_complete', 'results' => $results];
}

// -----------------------------------------------------------------------------
// ROUTER
// -----------------------------------------------------------------------------

$action = get_param('action') ?? 'info';

switch ($action) {

    // Return all known URLs
    case 'get_files':
        json_response(['status' => 'ok', 'files' => read_lines(FILES_TXT)]);

    // Return all known servers
    case 'get_servers':
        json_response(['status' => 'ok', 'servers' => read_lines(SERVERS_TXT)]);

    // Add a URL locally
    case 'add_url':
        $url = get_param('url');
        if ($url === null) {
            json_response(['error' => 'Missing required parameter: url'], 400);
        }
        json_response(add_url_to_list($url));

    // Add a server locally
    case 'add_server':
        $server = get_param('server');
        if ($server === null) {
            json_response(['error' => 'Missing required parameter: server'], 400);
        }
        json_response(add_server_to_list($server));

    // Receive a URL pushed from another Quokka Meento node
    case 'receive':
        $url = get_param('url');
        if ($url === null) {
            json_response(['error' => 'Missing required parameter: url'], 400);
        }
        $result = add_url_to_list($url);
        // Capture any credentials the peer attached, for informational logging.
        $creds = array_filter([
            'user'       => get_param('user'),
            'public_key' => get_param('public_key'),
            'btc'        => get_param('btc'),
        ], fn($v) => $v !== null && $v !== '');
        if (!empty($creds)) {
            $result['received_credentials'] = $creds;
        }
        json_response($result);

    // Receive a server pushed from another node
    case 'receive_server':
        $server = get_param('server');
        if ($server === null) {
            json_response(['error' => 'Missing required parameter: server'], 400);
        }
        json_response(add_server_to_list($server));

    // Sync: push all URLs to all servers
    case 'sync':
        json_response(sync_urls_to_servers());

    // Info / usage (default)
    default:
        json_response([
            'name'              => 'Quokka Meento',
            'version'           => '1.0.0',
            'verify_url_online' => VERIFY_URL_ONLINE,
            'max_input_length'  => MAX_INPUT_LENGTH,
            'actions'           => [
                'get_files'      => '?action=get_files',
                'get_servers'    => '?action=get_servers',
                'add_url'        => '?action=add_url&url=<url>',
                'add_server'     => '?action=add_server&server=<server>',
                'receive'        => '?action=receive&url=<url>[&user=..][&public_key=..][&btc=..]',
                'receive_server' => '?action=receive_server&server=<server>',
                'sync'           => '?action=sync',
            ],
        ]);
}