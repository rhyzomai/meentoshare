# Seal Meento

**Distributed File Tracker & Downloader**  
Single-file Java program — no external libraries required.

---

## Overview

Seal Meento reads a list of HTTP/HTTPS servers from `servers.txt`. Each server is expected to respond to a plain GET request at its root URL with a plain-text list of files it hosts. The program discovers all files across every server, ranks them by how many independent nodes carry them (same IP never counts twice), saves structured metadata as JSON, broadcasts the collected info back to all servers, and optionally downloads the files to disk.

---

## Requirements

- Java 11 or newer (`javac` / `java`)
- Network access to the servers listed in `servers.txt`
- No Maven, Gradle, or third-party JARs needed

---

## Quick Start

```bash
# 1. Compile
javac SealMeento.java

# 2. Create your server list
echo "https://example.com"   >  servers.txt
echo "http://another-node.net" >> servers.txt

# 3. Run
java SealMeento
```

---

## servers.txt Format

One server base URL per line. Rules:

- Must start with `http://` or `https://` — anything else is skipped with a warning.
- Trailing slashes are stripped automatically.
- Lines starting with `#` and blank lines are ignored.

```
# My nodes
https://node1.example.com
https://node2.example.com
http://192.168.1.50:8080
```

---

## Interactive Prompts

When launched, Seal Meento asks three yes/no questions before doing any network work:

| Prompt | What it controls |
|--------|-----------------|
| **Download files to disk?** | If `n`, the program only scans, ranks, and saves metadata — nothing is downloaded. |
| **Store files using SHA-256 hash + extension?** | If `y`, saved files are named `<sha256>.<ext>` (e.g. `a3f8…c2.jpg`). If `n`, the original filename is used. |
| **Overwrite files that already exist?** | If `n`, any file already present in `download/` is silently skipped. |

The second and third prompts only appear if you answered `y` to downloading.

---

## What Each Server Must Serve

A GET request to the server's root URL (`https://example.com`) must return a `200 OK` plain-text response. Each line is one file reference. Three formats are accepted:

| Line format | Interpreted as |
|-------------|---------------|
| `cat.jpg` | Plain filename → download URL becomes `https://example.com/download/cat.jpg` |
| `download/cat.jpg` | Relative path → download URL becomes `https://example.com/download/cat.jpg` |
| `https://example.com/download/cat.jpg` | Absolute URL → used exactly as given |

Lines longer than **2000 characters** are skipped.

---

## Block Metadata — `get_block/`

For any file whose SHA-256 hash is already known, Seal Meento tries to fetch additional metadata by sending a GET request to:

```
https://server.com/get_block/<sha256>
```

The server is expected to return a JSON object. Any of the following fields are read if present:

```json
{
  "sha256": "a3f8...c2",
  "size":   1048576
}
```

Missing fields are simply ignored. This enriches the local records before ranking and saving.

---

## Output Files

### `http_blocks/rank.json`

A JSON array of every discovered file, sorted from highest to lowest rank. Rank = number of **distinct IP addresses** that host the file (multiple server URLs resolving to the same IP count as one).

```json
[
  {
    "filename": "cat.jpg",
    "sha256":   "a3f8...c2",
    "size":     102400,
    "rank":     3,
    "servers": [
      "https://node1.example.com",
      "https://node2.example.com",
      "http://192.168.1.50:8080"
    ]
  },
  ...
]
```

### `http_blocks/<filename>.json`

One JSON file per discovered file, containing the same fields as above plus the full download URL for each server:

```json
{
  "filename": "cat.jpg",
  "sha256":   "a3f8...c2",
  "size":     102400,
  "rank":     3,
  "download_urls": {
    "https://node1.example.com": "https://node1.example.com/download/cat.jpg",
    "https://node2.example.com": "https://node2.example.com/download/cat.jpg"
  },
  "servers": [
    "https://node1.example.com",
    "https://node2.example.com"
  ]
}
```

### `download/`

Created only when the user chooses to download. Each file is saved here, named either by its original filename or by `<sha256>.<ext>` depending on the user's choice.

---

## Broadcast (GET only)

After ranking, Seal Meento notifies every server about every discovered file using a plain GET request. No server is started locally — Seal Meento is a sender only.

Endpoint format:

```
GET https://server.com/?action=block_info&filename=cat.jpg&sha256=a3f8...c2&size=102400&rank=3
```

Servers may ignore, log, or act on this information however they like. The response body is discarded.

---

## Ranking Logic

A file's rank is the number of **unique IP addresses** among all servers that host it.

- `node1.example.com` and `node2.example.com` both resolving to `203.0.113.5` → counted as **one** node.
- A server whose hostname cannot be resolved is counted by URL instead.
- Files are ranked highest-first in `rank.json` and downloaded in that order.

---

## Timeouts

| Setting | Value |
|---------|-------|
| Connection timeout | 8 seconds |
| Read timeout | 30 seconds |

---

## File Structure After a Run

```
.
├── SealMeento.java       ← source
├── SealMeento.class      ← compiled bytecode
├── servers.txt           ← your server list
├── download/             ← downloaded files (if chosen)
│   ├── cat.jpg
│   └── a3f8...c2.mp4
└── http_blocks/          ← always created
    ├── rank.json
    ├── cat.jpg.json
    └── video.mp4.json
```

---

## Notes

- Seal Meento never starts an HTTP or HTTPS server. It only sends GET requests.
- SHA-256 hashes are computed locally after download if not already provided by a server's `get_block/` endpoint.
- JSON is written using the standard library only — no Gson, Jackson, or similar.
- All network calls use `HttpURLConnection` from the Java standard library.

---

## PHP Server Node (`server.php`)

`server.php` is the server-side counterpart. It runs on each node and handles all incoming requests from Seal Meento Java clients and from browsers.

### Requirements

- PHP 7.4 or newer (CLI or web server)
- Write access to `downloads/` and `blocks/` directories (created automatically)

### Setup

Drop `server.php` into your web root. With Apache or Nginx it works as-is. For quick local testing:

```bash
php -S 0.0.0.0:8080 server.php
```

Add your binary files to the `downloads/` folder next to `server.php`.

### Endpoints

| Request | Response |
|---------|----------|
| `GET /` | Plain-text list of filenames in `downloads/` — **this is what Seal Meento Java reads** |
| `GET /?list=links` | Plain-text list of full download URLs, one per line |
| `GET /?action=block_info&filename=…&sha256=…&size=…&rank=…` | Receive a broadcast from a Seal Meento client; saves block metadata |
| `GET /download/<filename>` | Stream a file from `downloads/` |
| `GET /get_block/<sha256>` | Return the JSON block for a given 64-char SHA-256 hash |

### File Storage Layout

```
server.php
downloads/          ← binary files served to clients
blocks/
  <sha256>.json     ← one JSON block per known file
  block_log.json    ← newline-delimited log of every broadcast received
```

### Block JSON Schema

Each `blocks/<sha256>.json` file looks like:

```json
{
  "filename":   "cat.jpg",
  "sha256":     "a3f8...c2",
  "size":       102400,
  "rank":       3,
  "first_seen": "2025-01-01T12:00:00+00:00",
  "last_seen":  "2025-01-02T08:30:00+00:00",
  "senders":    ["203.0.113.5", "198.51.100.9"]
}
```

Multiple broadcasts for the same file are **merged**: rank keeps the highest value seen, `senders` accumulates unique IPs, and timestamps are preserved.

### Remote Verification (Optional)

By default `CHECK_REMOTE_BEFORE_WRITE` is `false` — the server trusts what clients broadcast and writes immediately.

Set it to `true` at the top of `server.php` to enable verification:

```php
define('CHECK_REMOTE_BEFORE_WRITE', true);
```

When enabled, before saving any block info the server performs HTTP HEAD requests to every previously-seen sender IP, checking either `/download/<filename>` or `/get_block/<sha256>`. The block is only saved if at least one remote server confirms the file exists. Both `http://` and `https://` are tried; TLS certificate errors are ignored for local/private networks.

### Security Notes

- Filenames are sanitised with `basename()` and stripped of control characters — directory traversal is not possible.
- The `downloads/` directory is never written to by the server; only files you place there manually are served.
- Only GET requests are used throughout; no POST, PUT, or DELETE handlers exist.

---

## Seal Meento PHP (`seal_meento.php`)

A single-file PHP program that acts as both **sender** (broadcasts entries to remote nodes) and **receiver** (stores incoming blocks from other nodes).

### Requirements

- PHP 7.4 or newer
- No cURL or external libraries — uses `file_get_contents` with stream contexts
- Write access to `seal/` and `seal/ip_check/` (created automatically)

### Setup

Drop `seal_meento.php` into your web root alongside `servers.txt`, `files.json`, and/or `files.txt`.

```bash
# Quick local test
php -S 0.0.0.0:8080 seal_meento.php

# Or run from CLI
php seal_meento.php send_json
```

### Configuration (top of file)

| Constant | Default | Purpose |
|----------|---------|---------|
| `USE_TXT_SOURCE` | `false` | `true` = use `files.txt`, `false` = use `files.json` |
| `IP_SALT` | `'SealMeentoPHP_s3cr3t!'` | Secret salt for IP rate-limit hashing — **change this** |
| `MAX_JSON_BYTES` | `5000` | Maximum byte size of a stored block JSON |
| `CONNECT_TIMEOUT` | `8` | Outbound HTTP request timeout in seconds |

### Endpoints

| URL / CLI action | Description |
|-----------------|-------------|
| `?action=send_json` | Read `files.json` and broadcast every entry to all servers |
| `?action=send_txt` | Read `files.txt` and broadcast every line to all servers |
| `?action=register&url=…[&fields…]` | **Receiver** — store an incoming block in `seal/` |
| `?action=list_plain` | Plain-text list of all registered URLs (one per line) |
| `?action=list_links` | HTML table with links and metadata |
| *(no action)* | Help/status page |

### Input Formats

**files.json** — an array of objects. Only `url` is required; all other fields are optional:

```json
[
  {
    "url":         "https://example.com/file.zip",
    "user":        "alice",
    "filename":    "file.zip",
    "filehash":    "a3f8...c2",
    "filesize":    "102400",
    "date":        "2025-01-01",
    "public_key":  "...",
    "server":      "https://example.com",
    "description": "My archive",
    "signature":   "...",
    "custom_field":"anything extra"
  }
]
```

**files.txt** — one URL per line. Optional metadata is appended as query-string parameters on the same line:

```
https://example.com/file.zip
https://example.com/photo.jpg?user=bob&description=Holiday+photo
https://example.com/data.csv?filehash=a3f8c2&filesize=4096
```

### Receiver — `?action=register`

Any node (including remote Seal Meento instances) can register a file by making a GET request:

```
GET /seal_meento.php?action=register
  &url=https://example.com/file.zip
  &user=alice
  &filename=file.zip
  &filehash=<sha256 or other hash>
  &filesize=102400
  &date=2025-01-01
  &public_key=<ed25519 or similar>
  &server=https://example.com
  &description=My+file
  &signature=<detached signature>
  &<any_extra_field>=<value>
```

All fields except `url` are optional. Any unrecognised GET parameters are stored as-is in the JSON block.

The block is written to `seal/<hash>.json` using `fopen` in exclusive-create mode (`'x'`) — if the file already exists it is never overwritten.

### Block JSON Schema

```json
{
  "url":          "https://example.com/file.zip",
  "filename":     "file.zip",
  "user":         "alice",
  "filehash":     "a3f8...c2",
  "filesize":     "102400",
  "date":         "2025-01-01",
  "description":  "My archive",
  "received_at":  "2025-01-01T12:00:00+00:00",
  "sender_ip":    "203.0.113.5"
}
```

The block filename is `<filehash>.json` when a valid hex hash is supplied, otherwise `sha256(url).json`.

### Rate Limiting

Only **one block submission per IP per minute** is accepted.

The check works by writing a zero-byte sentinel file at:

```
seal/ip_check/<sha256(SALT + IP + YYYYMMDDHHii)>.chk
```

If that file already exists the request returns HTTP 429 and nothing is written. The timestamp component includes minutes (`HHii`), so the slot resets every new minute. The IP itself is never stored in plaintext — only its salted hash appears in the filename.

### Security Notes

- All field values are stripped of ASCII control characters and capped at 1 000 characters each.
- The total encoded JSON must be ≤ 5 000 bytes or the write is rejected with HTTP 413.
- `fopen(..., 'x')` is used for all block writes — this is an atomic exclusive-create that prevents overwriting existing blocks even under concurrent requests.
- `seal/ip_check/` accumulates one small file per unique IP per minute. You may want a cron job to purge files older than a day.
