﻿<?php
/**
 * ╔══════════════════════════════════════════════════════╗
 * ║          S E A L   M E E N T O   P H P              ║
 * ║   Distributed File Registry — Sender & Receiver     ║
 * ╚══════════════════════════════════════════════════════╝
 *
 * DUAL ROLE
 * ─────────
 *  • Sender  : reads files.json (or files.txt) and broadcasts
 *              each entry to every server in servers.txt via GET.
 *  • Receiver: accepts incoming GET requests and persists the
 *              data as JSON inside the "seal/" folder.
 *
 * SENDER ENDPOINTS  (invoked from CLI or browser with ?action=send_*)
 * ────────────────
 *  ?action=send_json          → broadcast every entry in files.json
 *  ?action=send_txt           → broadcast every line  in files.txt
 *
 * RECEIVER ENDPOINT  (called by remote nodes)
 * ─────────────────
 *  ?action=register&url=…[&user=…&filename=…&filehash=…
 *                           &filesize=…&date=…&public_key=…
 *                           &server=…&description=…&signature=…
 *                           &<extra>=…]
 *
 * LISTING ENDPOINTS
 * ─────────────────
 *  ?action=list_plain         → plain-text URL list (one per line)
 *  ?action=list_links         → HTML page with clickable links
 *  (no action / unknown)      → show this help page
 *
 * CONFIGURATION  (edit the block below)
 * ─────────────
 *  USE_TXT_SOURCE             → true  = read files.txt  as source
 *                               false = read files.json as source
 *  IP_SALT                    → secret string mixed into IP-rate-limit hash
 *  CONNECT_TIMEOUT            → seconds per outbound HTTP request
 *  MAX_JSON_BYTES             → maximum byte size of a saved block (5000)
 */

// ═══════════════════════════════════════════════════════════════════
//  CONFIGURATION  —  edit here
// ═══════════════════════════════════════════════════════════════════

define('USE_TXT_SOURCE',   false);                   // true → files.txt, false → files.json
define('IP_SALT',          'SealMeentoPHP_s3cr3t!'); // change to something private
define('SEAL_DIR',         __DIR__ . '/seal');
define('IP_CHECK_DIR',     __DIR__ . '/seal/ip_check');
define('SERVERS_FILE',     __DIR__ . '/servers.txt');
define('FILES_JSON',       __DIR__ . '/files.json');
define('FILES_TXT',        __DIR__ . '/files.txt');
define('MAX_JSON_BYTES',   5000);
define('CONNECT_TIMEOUT',  8);

// ═══════════════════════════════════════════════════════════════════
//  BOOTSTRAP
// ═══════════════════════════════════════════════════════════════════

@mkdir(SEAL_DIR,     0755, true);
@mkdir(IP_CHECK_DIR, 0755, true);

// ── Detect execution context ──────────────────────────────────────
$isCli = (PHP_SAPI === 'cli');

// ── Parse action ──────────────────────────────────────────────────
$action = trim($_GET['action'] ?? ($argv[1] ?? ''));

// ═══════════════════════════════════════════════════════════════════
//  ROUTER
// ═══════════════════════════════════════════════════════════════════

switch ($action) {

    // ── Outbound: broadcast files.json ────────────────────────────
    case 'send_json':
        respondText();
        actionSendJson();
        break;

    // ── Outbound: broadcast files.txt ─────────────────────────────
    case 'send_txt':
        respondText();
        actionSendTxt();
        break;

    // ── Inbound: receive and store a block ────────────────────────
    case 'register':
        respondText();
        actionRegister();
        break;

    // ── Listing: plain-text URLs ──────────────────────────────────
    case 'list_plain':
        respondText();
        actionListPlain();
        break;

    // ── Listing: HTML links ───────────────────────────────────────
    case 'list_links':
        actionListLinks();
        break;

    // ── Default: help page ────────────────────────────────────────
    default:
        actionHelp();
        break;
}
exit;


// ═══════════════════════════════════════════════════════════════════
//  ACTION: SEND  files.json
// ═══════════════════════════════════════════════════════════════════

function actionSendJson(): void
{
    $srcFile = FILES_JSON;
    if (!is_file($srcFile)) {
        out("ERROR: " . $srcFile . " not found.\n");
        return;
    }

    $raw = file_get_contents($srcFile);
    $entries = json_decode($raw, true);
    if (!is_array($entries)) {
        out("ERROR: files.json is not a valid JSON array.\n");
        return;
    }

    $servers = loadServers();
    if (empty($servers)) {
        out("ERROR: no valid servers in servers.txt.\n");
        return;
    }

    out("Sending " . count($entries) . " entries to " . count($servers) . " server(s)...\n\n");

    foreach ($entries as $idx => $entry) {
        if (!is_array($entry)) {
            out("  [SKIP] Entry #$idx is not an object.\n");
            continue;
        }
        // url is the only mandatory field
        $url = trim((string)($entry['url'] ?? ''));
        if ($url === '') {
            out("  [SKIP] Entry #$idx has no 'url'.\n");
            continue;
        }

        $params = buildParams($entry);
        broadcastToServers($servers, $params, "Entry #$idx ({$url})");
    }

    out("\nDone.\n");
}


// ═══════════════════════════════════════════════════════════════════
//  ACTION: SEND  files.txt
// ═══════════════════════════════════════════════════════════════════

function actionSendTxt(): void
{
    $srcFile = FILES_TXT;
    if (!is_file($srcFile)) {
        out("ERROR: " . $srcFile . " not found.\n");
        return;
    }

    $servers = loadServers();
    if (empty($servers)) {
        out("ERROR: no valid servers in servers.txt.\n");
        return;
    }

    $lines = file($srcFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    out("Sending " . count($lines) . " lines to " . count($servers) . " server(s)...\n\n");

    foreach ($lines as $i => $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#') continue;

        // Each line IS the url; pass it straight through.
        // Extra GET params can be appended by the user in the line itself,
        // e.g.:  https://example.com/file.zip?user=alice&description=cool
        // We parse those out and merge into our standard param set.
        $params = parseTxtLine($line);

        if (($params['url'] ?? '') === '') {
            out("  [SKIP] Line " . ($i + 1) . ": no usable URL.\n");
            continue;
        }

        broadcastToServers($servers, $params, "Line " . ($i + 1) . " ({$params['url']})");
    }

    out("\nDone.\n");
}


// ═══════════════════════════════════════════════════════════════════
//  ACTION: REGISTER  (receiver)
// ═══════════════════════════════════════════════════════════════════

function actionRegister(): void
{
    // ── 1. Rate-limit by IP (one write per minute per IP) ──────────
    $ip     = senderIp();
    $ipFile = ipCheckPath($ip);

    if (file_exists($ipFile)) {
        http_response_code(429);
        out("RATE_LIMIT: only one submission per minute per IP.\n");
        return;
    }

    // ── 2. Collect and validate fields ────────────────────────────
    $url = trim($_GET['url'] ?? '');
    if ($url === '') {
        http_response_code(400);
        out("ERROR: 'url' is required.\n");
        return;
    }

    // Known standard fields (all optional except url)
    $knownFields = [
        'url', 'user', 'filename', 'filehash', 'filesize',
        'date', 'public_key', 'server', 'description', 'signature',
    ];

    $block = [];
    foreach ($knownFields as $field) {
        $val = $_GET[$field] ?? null;
        if ($val !== null && $val !== '') {
            $block[$field] = sanitiseValue((string)$val);
        }
    }

    // Absorb any extra GET params not in the known list
    foreach ($_GET as $key => $val) {
        $key = preg_replace('/[^a-zA-Z0-9_]/', '', $key);
        if ($key === '' || $key === 'action') continue;
        if (!array_key_exists($key, $block)) {
            $block[$key] = sanitiseValue((string)$val);
        }
    }

    // Always record meta fields
    $block['received_at'] = date('c');
    $block['sender_ip']   = $ip;

    // ── 3. Check JSON size before writing ─────────────────────────
    $json = json_encode($block, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if (strlen($json) > MAX_JSON_BYTES) {
        http_response_code(413);
        out("ERROR: payload exceeds " . MAX_JSON_BYTES . " bytes after encoding.\n");
        return;
    }

    // ── 4. Derive filename from filehash or url hash ───────────────
    $fileKey  = !empty($block['filehash']) && preg_match('/^[a-f0-9]{40,128}$/i', $block['filehash'])
                ? strtolower($block['filehash'])
                : hash('sha256', $block['url']);
    $sealPath = SEAL_DIR . '/' . $fileKey . '.json';

    // ── 5. Do not overwrite existing blocks ───────────────────────
    if (file_exists($sealPath)) {
        out("SKIP: block already exists (" . $fileKey . ".json).\n");
        // Still record the IP so the rate limit applies
        touchIpCheck($ipFile);
        return;
    }

    // ── 6. Write with fopen / fwrite ──────────────────────────────
    $fh = fopen($sealPath, 'x');   // 'x' = create only; fail if exists (race-safe)
    if ($fh === false) {
        // Another request may have just created it
        out("SKIP: block already exists (concurrent write).\n");
        touchIpCheck($ipFile);
        return;
    }

    fwrite($fh, $json . "\n");
    fclose($fh);

    // ── 7. Record IP check (rate limit) ───────────────────────────
    touchIpCheck($ipFile);

    out("OK: saved " . $fileKey . ".json\n");
}


// ═══════════════════════════════════════════════════════════════════
//  ACTION: LIST PLAIN
// ═══════════════════════════════════════════════════════════════════

function actionListPlain(): void
{
    $base  = baseUrl();
    foreach (sealEntries() as $entry) {
        $url = $entry['url'] ?? '';
        if ($url !== '') out($url . "\n");
    }
}


// ═══════════════════════════════════════════════════════════════════
//  ACTION: LIST LINKS  (HTML)
// ═══════════════════════════════════════════════════════════════════

function actionListLinks(): void
{
    header('Content-Type: text/html; charset=utf-8');
    $entries = sealEntries();
    $base    = baseUrl();
    $self    = htmlspecialchars($base . ($_SERVER['SCRIPT_NAME'] ?? '/seal_meento.php'));

    echo '<!DOCTYPE html><html lang="en"><head>';
    echo '<meta charset="utf-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>Seal Meento PHP — File Registry</title>';
    echo '<style>';
    echo 'body{font-family:monospace;background:#0d1117;color:#c9d1d9;margin:0;padding:2rem;}';
    echo 'h1{color:#58a6ff;border-bottom:1px solid #30363d;padding-bottom:.5rem;}';
    echo 'table{border-collapse:collapse;width:100%;font-size:.85rem;}';
    echo 'th{background:#161b22;color:#8b949e;text-align:left;padding:.4rem .8rem;border-bottom:1px solid #30363d;}';
    echo 'td{padding:.35rem .8rem;border-bottom:1px solid #21262d;vertical-align:top;word-break:break-all;}';
    echo 'tr:hover td{background:#161b22;}';
    echo 'a{color:#58a6ff;}';
    echo '.badge{background:#21262d;border-radius:4px;padding:1px 6px;font-size:.75rem;}';
    echo '.nav{margin-bottom:1.5rem;}';
    echo '.nav a{margin-right:1rem;color:#8b949e;text-decoration:none;border:1px solid #30363d;padding:.2rem .6rem;border-radius:4px;}';
    echo '.nav a:hover{color:#c9d1d9;border-color:#8b949e;}';
    echo '</style></head><body>';

    echo '<h1>&#x1F9F2; Seal Meento PHP — File Registry</h1>';

    echo '<div class="nav">';
    echo '<a href="' . $self . '">Help</a>';
    echo '<a href="' . $self . '?action=list_plain">Plain Text</a>';
    echo '<a href="' . $self . '?action=list_links">Links (this page)</a>';
    echo '<a href="' . $self . '?action=send_json">Send JSON</a>';
    echo '<a href="' . $self . '?action=send_txt">Send TXT</a>';
    echo '</div>';

    if (empty($entries)) {
        echo '<p>No entries yet.</p>';
    } else {
        echo '<p><span class="badge">' . count($entries) . ' entries</span></p>';
        echo '<table>';
        echo '<tr><th>#</th><th>URL</th><th>Filename</th><th>User</th><th>Hash</th><th>Size</th><th>Date</th><th>Description</th></tr>';
        foreach ($entries as $i => $e) {
            $url  = htmlspecialchars($e['url']         ?? '');
            $fn   = htmlspecialchars($e['filename']    ?? '');
            $user = htmlspecialchars($e['user']        ?? '');
            $hash = htmlspecialchars(substr($e['filehash'] ?? '', 0, 12));
            $size = htmlspecialchars($e['filesize']    ?? '');
            $date = htmlspecialchars($e['date']        ?? ($e['received_at'] ?? ''));
            $desc = htmlspecialchars(mb_strimwidth($e['description'] ?? '', 0, 80, '…'));
            echo '<tr>';
            echo '<td>' . ($i + 1) . '</td>';
            echo '<td><a href="' . $url . '" target="_blank" rel="noopener">' . ($fn ?: $url) . '</a></td>';
            echo '<td>' . $fn . '</td>';
            echo '<td>' . $user . '</td>';
            echo '<td>' . ($hash ? '<span class="badge">' . $hash . '…</span>' : '') . '</td>';
            echo '<td>' . $size . '</td>';
            echo '<td>' . $date . '</td>';
            echo '<td>' . $desc . '</td>';
            echo '</tr>';
        }
        echo '</table>';
    }

    echo '<p style="margin-top:2rem;color:#484f58;font-size:.75rem;">Seal Meento PHP &mdash; ' . htmlspecialchars($base) . '</p>';
    echo '</body></html>';
}


// ═══════════════════════════════════════════════════════════════════
//  ACTION: HELP
// ═══════════════════════════════════════════════════════════════════

function actionHelp(): void
{
    $isCli = (PHP_SAPI === 'cli');
    if ($isCli) {
        out("Seal Meento PHP\n");
        out("Usage: php seal_meento.php <action>\n\n");
        out("Actions:\n");
        out("  send_json    Broadcast files.json to all servers in servers.txt\n");
        out("  send_txt     Broadcast files.txt  to all servers in servers.txt\n");
        out("  list_plain   Print plain-text list of registered URLs\n");
        out("  list_links   (web only) Show HTML link listing\n");
        out("  register     (receiver) Called by remote nodes via GET\n");
        return;
    }

    header('Content-Type: text/html; charset=utf-8');
    $base = baseUrl();
    $self = htmlspecialchars($base . ($_SERVER['SCRIPT_NAME'] ?? '/seal_meento.php'));

    echo '<!DOCTYPE html><html lang="en"><head>';
    echo '<meta charset="utf-8">';
    echo '<title>Seal Meento PHP</title>';
    echo '<style>';
    echo 'body{font-family:monospace;background:#0d1117;color:#c9d1d9;margin:0;padding:2rem;max-width:800px;}';
    echo 'h1{color:#58a6ff;}h2{color:#8b949e;margin-top:2rem;}';
    echo 'code{background:#161b22;padding:2px 6px;border-radius:4px;color:#79c0ff;}';
    echo 'pre{background:#161b22;padding:1rem;border-radius:6px;overflow-x:auto;color:#e6edf3;}';
    echo 'a{color:#58a6ff;}';
    echo '.ep{margin:.4rem 0;}';
    echo '</style></head><body>';
    echo '<h1>&#x1F9F2; Seal Meento PHP</h1>';
    echo '<p>Distributed File Registry — Sender &amp; Receiver</p>';

    echo '<h2>Sender Endpoints</h2>';
    echo '<div class="ep"><a href="' . $self . '?action=send_json"><code>?action=send_json</code></a> — broadcast <code>files.json</code> to all servers</div>';
    echo '<div class="ep"><a href="' . $self . '?action=send_txt"><code>?action=send_txt</code></a>  — broadcast <code>files.txt</code>  to all servers</div>';

    echo '<h2>Receiver Endpoint</h2>';
    echo '<pre>GET ?action=register&amp;url=https://example.com/file.zip
         [&amp;user=alice]
         [&amp;filename=file.zip]
         [&amp;filehash=sha256hex]
         [&amp;filesize=102400]
         [&amp;date=2025-01-01]
         [&amp;public_key=...]
         [&amp;server=https://node.example.com]
         [&amp;description=My+file]
         [&amp;signature=...]
         [&amp;&lt;custom_field&gt;=...]</pre>';

    echo '<h2>Listing Endpoints</h2>';
    echo '<div class="ep"><a href="' . $self . '?action=list_plain"><code>?action=list_plain</code></a> — plain-text URL list</div>';
    echo '<div class="ep"><a href="' . $self . '?action=list_links"><code>?action=list_links</code></a>  — HTML link table</div>';

    echo '<h2>Configuration</h2>';
    echo '<pre>';
    echo 'USE_TXT_SOURCE  : ' . (USE_TXT_SOURCE ? 'true (files.txt)' : 'false (files.json)') . "\n";
    echo 'MAX_JSON_BYTES  : ' . MAX_JSON_BYTES . "\n";
    echo 'CONNECT_TIMEOUT : ' . CONNECT_TIMEOUT . "s\n";
    echo 'SEAL_DIR        : ' . SEAL_DIR . "\n";
    echo 'IP_CHECK_DIR    : ' . IP_CHECK_DIR . "\n";
    echo '</pre>';

    echo '</body></html>';
}


// ═══════════════════════════════════════════════════════════════════
//  BROADCAST HELPER
// ═══════════════════════════════════════════════════════════════════

/**
 * Send params to every server as ?action=register&<params>.
 */
function broadcastToServers(array $servers, array $params, string $label): void
{
    $query = http_build_query(array_merge(['action' => 'register'], $params));

    foreach ($servers as $srv) {
        $targetUrl = rtrim($srv, '/') . '/?' . $query;
        // Enforce URL total length sanity
        if (strlen($targetUrl) > 8000) {
            out("  [SKIP-LEN] $label → $srv (URL too long)\n");
            continue;
        }

        $result = httpGet($targetUrl);
        $status = $result['status'];
        $body   = trim($result['body']);
        out("  [$status] $label → $srv : $body\n");
    }
}


// ═══════════════════════════════════════════════════════════════════
//  PARAM BUILDERS
// ═══════════════════════════════════════════════════════════════════

/**
 * Build the GET param array from a JSON entry (files.json).
 * All fields are optional except 'url'.
 */
function buildParams(array $entry): array
{
    $allowed = [
        'url', 'user', 'filename', 'filehash', 'filesize',
        'date', 'public_key', 'server', 'description', 'signature',
    ];

    $params = [];
    // Standard fields
    foreach ($allowed as $field) {
        if (isset($entry[$field]) && $entry[$field] !== '') {
            $params[$field] = (string)$entry[$field];
        }
    }
    // Extra fields (anything else in the JSON object)
    foreach ($entry as $key => $val) {
        $key = preg_replace('/[^a-zA-Z0-9_]/', '', $key);
        if ($key === '' || array_key_exists($key, $params)) continue;
        $params[$key] = (string)$val;
    }
    return $params;
}

/**
 * Parse a files.txt line into a params array.
 *
 * A line can be:
 *   https://example.com/file.zip
 *   https://example.com/file.zip?user=alice&description=cool
 *
 * Any query-string params already in the URL are extracted and used
 * as optional metadata; the bare URL (without query string) becomes 'url'.
 */
function parseTxtLine(string $line): array
{
    $line  = trim($line);
    $parts = explode('?', $line, 2);
    $bare  = $parts[0];

    if (!preg_match('#^https?://#i', $bare)) return [];

    $params = ['url' => $bare];
    if (isset($parts[1])) {
        parse_str($parts[1], $extra);
        $allowed = [
            'user', 'filename', 'filehash', 'filesize',
            'date', 'public_key', 'server', 'description', 'signature',
        ];
        foreach ($extra as $key => $val) {
            $key = preg_replace('/[^a-zA-Z0-9_]/', '', $key);
            if ($key === '') continue;
            $params[$key] = (string)$val;
        }
    }
    return $params;
}


// ═══════════════════════════════════════════════════════════════════
//  IP RATE-LIMIT HELPERS
// ═══════════════════════════════════════════════════════════════════

/**
 * Build the path to the IP check file for the current minute.
 * Format: ip_check/<hash(salt + IP + YYYY + MM + DD + HHii)>.chk
 * One file per IP per minute → one allowed write per minute per IP.
 */
function ipCheckPath(string $ip): string
{
    $stamp = date('YmdHi');   // Year + Month + Day + Hour + Minute
    $hash  = hash('sha256', IP_SALT . $ip . $stamp);
    return IP_CHECK_DIR . '/' . $hash . '.chk';
}

/** Write a zero-byte sentinel file to record that this IP used its slot. */
function touchIpCheck(string $path): void
{
    $fh = @fopen($path, 'w');
    if ($fh) fclose($fh);
}

/** Determine sender IP, preferring forwarded headers in trusted proxies. */
function senderIp(): string
{
    // Accept X-Forwarded-For only as informational; always fall back to REMOTE_ADDR
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}


// ═══════════════════════════════════════════════════════════════════
//  SEAL ENTRY READER
// ═══════════════════════════════════════════════════════════════════

/**
 * Return all decoded JSON blocks from seal/*.json, sorted by received_at desc.
 */
function sealEntries(): array
{
    $entries = [];
    foreach (glob(SEAL_DIR . '/*.json') as $file) {
        $data = @json_decode(file_get_contents($file), true);
        if (is_array($data)) $entries[] = $data;
    }
    usort($entries, fn($a, $b) =>
        strcmp($b['received_at'] ?? '', $a['received_at'] ?? '')
    );
    return $entries;
}


// ═══════════════════════════════════════════════════════════════════
//  SERVERS LOADER
// ═══════════════════════════════════════════════════════════════════

function loadServers(): array
{
    if (!is_file(SERVERS_FILE)) return [];
    $servers = [];
    foreach (file(SERVERS_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#') continue;
        if (!preg_match('#^https?://#i', $line)) continue;
        $servers[] = rtrim($line, '/');
    }
    return $servers;
}


// ═══════════════════════════════════════════════════════════════════
//  HTTP CLIENT  (stream-based, no cURL required)
// ═══════════════════════════════════════════════════════════════════

function httpGet(string $url): array
{
    $ctx = stream_context_create([
        'http' => [
            'method'          => 'GET',
            'timeout'         => CONNECT_TIMEOUT,
            'ignore_errors'   => true,
            'follow_location' => 1,
            'max_redirects'   => 3,
            'header'          => "User-Agent: SealMeentoPHP/1.0\r\n",
        ],
        'ssl'  => [
            'verify_peer'      => false,
            'verify_peer_name' => false,
        ],
    ]);

    $body    = @file_get_contents($url, false, $ctx);
    $body    = ($body === false) ? '' : $body;
    $status  = 0;

    if (!empty($http_response_header)) {
        if (preg_match('/HTTP\/\S+\s+(\d{3})/', $http_response_header[0], $m)) {
            $status = (int)$m[1];
        }
    }

    return ['status' => $status, 'body' => $body];
}


// ═══════════════════════════════════════════════════════════════════
//  UTILITY
// ═══════════════════════════════════════════════════════════════════

/** Strip control characters; keep printable UTF-8. */
function sanitiseValue(string $v): string
{
    $v = preg_replace('/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/u', '', $v);
    return mb_substr($v, 0, 1000);   // hard cap per field
}

function baseUrl(): string
{
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? ($_SERVER['SERVER_NAME'] ?? 'localhost');
    return $scheme . '://' . $host;
}

/** Output to browser (text/plain already set) or stdout. */
function out(string $msg): void
{
    echo $msg;
    if (PHP_SAPI !== 'cli') ob_flush();
    flush();
}

/** Set text/plain header (safe to call before any output). */
function respondText(): void
{
    if (PHP_SAPI !== 'cli') {
        header('Content-Type: text/plain; charset=utf-8');
    }
}