﻿<?php
// ─── Output buffer: prevents PHP warnings from corrupting JSON responses ──────
ob_start();

// ─── Configuration ────────────────────────────────────────────────────────────
define('UPLOAD_DIR',  __DIR__ . '/download/');
define('JSON_BASE',   __DIR__ . '/files');       // files.json, files_2.json, …
define('JSON_EXT',    '.json');
define('JSON_MAX',    512 * 1024);               // 500 KB per shard
define('MAX_SIZE',    1 * 1024 * 1024 * 1024);  // 1 GB max upload
define('FORBIDDEN',   ['php','phtml','php3','php4','php5','php7','phps','phar']);

// ─── JSON shard helpers ───────────────────────────────────────────────────────

/** Filesystem path for shard N.  1 → files.json, 2 → files_2.json, … */
function shard_path(int $n): string {
    return JSON_BASE . ($n === 1 ? '' : '_' . $n) . JSON_EXT;
}

/** Web-accessible filename for shard N (relative, for fetch() in JS). */
function shard_name(int $n): string {
    return 'files' . ($n === 1 ? '' : '_' . $n) . '.json';
}

/** Highest existing shard number (returns 1 even if nothing exists yet). */
function last_shard(): int {
    $n = 1;
    while (file_exists(shard_path($n + 1))) $n++;
    return $n;
}

/** Read one shard with a shared lock. Returns [] on missing / empty / invalid. */
function read_shard(int $n): array {
    $path = shard_path($n);
    if (!file_exists($path)) return [];
    $fh = fopen($path, 'r');
    if (!$fh) return [];
    flock($fh, LOCK_SH);
    $content = stream_get_contents($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
    if (!trim($content)) return [];
    $data = json_decode($content, true);
    return is_array($data) ? $data : [];
}

/** Write $entries to shard $n with an exclusive lock. */
function write_shard(int $n, array $entries): void {
    $fh = fopen(shard_path($n), 'c+');
    if (!$fh) return;
    flock($fh, LOCK_EX);
    ftruncate($fh, 0);
    rewind($fh);
    fwrite($fh, json_encode(array_values($entries),
        JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    fflush($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
}

/**
 * Append one entry to the right shard.
 * Starts a new shard whenever the current last one is at/over JSON_MAX bytes.
 * Returns the shard number where the entry was written.
 */
function append_entry(array $entry): int {
    $n    = last_shard();
    $path = shard_path($n);
    if (file_exists($path) && filesize($path) >= JSON_MAX) {
        $n++;
    }
    $entries   = read_shard($n);
    $entries[] = $entry;
    write_shard($n, $entries);
    return $n;
}

/**
 * Recursively scan UPLOAD_DIR, rename files to <sha256>.<ext>,
 * then distribute all entries across shards respecting JSON_MAX.
 */
function scan_and_rebuild(): void {
    ensure_dir();
    $all  = [];
    $iter = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator(UPLOAD_DIR, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($iter as $fi) {
        if (!$fi->isFile()) continue;
        $abs      = $fi->getPathname();
        $dir      = $fi->getPath() . DIRECTORY_SEPARATOR;
        $ext      = strtolower($fi->getExtension());
        $hash     = hash_file('sha256', $abs);
        $hashName = $ext !== '' ? "{$hash}.{$ext}" : $hash;
        $hashAbs  = $dir . $hashName;
        if ($fi->getFilename() !== $hashName) {
            if (!file_exists($hashAbs)) rename($abs, $hashAbs);
            else                        unlink($abs);
            $abs = $hashAbs;
        }
        $abs_norm  = str_replace('\\', '/', $abs);
        $base_norm = str_replace('\\', '/', UPLOAD_DIR);
        $relative  = ltrim(substr($abs_norm, strlen($base_norm)), '/');
        $all[] = [
            'original_name' => basename($relative),
            'filename'      => $relative,
            'date'          => date('Y-m-d H:i:s', filemtime($abs)),
            'filesize'      => filesize($abs),
            'filehash'      => $hash,
        ];
    }

    // Distribute into size-capped shards
    $shardNum  = 1;
    $shard     = [];
    $shardSize = 0;
    foreach ($all as $entry) {
        $sz = strlen(json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) + 4;
        if (!empty($shard) && ($shardSize + $sz) >= JSON_MAX) {
            write_shard($shardNum, $shard);
            $shardNum++;
            $shard     = [];
            $shardSize = 0;
        }
        $shard[]    = $entry;
        $shardSize += $sz;
    }
    write_shard($shardNum, $shard); // flush last (or only) shard

    // Remove stale shards left over from a previous larger index
    for ($k = $shardNum + 1; file_exists(shard_path($k)); $k++) {
        unlink(shard_path($k));
    }
}

/** Ensure shard 1 exists (triggers rebuild if missing/empty). */
function bootstrap(): void {
    if (!file_exists(shard_path(1)) || filesize(shard_path(1)) === 0) {
        scan_and_rebuild();
    }
}

function ensure_dir(): void {
    if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);
}

function fmt_size(int $bytes): string {
    if ($bytes >= 1073741824) return round($bytes / 1073741824, 2) . ' GB';
    if ($bytes >= 1048576)    return round($bytes / 1048576, 2)    . ' MB';
    if ($bytes >= 1024)       return round($bytes / 1024, 2)       . ' KB';
    return $bytes . ' B';
}

// ─── XHR detection ───────────────────────────────────────────────────────────
$isXhr = isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
         strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

// ─── Upload handler ───────────────────────────────────────────────────────────
$uploadError  = null;
$uploadedFile = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    ensure_dir();
    $file = $_FILES['file'];

    do {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $msgs = [
                UPLOAD_ERR_INI_SIZE   => 'File exceeds server limit.',
                UPLOAD_ERR_FORM_SIZE  => 'File exceeds form limit.',
                UPLOAD_ERR_PARTIAL    => 'Upload was partial.',
                UPLOAD_ERR_NO_FILE    => 'No file received.',
                UPLOAD_ERR_NO_TMP_DIR => 'Missing temp folder.',
                UPLOAD_ERR_CANT_WRITE => 'Cannot write to disk.',
                UPLOAD_ERR_EXTENSION  => 'Upload blocked by extension.',
            ];
            $uploadError = $msgs[$file['error']] ?? 'Unknown upload error.';
            break;
        }
        if ($file['size'] > MAX_SIZE) { $uploadError = 'File exceeds the 1 GB limit.'; break; }

        $originalName = basename($file['name']);
        $ext          = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        if (in_array($ext, FORBIDDEN, true)) { $uploadError = 'PHP files are not allowed.'; break; }

        $hash     = hash_file('sha256', $file['tmp_name']);
        $hashName = $ext !== '' ? "{$hash}.{$ext}" : $hash;
        $dest     = UPLOAD_DIR . $hashName;

        if (file_exists($dest)) { $uploadError = 'This file already exists (identical content is already stored).'; break; }
        if (!move_uploaded_file($file['tmp_name'], $dest)) { $uploadError = 'Failed to save the file. Check folder permissions.'; break; }

        $newEntry = [
            'original_name' => $originalName,
            'filename'      => $hashName,
            'date'          => date('Y-m-d H:i:s'),
            'filesize'      => filesize($dest),
            'filehash'      => $hash,
        ];

        bootstrap();
        append_entry($newEntry);
        $uploadedFile = $newEntry;

    } while (false);

    // XHR: return JSON only
    if ($isXhr) {
        // Discard any stray PHP warnings/notices buffered above —
        // even one extra byte breaks JSON.parse() on the client.
        ob_end_clean();
        ini_set('display_errors', '0');

        header('Content-Type: application/json; charset=utf-8');
        if ($uploadError) {
            echo json_encode(['ok' => false, 'error' => $uploadError]);
        } else {
            $dir = dirname($_SERVER['REQUEST_URI']);
            $dir = ($dir === '/' || $dir === '\\') ? '' : rtrim($dir, '/');
            $bu = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
                . '://' . $_SERVER['HTTP_HOST']
                . $dir . '/download/';
            $url_path = implode('/', array_map('rawurlencode', explode('/', $uploadedFile['filename'])));
            $sz = $uploadedFile['filesize'];
            echo json_encode([
                'ok'            => true,
                'original_name' => $uploadedFile['original_name'],
                'filename'      => $uploadedFile['filename'],
                'date'          => $uploadedFile['date'],
                'filesize'      => fmt_size($sz),
                'filehash'      => $uploadedFile['filehash'],
                'url'           => $bu . $url_path,
            ]);
        }
        exit;
    }
}

// ─── Bootstrap index & build page data ───────────────────────────────────────
bootstrap();

$_req_dir = dirname($_SERVER['REQUEST_URI']);
$_req_dir = ($_req_dir === '/' || $_req_dir === '\\') ? '' : rtrim($_req_dir, '/');
$base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
          . '://' . $_SERVER['HTTP_HOST']
          . $_req_dir . '/download/';

// Only shard 1 is injected into the page; JS fetches subsequent shards itself
$shard1 = read_shard(1);
$js_shard1 = json_encode(array_map(function($e) use ($base_url) {
    $url_path = implode('/', array_map('rawurlencode', explode('/', $e['filename'])));
    return [
        'original_name' => $e['original_name'] ?? $e['filename'],
        'filename'      => $e['filename'],
        'date'          => $e['date'],
        'filesize'      => fmt_size((int)$e['filesize']),
        'filehash'      => $e['filehash'],
        'url'           => $base_url . $url_path,
    ];
}, $shard1), JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES);

// Pass the base URL to JS so it can build shard URLs itself
$js_base_url = json_encode(
    (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
    . '://' . $_SERVER['HTTP_HOST']
    . $_req_dir
    . '/'
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Meento</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;1,9..40,300&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  [hidden] { display: none !important; }
  html { scroll-behavior: smooth; }

  :root {
    --brand:    #ff4d00;
    --brand-2:  #ff8c42;
    --bg:       #0d0d0d;
    --surface:  #161616;
    --surface2: #1f1f1f;
    --border:   #2a2a2a;
    --text:     #f0ece6;
    --muted:    #666;
    --muted2:   #888;
    --link:     #ff7a3d;
    --green:    #22c55e;
    --red:      #ef4444;
    --radius:   12px;
    --font-display: 'Syne', sans-serif;
    --font-body:    'DM Sans', sans-serif;
  }

  body {
    font-family: var(--font-body);
    color: var(--text);
    background: var(--bg);
    display: flex;
    flex-direction: column;
    min-height: 100vh;
    -webkit-font-smoothing: antialiased;
  }

  /* ─── Noise texture overlay ─────────────────────────────────────── */
  body::before {
    content: '';
    position: fixed; inset: 0; z-index: 0; pointer-events: none;
    background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.04'/%3E%3C/svg%3E");
    opacity: .4;
  }

  /* ─── Header ─────────────────────────────────────────────────────── */
  .topbar {
    position: sticky; top: 0; z-index: 100;
    background: rgba(13,13,13,.88);
    backdrop-filter: blur(18px) saturate(140%);
    -webkit-backdrop-filter: blur(18px) saturate(140%);
    border-bottom: 1px solid var(--border);
    padding: 0 32px;
    height: 64px;
    display: flex; align-items: center; gap: 16px;
  }

  .brand {
    font-family: var(--font-display);
    font-weight: 800; font-size: 20px; letter-spacing: -.02em;
    color: var(--text); text-decoration: none; flex-shrink: 0;
    display: flex; align-items: center; gap: 8px;
  }
  .brand-dot {
    width: 8px; height: 8px; border-radius: 50%;
    background: var(--brand);
    display: inline-block;
    box-shadow: 0 0 10px var(--brand);
  }

  .search-wrap {
    flex: 1; display: flex; align-items: center;
    background: var(--surface2); border: 1px solid var(--border);
    border-radius: 10px; overflow: hidden; max-width: 540px;
    transition: border-color .2s, box-shadow .2s;
  }
  .search-wrap:focus-within {
    border-color: var(--brand);
    box-shadow: 0 0 0 3px rgba(255,77,0,.12);
  }
  .search-wrap svg { margin-left: 14px; flex-shrink: 0; color: var(--muted); }
  .search-wrap input {
    flex: 1; background: transparent; border: none; outline: none;
    color: var(--text); font-family: var(--font-body);
    font-size: 15px; padding: 0 14px; height: 44px; min-width: 0;
  }
  .search-wrap input::placeholder { color: var(--muted); }
  .btn-search {
    background: var(--brand); color: #fff; border: none;
    padding: 0 20px; height: 44px; font-family: var(--font-display);
    font-size: 13px; font-weight: 700; letter-spacing: .04em;
    text-transform: uppercase; cursor: pointer;
    transition: background .15s, filter .15s; flex-shrink: 0;
  }
  .btn-search:hover { filter: brightness(1.1); }

  /* ─── Main ───────────────────────────────────────────────────────── */
  main { flex: 1; max-width: 1160px; width: 100%; margin: 0 auto; padding: 64px 32px 48px; position: relative; z-index: 1; }

  /* ─── Hero ───────────────────────────────────────────────────────── */
  .hero { margin-bottom: 72px; }
  .hero.hidden-by-search { display: none; }

  .hero-inner {
    display: grid; grid-template-columns: 1fr 1fr; gap: 64px; align-items: center;
  }

  .hero-text { }
  .hero-eyebrow {
    font-family: var(--font-display); font-size: 11px; font-weight: 700;
    letter-spacing: .18em; text-transform: uppercase; color: var(--brand);
    margin-bottom: 20px; display: flex; align-items: center; gap: 8px;
  }
  .hero-eyebrow::before {
    content: ''; width: 24px; height: 2px; background: var(--brand); display: inline-block;
  }

  .hero-text h1 {
    font-family: var(--font-display); font-size: 56px; line-height: 1.04;
    font-weight: 800; letter-spacing: -.03em; margin-bottom: 24px;
    color: var(--text);
  }
  .hero-text h1 em {
    font-style: normal; color: transparent;
    -webkit-text-stroke: 1.5px var(--brand);
  }

  .hero-text p {
    font-size: 16px; line-height: 1.75; color: var(--muted2);
    font-weight: 300; margin-bottom: 36px; max-width: 440px;
  }
  .hero-text p code {
    font-family: 'SFMono-Regular', Consolas, monospace;
    font-size: 13px; background: var(--surface2);
    border: 1px solid var(--border); border-radius: 4px;
    padding: 1px 6px; color: var(--brand-2);
  }
  .hero-text p strong { color: var(--text); font-weight: 500; }

  #fileInput { display: none; }
  .upload-btn {
    display: inline-flex; align-items: center; gap: 10px;
    background: var(--brand); color: #fff;
    padding: 15px 32px; border-radius: var(--radius);
    font-family: var(--font-display); font-size: 15px; font-weight: 700;
    letter-spacing: .01em; cursor: pointer; border: none;
    transition: transform .15s, box-shadow .2s, filter .15s;
    box-shadow: 0 4px 24px rgba(255,77,0,.4);
    position: relative; overflow: hidden;
  }
  .upload-btn::after {
    content: ''; position: absolute; inset: 0;
    background: linear-gradient(135deg, rgba(255,255,255,.15) 0%, transparent 60%);
    pointer-events: none;
  }
  .upload-btn:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 8px 32px rgba(255,77,0,.5);
    filter: brightness(1.06);
  }
  .upload-btn:disabled { opacity: .5; cursor: default; }
  .upload-btn svg { flex-shrink: 0; }

  /* Drop zone */
  .hero-drop {
    position: relative; border-radius: 20px; overflow: hidden;
    border: 1.5px solid var(--border);
    background: var(--surface);
    min-height: 320px; display: flex; align-items: center; justify-content: center;
    cursor: pointer; transition: border-color .2s, background .2s;
  }
  .hero-drop::before {
    content: ''; position: absolute; inset: 0; pointer-events: none;
    background: radial-gradient(ellipse 80% 60% at 50% 50%, rgba(255,77,0,.07) 0%, transparent 70%);
  }
  .hero-drop.drag-over {
    border-color: var(--brand);
    background: rgba(255,77,0,.06);
    box-shadow: 0 0 0 4px rgba(255,77,0,.1), inset 0 0 40px rgba(255,77,0,.05);
  }
  .drop-content { text-align: center; padding: 40px 32px; }
  .drop-icon {
    width: 72px; height: 72px; border-radius: 50%;
    background: rgba(255,77,0,.1); border: 1.5px solid rgba(255,77,0,.25);
    display: flex; align-items: center; justify-content: center;
    margin: 0 auto 20px; transition: transform .3s, background .2s;
  }
  .hero-drop:hover .drop-icon, .hero-drop.drag-over .drop-icon {
    transform: translateY(-4px) scale(1.06);
    background: rgba(255,77,0,.18);
  }
  .drop-content p { font-size: 14px; color: var(--muted); line-height: 1.6; margin-top: 8px; }
  .drop-content strong { color: var(--muted2); font-weight: 500; }

  /* ─── Notices ────────────────────────────────────────────────────── */
  .notice {
    display: flex; align-items: flex-start; gap: 14px; padding: 16px 20px;
    border-radius: var(--radius); margin-bottom: 32px; font-size: 14px;
    line-height: 1.55; border: 1px solid transparent;
  }
  .notice.error   { background: rgba(239,68,68,.08); border-color: rgba(239,68,68,.25); color: #f87171; }
  .notice.success { background: rgba(34,197,94,.08); border-color: rgba(34,197,94,.25); color: #4ade80; }
  .notice .icon   { font-size: 16px; flex-shrink: 0; line-height: 1.55; }

  /* ─── Progress ───────────────────────────────────────────────────── */
  #progressWrap  { margin-bottom: 32px; display: none; }
  #progressLabel {
    font-size: 13px; color: var(--muted2); margin-bottom: 10px;
    font-family: var(--font-display); letter-spacing: .02em;
    display: flex; justify-content: space-between;
  }
  #progressBar   { width: 100%; height: 3px; background: var(--border); border-radius: 99px; overflow: hidden; }
  #progressFill  { height: 100%; width: 0%; background: linear-gradient(90deg, var(--brand), var(--brand-2)); border-radius: 99px; transition: width .1s linear; }

  /* ─── Results grid ───────────────────────────────────────────────── */
  #listWrap { display: none; }
  .results-header {
    font-family: var(--font-display); font-size: 11px; font-weight: 700;
    letter-spacing: .12em; text-transform: uppercase; color: var(--muted);
    margin-bottom: 20px; padding-bottom: 16px;
    border-bottom: 1px solid var(--border);
  }
  .results {
    list-style: none;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(210px, 1fr));
    gap: 16px;
    padding: 0;
  }

  /* Card */
  .results li {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 16px;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    transition: transform .2s cubic-bezier(.34,1.56,.64,1), box-shadow .2s, border-color .2s;
    position: relative;
    animation: cardIn .3s ease both;
  }
  @keyframes cardIn {
    from { opacity: 0; transform: translateY(12px); }
    to   { opacity: 1; transform: translateY(0); }
  }
  .results li:hover {
    transform: translateY(-4px);
    box-shadow: 0 16px 40px rgba(0,0,0,.4);
    border-color: rgba(255,77,0,.3);
  }

  /* Thumbnail */
  .card-thumb {
    width: 100%; aspect-ratio: 16/10;
    background: var(--surface2); overflow: hidden; flex-shrink: 0;
    display: flex; align-items: center; justify-content: center;
    position: relative;
  }
  .card-thumb::after {
    content: ''; position: absolute; inset: 0; pointer-events: none;
    background: linear-gradient(180deg, transparent 60%, rgba(0,0,0,.5) 100%);
  }
  .card-thumb img { width: 100%; height: 100%; object-fit: cover; display: block; transition: transform .4s ease; }
  .results li:hover .card-thumb img { transform: scale(1.04); }
  .card-thumb img.generic {
    width: 40px; height: 40px; object-fit: contain; opacity: .3; transform: none !important;
  }

  /* Card body */
  .card-body { padding: 14px 14px 10px; display: flex; flex-direction: column; gap: 6px; flex: 1; }

  .card-filename {
    color: var(--text); text-decoration: none;
    font-size: 13px; font-weight: 500; word-break: break-all;
    line-height: 1.4;
    display: -webkit-box; -webkit-line-clamp: 2;
    -webkit-box-orient: vertical; overflow: hidden;
  }
  .card-filename:hover { color: var(--brand-2); }

  .card-meta {
    display: flex; flex-direction: column; gap: 3px; margin-top: 4px;
  }
  .card-meta span {
    font-size: 10.5px; color: var(--muted); line-height: 1.5;
    display: flex; align-items: center; gap: 5px;
  }
  .card-meta .meta-icon { opacity: .5; }
  .card-meta .hash {
    font-family: 'SFMono-Regular', Consolas, monospace;
    font-size: 9.5px; word-break: break-all; color: #444;
  }

  /* Comment button */
  .btn-comment {
    display: block; margin: 4px 14px 14px;
    background: transparent; color: var(--muted2);
    border: 1px solid var(--border);
    padding: 7px 0; font-family: var(--font-display);
    font-size: 11px; font-weight: 700; letter-spacing: .06em;
    text-transform: uppercase; border-radius: 8px;
    cursor: pointer; text-decoration: none; text-align: center;
    transition: background .15s, color .15s, border-color .15s;
  }
  .btn-comment:hover {
    background: rgba(255,77,0,.1);
    border-color: rgba(255,77,0,.4);
    color: var(--brand-2);
  }

  /* ─── Next / pagination ──────────────────────────────────────────── */
  #nextWrap { display: none; text-align: center; margin-top: 40px; }
  #nextWrap a {
    display: inline-flex; align-items: center; gap: 8px;
    color: var(--muted2); font-family: var(--font-display);
    font-size: 12px; font-weight: 700; letter-spacing: .1em;
    text-transform: uppercase; text-decoration: none;
    border: 1px solid var(--border); border-radius: 8px;
    padding: 10px 24px; transition: border-color .15s, color .15s;
  }
  #nextWrap a:hover { border-color: var(--brand); color: var(--brand-2); }

  .empty {
    text-align: center; color: var(--muted); padding: 64px 0;
    font-size: 15px; font-weight: 300; letter-spacing: .02em;
  }
  .empty strong { display: block; font-family: var(--font-display); font-size: 18px; color: var(--muted2); margin-bottom: 8px; font-weight: 700; }

  /* ─── Footer ─────────────────────────────────────────────────────── */
  footer {
    border-top: 1px solid var(--border); color: var(--muted);
    text-align: center; padding: 24px; font-size: 13px;
    font-weight: 300; letter-spacing: .03em; position: relative; z-index: 1;
  }

  /* ─── Responsive ─────────────────────────────────────────────────── */
  @media (max-width: 780px) {
    main { padding: 40px 20px 32px; }
    .hero-inner { grid-template-columns: 1fr; gap: 40px; }
    .hero-drop { min-height: 200px; }
    .hero-text h1 { font-size: 38px; }
    .topbar { padding: 0 20px; gap: 12px; }
    .search-wrap { max-width: none; }
    .btn-search { display: none; }
    .results { grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); }
  }
</style>
</head>
<body>

<header class="topbar">
  <a href="index.php" class="brand">
    <span class="brand-dot"></span>
    Meento
  </a>
  <div class="search-wrap">
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
      <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
    </svg>
    <input id="searchInput" type="text" placeholder="Search by name, extension, hash…" autocomplete="off" />
    <button type="button" class="btn-search" id="searchBtn">Search</button>
  </div>
</header>

<main>

  <?php if ($uploadError): ?>
  <div class="notice error" role="alert">
    <span class="icon">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
    </span>
    <div><?= htmlspecialchars($uploadError) ?></div>
  </div>
  <?php endif; ?>

  <!-- Hero -->
  <section class="hero" id="hero">
    <div class="hero-inner">
      <div class="hero-text">
        <p class="hero-eyebrow">File storage</p>
        <h1>Drop your file,<br><em>own the link.</em></h1>
        <p>
          Meento stores every upload under its <strong>SHA-256 hash</strong>,
          indexes it in <code>files.json</code>, and lets you search and
          annotate files instantly — zero dependencies, pure PHP.
        </p>
        <form method="POST" enctype="multipart/form-data" id="uploadForm">
          <input type="file" name="file" id="fileInput" />
          <button type="button" class="upload-btn" id="uploadBtn">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.39 18.39A5 5 0 0018 9h-1.26A8 8 0 103 16.3"/></svg>
            Upload File
          </button>
        </form>
      </div>
      <div class="hero-drop" id="dropZone" role="button" tabindex="0" aria-label="Drop zone — drag a file here or click to browse">
        <div class="drop-content">
          <div class="drop-icon">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#ff4d00" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
              <polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/>
              <path d="M20.39 18.39A5 5 0 0018 9h-1.26A8 8 0 103 16.3"/>
            </svg>
          </div>
          <strong style="font-family:var(--font-display);font-size:16px;font-weight:700;color:var(--text);">Drag &amp; drop here</strong>
          <p>or click <strong>Upload File</strong> to browse<br>Max size: 1 GB &nbsp;·&nbsp; No PHP files</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Progress -->
  <div id="progressWrap">
    <div id="progressLabel">
      <span>Uploading…</span>
      <span id="progressPct">0%</span>
    </div>
    <div id="progressBar"><div id="progressFill"></div></div>
  </div>

  <!-- Results -->
  <div id="listWrap">
    <p class="results-header">Results</p>
    <ul id="results" class="results"></ul>
    <div class="empty" id="emptyMsg" hidden><strong>Nothing found</strong>Try a different search term.</div>
    <div id="nextWrap"><a id="nextAnchor" href="#">Load more &rarr;</a></div>
  </div>

</main>

<footer>Meento &mdash; all rights reserved</footer>

<script>
(function () {
  'use strict';

  // ── Constants injected by PHP ──────────────────────────────────────────────
  // Shard 1 entries, already formatted
  const SHARD1      = <?= $js_shard1 ?>;
  // Base URL of this directory (no trailing slash needed — we append filenames)
  const BASE_URL    = <?= $js_base_url ?>;   // e.g. "https://host/path/"

  // ── Shard URL builder (mirrors PHP shard_name()) ──────────────────────────
  // shard 1 → files.json, shard 2 → files_2.json, …
  function shardUrl(n) {
    return BASE_URL + (n === 1 ? 'files.json' : 'files_' + n + '.json');
  }

  // ── Download-URL builder for a file entry ─────────────────────────────────
  function fileUrl(filename) {
    return BASE_URL + 'download/' +
      filename.split('/').map(encodeURIComponent).join('/');
  }

  // ── Format a raw entry fetched from a shard JSON (no PHP fmt_size there) ──
  function formatEntry(raw) {
    const sz = raw.filesize;
    let fmtSz;
    if      (sz >= 1073741824) fmtSz = (sz/1073741824).toFixed(2) + ' GB';
    else if (sz >= 1048576)    fmtSz = (sz/1048576).toFixed(2)    + ' MB';
    else if (sz >= 1024)       fmtSz = (sz/1024).toFixed(2)       + ' KB';
    else                       fmtSz = sz + ' B';
    return {
      original_name: raw.original_name || raw.filename,
      filename:      raw.filename,
      date:          raw.date,
      filesize:      fmtSz,
      filehash:      raw.filehash,
      url:           fileUrl(raw.filename),
    };
  }

  // ── State ──────────────────────────────────────────────────────────────────
  let currentShard = 1;           // which shard is currently displayed
  let currentQuery = '';          // active search term
  let shardCache   = {};          // shard number → formatted entries[]
  shardCache[1]    = SHARD1;      // shard 1 is already formatted by PHP

  // ── DOM refs ──────────────────────────────────────────────────────────────
  const hero        = document.getElementById('hero');
  const listWrap    = document.getElementById('listWrap');
  const resultsList = document.getElementById('results');
  const emptyMsg    = document.getElementById('emptyMsg');
  const nextWrap    = document.getElementById('nextWrap');
  const nextAnchor  = document.getElementById('nextAnchor');
  const searchInput = document.getElementById('searchInput');
  const searchBtn   = document.getElementById('searchBtn');

  // ── Image extensions that can be shown directly ───────────────────────────
  const IMAGE_EXTS = new Set(['jpg','jpeg','png','gif','webp','bmp','svg','avif','ico']);

  // ── Generic file SVG (inline data URI) ────────────────────────────────────
  const GENERIC_ICON = `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 80'%3E%3Crect x='4' y='4' width='56' height='72' rx='6' fill='%23e8e8e8'/%3E%3Cpath d='M38 4 L60 26 L38 26 Z' fill='%23ccc'/%3E%3Crect x='14' y='36' width='36' height='4' rx='2' fill='%23bbb'/%3E%3Crect x='14' y='46' width='28' height='4' rx='2' fill='%23bbb'/%3E%3Crect x='14' y='56' width='20' height='4' rx='2' fill='%23bbb'/%3E%3C/svg%3E`;

  // ── Build one <li> card from a formatted entry ────────────────────────────
  function buildLi(e) {
    const commentHref = 'hash.php?hash=' + encodeURIComponent(e.filehash);
    const ext = (e.filename.split('.').pop() || '').toLowerCase();
    const isImage = IMAGE_EXTS.has(ext);

    // Determine thumbnail src
    let thumbSrc;
    if (isImage) {
      thumbSrc = esc(e.url);          // serve image directly
    } else {
      thumbSrc = BASE_URL + 'thumbs/' + esc(e.filehash) + '.jpg';
    }

    const li = document.createElement('li');
    li.innerHTML =
      `<div class="card-thumb">
         <img src="${thumbSrc}" alt="" loading="lazy" />
       </div>
       <div class="card-body">
         <a class="card-filename" href="${esc(e.url)}" target="_blank" rel="noopener noreferrer">${esc(e.original_name)}</a>
         <div class="card-meta">
           <span><span class="meta-icon">↗</span> ${esc(e.date)}</span>
           <span><span class="meta-icon">◎</span> ${esc(e.filesize)}</span>
           <span class="hash" title="SHA-256">${esc(e.filehash)}</span>
         </div>
       </div>
       <a class="btn-comment" href="${esc(commentHref)}" target="_blank" rel="noopener noreferrer">Comment</a>`;

    // Fallback: if thumb fails to load, swap to generic icon
    const img = li.querySelector('.card-thumb img');
    img.addEventListener('error', function onErr() {
      this.removeEventListener('error', onErr);
      if (this.src !== GENERIC_ICON) {
        this.src = GENERIC_ICON;
        this.classList.add('generic');
      }
    });

    return li;
  }

  // ── Fetch a shard by number, using the cache ───────────────────────────────
  // Returns a Promise<entry[]>. Resolves to [] if the file doesn't exist (404).
  async function fetchShard(n) {
    if (shardCache[n] !== undefined) return shardCache[n];
    try {
      const res = await fetch(shardUrl(n), { cache: 'no-store' });
      if (!res.ok) { shardCache[n] = []; return []; }
      const raw = await res.json();
      shardCache[n] = Array.isArray(raw) ? raw.map(formatEntry) : [];
    } catch (_) {
      shardCache[n] = [];
    }
    return shardCache[n];
  }

  // ── Check whether the shard AFTER n exists ────────────────────────────────
  // Uses a HEAD request — no body downloaded.
  async function nextShardExists(n) {
    try {
      const res = await fetch(shardUrl(n + 1), { method: 'HEAD', cache: 'no-store' });
      return res.ok;
    } catch (_) { return false; }
  }

  // ── Render results for the current shard + query ──────────────────────────
  async function renderResults(q, shardN) {
    q      = (q      ?? currentQuery).trim().toLowerCase();
    shardN = shardN  ?? currentShard;

    currentQuery = q;
    currentShard = shardN;

    if (!q) {
      hero.classList.remove('hidden-by-search');
      listWrap.style.display = 'none';
      nextWrap.style.display = 'none';
      return;
    }

    hero.classList.add('hidden-by-search');

    const entries = await fetchShard(shardN);
    const matches = entries.filter(e =>
      e.original_name.toLowerCase().includes(q) ||
      e.filename.toLowerCase().includes(q)       ||
      e.filehash.toLowerCase().includes(q)
    );

    resultsList.innerHTML = '';
    listWrap.style.display = 'block';

    if (matches.length === 0) {
      emptyMsg.hidden = false;
      nextWrap.style.display = 'none';
      return;
    }

    emptyMsg.hidden = true;
    matches.forEach(e => resultsList.appendChild(buildLi(e)));

    // Check whether a next shard file exists — JS-only, no PHP involvement
    const hasNext = await nextShardExists(shardN);
    if (hasNext) {
      nextWrap.style.display = 'block';
      // Clicking Next loads the next shard in-page (no navigation)
      nextAnchor.onclick = async (ev) => {
        ev.preventDefault();
        await renderResults(currentQuery, currentShard + 1);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      };
    } else {
      nextWrap.style.display = 'none';
    }
  }

  // ── Hero visibility helper ─────────────────────────────────────────────────
  function setHeroVisible(v) {
    hero.classList.toggle('hidden-by-search', !v);
  }

  // ── Post-upload: inject a single highlighted result card ──────────────────
  function showUploadResult(entry) {
    // Insert into shard 1 cache so it shows in future searches
    if (!shardCache[1]) shardCache[1] = [];
    shardCache[1].unshift(entry);

    setHeroVisible(false);
    resultsList.innerHTML = '';
    emptyMsg.hidden = true;
    nextWrap.style.display = 'none';
    listWrap.style.display = 'block';

    const li = buildLi(entry);
    li.style.outline = '2px solid var(--green)';
    li.style.outlineOffset = '-2px';
    resultsList.appendChild(li);
  }

  // ── Upload ─────────────────────────────────────────────────────────────────
  const uploadBtn    = document.getElementById('uploadBtn');
  const fileInput    = document.getElementById('fileInput');
  const uploadForm   = document.getElementById('uploadForm');
  const dropZone     = document.getElementById('dropZone');
  const progressWrap = document.getElementById('progressWrap');
  const progressFill = document.getElementById('progressFill');
  const progressPct  = document.getElementById('progressPct');

  uploadBtn.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', () => {
    if (fileInput.files.length) submitUpload(fileInput.files[0]);
  });
  ['dragenter','dragover'].forEach(ev =>
    dropZone.addEventListener(ev, e => { e.preventDefault(); dropZone.classList.add('drag-over'); })
  );
  ['dragleave','drop'].forEach(ev =>
    dropZone.addEventListener(ev, e => { e.preventDefault(); dropZone.classList.remove('drag-over'); })
  );
  dropZone.addEventListener('drop', e => {
    const f = e.dataTransfer.files[0];
    if (f) submitUpload(f);
  });

  function submitUpload(file) {
    if (file.size > 1073741824) { showNotice('error', 'File exceeds the 1 GB limit.'); return; }
    const ext = file.name.split('.').pop().toLowerCase();
    if (['php','phtml','php3','php4','php5','php7','phps','phar'].includes(ext)) {
      showNotice('error', 'PHP files are not allowed.'); return;
    }
    const dt = new DataTransfer();
    dt.items.add(file);
    fileInput.files = dt.files;

    const fd  = new FormData(uploadForm);
    const xhr = new XMLHttpRequest();
    xhr.open('POST', window.location.href, true);
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');

    xhr.upload.addEventListener('progress', ev => {
      if (ev.lengthComputable) {
        const pct = Math.round(ev.loaded / ev.total * 100);
        progressFill.style.width = pct + '%';
        progressPct.textContent  = pct + '%';
      }
    });
    xhr.addEventListener('loadstart', () => {
      progressWrap.style.display = 'block';
      uploadBtn.disabled = true;
      uploadBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 8 12 16"/><polyline points="8 12 12 8 16 12"/></svg> Uploading…';
    });
    xhr.addEventListener('load', () => {
      progressWrap.style.display = 'none';
      uploadBtn.disabled = false;
      uploadBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.39 18.39A5 5 0 0018 9h-1.26A8 8 0 103 16.3"/></svg> Upload File';
      fileInput.value = '';

      let resp;
      try { resp = JSON.parse(xhr.responseText); }
      catch(e) { showNotice('error', 'Unexpected server response.'); return; }

      if (!resp.ok) { showNotice('error', resp.error || 'Upload failed.'); return; }

      clearNotices();
      showUploadResult(resp);
      searchInput.value = '';
      currentQuery = '';
      currentShard = 1;
      // Bust the shard 1 cache so the next search re-fetches the updated file
      delete shardCache[1];
      shardCache[1] = undefined;
    });
    xhr.addEventListener('error', () => {
      progressWrap.style.display = 'none';
      uploadBtn.disabled = false;
      uploadBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.39 18.39A5 5 0 0018 9h-1.26A8 8 0 103 16.3"/></svg> Upload File';
      showNotice('error', 'Network error during upload.');
    });
    xhr.send(fd);
  }

  // ── Notice helpers ─────────────────────────────────────────────────────────
  function showNotice(type, msg) {
    clearNotices();
    const div = document.createElement('div');
    div.className = 'notice ' + type;
    div.dataset.dynamic = '1';
    div.innerHTML = `<span class="icon">${type === 'error'
      ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>'
      : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><polyline points="9 12 11 14 15 10"/></svg>'
    }</span><div>${esc(msg)}</div>`;
    document.querySelector('main').prepend(div);
  }
  function clearNotices() {
    document.querySelectorAll('.notice[data-dynamic]').forEach(n => n.remove());
  }

  // ── Escape helper ──────────────────────────────────────────────────────────
  function esc(str) {
    return String(str)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  // ── Search listeners ───────────────────────────────────────────────────────
  searchInput.addEventListener('input', e => {
    currentShard = 1; // reset to shard 1 on every new keystroke
    renderResults(e.target.value, 1);
  });
  searchBtn.addEventListener('click', () => {
    currentShard = 1;
    renderResults(searchInput.value, 1);
  });
  searchInput.addEventListener('keydown', e => {
    if (e.key === 'Enter') { currentShard = 1; renderResults(searchInput.value, 1); }
  });

})();
</script>
</body>
</html>