﻿#!/usr/bin/env php
<?php
/**
 * +----------------------------------------------------------+
 *  DHT meento - Distributed Hash Table  v1.0.0
 *  Peer Discovery & File Index System  [PHP edition]
 * +----------------------------------------------------------+
 *
 * Single-file DHT implementation using Kademlia-inspired routing.
 *  · servers.txt  -- known peer addresses (host:port), one per line
 *  · files.txt    -- indexed files (filename|host:port|nodeId), one per line
 *
 * Wire protocol (TCP, newline-terminated):
 *  · Fields within a command use  |  as separator
 *  · Record lists in responses use  ;;  as entry separator
 *  · Every line is capped at MAX_LINE_LEN bytes before sending
 *
 * Requirements: PHP 7.4+, ext-sockets, ext-pcntl (node mode)
 *
 * Usage:
 *   php dht_meento.php node [port]      Start a DHT node (default 4480)
 *   php dht_meento.php discover         Ping peers, crawl network, sync files
 *   php dht_meento.php share <file>     Announce a file to the network
 *   php dht_meento.php search <query>   Search files across the network
 *   php dht_meento.php list             List all files in files.txt
 *   php dht_meento.php peers            List all peers in servers.txt
 *   php dht_meento.php help             Show this help
 */

declare(strict_types=1);

// ---------------------------------------------------------------------------
//  Constants
// ---------------------------------------------------------------------------
const SERVERS_FILE  = 'servers.txt';
const FILES_FILE    = 'files.txt';
const DEFAULT_PORT  = 4480;
const TIMEOUT_SEC   = 3;
const MAX_LINE_LEN  = 2000;       // hard cap on every sent/received line
const VERSION       = '1.0.0';
const ENTRY_SEP     = ';;';       // record separator inside list responses

// Protocol commands
const CMD_PING       = 'DHT_PING';
const CMD_PONG       = 'DHT_PONG';
const CMD_GET_PEERS  = 'DHT_GET_PEERS';
const CMD_PEERS      = 'DHT_PEERS';
const CMD_GET_FILES  = 'DHT_GET_FILES';
const CMD_FILES      = 'DHT_FILES';
const CMD_ANNOUNCE   = 'DHT_ANNOUNCE';
const CMD_ACK        = 'DHT_ACK';
const CMD_SEARCH     = 'DHT_SEARCH';
const CMD_SEARCH_RES = 'DHT_SEARCH_RES';

// ---------------------------------------------------------------------------
//  Entry point
// ---------------------------------------------------------------------------
function main(array $argv): void
{
    print_banner();

    $cmd = strtolower($argv[1] ?? '');

    switch ($cmd) {
        case 'node':
            $port = isset($argv[2]) ? (int)$argv[2] : DEFAULT_PORT;
            node_start($port);
            break;

        case 'discover':
            client_discover();
            break;

        case 'share':
            if (empty($argv[2])) { echo "  Usage: share <filename>\n"; exit(1); }
            client_share($argv[2]);
            break;

        case 'search':
            if (empty($argv[2])) { echo "  Usage: search <query>\n"; exit(1); }
            client_search($argv[2]);
            break;

        case 'list':
            client_list_files();
            break;

        case 'peers':
            client_list_peers();
            break;

        case 'help':
        default:
            print_help();
    }
}

// ---------------------------------------------------------------------------
//  Banner & help
// ---------------------------------------------------------------------------
function print_banner(): void
{
    echo "\n";
    echo "  +----------------------------------------------------+\n";
    echo "  |  DHT meento  --  Distributed Hash Table  v" . VERSION . "    |\n";
    echo "  |  Peer Discovery & Distributed File Index  [PHP]   |\n";
    echo "  +----------------------------------------------------+\n";
    echo "\n";
}

function print_help(): void
{
    echo "  COMMANDS\n";
    echo "    node [port]      Start a DHT node (default port: " . DEFAULT_PORT . ")\n";
    echo "    discover         Ping all known peers, crawl for new ones\n";
    echo "    share <file>     Announce a file to the network\n";
    echo "    search <query>   Search for files across the network\n";
    echo "    list             List all files indexed in files.txt\n";
    echo "    peers            List all peers stored in servers.txt\n";
    echo "    help             Show this help\n";
    echo "\n";
    echo "  STORAGE FILES\n";
    echo "    servers.txt    Peer addresses  (host:port), one per line, no duplicates\n";
    echo "    files.txt      File entries  (filename|host:port|nodeId), no duplicates\n";
    echo "    Max line size  " . MAX_LINE_LEN . " bytes (enforced on send and receive)\n";
    echo "\n";
}

// ---------------------------------------------------------------------------
//  Node ID  --  SHA-1 hex of "host:port"
// ---------------------------------------------------------------------------
function compute_node_id(string $address): string
{
    return sha1($address);
}

// ---------------------------------------------------------------------------
//  File I/O  --  no duplicates, max-line enforcement
// ---------------------------------------------------------------------------

/**
 * Read all non-blank, non-comment lines from a file.
 * Lines longer than MAX_LINE_LEN are silently skipped (corrupted / foreign).
 * Returns an array keyed by the line string for O(1) lookup.
 */
function read_lines(string $filename): array
{
    $set = [];
    if (!file_exists($filename)) return $set;

    $fh = fopen($filename, 'r');
    if ($fh === false) {
        fwrite(STDERR, "  [WARN] Cannot read $filename\n");
        return $set;
    }

    while (($line = fgets($fh, MAX_LINE_LEN + 2)) !== false) {
        $line = rtrim($line, "\r\n");
        $line = trim($line);
        if ($line === '' || $line[0] === '#') continue;
        if (strlen($line) > MAX_LINE_LEN) continue;  // skip oversized lines
        $set[$line] = true;
    }
    fclose($fh);
    return $set;
}

/**
 * Append $entry to $filename only if not already present.
 * Truncates the entry to MAX_LINE_LEN before writing.
 * Returns true when actually written.
 */
function add_line(string $filename, string $entry): bool
{
    $entry = trim($entry);
    if ($entry === '') return false;
    if (strlen($entry) > MAX_LINE_LEN) {
        $entry = substr($entry, 0, MAX_LINE_LEN);
    }

    // Acquire an exclusive lock via a lock-file to be safe under fork()
    $lock = $filename . '.lock';
    $lh   = fopen($lock, 'c');
    if ($lh === false) return false;
    flock($lh, LOCK_EX);

    $exists = isset(read_lines($filename)[$entry]);
    if (!$exists) {
        $fh = fopen($filename, 'a');
        if ($fh !== false) {
            fwrite($fh, $entry . "\n");
            fclose($fh);
        }
    }

    flock($lh, LOCK_UN);
    fclose($lh);
    return !$exists;
}

/**
 * Overwrite $filename with $lines (deduplication applied, order preserved).
 */
function write_lines(string $filename, array $lines): void
{
    $seen   = [];
    $output = '';
    foreach ($lines as $line) {
        $line = trim((string)$line);
        if ($line === '' || isset($seen[$line])) continue;
        if (strlen($line) > MAX_LINE_LEN) $line = substr($line, 0, MAX_LINE_LEN);
        $seen[$line] = true;
        $output     .= $line . "\n";
    }

    $lock = $filename . '.lock';
    $lh   = fopen($lock, 'c');
    if ($lh === false) return;
    flock($lh, LOCK_EX);
    file_put_contents($filename, $output);
    flock($lh, LOCK_UN);
    fclose($lh);
}

// ---------------------------------------------------------------------------
//  Network helpers
// ---------------------------------------------------------------------------

/**
 * Detect this machine's best outbound IP; falls back to 127.0.0.1.
 */
function get_local_address(int $port): string
{
    $sock = @fsockopen('8.8.8.8', 80, $errno, $errstr, 1);
    if ($sock !== false) {
        $local = stream_socket_get_name($sock, false);
        fclose($sock);
        // $local = "ip:ephemeralPort" -- extract just the IP
        $ip = preg_replace('/:\d+$/', '', $local);
        return $ip . ':' . $port;
    }
    return '127.0.0.1:' . $port;
}

/**
 * Parse "host:port" -- supports IPv4 and hostnames.
 * Returns [host, port] or null on bad input.
 */
function split_host_port(string $peer): ?array
{
    $idx = strrpos($peer, ':');
    if ($idx === false || $idx === 0) return null;
    $host = substr($peer, 0, $idx);
    $port = (int)substr($peer, $idx + 1);
    if ($port <= 0 || $port > 65535) return null;
    return [$host, $port];
}

/**
 * Send one line to host:port, return the single response line.
 * Both sent and received lines are capped at MAX_LINE_LEN.
 * Returns null on any failure.
 */
function send_request(string $host, int $port, string $message): ?string
{
    // Enforce max length before sending
    if (strlen($message) > MAX_LINE_LEN) {
        $message = substr($message, 0, MAX_LINE_LEN);
    }

    $sock = @fsockopen($host, $port, $errno, $errstr, TIMEOUT_SEC);
    if ($sock === false) return null;

    stream_set_timeout($sock, TIMEOUT_SEC);

    fwrite($sock, $message . "\n");

    $response = fgets($sock, MAX_LINE_LEN + 2);
    fclose($sock);

    if ($response === false) return null;

    $response = rtrim($response, "\r\n");
    if (strlen($response) > MAX_LINE_LEN) {
        $response = substr($response, 0, MAX_LINE_LEN);
    }
    return $response;
}

/**
 * Split a list-response that uses ENTRY_SEP as record delimiter.
 * Index 0 is the command token and is skipped.
 */
function split_entries(?string $response): array
{
    if ($response === null || $response === '') return [];
    $parts = explode(ENTRY_SEP, $response);
    $result = [];
    for ($i = 1; $i < count($parts); $i++) {
        $e = trim($parts[$i]);
        if ($e !== '') $result[] = $e;
    }
    return $result;
}

/**
 * Build a response that may contain many entries.
 * Entries are joined with ENTRY_SEP; if the joined string exceeds MAX_LINE_LEN,
 * entries are dropped from the END until it fits (oldest entries survive).
 */
function build_list_response(string $command, array $entries): string
{
    $line = $command;
    foreach ($entries as $entry) {
        $entry = trim((string)$entry);
        if ($entry === '') continue;
        $candidate = $line . ENTRY_SEP . $entry;
        if (strlen($candidate) > MAX_LINE_LEN) break;  // stop adding entries
        $line = $candidate;
    }
    return $line;
}

// ---------------------------------------------------------------------------
//  DHT Node  --  TCP server (uses pcntl_fork for concurrency)
// ---------------------------------------------------------------------------
function node_start(int $port): void
{
    if (!extension_loaded('sockets')) {
        echo "  [ERROR] ext-sockets is required to run a node.\n";
        exit(1);
    }

    $address = get_local_address($port);
    $node_id = compute_node_id($address);

    $is_new = add_line(SERVERS_FILE, $address);

    echo "  [NODE] Address  : $address\n";
    echo "  [NODE] Node ID  : $node_id\n";
    echo "  [NODE] Port     : $port\n";
    echo "  [NODE] Registry : " . ($is_new ? 'registered in servers.txt' : 'already in servers.txt') . "\n";
    echo "\n";

    // Create TCP server socket
    $server = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
    if ($server === false) {
        echo "  [ERROR] socket_create failed: " . socket_strerror(socket_last_error()) . "\n";
        exit(1);
    }
    socket_set_option($server, SOL_SOCKET, SO_REUSEADDR, 1);

    if (!socket_bind($server, '0.0.0.0', $port)) {
        echo "  [ERROR] Cannot bind port $port: " . socket_strerror(socket_last_error($server)) . "\n";
        exit(1);
    }
    socket_listen($server, 64);

    echo "  [NODE] Listening on port $port  (Ctrl+C to stop)\n\n";

    // Periodic peer refresh: use SIGALRM every 60 s
    if (function_exists('pcntl_signal') && function_exists('pcntl_alarm')) {
        pcntl_signal(SIGALRM, function () use ($address, $node_id) {
            node_refresh_peers($address);
            pcntl_alarm(60);
        });
        pcntl_signal(SIGCHLD, SIG_IGN); // auto-reap children
        pcntl_alarm(30);                // first refresh after 30 s
    }

    while (true) {
        // Dispatch pending signals
        if (function_exists('pcntl_signal_dispatch')) pcntl_signal_dispatch();

        // Non-blocking accept check
        $read   = [$server];
        $write  = null;
        $except = null;
        $ready  = socket_select($read, $write, $except, 1);  // 1 s timeout

        if ($ready === false || $ready === 0) continue;

        $client = socket_accept($server);
        if ($client === false) continue;

        if (function_exists('pcntl_fork')) {
            $pid = pcntl_fork();
            if ($pid === -1) {
                // Fork failed — handle in-process
                node_handle_client($client, $address, $node_id);
            } elseif ($pid === 0) {
                // Child: close server reference and handle the client
                socket_close($server);
                node_handle_client($client, $address, $node_id);
                exit(0);
            } else {
                // Parent: close client reference, continue accepting
                socket_close($client);
            }
        } else {
            // No pcntl -- single-process fallback
            node_handle_client($client, $address, $node_id);
        }
    }
}

function node_handle_client($client, string $address, string $node_id): void
{
    socket_set_option($client, SOL_SOCKET, SO_RCVTIMEO, ['sec' => TIMEOUT_SEC, 'usec' => 0]);
    socket_set_option($client, SOL_SOCKET, SO_SNDTIMEO, ['sec' => TIMEOUT_SEC, 'usec' => 0]);

    $remote = '';
    socket_getpeername($client, $remote);

    // Read one line (up to MAX_LINE_LEN + newline)
    $raw = '';
    $buf = '';
    while (strlen($raw) < MAX_LINE_LEN + 1) {
        $chunk = socket_read($client, 256, PHP_NORMAL_READ);
        if ($chunk === false || $chunk === '') break;
        $raw .= $chunk;
        if (strpos($raw, "\n") !== false) break;
    }
    $raw = trim($raw);
    if (strlen($raw) > MAX_LINE_LEN) $raw = substr($raw, 0, MAX_LINE_LEN);

    if ($raw === '') { socket_close($client); return; }

    $parts   = explode('|', $raw, -1);  // -1 = keep all empty trailing fields
    // PHP explode with -1 as limit only works as "all fields"; use 0 for no-limit
    $parts   = explode('|', $raw);
    $command = $parts[0] ?? '';

    echo "  [NODE] $command from $remote\n";

    $response = '';

    switch ($command) {

        case CMD_PING:
            // parts[1] = sender "host:port"
            $sender = $parts[1] ?? '';
            if ($sender !== '') {
                $added = add_line(SERVERS_FILE, $sender);
                if ($added) echo "  [NODE] New peer registered: $sender\n";
            }
            $response = CMD_PONG . '|' . $address . '|' . $node_id;
            break;

        case CMD_GET_PEERS:
            $peers    = array_keys(read_lines(SERVERS_FILE));
            $response = build_list_response(CMD_PEERS, $peers);
            break;

        case CMD_GET_FILES:
            $files    = array_keys(read_lines(FILES_FILE));
            $response = build_list_response(CMD_FILES, $files);
            break;

        case CMD_ANNOUNCE:
            // parts[1]=filename  parts[2]=sourceAddr  [parts[3]=sourceNodeId]
            $fname  = $parts[1] ?? '';
            $src    = $parts[2] ?? '';
            $src_id = $parts[3] ?? compute_node_id($src);
            if ($fname !== '' && $src !== '') {
                $entry = $fname . '|' . $src . '|' . $src_id;
                $added = add_line(FILES_FILE, $entry);
                echo '  [NODE] File ' . ($added ? 'indexed' : 'known  ') . ": $fname @ $src\n";
            }
            $response = CMD_ACK;
            break;

        case CMD_SEARCH:
            $query = strtolower($parts[1] ?? '');
            $files = array_keys(read_lines(FILES_FILE));
            $hits  = [];
            foreach ($files as $f) {
                $fname = strtolower(explode('|', $f)[0]);
                if (strpos($fname, $query) !== false) $hits[] = $f;
            }
            $response = build_list_response(CMD_SEARCH_RES, $hits);
            break;

        default:
            $response = 'DHT_ERR|Unknown command: ' . $command;
    }

    // Enforce max length on outgoing line
    if (strlen($response) > MAX_LINE_LEN) $response = substr($response, 0, MAX_LINE_LEN);

    socket_write($client, $response . "\n");
    socket_close($client);
}

function node_refresh_peers(string $own_address): void
{
    $peers = array_keys(read_lines(SERVERS_FILE));
    echo '  [NODE] Refreshing ' . count($peers) . " peer(s)...\n";
    $alive = [];

    foreach ($peers as $peer) {
        if ($peer === $own_address) { $alive[] = $peer; continue; }
        $hp = split_host_port($peer);
        if ($hp === null) continue;

        $resp = send_request($hp[0], $hp[1], CMD_PING . '|' . $own_address);
        if ($resp !== null && strncmp($resp, CMD_PONG, strlen(CMD_PONG)) === 0) {
            $alive[] = $peer;
        } else {
            echo "  [NODE] Unreachable, removing: $peer\n";
        }
    }

    write_lines(SERVERS_FILE, $alive);
    echo '  [NODE] Refresh done: ' . count($alive) . '/' . count($peers) . " alive.\n";
}

// ---------------------------------------------------------------------------
//  DHT Client  --  CLI operations
// ---------------------------------------------------------------------------
function client_discover(): void
{
    echo "  [DISCOVER] Starting peer discovery...\n";

    $initial = read_lines(SERVERS_FILE);
    if (empty($initial)) {
        echo "  [DISCOVER] servers.txt is empty.\n";
        echo "  [DISCOVER] Add at least one seed peer (host:port) to get started.\n\n";
        return;
    }
    echo '  [DISCOVER] Seed peers : ' . count($initial) . "\n";

    $to_visit  = array_keys($initial);
    $visited   = [];
    $alive     = [];
    $new_peers = [];
    $new_files = 0;

    while (!empty($to_visit)) {
        $peer = array_shift($to_visit);
        if (isset($visited[$peer])) continue;
        $visited[$peer] = true;

        $hp = split_host_port($peer);
        if ($hp === null) continue;

        // PING
        $pong = send_request($hp[0], $hp[1], CMD_PING . '|' . get_local_address(DEFAULT_PORT));
        if ($pong === null || strncmp($pong, CMD_PONG, strlen(CMD_PONG)) !== 0) {
            echo "  [DISCOVER] x Unreachable : $peer\n";
            continue;
        }
        echo "  [DISCOVER] + Alive       : $peer\n";
        $alive[$peer] = true;

        // GET_PEERS -- crawl transitively
        $remote_peers = split_entries(send_request($hp[0], $hp[1], CMD_GET_PEERS));
        foreach ($remote_peers as $rp) {
            if (!isset($visited[$rp])) {
                $to_visit[] = $rp;
                if (!isset($initial[$rp])) $new_peers[$rp] = true;
            }
        }

        // GET_FILES -- merge into local files.txt
        $remote_files = split_entries(send_request($hp[0], $hp[1], CMD_GET_FILES));
        foreach ($remote_files as $rf) {
            if (add_line(FILES_FILE, $rf)) $new_files++;
        }
    }

    // Persist new peers; prune dead ones
    foreach (array_keys($new_peers) as $np) add_line(SERVERS_FILE, $np);
    $to_write = array_merge(array_keys($alive), array_keys($new_peers));
    write_lines(SERVERS_FILE, $to_write);

    echo "\n";
    echo '  [DISCOVER] Alive peers   : ' . count($alive)     . "\n";
    echo '  [DISCOVER] New peers     : ' . count($new_peers) . "\n";
    echo "  [DISCOVER] New files     : $new_files\n";
    echo "  [DISCOVER] servers.txt   : updated (no duplicates)\n";
    echo "  [DISCOVER] files.txt     : updated (no duplicates)\n";
    echo "  [DISCOVER] Done.\n\n";
}

function client_share(string $filename): void
{
    $local_addr = get_local_address(DEFAULT_PORT);
    $local_id   = compute_node_id($local_addr);
    $entry      = $filename . '|' . $local_addr . '|' . $local_id;

    echo "  [SHARE] Announcing: $filename\n";

    $local = add_line(FILES_FILE, $entry);
    echo '  [SHARE] Local index  : ' . ($local ? 'added' : 'already present') . "\n";

    $peers = array_keys(read_lines(SERVERS_FILE));
    $ok    = 0;
    foreach ($peers as $peer) {
        $hp = split_host_port($peer);
        if ($hp === null) continue;
        $msg  = CMD_ANNOUNCE . '|' . $filename . '|' . $local_addr . '|' . $local_id;
        $resp = send_request($hp[0], $hp[1], $msg);
        if ($resp === CMD_ACK) {
            echo "  [SHARE] + Announced  : $peer\n";
            $ok++;
        } else {
            echo "  [SHARE] x Failed     : $peer\n";
        }
    }

    echo "\n  [SHARE] Announced to $ok/" . count($peers) . " peer(s).\n\n";
}

function client_search(string $query): void
{
    echo "  [SEARCH] Query: \"$query\"\n\n";

    $results = [];

    // Local index
    foreach (array_keys(read_lines(FILES_FILE)) as $f) {
        $fname = strtolower(explode('|', $f)[0]);
        if (strpos($fname, strtolower($query)) !== false) $results[$f] = true;
    }

    // Remote peers
    foreach (array_keys(read_lines(SERVERS_FILE)) as $peer) {
        $hp = split_host_port($peer);
        if ($hp === null) continue;
        $found = split_entries(send_request($hp[0], $hp[1], CMD_SEARCH . '|' . $query));
        foreach ($found as $f) $results[$f] = true;
    }

    if (empty($results)) {
        echo "  [SEARCH] No results found.\n";
    } else {
        echo '  [SEARCH] ' . count($results) . " result(s):\n\n";
        print_file_table(array_keys($results));
    }
    echo "\n";
}

function client_list_files(): void
{
    $files = array_keys(read_lines(FILES_FILE));
    echo '  [LIST] ' . count($files) . ' file(s) in ' . FILES_FILE . "\n\n";
    if (empty($files)) {
        echo "  (empty -- run 'share' or 'discover' to populate)\n";
    } else {
        print_file_table($files);
    }
    echo "\n";
}

function client_list_peers(): void
{
    $peers = array_keys(read_lines(SERVERS_FILE));
    echo '  [PEERS] ' . count($peers) . ' peer(s) in ' . SERVERS_FILE . "\n\n";
    if (empty($peers)) {
        echo "  (empty -- add seed peers manually, one host:port per line)\n";
    } else {
        printf("  %-32s  %s\n", 'ADDRESS', 'NODE-ID (truncated)');
        echo '  ' . str_repeat('-', 60) . "\n";
        foreach ($peers as $peer) {
            $nid = compute_node_id($peer);
            printf("  %-32s  %s\n", $peer, substr($nid, 0, 16) . '...');
        }
    }
    echo "\n";
}

// ---------------------------------------------------------------------------
//  Shared formatting
// ---------------------------------------------------------------------------
function print_file_table(array $entries): void
{
    printf("  %-32s  %-26s  %s\n", 'FILENAME', 'SOURCE', 'NODE-ID');
    echo '  ' . str_repeat('-', 80) . "\n";
    foreach ($entries as $e) {
        $p      = explode('|', $e);
        $fname  = $p[0] ?? $e;
        $source = $p[1] ?? '?';
        $nid    = isset($p[2]) ? substr($p[2], 0, 12) . '...' : '?';
        printf("  %-32s  %-26s  %s\n", $fname, $source, $nid);
    }
}

// ---------------------------------------------------------------------------
//  Run
// ---------------------------------------------------------------------------
main($argv);