﻿<?php
if (isset($_GET['q']) || isset($_GET['maxpage'])) {
    header('Content-Type: application/json');

    $dataFile = __DIR__ . '/data.json';
    $entries  = file_exists($dataFile) ? json_decode(file_get_contents($dataFile), true) : [];
    if (!is_array($entries)) $entries = [];

    $perPage = 20;

    if (isset($_GET['maxpage'])) {
        echo json_encode(['max' => max(1, (int)ceil(count($entries) / $perPage))]);
        exit;
    }

    $q    = strtolower(trim($_GET['q'] ?? ''));
    $page = max(1, (int)($_GET['p'] ?? 1));

    // filter by query
    $filtered = array_values(array_filter($entries, function($item) use ($q) {
        return str_contains(strtolower($item['original_filename'] ?? ''), $q)
            || str_contains(strtolower($item['description']       ?? ''), $q)
            || str_contains(strtolower($item['hash']              ?? ''), $q)
            || str_contains(strtolower($item['public_key']        ?? ''), $q)
            || str_contains(strtolower($item['node_info']         ?? ''), $q);
    }));

    $total   = count($filtered);
    $maxPage = max(1, (int)ceil($total / $perPage));
    $page    = min($page, $maxPage);
    $slice   = array_slice($filtered, ($page - 1) * $perPage, $perPage);

    echo json_encode(['results' => $slice, 'page' => $page, 'max' => $maxPage]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>meento · view</title>
<style>
/* ── minimal reset ───────────────────────────────────────────────────────── */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

/* ── base (monochrome, system fonts) ─────────────────────────────────────── */
body {
  background: #ffffff;
  color: #111;
  font-family: system-ui, -apple-system, 'Segoe UI', 'Roboto', Helvetica, Arial, sans-serif;
  font-size: 14px;
  line-height: 1.5;
}

/* ── header (bare) ───────────────────────────────────────────────────────── */
header {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  padding: 1rem 1.5rem;
  border-bottom: 1px solid #e5e5e5;
  background: #fff;
}

.logo {
  font-size: 1.25rem;
  font-weight: 500;
  text-decoration: none;
  color: #000;
  letter-spacing: -0.01em;
}
.logo em {
  font-style: normal;
  font-weight: 400;
  color: #555;
}

nav a {
  color: #555;
  text-decoration: none;
  font-size: 0.75rem;
  border: 1px solid #ddd;
  padding: 0.2rem 0.7rem;
  border-radius: 20px;
  transition: 0.1s ease;
}
nav a:hover {
  background: #f5f5f5;
  border-color: #aaa;
  color: #000;
}

/* ── main container (tight, readable) ────────────────────────────────────── */
main {
  max-width: 880px;
  margin: 0 auto;
  padding: 2rem 1.2rem 3rem;
}

/* ── hero minimal ───────────────────────────────────────────────────────── */
.hero {
  text-align: center;
  margin-bottom: 1.8rem;
}
.hero h1 {
  font-size: 1.9rem;
  font-weight: 450;
  letter-spacing: -0.02em;
  margin-bottom: 0.2rem;
}
.hero h1 em {
  font-style: normal;
  font-weight: 500;
  color: #2c2c2c;
}
.hero p {
  color: #6b6b6b;
  font-size: 0.8rem;
}

/* ── search (clean, no icon) ─────────────────────────────────────────────── */
.search-wrap {
  max-width: 500px;
  margin: 0 auto 1.8rem auto;
}
#searchInput {
  width: 100%;
  padding: 0.65rem 0.9rem;
  font-size: 0.85rem;
  font-family: inherit;
  background: #fff;
  border: 1px solid #ccc;
  border-radius: 6px;
  outline: none;
  transition: 0.1s;
}
#searchInput:focus {
  border-color: #000;
  box-shadow: none;
}
#searchInput::placeholder {
  color: #aaa;
}

/* ── pagination (tiny, compact) ─────────────────────────────────────────── */
.pagination {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.6rem;
  margin-bottom: 1.6rem;
}
.page-btn {
  background: none;
  border: 1px solid #ccc;
  padding: 0.3rem 0.9rem;
  font-size: 0.7rem;
  font-weight: 450;
  font-family: inherit;
  border-radius: 20px;
  cursor: pointer;
  color: #111;
  transition: 0.1s linear;
}
.page-btn:hover:not(:disabled) {
  background: #f2f2f2;
  border-color: #888;
}
.page-btn:disabled {
  opacity: 0.4;
  cursor: default;
}
.page-info {
  font-size: 0.7rem;
  color: #555;
  letter-spacing: 0.02em;
}
.pagination.hidden {
  display: none;
}

/* ── results list (clean vertical rhythm) ───────────────────────────────── */
#resultsList {
  display: flex;
  flex-direction: column;
  gap: 1.2rem;
}

/* ── minimal card: single column, thin border, no hover fx ───────────────── */
.item {
  display: flex;
  gap: 1rem;
  background: #fff;
  border: 1px solid #eaeaea;
  border-radius: 8px;
  padding: 0.9rem;
  text-decoration: none;
  color: #111;
  transition: border 0.1s;
}
.item:hover {
  border-color: #aaa;
}

/* thumbnail area (fixed width, neutral) */
.item-thumb {
  flex-shrink: 0;
  width: 90px;
  height: 90px;
  background: #f8f8f8;
  border-radius: 5px;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
}
.item-thumb img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.thumb-placeholder {
  display: none;
  width: 100%;
  height: 100%;
  align-items: center;
  justify-content: center;
  color: #aaa;
  font-size: 1.6rem;
  background: #f3f3f3;
}

/* right side: all metadata as clean list */
.item-info {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 0.3rem;
}

.item-title {
  font-weight: 550;
  font-size: 0.9rem;
  letter-spacing: -0.2px;
  word-break: break-word;
  margin-bottom: 0.15rem;
}
.item-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  align-items: baseline;
  font-size: 0.7rem;
  color: #4a4a4a;
}
.ext-badge {
  background: #efefef;
  padding: 0.1rem 0.45rem;
  border-radius: 12px;
  text-transform: uppercase;
  font-size: 0.65rem;
  font-weight: 500;
  letter-spacing: 0.02em;
  color: #2b2b2b;
}
.field-group {
  margin-top: 0.25rem;
  display: flex;
  flex-wrap: wrap;
  gap: 0.8rem;
  row-gap: 0.3rem;
}
.field {
  font-size: 0.7rem;
  color: #3a3a3a;
  min-width: 120px;
}
.field-label {
  font-weight: 500;
  color: #6f6f6f;
  margin-right: 0.4rem;
  text-transform: uppercase;
  font-size: 0.65rem;
  letter-spacing: 0.02em;
}
.field-value {
  word-break: break-all;
  color: #222;
}
.field-value.hash {
  font-family: monospace;
  font-size: 0.68rem;
}
.field-value.empty {
  color: #bbb;
  font-style: normal;
}

/* responsive: thumbnail stacks on small screens */
@media (max-width: 560px) {
  .item {
    flex-direction: column;
  }
  .item-thumb {
    width: 100%;
    height: auto;
    aspect-ratio: 16/9;
  }
  .field-group {
    flex-direction: column;
    gap: 0.3rem;
  }
}

/* ── empty / hint state (text only) ──────────────────────────────────────── */
.state-msg {
  text-align: center;
  padding: 2.5rem 1rem;
  color: #777;
  font-size: 0.85rem;
  border-top: 1px solid #eee;
}

/* ── footer minimal ──────────────────────────────────────────────────────── */
footer {
  border-top: 1px solid #ececec;
  text-align: center;
  font-size: 0.65rem;
  color: #888;
  padding: 1.2rem;
  background: #fff;
}
footer span {
  color: #2c2c2c;
}
</style>
</head>
<body>

<header>
  <a class="logo" href="?">view <em>meento</em></a>
  <nav><a href="index.php">↑ upload</a></nav>
</header>

<main>
  <div class="hero">
    <h1><em>meento</em></h1>
    <p>type — search — browse</p>
  </div>

  <!-- search field -->
  <div class="search-wrap">
    <input id="searchInput" type="text" placeholder="name, description, hash …" autocomplete="off" autofocus>
  </div>

  <!-- pagination (hidden if single file) -->
  <div class="pagination hidden" id="pagination">
    <button class="page-btn" id="prevBtn" disabled>← prev</button>
    <span class="page-info" id="pageInfo">— / —</span>
    <button class="page-btn" id="nextBtn" disabled>next →</button>
  </div>

  <!-- results container -->
  <div id="resultsList">
    <div class="state-msg">🔍 start typing to search the catalogue</div>
  </div>
</main>

<footer>
  © <?= date('Y') ?> <span>meento</span>
</footer>

<script>
(function() {
  'use strict';

  // DOM elements
  const listEl      = document.getElementById('resultsList');
  const searchInput = document.getElementById('searchInput');
  const pagination  = document.getElementById('pagination');
  const prevBtn     = document.getElementById('prevBtn');
  const nextBtn     = document.getElementById('nextBtn');
  const pageSpan    = document.getElementById('pageInfo');

  let currentPage = 1;
  let maxPage     = 1;
  let currentQuery = '';
  let searchDelay  = null;

  // ── helpers: format, escape ──────────────────────────────────────────────
  const escapeHtml = (str) => {
    if (!str) return '';
    return String(str).replace(/[&<>]/g, function(m) {
      if (m === '&') return '&amp;';
      if (m === '<') return '&lt;';
      if (m === '>') return '&gt;';
      return m;
    }).replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, function(c) {
      return c;
    });
  };

  const formatSize = (bytes) => {
    if (!bytes && bytes !== 0) return '';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / 1048576).toFixed(2) + ' MB';
  };

  // ── minimalist card builder (plain, no animations, no extra icons) ───────
  const buildItemCard = (item) => {
    const hash = item.hash || item._file || '';
    const ext = (item.extension || 'bin').toLowerCase();
    const fileUrl = 'files/' + encodeURIComponent(hash) + '.' + ext;
    
    // thumbnail: use actual image if image extension, otherwise fallback to thumbs folder
    const imageExts = ['jpg','jpeg','png','gif','webp','bmp','svg','avif'];
    const thumbSrc = imageExts.includes(ext)
      ? 'files/' + encodeURIComponent(hash) + '.' + ext
      : 'thumbs/' + encodeURIComponent(hash) + '.jpg';
    
    const title = item.original_filename || hash || 'untitled';
    const sizeStr = formatSize(item.size);
    const description = item.description || '';
    const publicKey = item.public_key || '';
    const nodeInfo = item.node_info || '';

    // field row helper (compact)
    const metaField = (label, value, addClass = '') => {
      if (!value) return '';
      const valClass = addClass ? `field-value ${addClass}` : 'field-value';
      return `<div class="field">
        <span class="field-label">${escapeHtml(label)}</span>
        <span class="${valClass}">${escapeHtml(value)}</span>
      </div>`;
    };

    // left thumbnail + right details
    return `
      <a class="item" href="${escapeHtml(fileUrl)}" target="_blank" rel="noopener">
        <div class="item-thumb">
          <img src="${escapeHtml(thumbSrc)}" alt="${escapeHtml(title)}" loading="lazy"
               onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
          <div class="thumb-placeholder">📄</div>
        </div>
        <div class="item-info">
          <div class="item-title">${escapeHtml(title)}</div>
          <div class="item-meta">
            ${sizeStr ? `<span>${escapeHtml(sizeStr)}</span>` : ''}
            <span class="ext-badge">${escapeHtml(ext)}</span>
          </div>
          <div class="field-group">
            ${metaField('hash', hash, 'hash')}
            ${description ? metaField('desc', description) : ''}
            ${publicKey ? metaField('pubkey', publicKey, 'hash') : ''}
            ${nodeInfo ? metaField('node', nodeInfo) : ''}
          </div>
        </div>
      </a>
    `;
  };

  // ── render states ────────────────────────────────────────────────────────
  const renderEmpty = (queryTerm) => {
    const msg = queryTerm
      ? `✗ no results for “${escapeHtml(queryTerm)}”`
      : 'no entries in this file';
    listEl.innerHTML = `<div class="state-msg">${msg}</div>`;
  };

  const renderHint = () => {
    listEl.innerHTML = `<div class="state-msg">🔍 start typing to search</div>`;
  };

  const updatePaginationUI = () => {
    if (maxPage <= 1) {
      pagination.classList.add('hidden');
      return;
    }
    pagination.classList.remove('hidden');
    pageSpan.innerText = `${currentPage} / ${maxPage}`;
    prevBtn.disabled = (currentPage <= 1);
    nextBtn.disabled = (currentPage >= maxPage);
  };

  // ── fetch results (exactly same endpoint logic) ──────────────────────────
  const performSearch = (query, page) => {
    const url = '?q=' + encodeURIComponent(query) + '&p=' + page;
    fetch(url)
      .then(res => res.json())
      .then(data => {
        maxPage = data.max || 1;
        currentPage = data.page || page;
        updatePaginationUI();

        const items = data.results || [];
        if (!items.length) {
          renderEmpty(query);
          return;
        }
        // render list with no animations, just plain cards
        listEl.innerHTML = items.map(item => buildItemCard(item)).join('');
      })
      .catch(() => {
        listEl.innerHTML = '<div class="state-msg">⚠️ search error — try again</div>';
      });
  };

  // ── initialize maxpages (fetch total data files count) ───────────────────
  const initMaxPage = () => {
    fetch('?maxpage=1')
      .then(r => r.json())
      .then(d => {
        maxPage = d.max || 1;
        updatePaginationUI();
      })
      .catch(() => {});
  };

  // ── event handlers ───────────────────────────────────────────────────────
  const onSearchInput = () => {
    clearTimeout(searchDelay);
    currentQuery = searchInput.value.trim();
    currentPage = 1;

    if (currentQuery === '') {
      renderHint();
      updatePaginationUI();
      return;
    }
    searchDelay = setTimeout(() => {
      performSearch(currentQuery, currentPage);
    }, 200);
  };

  const goPrev = () => {
    if (currentPage <= 1) return;
    currentPage--;
    performSearch(currentQuery, currentPage);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const goNext = () => {
    if (currentPage >= maxPage) return;
    currentPage++;
    performSearch(currentQuery, currentPage);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // ── attach listeners ─────────────────────────────────────────────────────
  searchInput.addEventListener('input', onSearchInput);
  prevBtn.addEventListener('click', goPrev);
  nextBtn.addEventListener('click', goNext);
  
  // set initial hint
  renderHint();
  initMaxPage();
})();
</script>
</body>
</html>