﻿# FileHashBuilder

A single-file Java 8 utility that scans a `files/` folder, ensures every file is named after its SHA-256 hash, and generates a companion JSON metadata file for each one inside an `info/` folder.

---

## Requirements

- Java 8 or higher
- No external libraries needed

---

## Directory Structure

Place the following files in the same working directory before running:

```
your-working-dir/
├── FileHashBuilder.java
├── public_key.txt          ← your public key (one line)
├── node_info.txt           ← your node info (one line)
├── files/                  ← put your files here
│   ├── photo.jpg
│   ├── report.pdf
│   └── ...
└── info/                   ← created automatically if missing
```

---

## Configuration Files

| File | Description | JSON field populated |
|---|---|---|
| `public_key.txt` | Your public key value | `public_key` |
| `node_info.txt` | Node identifier/info | `node_info` |

Both files are read from the same directory as the program. If either is missing, a warning is printed and an empty string is used in its place.

---

## How to Compile and Run

```bash
# Compile
javac FileHashBuilder.java

# Run
java FileHashBuilder
```

---

## What It Does

1. **Scans** every file inside the `files/` folder.
2. **Computes** the SHA-256 hash of each file's contents.
3. **Renames** the file to `<sha256>.<extension>` if its current name is not already a valid 64-character hex SHA-256 hash.
4. **Creates** a JSON metadata file at `info/<sha256>.json` for each file.

### Rename rules

| Condition | Result |
|---|---|
| Filename is not a valid SHA-256 | Renamed to `<sha256>.<ext>` |
| Filename is already a valid SHA-256 | Left untouched |
| Rename target already exists on disk | Rename skipped; JSON is still written |

---

## Output JSON Format

Each file produces a JSON like this in the `info/` folder:

```json
{
    "filename": "photo.jpg",
    "size": 1096511,
    "extension": "jpg",
    "date": "2026-06-15T06:23:59+02:00",
    "public_key": "<contents of public_key.txt>",
    "server_public_key": "<sha256 hash of the file>",
    "node_info": "<contents of node_info.txt>",
    "description": ""
}
```

| Field | Source |
|---|---|
| `filename` | Original filename before any rename |
| `size` | File size in bytes |
| `extension` | File extension without the dot |
| `date` | File last-modified time (ISO-8601 with timezone offset) |
| `public_key` | Contents of `public_key.txt` |
| `server_public_key` | SHA-256 hash of the file contents |
| `node_info` | Contents of `node_info.txt` |
| `description` | Empty by default |

---

## Console Output Example

```
[INFO] Processing: photo.jpg
[INFO] Renamed 'photo.jpg' -> 'e3b0c44298fc1c149afb...a97fcbd49.jpg'
[INFO] JSON written: e3b0c44298fc1c149afb...a97fcbd49.json
[INFO] Processing: e3b0c44298fc1c149afb...a97fcbd49.pdf
[INFO] Filename already valid SHA-256, no rename needed.
[INFO] JSON written: e3b0c44298fc1c149afb...a97fcbd49.json
[DONE] Processing complete.
```

### Log prefixes

| Prefix | Meaning |
|---|---|
| `[INFO]` | Normal operation message |
| `[WARN]` | Non-fatal issue (e.g. missing config file) |
| `[SKIP]` | Action skipped (rename target already exists) |
| `[ERROR]` | Something went wrong for this file |
| `[DONE]` | All files processed |