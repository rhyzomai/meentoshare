<?php
declare(strict_types=1);

// -------------------------------------------------------------------------------
//  CONFIGURATIONS & ENVIRONMENT SETUP
// -------------------------------------------------------------------------------
define('DB_HOST', 'localhost');
define('DB_NAME', 'mesh_db');
define('DB_USER', 'root');
define('DB_PASS', '');

class VerificationConfig
{
    public const FILE_SERVERS   = __DIR__ . '/servers.txt';
    public const FILE_PUB_KEY   = __DIR__ . '/public_key.txt';
    public const FILE_NODE_INFO = __DIR__ . '/node_info.txt';
    public const IP_SALT        = '3phem3ra_Secur3_Salt_2026!'; // Change this to your preferred custom salt
    public const MAX_FIELD_LEN  = 512;
}

class FileCheckerEngine
{
    private PDO $db;

public function __construct()
    {
        // 1. Connect to the MySQL server without selecting a specific database first
        $dsnWithoutDb = sprintf("mysql:host=%s;charset=utf8mb4", DB_HOST);
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        
        $initialPdo = new PDO($dsnWithoutDb, DB_USER, DB_PASS, $options);
        
        // 2. Safely execute database creation syntax
        $dbNameSanitized = '`' . str_replace('`', '``', DB_NAME) . '`';
        $initialPdo->exec("CREATE DATABASE IF NOT EXISTS $dbNameSanitized CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        
        // 3. Switch connection context to the targeted database instance
        $initialPdo->exec("USE $dbNameSanitized");
        
        // 4. Ensure structural ledger table exists
        $initialPdo->exec("
            CREATE TABLE IF NOT EXISTS `file_checks` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `file_hash` VARCHAR(64) NOT NULL,
                `filename` VARCHAR(512) NOT NULL,
                `file_size` BIGINT NOT NULL,
                `extension` VARCHAR(255) NOT NULL,
                `public_key` VARCHAR(512) NOT NULL,
                `server_public_key` VARCHAR(512) NOT NULL,
                `node_info` VARCHAR(512) NOT NULL,
                `description` VARCHAR(512) NOT NULL,
                `file_date` VARCHAR(512) NOT NULL,
                `own_public_key` VARCHAR(512) NOT NULL,
                `own_node_info` VARCHAR(512) NOT NULL,
                `data_check` DATETIME NOT NULL,
                `user_ip_hash` VARCHAR(64) NOT NULL,
                `server_ip_hash` VARCHAR(64) NOT NULL,
                `hash_match` TINYINT(1) NOT NULL,
                `server_url` VARCHAR(512) NOT NULL,
                INDEX (`data_check`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");
        
        // 5. Assign initialized connection object instance locally
        $this->db = $initialPdo;
    }

    public static function getClientIpHash(): string
    {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        return hash('sha256', $ip . VerificationConfig::IP_SALT);
    }

    public static function getServerIpHash(string $url): string
    {
        $host = parse_url($url, PHP_URL_HOST) ?: 'unknown';
        $ip = gethostbyname($host);
        return hash('sha256', $ip . VerificationConfig::IP_SALT);
    }

    private function readLocalMetadata(string $path): string
    {
        if (!file_exists($path)) {
            return '';
        }
        return substr(trim((string)file_get_contents($path)), 0, VerificationConfig::MAX_FIELD_LEN);
    }

    /**
     * Streams a remote file to accurately evaluate its SHA-256 hash without overloading memory limits.
     */
    private function verifyRemoteFileHash(string $fileUrl, string $expectedHash): bool
    {
        $ctx = stream_context_create([
            'http' => ['timeout' => 15, 'ignore_errors' => true],
            'ssl'  => ['verify_peer' => false, 'verify_peer_name' => false]
        ]);

        $handle = @fopen($fileUrl, 'rb', false, $ctx);
        if (!$handle) {
            return false;
        }

        $hashCtx = hash_init('sha256');
        while (!feof($handle)) {
            $chunk = fread($handle, 8192);
            if ($chunk !== false) {
                hash_update($hashCtx, $chunk);
            }
        }
        fclose($handle);

        $calculatedHash = hash_final($hashCtx);
        return hash_equals(strtolower($expectedHash), strtolower($calculatedHash));
    }

    public function runSync(): array
    {
        if (!file_exists(VerificationConfig::FILE_SERVERS)) {
            return ['ok' => false, 'error' => 'servers.txt not found.'];
        }

        $servers = array_filter(array_map('trim', file(VerificationConfig::FILE_SERVERS)));
        $ownPublicKey = $this->readLocalMetadata(VerificationConfig::FILE_PUB_KEY);
        $ownNodeInfo = $this->readLocalMetadata(VerificationConfig::FILE_NODE_INFO);
        $userIpHash = self::getClientIpHash();

        $processed = 0;
        $inserted = 0;

        foreach ($servers as $serverUrl) {
            if (empty($serverUrl)) continue;
            $serverUrl = rtrim($serverUrl, '/');
            if (!preg_match('#^https?://#i', $serverUrl)) {
                $serverUrl = 'http://' . $serverUrl;
            }

            $serverIpHash = self::getServerIpHash($serverUrl);
            $filesTxtUrl = $serverUrl . '/files.txt';

            $ctx = stream_context_create([
                'http' => ['timeout' => 10, 'ignore_errors' => true],
                'ssl'  => ['verify_peer' => false, 'verify_peer_name' => false]
            ]);
            
            $filesContent = @file_get_contents($filesTxtUrl, false, $ctx);
            if ($filesContent === false) continue;

            $lines = array_filter(array_map('trim', explode("\n", $filesContent)));

            foreach ($lines as $line) {
                // Extract filename cleanly from formats like "hash.ext" or just plain "hash.ext"
                if (!preg_match('/([a-f0-9]{64})(?:\.([a-z0-9]+))?$/i', $line, $matches)) {
                    continue;
                }

                $fullFilename = $matches[0];
                $expectedHash = $matches[1];
                $processed++;

                // 1. Check if filename matches actual hash of remote file data
                $remoteFileUrl = $serverUrl . '/files/' . $fullFilename;
                $isMatch = $this->verifyRemoteFileHash($remoteFileUrl, $expectedHash);

                // 2. Fetch structural JSON from server
                $jsonUrl = $serverUrl . '/info/' . $expectedHash . '.json';
                $jsonRaw = @file_get_contents($jsonUrl, false, $ctx);
                if ($jsonRaw === false) {
                    continue; // Skip entry: JSON file does not exist
                }

                $meta = json_decode($jsonRaw, true);
                if (!is_array($meta)) {
                    continue; // Skip entry: Invalid structural footprint
                }

                // Required fields validation manifest
                $requiredFields = ['filename', 'size', 'extension', 'public_key', 'server_public_key', 'node_info', 'description', 'date'];
                $isValid = true;
                $sanitizedData = [];

                foreach ($requiredFields as $field) {
                    if (!isset($meta[$field])) {
                        $isValid = false;
                        break;
                    }
                    $value = (string)$meta[$field];
                    if (mb_strlen($value) > VerificationConfig::MAX_FIELD_LEN) {
                        $isValid = false; // Skip entry: Field length exceeds 512 validation window
                        break;
                    }
                    $sanitizedData[$field] = trim($value);
                }

                if (!$isValid) {
                    continue;
                }

                // 3. Write validated tracking state to Node Ledger
                $stmt = $this->db->prepare("
                    INSERT INTO file_checks (
                        file_hash, filename, file_size, extension, public_key, server_public_key, 
                        node_info, description, file_date, own_public_key, own_node_info, 
                        data_check, user_ip_hash, server_ip_hash, hash_match, server_url
                    ) VALUES (
                        :file_hash, :filename, :file_size, :extension, :public_key, :server_public_key, 
                        :node_info, :description, :file_date, :own_public_key, :own_node_info, 
                        NOW(), :user_ip_hash, :server_ip_hash, :hash_match, :server_url
                    )
                ");

                $stmt->execute([
                    ':file_hash'         => $expectedHash,
                    ':filename'          => $sanitizedData['filename'],
                    ':file_size'         => (int)$sanitizedData['size'],
                    ':extension'         => $sanitizedData['extension'],
                    ':public_key'        => $sanitizedData['public_key'],
                    ':server_public_key' => $sanitizedData['server_public_key'],
                    ':node_info'         => $sanitizedData['node_info'],
                    ':description'       => $sanitizedData['description'],
                    ':file_date'         => $sanitizedData['date'],
                    ':own_public_key'    => $ownPublicKey,
                    ':own_node_info'     => $ownNodeInfo,
                    ':user_ip_hash'      => $userIpHash,
                    ':server_ip_hash'    => $serverIpHash,
                    ':hash_match'        => $isMatch ? 1 : 0,
                    ':server_url'        => $serverUrl
                ]);

                $inserted++;
            }
        }

        return ['ok' => true, 'processed' => $processed, 'inserted' => $inserted];
    }

    public function fetchLatestChecks(int $limit = 10): array
    {
        $stmt = $this->db->prepare("SELECT * FROM file_checks ORDER BY data_check DESC LIMIT :limit");
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}

// -- Controller Execution Handler --
$engine = new FileCheckerEngine();
$syncResult = null;

if (isset($_GET['action']) && $_GET['action'] === 'sync') {
    $syncResult = $engine->runSync();
}

$latestEntries = $engine->fetchLatestChecks(10);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mesh Ledger Dashboard</title>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            background-color: #0b0f19;
            color: #cdd6f4;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            padding: 2rem 1.5rem;
            line-height: 1.5;
        }
        .container { max-width: 68rem; margin: 0 auto; width: 100%; }
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #1e1e2e;
            padding-bottom: 1.5rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        h1 { font-size: 1.6rem; font-weight: 700; color: #f5c2e7; letter-spacing: -0.02em; }
        h1 em { font-weight: 300; color: #a6adc8; font-style: normal; }
        .btn {
            display: inline-flex;
            align-items: center;
            padding: 0.5rem 1.2rem;
            background-color: #89b4fa;
            color: #11111b;
            text-decoration: none;
            border-radius: 4px;
            font-size: 0.85rem;
            font-weight: 600;
            transition: opacity 0.2s ease;
            border: none;
            cursor: pointer;
        }
        .btn:hover { opacity: 0.9; }
        .alert {
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1.5rem;
            font-size: 0.9rem;
        }
        .alert-success { background-color: #112b28; border: 1px solid #2e7d32; color: #a6e3a1; }
        .alert-error { background-color: #2d1926; border: 1px solid #f38ba8; color: #f38ba8; }
        
        .table-responsive { width: 100%; overflow-x: auto; background: #11111b; border-radius: 6px; border: 1px solid #1e1e2e; }
        table { width: 100%; border-collapse: collapse; text-align: left; font-size: 0.85rem; }
        th, td { padding: 0.85rem 1rem; border-bottom: 1px solid #1e1e2e; }
        th { background-color: #181825; color: #cba6f7; font-weight: 600; text-transform: uppercase; font-size: 0.75rem; letter-spacing: 0.05em; }
        tr:hover { background-color: #1e1e2e; }
        
        .badge {
            display: inline-block;
            padding: 0.15rem 0.4rem;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .badge-ok { background-color: rgba(166, 227, 161, 0.15); color: #a6e3a1; border: 1px solid rgba(166, 227, 161, 0.3); }
        .badge-fail { background-color: rgba(243, 139, 168, 0.15); color: #f38ba8; border: 1px solid rgba(243, 139, 168, 0.3); }
        
        .file-link { color: #89b4fa; text-decoration: none; word-break: break-all; font-weight: 500; }
        .file-link:hover { text-decoration: underline; }
        .meta-text { color: #6c7086; font-size: 0.75rem; display: block; margin-top: 0.2rem; }
        .hash-truncate { font-family: monospace; color: #f2cdcd; }
        
        footer { margin-top: 3rem; text-align: center; font-size: 0.75rem; color: #585b70; border-top: 1px solid #1e1e2e; padding-top: 1.5rem; }
    </style>
</head>
<body>

<div class="container">
    <header>
        <div>
            <h1>Mesh Ledger <em>Node Checker</em></h1>
            <p style="color: #6c7086; font-size: 0.8rem; margin-top: 0.2rem;">SHA-256 Validation Matrix & Telemetry Storage Engine</p>
        </div>
        <a href="?action=sync" class="btn">
            <svg style="width:14px; height:14px; margin-right:6px; fill:currentColor;" viewBox="0 0 24 24"><path d="M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.97-.7 2.8l1.46 1.46C19.54 15.03 20 13.57 20 12c0-4.42-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6 0-1.01.25-1.97.7-2.8L5.24 7.74C4.46 8.97 4 10.43 4 12c0 4.42 3.58 8 8 8v3l4-4-4-4v3z"/></svg>
            Trigger Network Sync
        </a>
    </header>

    <?php if ($syncResult !== null): ?>
        <?php if ($syncResult['ok']): ?>
            <div class="alert alert-success">
                <strong>Sync completed successfully!</strong> Inspected <?php echo $syncResult['processed']; ?> file registry definitions, logged <?php echo $syncResult['inserted']; ?> newly checked entries to database.
            </div>
        <?php else: ?>
            <div class="alert alert-error">
                <strong>Sync engine runtime alert:</strong> <?php echo htmlspecialchars($syncResult['error']); ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <h2 style="font-size: 1.1rem; margin-bottom: 1rem; color: #cba6f7;">Latest 10 Registry Verifications</h2>
    
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>File Tracking Info</th>
                    <th>Node Source Location</th>
                    <th>Hash Identity Match</th>
                    <th>Encryption Keys & Details</th>
                    <th>Telemetry Log Date</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($latestEntries)): ?>
                    <tr>
                        <td colspan="5" style="text-align: center; color: #6c7086; padding: 2rem;">No logs found inside the verified registry ledger database. Hit "Trigger Network Sync" above.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($latestEntries as $entry): ?>
                        <tr>
                            <td>
                                <a class="file-link" href="<?php echo htmlspecialchars($entry['server_url'] . '/files/' . $entry['filename'] . '.' . $entry['extension']); ?>" target="_blank" rel="noopener noreferrer">
                                    <?php echo htmlspecialchars($entry['filename']); ?>
                                </a>
                                <span class="meta-text">Size: <?php echo number_format($entry['file_size'] / 1024, 2); ?> KB | Ext: .<?php echo htmlspecialchars($entry['extension']); ?></span>
                            </td>
                            <td>
                                <span style="color: #b4befe; font-weight:500;"><?php echo htmlspecialchars(parse_url($entry['server_url'], PHP_URL_HOST)); ?></span>
                                <span class="meta-text hash-truncate">Srv IP Hash: <?php echo substr($entry['server_ip_hash'], 0, 12); ?>...</span>
                            </td>
                            <td>
                                <?php if ($entry['hash_match'] === 1): ?>
                                    <span class="badge badge-ok">MATCH TRUE</span>
                                <?php else: ?>
                                    <span class="badge badge-fail">HASH MISMATCH</span>
                                <?php endif; ?>
                                <span class="meta-text hash-truncate"><?php echo substr($entry['file_hash'], 0, 16); ?>...</span>
                            </td>
                            <td>
                                <span class="meta-text"><strong>User PK:</strong> <?php echo htmlspecialchars($entry['public_key'] ?: 'None'); ?></span>
                                <span class="meta-text"><strong>Desc:</strong> <?php echo htmlspecialchars($entry['description'] ?: 'No Description Provided'); ?></span>
                            </td>
                            <td>
                                <span style="color: #a6adc8;"><?php echo date('Y-m-d H:i:s', strtotime($entry['data_check'])); ?></span>
                                <span class="meta-text hash-truncate">User IP Hash: <?php echo substr($entry['user_ip_hash'], 0, 12); ?>...</span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <footer>
        <p>Mesh Verification Engine Framework � Running on PHP <?php echo PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION; ?></p>
    </footer>
</div>

</body>
</html>