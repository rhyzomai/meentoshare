# Meshare

A small desktop GUI (Java Swing) that browses a decentralized network of file
servers. You give it a list of server URLs; it pulls each server's `files.txt`,
fetches the matching `info/<hash>.json` metadata, and lets you search, browse
and download the files — streaming results in as they arrive.

Single Java 8 source file, no external libraries.

---

## Table of contents

- [Features](#features)
- [Quick start](#quick-start)
- [Project layout on disk](#project-layout-on-disk)
- [Server protocol](#server-protocol)
- [Building and running](#building-and-running)
- [Using the GUI](#using-the-gui)
- [Buttons and actions](#buttons-and-actions)
- [Options](#options)
- [Output structure](#output-structure)
- [Logging](#logging)
- [JSON field handling](#json-field-handling)
- [Limitations](#limitations)
- [Troubleshooting](#troubleshooting)

---

## Features

- Reads `servers.txt` and connects to every server in parallel.
- Streams results into the table as each JSON arrives — no waiting for the
  slowest server.
- Live search across every JSON field, the hash, the date and the server URL.
- `Random tries` mode: sample N files from each server's `files.txt` instead
  of fetching every JSON. Useful when a server has thousands of files and you
  just want to see what's there.
- Double-click a row to download the file from `files/` (and its `info/` JSON).
- Right-click a row for: download this file, download this info JSON only,
  copy hash, copy server URL, or open the file URL in a browser.
- **Download ALL**: re-reads every server's full `files.txt` and saves every
  `files/<name>` and every `info/<hash>.json` to disk.
- **Download MATCHED**: downloads only the entries that match the current
  search filter, using the JSON's `extension` field for the filename.
- Writes a per-file JSON log into `log/` after every successful download.
- Configurable output directory, per-file 200 MB safety cap, cancel button
  that aborts cleanly mid-download.

---

## Quick start

1. Drop a `servers.txt` next to the program. One URL per line, e.g.:
   ```
   http://localhost
   http://localhost/meento/index.php
   http://files.example.com/share
   ```
2. Compile and run:
   ```bash
   javac Meshare.java
   java Meshare
   ```
3. The window opens, starts indexing, and rows stream in. Type in the search
   field to filter.

---

## Project layout on disk

When you start the program, the working directory should look like this:

```
.
├── Meshare.java         (the program)
├── servers.txt          (one server URL per line)
├── downloads/           (created on first run)
│   └── <server-folder>/
│       ├── files/<hash>.<ext>
│       └── info/<hash>.json
└── log/                 (created on first run)
    └── <downloaded-name>.download.json
```

`<server-folder>` is the server URL with the protocol stripped and any
`\ / : * ? " < > |` characters replaced with `_`. For example
`http://localhost/meento/index.php` becomes `localhost_meento_index.php`.

---

## Server protocol

For every base URL `B` in `servers.txt` (a trailing `/` is added automatically
if missing) the program expects:

| URL                         | Contents                                  |
|-----------------------------|-------------------------------------------|
| `B/files.txt`               | One filename per line: `<sha256>.<ext>`   |
| `B/files/<sha256>.<ext>`    | The actual file bytes                     |
| `B/info/<sha256>.json`      | The file's metadata (see below)           |

The hash is the file's SHA-256 (or any opaque ID — the program treats it as a
string and just matches the prefix before the last `.`). The extension is
informational; the JSON's `extension` field is the source of truth for
downloading matched files.

### `info/<hash>.json` schema

The program reads every flat key/value in the object. It recognizes these
fields by name and uses them for columns and downloads:

| Field             | Type    | Used for                                     |
|-------------------|---------|----------------------------------------------|
| `filename`        | string  | The "Filename" column                        |
| `size`            | number  | The "Size" column                            |
| `extension`       | string  | File extension used when downloading matched |
| `public_key`      | string  | Searchable                                   |
| `server_public_key` | string | Searchable                                   |
| `node_info`       | string  | Searchable                                   |
| `description`     | string  | The "Description" column                     |
| `date`            | string  | The "Date" column                            |

Any other top-level fields are kept as-is and contribute to the search index
(up to 512 chars each — see [JSON field handling](#json-field-handling)).

Example:
```json
{
    "filename": "20260328 12 49 43 AM.jpg",
    "size": 89578,
    "extension": "jpg",
    "public_key": "123",
    "server_public_key": "123",
    "node_info": "",
    "description": "test",
    "date": "2026-06-16T05:16:36+02:00"
}
```

---

## Building and running

Requires a JDK 8 or newer on `PATH`. No external libraries.

```bash
# Compile
javac Meshare.java

# Run
java Meshare
```

To make a runnable JAR:

```bash
jar cfe Meshare.jar Meshare Meshare.class
java -jar Meshare.jar
```

If you want to lock the bytecode level to Java 8 (recommended for portability):

```bash
javac -source 8 -target 8 Meshare.java
```

---

## Using the GUI

```
┌───────────────────────────────────────────────────────────────┐
│  [ Search: _______________________________ ] [Search] [Reload]│
│  ☐ Random tries per server  N: [ 20 ]  Output dir: [.../path] │
├───────────────────────────────────────────────────────────────┤
│ Filename        │ Description │ Size  │ Ext │ Date       │Server
│ 20260328 12...  │ test        │ 89578 │ jpg │ 2026-06... │http://...
│ ...                                                          │
├───────────────────────────────────────────────────────────────┤
│ [Download ALL] [Download MATCHED] [Cancel]   <status>  shown/total
└───────────────────────────────────────────────────────────────┘
```

- **Search field**: filters as you type across every JSON field, the hash, the
  date, and the server URL. Case-insensitive.
- **Reload servers**: clears the table and re-indexes from `servers.txt`.
- **Cancel**: flips a cancel flag that workers check between reads; the
  in-flight file finishes or aborts cleanly.
- **Right-click a row**: download this file, download info JSON only, copy
  hash, copy server URL, or open the file URL in a browser.

---

## Buttons and actions

| Button / Action           | What it does                                                                                            |
|---------------------------|---------------------------------------------------------------------------------------------------------|
| **Double-click row**      | Downloads `files/<hash>.<ext>` (ext from JSON) and its `info/<hash>.json` into the output dir.        |
| **Download ALL**          | Re-reads each server's full `files.txt` and saves every `files/<name>` and every `info/<hash>.json`.   |
| **Download MATCHED**      | Saves only the rows currently visible (filtered by the search box), using the JSON `extension` field.  |
| **Right-click → Download file** | Same as double-click, but only the `files/` file (not the info JSON).                              |
| **Right-click → Download info** | Saves just the `info/<hash>.json`.                                                                 |
| **Right-click → Copy hash**    | Copies the hash to the clipboard.                                                              |
| **Right-click → Copy server**  | Copies the server's base URL to the clipboard.                                                 |
| **Right-click → Open in browser** | Opens the `files/<hash>.<ext>` URL in the system browser.                                    |

---

## Options

- **Random tries per server** (off by default): when enabled, after reading
  `files.txt` from a server the program randomly samples N entries (the value
  in the `N:` field) and only fetches those N JSONs. If N is greater than the
  number of entries in `files.txt`, all entries are used.
- **N**: the sample size for random tries. Default is 20.
- **Output dir**: where `downloads/` and `log/` are created. Change with the
  `...` button.

---

## Output structure

```
<output-dir>/
├── downloads/
│   └── <server-folder>/
│       ├── files/<hash>.<ext>
│       └── info/<hash>.json
└── log/
    └── <downloaded-name>.download.json
```

The `<downloaded-name>.download.json` looks like this:

```json
{
  "file": "/abs/path/to/downloads/<server>/files/<hash>.<ext>",
  "url": "http://server/files/<hash>.<ext>",
  "name": "<hash>.<ext>",
  "size": 89578,
  "date": "2026-06-16T13:21:42+03:00",
  "timestamp": 1749732102000
}
```

The log write is best-effort: a log failure never fails the download.

---

## Logging

Every successful download produces a JSON record in `<output-dir>/log/`. The
filename is `<downloaded-name>.download.json` so it sorts naturally next to
the downloaded file. The record contains:

- `file` — absolute path of the saved file
- `url` — the URL it was downloaded from
- `name` — the filename on disk
- `size` — bytes written
- `date` — ISO-8601 timestamp
- `timestamp` — epoch milliseconds

If you want a single combined log instead, just `cat log/*.download.json` —
they're line-delimited-friendly enough to grep / pipe into `jq`.

---

## JSON field handling

- Every top-level field in the `info` JSON is captured.
- **String values longer than 512 characters are truncated to 512 characters**
  when stored in memory and displayed. This is enforced inside the JSON parser
  itself, so a 10 MB string in a single field will not blow up the table.
- Nested objects and arrays are stored as their raw JSON source (also
  truncated to 512 chars).
- Numbers, booleans and `null` are stringified.

If you need the full value of a truncated field, open the saved
`info/<hash>.json` from the `downloads/` folder — only the in-memory display
and search index are truncated.

---

## Limitations

- No HTTPS client certificate support — uses the JVM's default trust store.
- HTTP basic auth is not built in. Pre-authenticate with a header by patching
  `openConn()` if you need it.
- The bundled JSON parser is minimal: it handles the flat-object shape the
  program expects, including escapes, unicode (`\uXXXX`), numbers, booleans
  and `null`. If your server emits deeply nested or exotic JSON, prefer
  round-tripping through `info/<hash>.json` on disk rather than the in-memory
  table.
- The 200 MB per-file safety cap is there to keep a runaway download from
  filling the disk. Bump `MAX_DOWNLOAD_BYTES` in the source if you need more.
- The cancel button is cooperative: it stops dispatching new work and aborts
  the current file, but it does not preempt an in-flight TCP read.

---

## Troubleshooting

- **`servers.txt not found`**: the program looks for `servers.txt` in the
  current working directory. Run it from the same folder, or pass an absolute
  path via `cd`.
- **Empty results**: open the status bar — it shows per-server progress and
  errors. Common causes: server returns 404 for `files.txt`, JSON is
  malformed, or the file is unreachable.
- **Slow first run**: indexing a server with thousands of files means
  thousands of HTTP requests. Use the **Random tries** option to peek first.
- **Permission errors on download**: choose a writable output directory with
  the `...` button next to **Output dir**.
- **`HTTP 4xx/5xx` for one file**: logged in the status bar; the rest of the
  batch continues.

---

## License

Use it however you like. If you ship it, a credit is appreciated.
