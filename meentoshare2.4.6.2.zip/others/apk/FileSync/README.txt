Easily sync with servers. 
Encode files in base64 and chunks in 1000 size for send using GET. 