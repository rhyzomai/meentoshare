﻿<?php
// ─── Config ───────────────────────────────────────────────────────────────────
define('CHUNKS_DIR', __DIR__ . '/chunks');
define('PUBLIC_KEY_FILE', __DIR__ . '/public_key.txt');

// ─── Helpers ──────────────────────────────────────────────────────────────────
function respond($ok, $message) {
    header('Content-Type: application/json');
    echo json_encode(['ok' => $ok, 'message' => $message]);
    exit;
}

// ─── Validate required GET params ─────────────────────────────────────────────
$filename   = isset($_GET['filename'])   ? trim($_GET['filename'])   : '';
$contents   = isset($_GET['contents'])   ? $_GET['contents']         : '';
$public_key = isset($_GET['public_key']) ? trim($_GET['public_key']) : '';

if ($filename === '' || $contents === '' || $public_key === '') {
    respond(false, 'Missing required parameters: filename, contents, public_key');
}

// ─── Validate public key ───────────────────────────────────────────────────────
if (!file_exists(PUBLIC_KEY_FILE)) {
    respond(false, 'Server has no public key configured');
}
$expected_key = trim(file_get_contents(PUBLIC_KEY_FILE));
if ($public_key !== $expected_key) {
    respond(false, 'Invalid public key');
}

// ─── Validate filename format: md5.chunknum.md5[.ext] ─────────────────────────
// Allowed: letters, digits, dots, hyphens only — no slashes, no spaces
if (!preg_match('/^[a-zA-Z0-9.\-]+$/', $filename)) {
    respond(false, 'Invalid filename characters');
}

// Must not escape the chunks directory
$real_dir  = realpath(CHUNKS_DIR);
$dest_path = CHUNKS_DIR . '/' . basename($filename);

// ─── Decode Base64 contents ────────────────────────────────────────────────────
$chunk_data = base64_decode($contents, true);
if ($chunk_data === false) {
    respond(false, 'contents is not valid Base64');
}

// ─── Verify chunk MD5 matches what the filename promises ──────────────────────
// Filename format: <fileMD5>.<chunkIndex>.<chunkMD5>[.ext]
$parts = explode('.', $filename);
if (count($parts) < 3) {
    respond(false, 'Filename does not match expected format: fileMD5.chunkNum.chunkMD5[.ext]');
}
$claimed_chunk_md5 = $parts[2];
$actual_chunk_md5  = md5($chunk_data);
if ($claimed_chunk_md5 !== $actual_chunk_md5) {
    respond(false, 'Chunk MD5 mismatch — data may be corrupted');
}

// ─── Create chunks directory if needed ────────────────────────────────────────
if (!is_dir(CHUNKS_DIR)) {
    if (!mkdir(CHUNKS_DIR, 0755, true)) {
        respond(false, 'Could not create chunks directory');
    }
}

// ─── Write the chunk ──────────────────────────────────────────────────────────
if (file_exists($dest_path)) {
    respond(true, 'Chunk already exists: ' . $filename);
}

$written = file_put_contents($dest_path, $chunk_data);
if ($written === false) {
    respond(false, 'Failed to write chunk: ' . $filename);
}

respond(true, 'Chunk saved: ' . $filename . ' (' . $written . ' bytes)');