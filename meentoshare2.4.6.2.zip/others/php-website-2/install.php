<?php
/**
 * Meento Share - Verificador de instalação
 * Apenas abre o config.php (que cria o schema) e mostra o status.
 */
require_once __DIR__ . '/config.php';

$tables = ['users', 'payments', 'balance_transactions', 'file_interactions', 'file_registry'];
$status = [];
foreach ($tables as $t) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = ? AND table_name = ?");
    $stmt->execute([$db_name, $t]);
    $status[$t] = ((int)$stmt->fetchColumn() > 0);
}

$allOk = !in_array(false, $status, true);

echo render_header('Verificação de instalação', $pdo);
?>
<div class="card" style="max-width: 720px; margin: 30px auto;">
    <h1>🔧 Verificação de instalação</h1>
    <p class="muted">
        Esta página apenas garante que o banco de dados <code><?= h($db_name) ?></code>
        e as tabelas existem. Se algo estiver faltando, o <code>config.php</code> cria
        automaticamente ao ser carregado por qualquer página do site.
    </p>

    <table>
        <thead><tr><th>Tabela</th><th>Status</th></tr></thead>
        <tbody>
            <?php foreach ($status as $t => $ok): ?>
                <tr>
                    <td><code><?= h($t) ?></code></td>
                    <td>
                        <?php if ($ok): ?>
                            <span class="badge badge-ext">OK</span>
                        <?php else: ?>
                            <span class="badge badge-danger">AUSENTE</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="divider"></div>

    <?php if ($allOk): ?>
        <div class="alert success">
            ✅ Tudo certo! Sua instalação do Meento Share está pronta.
        </div>
        <p>Próximos passos:</p>
        <ol>
            <li>Faça login como admin: <strong><?= h(ADMIN_EMAIL) ?></strong> / <strong><?= h(ADMIN_PASSWORD) ?></strong></li>
            <li>Altere a senha do admin em <code>config.php</code> e crie um hash novo para o usuário.</li>
            <li>Popule <code>file_registry</code> rodando a sincronização original ou inserindo registros manualmente.</li>
        </ol>
        <a href="<?= url('index.php') ?>" class="btn btn-primary">Ir para a página inicial</a>
    <?php else: ?>
        <div class="alert error">
            ❌ Algumas tabelas estão faltando. Tente acessar qualquer página do site (ex.: <code>index.php</code>)
            para que o <code>config.php</code> tente criar tudo novamente.
        </div>
    <?php endif; ?>
</div>
<?= render_footer(); ?>
