<?php declare(strict_types=1);

// -------------------------------------------------------------------------------
//  MESH NODE � file replication over HTTP/HTTPS
//  Single-file PHP 7+ application
// -------------------------------------------------------------------------------

// Remove this line to avoid creating duplicate files in the 'users' directory.
@include_once __DIR__ . '/user_files.php';

class MeshConfig
{
    public const DIR_FILES       = __DIR__ . '/files';
    public const DIR_INFO        = __DIR__ . '/info';
    public const FILE_INDEX      = __DIR__ . '/files.txt';
    public const FILE_DATA_JSON  = __DIR__ . '/data.json';
    public const FILE_SERVERS    = __DIR__ . '/servers.txt';
    public const FILE_PUB_KEY    = __DIR__ . '/public_key.txt';
    public const FILE_NODE_INFO  = __DIR__ . '/node_info.txt';

    public const MAX_FILE_SIZE   = 1073741824; // 1 GB in bytes
    public const MAX_TEXT_LEN    = 512;        // Characters
    public const BLOCKED_EXT     = ['php', 'php3', 'php4', 'php5', 'php7', 'phtml', 'phar'];
}

class MeshNode
{
    public static function bootstrap(): void
    {
        foreach ([MeshConfig::DIR_FILES, MeshConfig::DIR_INFO] as $dir) {
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
        }
        if (!file_exists(MeshConfig::FILE_INDEX)) {
            file_put_contents(MeshConfig::FILE_INDEX, '');
        }
    }

    public static function handleRequest(): void
    {
        if (isset($_GET['node_status'])) {
            self::handleStatusRequest();
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
            $isPeerPush = isset($_POST['peer_push']) && $_POST['peer_push'] === '1';
            self::handleUpload($_FILES['file'], $_POST, $isPeerPush);
        }
    }

    private static function handleStatusRequest(): void
    {
        self::jsonOut([
            'public_key' => self::readOptionalFile(MeshConfig::FILE_PUB_KEY) !== '',
            'node_info'  => self::readOptionalFile(MeshConfig::FILE_NODE_INFO) !== '',
            'peers'      => count(self::loadServers()),
        ]);
    }

    private static function handleUpload(array $upload, array $postData, bool $isPeerPush): void
    {
        // 1. Validate Upload Errors
        if ($upload['error'] !== UPLOAD_ERR_OK) {
            $msg = ($upload['error'] === UPLOAD_ERR_INI_SIZE || $upload['error'] === UPLOAD_ERR_FORM_SIZE)
                ? 'File exceeds server configuration size limits.'
                : 'Upload error code: ' . $upload['error'];
            self::jsonOut(['ok' => false, 'error' => $msg], 400);
        }

        // 2. Validate File Size limit
        if ($upload['size'] > MeshConfig::MAX_FILE_SIZE) {
            self::jsonOut(['ok' => false, 'error' => 'File exceeds the 1GB size limit.'], 400);
        }

        // 3. Validate Extension
        $ext = self::safeExt($upload['name']);
        if (in_array($ext, MeshConfig::BLOCKED_EXT, true)) {
            self::jsonOut(['ok' => false, 'error' => 'PHP files are strictly blocked.'], 400);
        }

        // 4. Sanitize Input Fields
        $description = self::sanitize($postData['description'] ?? $postData['comment'] ?? '');
        $userPubKey  = self::sanitize($postData['public_key'] ?? '');
        $nodeInfo    = self::sanitize($postData['node_info'] ?? self::readOptionalFile(MeshConfig::FILE_NODE_INFO));
        
        // As per spec: server_public_key is ALWAYS loaded from local file.
        $serverPubKey = self::sanitize(self::readOptionalFile(MeshConfig::FILE_PUB_KEY));

        // 5. Store Locally
        $local = self::storeLocally(
            $upload['tmp_name'],
            $upload['name'],
            $description,
            $userPubKey,
            $serverPubKey,
            $nodeInfo
        );

        if (!$local['ok']) {
            self::jsonOut($local, 500);
        }

        // 6. Handle successful local storage
        if (!$local['existed']) {
            self::appendFilesAndDataJson($local['hash']);
        }

        if ($isPeerPush) {
            // Peer push completes here.
            self::jsonOut($local, 200);
        }

        // 7. Browser Request: Respond immediately, then background propagate
        $servers = self::loadServers();
        $storedPath = MeshConfig::DIR_FILES . '/' . $local['filename'];

        $responsePayload = json_encode(array_merge($local, [
            'peers_total' => count($servers),
            'peers'       => [],
        ]), JSON_UNESCAPED_UNICODE);

        http_response_code(200);
        header('Content-Type: application/json');
        header('Content-Length: ' . strlen($responsePayload));
        header('Connection: close');
        echo $responsePayload;

        if (ob_get_level()) {
            ob_end_flush();
        }
        flush();

        // 8. Propagate to peers
        if (!$local['existed']) {
            ignore_user_abort(true);
            foreach ($servers as $server) {
                self::pushToServer($server, $storedPath, $upload['name'], $description, $userPubKey, $nodeInfo);
            }
        }
        exit;
    }

    private static function storeLocally(
        string $tmpPath,
        string $originalName,
        string $description,
        string $userPubKey,
        string $serverPubKey,
        string $nodeInfo
    ): array {
        $ext = self::safeExt($originalName);
        $hash = hash_file('sha256', $tmpPath);
        $baseName = $ext !== '' ? "{$hash}.{$ext}" : $hash;
        
        $destFile = MeshConfig::DIR_FILES . '/' . $baseName;
        $destInfo = MeshConfig::DIR_INFO  . '/' . $hash . '.json';

        $existed = file_exists($destFile);

        if (!$existed) {
            if (!copy($tmpPath, $destFile)) {
                return ['ok' => false, 'error' => 'Could not write file to disk.'];
            }
            self::appendIndex($baseName);
        }

        if (!file_exists($destInfo)) {
            $info = [
                'filename'          => self::sanitize($originalName),
                'size'              => (int) filesize($destFile),
                'extension'         => self::sanitize($ext),
                'public_key'        => $userPubKey,
                'server_public_key' => $serverPubKey,
                'node_info'         => $nodeInfo,
                'description'       => $description,
                'date'              => date('c'), // ISO 8601 Timestamp
            ];
            file_put_contents($destInfo, json_encode($info, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }

        return ['ok' => true, 'hash' => $hash, 'filename' => $baseName, 'existed' => $existed];
    }

    private static function pushToServer(
        string $server,
        string $filePath,
        string $filename,
        string $description,
        string $userPubKey,
        string $nodeInfo
    ): void {
        $boundary = '----MeshBoundary' . bin2hex(random_bytes(12));
        $body = '';

        $mime  = @mime_content_type($filePath) ?: 'application/octet-stream';
        $body .= "--{$boundary}\r\n";
        $body .= 'Content-Disposition: form-data; name="file"; filename="' . addslashes($filename) . "\"\r\n";
        $body .= "Content-Type: {$mime}\r\n\r\n";
        $body .= file_get_contents($filePath) . "\r\n";

        $fields = [
            'description' => $description,
            'public_key'  => $userPubKey,
            'node_info'   => $nodeInfo,
            'peer_push'   => '1',
        ];

        foreach ($fields as $name => $value) {
            $body .= "--{$boundary}\r\n";
            $body .= "Content-Disposition: form-data; name=\"{$name}\"\r\n\r\n";
            $body .= $value . "\r\n";
        }
        $body .= "--{$boundary}--\r\n";

        $url = rtrim($server, '/') . '/' . basename(__FILE__);
        $ctx = stream_context_create([
            'http' => [
                'method'        => 'POST',
                'header'        => implode("\r\n", [
                    "Content-Type: multipart/form-data; boundary={$boundary}",
                    "Content-Length: " . strlen($body),
                    "X-Mesh-Node: 1",
                ]),
                'content'       => $body,
                'timeout'       => 20,
                'ignore_errors' => true,
            ],
            'ssl'  => [
                'verify_peer'      => false,
                'verify_peer_name' => false,
            ],
        ]);

        @file_get_contents($url, false, $ctx);
    }

    private static function appendFilesAndDataJson(string $hash): void
    {
        ob_start();
        $prev = error_reporting(0);
        try {
            $infoPath = MeshConfig::DIR_INFO . '/' . $hash . '.json';
            $raw = @file_get_contents($infoPath);
            if ($raw === false) return;

            $info = json_decode($raw, true);
            if (!is_array($info)) return;

            $ext = $info['extension'] ?? '';
            $baseName = $ext !== '' ? "{$hash}.{$ext}" : $hash;
            self::appendIndex($baseName);

            $entry = array_merge(['hash' => $hash], $info);
            $dataJson = MeshConfig::FILE_DATA_JSON;

            if (!file_exists($dataJson)) {
                file_put_contents($dataJson, "[\n]", LOCK_EX);
            }

            $fp = @fopen($dataJson, 'c+');
            if ($fp === false || !flock($fp, LOCK_EX)) {
                if ($fp) fclose($fp);
                return;
            }

            $content = rtrim((string) stream_get_contents($fp));
            $closingPos = strrpos($content, ']');
            $encoded = json_encode($entry, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            $indented = implode("\n", array_map(static function(string $l) { return '    ' . $l; }, explode("\n", $encoded)));

            if ($closingPos === false || trim(substr($content, 1, $closingPos - 1)) === '') {
                $newContent = "[\n" . $indented . "\n]";
            } else {
                $newContent = rtrim(substr($content, 0, $closingPos)) . ",\n" . $indented . "\n]";
            }

            rewind($fp);
            ftruncate($fp, 0);
            fwrite($fp, $newContent);
            flock($fp, LOCK_UN);
            fclose($fp);
        } finally {
            error_reporting($prev);
            ob_end_clean();
        }
    }

    // -- Helper Utilities --

    private static function sanitize(string $input): string
    {
        return substr(trim($input), 0, MeshConfig::MAX_TEXT_LEN);
    }

    private static function safeExt(string $filename): string
    {
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        return substr(preg_replace('/[^a-z0-9]/', '', $ext), 0, MeshConfig::MAX_TEXT_LEN);
    }

    private static function readOptionalFile(string $path): string
    {
        return file_exists($path) ? trim((string) file_get_contents($path)) : '';
    }

    private static function appendIndex(string $entry): void
    {
        $lines = file_exists(MeshConfig::FILE_INDEX)
            ? array_map('trim', file(MeshConfig::FILE_INDEX, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES))
            : [];
        if (!in_array($entry, $lines, true)) {
            file_put_contents(MeshConfig::FILE_INDEX, $entry . PHP_EOL, FILE_APPEND | LOCK_EX);
        }
    }

    private static function loadServers(): array
    {
        if (!file_exists(MeshConfig::FILE_SERVERS)) return [];
        $lines = file(MeshConfig::FILE_SERVERS, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $out = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line !== '') {
                if (!preg_match('#^https?://#i', $line)) $line = 'http://' . $line;
                $out[] = rtrim($line, '/');
            }
        }
        return array_unique($out);
    }

    private static function jsonOut(array $data, int $code = 200): void
    {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// -- Application Initialization ------------------------------------------------
MeshNode::bootstrap();
MeshNode::handleRequest();

// -------------------------------------------------------------------------------
//  HTML FRONT-END
// -------------------------------------------------------------------------------
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Mesh Node</title>
<style>
/* �� minimalist reset �� */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{min-height:100%;background:#fff;color:#111;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
body{display:flex;flex-direction:column;align-items:center;padding:2rem 1.5rem}

/* �� container �� */
.page{max-width:36rem;width:100%}

/* �� header �� */
header{margin-bottom:2rem;display:flex;align-items:baseline;justify-content:space-between;flex-wrap:wrap;gap:0.8rem}
h1{font-size:1.4rem;font-weight:700;letter-spacing:-0.02em}
h1 em{font-weight:400;color:#555;font-style:normal}
.sub{font-size:0.8rem;color:#777;margin-top:0.2rem}

/* �� nav menu �� */
.head-nav {display:flex;gap:1rem;align-items:center; flex-wrap: wrap;}
.head-nav a {font-size:0.85rem;color:#0044cc;text-decoration:none;font-weight:500;}
.head-nav a:hover {text-decoration:underline;}

/* �� node status bar �� */
#node-bar{display:flex;gap:0.75rem;flex-wrap:wrap;margin-bottom:1.75rem;font-size:0.8rem;color:#555}
.nb-pill{display:flex;align-items:center;gap:0.35rem;padding:0.25rem 0.6rem;background:#f5f5f5;border-radius:4px;border:1px solid #e0e0e0}
.nb-dot{width:7px;height:7px;border-radius:50%;background:#aaa}
.nb-dot.ok{background:#1a8e3f}
.nb-dot.blue{background:#0044cc}
.nb-val{font-weight:500}

/* �� drop zone �� */
#drop-zone{border:2px dashed #ccc;border-radius:6px;padding:2rem 1rem;text-align:center;cursor:pointer;transition:border-color 0.2s,background 0.2s}
#drop-zone:hover,#drop-zone:focus{background:#fafafa;border-color:#999}
#drop-zone.over{border-color:#0044cc;background:#f0f4ff}
.dz-icon{margin-bottom:0.75rem;font-size:1.8rem;color:#777}
.dz-title{font-size:1rem;font-weight:600;margin-bottom:0.3rem}
.dz-sub{font-size:0.8rem;color:#666;line-height:1.5}
.dz-sub b{color:#0044cc;font-weight:600}
#file-input{display:none}

/* �� upload panel �� */
#panel{display:none;margin-top:1.25rem;border:1px solid #ddd;border-radius:6px;overflow:hidden}
.panel-top{display:flex;align-items:center;gap:0.8rem;padding:0.8rem 1rem;border-bottom:1px solid #eee}
.f-icon{width:2rem;height:2rem;background:#f0f4ff;border-radius:4px;display:grid;place-items:center;flex-shrink:0;font-size:1rem;color:#0044cc}
#f-name{font-size:0.9rem;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#f-size{font-size:0.8rem;color:#777;flex-shrink:0}
.x-btn{background:none;border:none;cursor:pointer;font-size:1.2rem;color:#999;padding:0 0.2rem;transition:color 0.15s}
.x-btn:hover{color:#d00}

/* �� metadata pills �� */
.meta-pills{padding:0.5rem 1rem;display:flex;gap:0.5rem;flex-wrap:wrap;border-bottom:1px solid #eee;background:#fafafa;align-items: center;}
.mpill{font-size:0.75rem;padding:0.2rem 0.6rem;border-radius:4px;border:1px solid #ddd;color:#555;background:#fff;display:flex;align-items:center;gap:0.3rem}
.mpill.has{border-color:#1a8e3f;color:#1a8e3f;background:#f0fff0}
.mpill svg{width:0.9rem;height:0.9rem;stroke:currentColor;fill:none;stroke-width:2.5;stroke-linecap:round;stroke-linejoin:round}
.input-inline{flex:1;min-width:150px;padding:0.3rem 0.5rem;border:1px solid #ccc;border-radius:4px;font-family:inherit;font-size:0.78rem;outline:none;color:#333;background:#fff;transition:border-color 0.2s}
.input-inline:focus{border-color:#0044cc}

/* �� description �� */
.panel-mid{padding:1rem}
.fl{display:block;font-size:0.75rem;color:#777;margin-bottom:0.5rem}
textarea#comment-box{width:100%;min-height:5rem;padding:0.6rem 0.8rem;border:1px solid #ccc;border-radius:4px;font-family:inherit;font-size:0.9rem;resize:vertical;outline:none;transition:border-color 0.2s}
textarea#comment-box:focus{border-color:#0044cc}
.cmeta{display:flex;justify-content:space-between;margin-top:0.4rem;font-size:0.75rem;color:#999}
.ccount.over{color:#d00}

/* �� panel footer �� */
.panel-bot{padding:0.8rem 1rem;border-top:1px solid #eee;display:flex;align-items:center;justify-content:space-between;gap:0.8rem}
.peer-info{font-size:0.8rem;color:#555}
.peer-info b{font-weight:600}
.btn-send{padding:0.5rem 1.2rem;background:#0044cc;color:#fff;border:none;border-radius:4px;font-weight:600;font-size:0.85rem;cursor:pointer;transition:opacity 0.2s;display:flex;align-items:center;gap:0.4rem}
.btn-send:hover{opacity:0.9}
.btn-send.busy{opacity:0.5;pointer-events:none}
.btn-send svg{width:1rem;height:1rem;stroke:#fff;stroke-width:2.2;fill:none;stroke-linecap:round;stroke-linejoin:round}

/* �� progress bar �� */
#prog-wrap{height:3px;background:#eee;border-radius:3px;overflow:hidden;display:none;margin-top:1rem}
#prog-bar{height:100%;width:0%;background:#0044cc;transition:width 0.1s linear}

/* �� status message �� */
#status{display:none;margin-top:1rem;padding:0.8rem 1rem;border-radius:4px;font-size:0.9rem;line-height:1.5;animation:fadeUp 0.25s ease}
#status.ok{background:#f0fff0;border:1px solid #c0e0c0;color:#1a8e3f}
#status.fail{background:#fff0f0;border:1px solid #e0c0c0;color:#d00}
.hash-line{margin-top:0.6rem}
.file-link{display:inline-flex;align-items:center;gap:0.4rem;padding:0.4rem 1rem;font-size:0.85rem;text-decoration:none;color:#0044cc;border:1px solid #0044cc;border-radius:4px;transition:background 0.15s}
.file-link:hover{background:#f0f4ff}
.file-link svg{width:0.9rem;height:0.9rem;stroke:currentColor;stroke-width:2.2;fill:none;stroke-linecap:round;stroke-linejoin:round}

/* �� info box �� */
.json-preview{margin-top:2rem;border:1px solid #ddd;border-radius:4px;overflow:hidden}
.json-preview-head{padding:0.5rem 1rem;border-bottom:1px solid #eee;font-size:0.75rem;color:#777;background:#fafafa;display:flex;align-items:center;gap:0.4rem}
.json-preview-head svg{width:0.9rem;height:0.9rem;stroke:#777;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
pre#json-schema{padding:1rem;font-family:"SF Mono","Fira Code","Fira Mono","Roboto Mono",monospace;font-size:0.8rem;line-height:1.6;color:#333;overflow-x:auto;margin:0}
.jk{color:#0044cc} .js{color:#1a8e3f} .jn{color:#b04000} .jb{color:#d00}

/* �� footer �� */
footer{border-top:1px solid #eee;padding-top:1.2rem;margin-top:2rem;display:flex;justify-content:space-between;flex-wrap:wrap;gap:0.5rem;font-size:0.75rem;color:#aaa}

@keyframes fadeUp{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
</style>
</head>
<body>
<div class="page">

<header>
  <div>
    <h1>Mesh <em>Node</em></h1>
    <p class="sub">Peer replication � SHA-256 storage</p>
  </div>
  <nav class="head-nav">
    <a href="index.php">Upload</a>
    <a href="view.php">Search</a>
    <a href="user_files.php">Users</a>
    <a href="servers.php">Servers</a>
    <a href="panel.php">Panel</a>
    <a href="sync.php">Sync</a>
    <a href="dashboard.php">Dashboard</a>
    <a href="indexer.php">Indexer</a> 
    <a href="feed_full.php">Feed</a>
    <a href="index_full.php">Account</a>
  </nav>
</header>

<div id="node-bar">
  <div class="nb-pill">
    <span class="nb-dot blue"></span>
    peers <span class="nb-val" id="nb-peers">�</span>
  </div>
  <div class="nb-pill">
    <span class="nb-dot" id="nb-pk-dot"></span>
    public_key.txt <span class="nb-val" id="nb-pk">�</span>
  </div>
  <div class="nb-pill">
    <span class="nb-dot" id="nb-ni-dot"></span>
    node_info.txt <span class="nb-val" id="nb-ni">�</span>
  </div>
</div>

<div id="drop-zone" tabindex="0" role="button" aria-label="Select or drop a file">
  <div class="dz-icon">??</div>
  <p class="dz-title">Drop a file or click to select</p>
  <p class="dz-sub">Max Size: <b>1GB</b> � pushed to all peers � <b>.php</b> blocked</p>
</div>
<input type="file" id="file-input">

<div id="panel">
  <div class="panel-top">
    <div class="f-icon">??</div>
    <span id="f-name">�</span>
    <span id="f-size"></span>
    <button class="x-btn" id="x-btn" aria-label="Remove file">?</button>
  </div>

  <div class="meta-pills">
    <input type="text" class="input-inline" id="pk-inline" maxlength="512" placeholder="Your Public Key (Optional)�">
    <div class="mpill" id="mpill-ni">
      <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
      node_info
    </div>
    <div class="mpill has">
      <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
      metadata extracted
    </div>
  </div>

  <div class="panel-mid">
    <label class="fl" for="comment-box">Description <span style="color:#aaa">(optional � max 512 chars)</span></label>
    <textarea id="comment-box" placeholder="Add an optional description for this file�"></textarea>
    <div class="cmeta">
      <span>Stored as �description� field</span>
      <span class="ccount" id="ccount">0 / 512</span>
    </div>
  </div>

  <div class="panel-bot">
    <span class="peer-info">Sending to <b id="peer-count">�</b> peer(s)</span>
    <button class="btn-send" id="send-btn">
      <svg viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
      Send to network
    </button>
  </div>
</div>

<div id="prog-wrap"><div id="prog-bar"></div></div>
<div id="status"></div>

<div class="json-preview">
  <div class="json-preview-head">
    <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
    info/&lt;hash&gt;.json � structured layout
  </div>
  <pre id="json-schema">{
  <span class="jk">"filename"</span>:          <span class="js">"photo.jpg"</span>,
  <span class="jk">"size"</span>:              <span class="jn">204800</span>,
  <span class="jk">"extension"</span>:         <span class="js">"jpg"</span>,
  <span class="jk">"public_key"</span>:        <span class="js">"&lt;user input from form (max 512)&gt;"</span>,
  <span class="jk">"server_public_key"</span>: <span class="js">"&lt;loaded from public_key.txt&gt;"</span>,
  <span class="jk">"node_info"</span>:         <span class="js">"&lt;loaded from node_info.txt&gt;"</span>,
  <span class="jk">"description"</span>:       <span class="js">"&lt;user description (max 512)&gt;"</span>,
  <span class="jk">"date"</span>:              <span class="js">"2026-06-15T11:25:10-03:00"</span>
}</pre>
</div>

</div><footer class="page">
  <p>Mesh Node � Object Oriented � 1GB Limit � Strict PHP 7+</p>
  <p>PHP <?php echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION; ?></p>
</footer>

<script>
(function(){
'use strict';

const dz       = document.getElementById('drop-zone');
const fi       = document.getElementById('file-input');
const panel    = document.getElementById('panel');
const fName    = document.getElementById('f-name');
const fSize    = document.getElementById('f-size');
const xBtn     = document.getElementById('x-btn');
const commentB = document.getElementById('comment-box');
const ccount   = document.getElementById('ccount');
const sendBtn  = document.getElementById('send-btn');
const peerCnt  = document.getElementById('peer-count');
const status   = document.getElementById('status');
const progWrap = document.getElementById('prog-wrap');
const progBar  = document.getElementById('prog-bar');
const mpillNi  = document.getElementById('mpill-ni');
const pkInline = document.getElementById('pk-inline');

const MAX_CHARS = 512;
const MAX_BYTES = 1073741824; // 1 GB
const BLOCKED   = ['php','php3','php4','php5','php7','phtml','phar'];

let file = null;
let ns   = { public_key: false, node_info: false, peers: 0 };

// -- fetch node status ----------------------------------------------------------
fetch(window.location.href + '?node_status=1')
  .then(r => r.json())
  .then(d => {
    ns = d;
    document.getElementById('nb-peers').textContent = d.peers;
    peerCnt.textContent = d.peers;

    const dot = (id, ok) => {
      const el = document.getElementById(id);
      if(el) el.className = 'nb-dot ' + (ok ? 'ok' : '');
    };
    dot('nb-pk-dot', d.public_key);
    dot('nb-ni-dot', d.node_info);
    document.getElementById('nb-pk').textContent = d.public_key ? '? found' : '� missing';
    document.getElementById('nb-ni').textContent = d.node_info  ? '? found' : '� missing';
    mpillNi.className = 'mpill ' + (ns.node_info ? 'has' : '');
  })
  .catch(() => {
    ['nb-peers','nb-pk','nb-ni'].forEach(id => {
      const el = document.getElementById(id); if(el) el.textContent='?';
    });
    peerCnt.textContent = '?';
  });

function fmt(b){
  if(b<1024) return b+' B';
  if(b<1048576) return (b/1024).toFixed(1)+' KB';
  if(b<1073741824) return (b/1048576).toFixed(2)+' MB';
  return (b/1073741824).toFixed(2)+' GB';
}

function extOf(n){ return n.split('.').pop().toLowerCase(); }

function setFile(f){
  if(!f) return;
  if(BLOCKED.includes(extOf(f.name))){ show('fail','PHP files are strictly blocked.'); return; }
  if(f.size > MAX_BYTES){ show('fail', 'File exceeds the 1GB size limit.'); return; }
  
  file = f;
  fName.textContent = f.name;
  fSize.textContent = fmt(f.size);
  panel.style.display = 'block';
  commentB.value = '';
  updateCount();
  hide();
}

function clear(){
  file = null; fi.value = '';
  panel.style.display = 'none';
  commentB.value = '';
  pkInline.value = '';
}

dz.addEventListener('click', () => fi.click());
dz.addEventListener('keydown', e => { if(e.key==='Enter'||e.key===' ') fi.click(); });
fi.addEventListener('change', () => { if(fi.files[0]) setFile(fi.files[0]); });
xBtn.addEventListener('click', clear);

['dragenter','dragover'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.add('over'); }));
['dragleave','drop'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.remove('over'); }));
dz.addEventListener('drop', e => { if(e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]); });

function updateCount(){
  const len = [...commentB.value].length; // Account for unicode characters accurately
  ccount.textContent = len.toLocaleString() + ' / ' + MAX_CHARS;
  ccount.classList.toggle('over', len > MAX_CHARS);
}
commentB.addEventListener('input', updateCount);

function show(type, html){ status.className=type; status.innerHTML=html; status.style.display='block'; }
function hide(){ status.style.display='none'; }

sendBtn.addEventListener('click', () => {
  if(!file) return;
  
  const descText = commentB.value.trim();
  if([...descText].length > MAX_CHARS){
    show('fail','Description exceeds the 512 character limit.'); return;
  }

  const fd = new FormData();
  fd.append('file', file);
  fd.append('description', descText);
  
  const userPk = pkInline.value.trim();
  if (userPk !== '') {
    fd.append('public_key', userPk.slice(0, MAX_CHARS));
  }

  const xhr = new XMLHttpRequest();
  sendBtn.classList.add('busy');
  sendBtn.lastChild.textContent = ' Transmitting�';
  progWrap.style.display = 'block';
  progBar.style.width = '0%';
  hide();

  xhr.upload.addEventListener('progress', e => {
    if(e.lengthComputable) progBar.style.width = Math.round(e.loaded/e.total*100)+'%';
  });

  xhr.addEventListener('load', () => {
    sendBtn.classList.remove('busy');
    sendBtn.lastChild.textContent = ' Send to network';
    progBar.style.width = '100%';
    setTimeout(() => { progWrap.style.display='none'; progBar.style.width='0%'; }, 700);

    let res;
    try {
      const raw = xhr.responseText.replace(/^[\s\S]*?(\{)/, '$1');
      res = JSON.parse(raw);
    } catch(e){
      const m = xhr.responseText.match(/"filename"\s*:\s*"([^"]+)"/);
      if(m){
        showLink(m[1], false);
        clear(); return;
      }
      show('fail','Unexpected server response.'); return;
    }
    if(!res.ok){ show('fail','? '+(res.error||'Unknown error')); return; }

    showLink(res.filename, !!res.existed);
    clear();
  });

  xhr.addEventListener('error', () => {
    sendBtn.classList.remove('busy');
    sendBtn.lastChild.textContent = ' Send to network';
    show('fail','? Network error.'); progWrap.style.display='none';
  });

  xhr.open('POST', window.location.href);
  xhr.send(fd);
});

function showLink(filename, existed){
  const fileUrl = 'files/' + esc(filename);
  const note    = existed ? ' <span style="opacity:0.6">(already stored)</span>' : '';
  show('ok',
    '? File stored' + note +
    '<div class="hash-line">' +
      '<a class="file-link" href="' + fileUrl + '" target="_blank" rel="noopener noreferrer">' +
        '<svg viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>' +
        'Open file in new tab' +
      '</a>' +
    '</div>'
  );
}

function esc(s){
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

})();
</script>
</body>
</html>