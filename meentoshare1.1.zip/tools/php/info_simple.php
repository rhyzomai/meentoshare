<?php
if (!isset($_GET['info'])) {
    echo "Error: Missing 'info' GET parameter.";
    exit;
}

$raw = $_GET['info'];
$data = json_decode($raw, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    echo "Error: Invalid JSON - " . json_last_error_msg();
    exit;
}

$required = ['filename', 'filesize', 'sha256', 'sender', 'receiver', 'timestamp'];
foreach ($required as $field) {
    if (!isset($data[$field])) {
        echo "Error: Missing required field '$field'.";
        exit;
    }
}

$dir = __DIR__ . '/get_blocks';
if (!is_dir($dir)) {
    if (!mkdir($dir, 0755, true)) {
        echo "Error: Could not create directory 'get_blocks'.";
        exit;
    }
}

$filename = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $data['sha256']) . '.json';
$filepath = $dir . '/' . $filename;

if (file_exists($filepath)) {
    echo "Info: Record already exists. No changes made.";
    echo "<br>File: " . htmlspecialchars($filename);
    exit;
}

$fh = fopen($filepath, 'x');
if ($fh === false) {
    echo "Error: Could not create file (may already exist or permission denied).";
    exit;
}

$json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
fwrite($fh, $json);
fclose($fh);

echo "Success: Record saved.";
echo "<br>File: " . htmlspecialchars($filename);
echo "<br>SHA256: " . htmlspecialchars($data['sha256']);
echo "<br>Filename: " . htmlspecialchars($data['filename']);
echo "<br>Filesize: " . htmlspecialchars($data['filesize']) . " bytes";
echo "<br>Sender: " . htmlspecialchars($data['sender']);
echo "<br>Receiver: " . htmlspecialchars($data['receiver']);
echo "<br>Timestamp: " . htmlspecialchars($data['timestamp']);