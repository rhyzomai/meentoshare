﻿<?php
/**
 * Meento Server — info.php
 * Returns server statistics as JSON for Owl Meento and compatible clients.
 *
 * Place this file in your web root or alongside your Meento server files.
 * Owl Meento will fetch this endpoint and parse the response automatically.
 *
 * Adjust the CONFIG section below to match your installation paths.
 */

// ── CORS (allow Owl Meento to reach this from any origin) ─────────────────────
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

// ── CONFIG ────────────────────────────────────────────────────────────────────

// Absolute or relative path to the directory where shared files are stored.
define('FILES_DIR', __DIR__ . '/download');

// Path to the public key file (PEM, raw, or hex — returned as-is).
define('PUBKEY_FILE', __DIR__ . '/pubkey.pem');

// Path to a simple counter file that tracks total downloads.
// Each download your server handles should append a line or increment this.
// If you don't have one, set to '' and downloads will be reported as 0.
define('DOWNLOADS_FILE', __DIR__ . '/downloads.count');

// Path to the blockchain directory (used only to count blocks/records).
// Set to '' to skip.
define('BLOCKCHAIN_DIR', __DIR__ . '/blockchain');

// Your server's display name (optional, shown in some clients).
define('SERVER_NAME', 'Meento Node');

// Your server's version string.
define('SERVER_VERSION', '1.0');

// ── HELPERS ───────────────────────────────────────────────────────────────────

/**
 * Recursively lists all files under a directory.
 * Returns an array of relative paths.
 */
function list_files($dir) {
    $result = [];
    if (!is_dir($dir)) return $result;
    $iter = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS)
    );
    foreach ($iter as $file) {
        if ($file->isFile()) {
            $result[] = str_replace('\\', '/', substr($file->getPathname(), strlen($dir) + 1));
        }
    }
    return $result;
}

/**
 * Counts files by extension, returns sorted array [ 'ext' => count ].
 */
function count_extensions(array $files) {
    $map = [];
    foreach ($files as $f) {
        $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
        if ($ext === '') $ext = '(none)';
        $map[$ext] = isset($map[$ext]) ? $map[$ext] + 1 : 1;
    }
    arsort($map);
    return $map;
}

/**
 * Reads the public key file and returns a single-line safe string.
 */
function read_pubkey($path) {
    if (!$path || !file_exists($path)) return '';
    $raw = file_get_contents($path);
    if ($raw === false) return '';
    // Strip PEM headers and whitespace → compact base64 string
    $clean = preg_replace('/-----[^-]+-----/', '', $raw);
    $clean = preg_replace('/\s+/', '', $clean);
    return $clean;
}

/**
 * Reads the download counter.
 * Supports two formats:
 *   - A file containing a single integer.
 *   - A file with one record per line (count = number of lines).
 */
function read_downloads($path) {
    if (!$path || !file_exists($path)) return 0;
    $content = trim(file_get_contents($path));
    if ($content === false || $content === '') return 0;
    if (is_numeric($content)) return (int)$content;
    // Line-per-download format
    return count(array_filter(explode("\n", $content)));
}

/**
 * Counts blockchain block files in the blockchain directory.
 */
function count_blocks($dir) {
    if (!$dir || !is_dir($dir)) return 0;
    $files = glob(rtrim($dir, '/') . '/*.json');
    return $files ? count($files) : 0;
}

// ── COLLECT DATA ──────────────────────────────────────────────────────────────

$files      = list_files(FILES_DIR);
$total      = count($files);
$ext_map    = count_extensions($files);
$top_ext    = $total > 0 ? array_key_first($ext_map) : '';
$pubkey     = read_pubkey(PUBKEY_FILE);
$downloads  = read_downloads(DOWNLOADS_FILE);
$blocks     = count_blocks(BLOCKCHAIN_DIR);

// Total size of all shared files in bytes
$total_size = 0;
if (is_dir(FILES_DIR)) {
    foreach ($files as $f) {
        $full = FILES_DIR . '/' . $f;
        if (is_file($full)) $total_size += filesize($full);
    }
}

// Server uptime (Linux only — graceful fallback on other OS)
$uptime_seconds = 0;
if (file_exists('/proc/uptime')) {
    $uptime_raw = file_get_contents('/proc/uptime');
    if ($uptime_raw !== false) {
        $uptime_seconds = (int)floatval(explode(' ', $uptime_raw)[0]);
    }
}

// ── BUILD RESPONSE ────────────────────────────────────────────────────────────

$response = [

    // ── Fields read by Owl Meento ──────────────────────────────────────────
    'files'            => $total,               // total files hosted
    'total_files'      => $total,               // alias
    'filecount'        => $total,               // alias
    'downloads'        => $downloads,           // total download events
    'download_count'   => $downloads,           // alias
    'total_downloads'  => $downloads,           // alias
    'pubkey'           => $pubkey,              // compact base64 public key
    'public_key'       => $pubkey,              // alias
    'top_ext'          => $top_ext,             // most common file extension
    'extension'        => $top_ext,             // alias

    // ── Extended info ──────────────────────────────────────────────────────
    'name'             => SERVER_NAME,
    'version'          => SERVER_VERSION,
    'extensions'       => $ext_map,            // full map: { "mp3": 42, "pdf": 10, ... }
    'extension_count'  => count($ext_map),     // number of distinct extensions
    'total_size_bytes' => $total_size,         // total bytes of shared files
    'total_size_mb'    => round($total_size / 1048576, 2),
    'blockchain_blocks'=> $blocks,
    'uptime_seconds'   => $uptime_seconds,
    'timestamp'        => time(),              // Unix timestamp of this response
    'status'           => 'online',
];

// ── OUTPUT ────────────────────────────────────────────────────────────────────

echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);