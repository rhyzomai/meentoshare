import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;

/**
 * OWL MEENTO v1.0
 * P2P Server Hunter & Ranker
 *
 * Scans all known P2P servers (port 52525 or explicit port in entry),
 * queries each for file count via the LIST command, measures ping,
 * fetches public key, and ranks them by a composite score.
 * Results are shown in a single descending-order rank table.
 * Up to 100 results. Users may save the ranking to JSON.
 */
public class OwlMeento {

    // -- constants -------------------------------------------------------------
    private static final String  SERVERS_FILE   = "servers.txt";
    private static final int     DEFAULT_PORT   = 52525;
    private static final int     MAX_RESULTS    = 100;
    private static final int     CONNECT_TIMEOUT = 5000;
    private static final int     READ_TIMEOUT    = 10000;

    /** DHT bootstrap URLs (same as AntMeento) */
    private static final String[] DHT_BOOTSTRAP_URLS = {
        "http://meento.atwebpages.com/servers.php",
        "https://meentos.netlify.app/servers.txt",
        "https://meento.neocities.org/servers.txt",
        "https://geocities.ws/meento/servers.txt"
    };

    // -- protocol tokens -------------------------------------------------------
    private static final String CMD_LIST = "LIST";
    private static final String CMD_END  = "END";
    private static final String CMD_PUBKEY = "PUBKEY";
    private static final String CMD_OK     = "OK";

    // -- colours (identical to AntMeento) -------------------------------------
    private static final Color C_BG      = new Color(0x0D,0x11,0x17);
    private static final Color C_PANEL   = new Color(0x13,0x19,0x21);
    private static final Color C_CARD    = new Color(0x1A,0x22,0x2E);
    private static final Color C_BORDER  = new Color(0x25,0x35,0x48);
    private static final Color C_ACCENT  = new Color(0x00,0xC8,0xFF);
    private static final Color C_ACCENT2 = new Color(0x00,0xFF,0xAA);
    private static final Color C_TEXT    = new Color(0xD0,0xE4,0xF4);
    private static final Color C_MUTED   = new Color(0x55,0x72,0x8A);
    private static final Color C_WARN    = new Color(0xFF,0xB8,0x00);
    private static final Color C_ERR     = new Color(0xFF,0x45,0x5A);
    private static final Color C_OK      = new Color(0x00,0xFF,0xAA);
    private static final Color C_ROWALT  = new Color(0x16,0x1E,0x28);
    private static final Color C_CHAIN   = new Color(0xAA,0x88,0xFF);
    private static final Color C_GOLD    = new Color(0xFF,0xD7,0x00);
    private static final Color C_SILVER  = new Color(0xC0,0xC8,0xD0);
    private static final Color C_BRONZE  = new Color(0xCD,0x7F,0x32);

    // -- state -----------------------------------------------------------------
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private volatile boolean scanning  = false;

    // -- GUI refs --------------------------------------------------------------
    private JFrame             frame;
    private JTable             rankTable;
    private DefaultTableModel  rankModel;
    private JLabel             statusLabel, scanStatusLbl, dhtStatusLbl;
    private JProgressBar       scanProgress;
    private JButton            scanBtn, saveBtn;
    private JTextPane          logPane;

    /** Live scan results, protected by EDT for table; raw list for JSON export */
    private final List<ServerResult> results = new ArrayList<ServerResult>();

    // -------------------------------------------------------------------------
    //  DATA MODEL
    // -------------------------------------------------------------------------
    static class ServerResult {
        String host;
        int    port;
        long   pingMs    = -1;
        int    fileCount = 0;
        long   downloads = 0;   // not available via LIST-only protocol; kept 0
        String pubKey    = "";
        String status    = "Unknown";
        double score     = 0.0;
        double pct       = 0.0;

        ServerResult(String host, int port){ this.host=host; this.port=port; }

        /** Composite score: files (70%) + ping bonus (30%). Downloads column reserved. */
        void computeScore(int totalFiles){
            if(!"Online".equals(status)){ score=0; pct=0; return; }
            double filePart  = totalFiles > 0 ? (fileCount * 1.0 / totalFiles) * 70.0 : 0;
            // Ping: 0ms=30pts, 5000ms=0pts (linear)
            double pingPart  = pingMs >= 0 ? Math.max(0, 30.0 * (1.0 - pingMs / 5000.0)) : 0;
            score = filePart + pingPart;
            pct   = totalFiles > 0 ? (fileCount * 100.0 / totalFiles) : 0;
        }

        String toJson(){
            return "  {\n"
                + "    \"host\": \""      + esc(host)                + "\",\n"
                + "    \"port\": "        + port                     + ",\n"
                + "    \"status\": \""    + esc(status)              + "\",\n"
                + "    \"files\": "       + fileCount                + ",\n"
                + "    \"pct\": "         + String.format("%.2f",pct)+ ",\n"
                + "    \"pingMs\": "      + pingMs                   + ",\n"
                + "    \"pubKey\": \""    + esc(pubKey.length()>32 ? pubKey.substring(0,32)+"..." : pubKey) + "\",\n"
                + "    \"score\": "       + String.format("%.2f",score) + "\n"
                + "  }";
        }
        private String esc(String s){
            if(s==null) return "";
            return s.replace("\\","\\\\").replace("\"","\\\"");
        }
    }

    // -------------------------------------------------------------------------
    //  ENTRY POINT
    // -------------------------------------------------------------------------
    public static void main(String[] args){
        SwingUtilities.invokeLater(new Runnable(){public void run(){
            try{UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());}catch(Exception ig){}
            new OwlMeento().launch();
        }});
    }

    private void launch(){
        buildUI();
        frame.setVisible(true);
        // auto-bootstrap DHT on start
        pool.submit(new Runnable(){public void run(){ bootstrapAndScan(false); }});
    }

    // -------------------------------------------------------------------------
    //  PEER DISCOVERY
    // -------------------------------------------------------------------------

    /** Load servers.txt entries that are valid P2P peers */
    private Set<String> loadServers(){
        Set<String> set = new LinkedHashSet<String>();
        File f = new File(SERVERS_FILE);
        if(f.exists()){
            try{
                BufferedReader br = new BufferedReader(new FileReader(f));
                String line;
                while((line=br.readLine())!=null){
                    line=line.trim();
                    if(!line.isEmpty()) set.add(line);
                }
                br.close();
            }catch(IOException e){ log("Error reading servers.txt", C_ERR); }
        }
        return set;
    }

    /** Returns [host, portStr] for a P2P-capable entry, or null if not applicable. */
    private String[] entryToP2P(String entry){
        if(entry==null||entry.isEmpty()) return null;
        // URL with explicit port, e.g. http://host:52525/path or https://host:52525
        if(entry.startsWith("http://") || entry.startsWith("https://")){
            try{
                URL u = new URL(entry);
                int p = u.getPort();
                if(p > 0) return new String[]{u.getHost(), String.valueOf(p)};
                // no port ? not a P2P entry (pure HTTP resource)
                return null;
            }catch(Exception e){ return null; }
        }
        // host:port or host (default port)
        if(entry.contains(":")){
            int idx = entry.lastIndexOf(':');
            String h = entry.substring(0,idx).trim();
            String ps = entry.substring(idx+1).trim();
            try{ Integer.parseInt(ps); return new String[]{h, ps}; }
            catch(NumberFormatException e){ return null; }
        }
        // bare hostname ? assume default port
        if(entry.matches("[a-zA-Z0-9._\\-]+")){
            return new String[]{entry, String.valueOf(DEFAULT_PORT)};
        }
        return null;
    }

    /** Fetch lines from an HTTP URL (peer lists / bootstrap) */
    private List<String> fetchHttpLines(String url, int timeoutMs){
        List<String> lines = new ArrayList<String>();
        try{
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(timeoutMs); c.setReadTimeout(timeoutMs);
            c.setRequestProperty("User-Agent","OwlMeento/1.0");
            if(c.getResponseCode()==200){
                BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream()));
                String line;
                while((line=br.readLine())!=null){ line=line.trim(); if(!line.isEmpty()&&!line.startsWith("#")) lines.add(line); }
                br.close();
            }
            c.disconnect();
        }catch(Exception ig){}
        return lines;
    }

    /** Bootstrap DHT: fetch bootstrap URLs, collect P2P peers, then optionally scan */
    private void bootstrapAndScan(boolean scanAfter){
        setDhtStatus("DHT: connecting...");
        log("Bootstrapping DHT from "+DHT_BOOTSTRAP_URLS.length+" sources...", C_CHAIN);
        Set<String> peers = new LinkedHashSet<String>(loadServers());
        for(String url : DHT_BOOTSTRAP_URLS){
            List<String> lines = fetchHttpLines(url, 5000);
            for(String line : lines){
                String[] hp = entryToP2P(line);
                if(hp != null) peers.add(line);
                // also check if line is another peer-list URL
                else if(line.startsWith("http://") || line.startsWith("https://")){
                    // fetch one level deep
                    List<String> sub = fetchHttpLines(line, 4000);
                    for(String sl : sub){
                        String[] shp = entryToP2P(sl);
                        if(shp != null) peers.add(sl);
                    }
                }
            }
        }
        setDhtStatus("DHT: "+peers.size()+" peers found");
        log("DHT bootstrap complete. "+peers.size()+" P2P peers discovered.", C_OK);
        if(scanAfter || !results.isEmpty()) doScan(peers);
    }

    // -------------------------------------------------------------------------
    //  SCANNING
    // -------------------------------------------------------------------------

    private void startScan(){
        if(scanning){ log("Scan already running.", C_WARN); return; }
        pool.submit(new Runnable(){public void run(){
            Set<String> peers = new LinkedHashSet<String>(loadServers());
            // also quick-fetch bootstrap to pick up runtime peers
            for(String url : DHT_BOOTSTRAP_URLS){
                List<String> lines = fetchHttpLines(url, 4000);
                for(String line : lines){
                    if(entryToP2P(line) != null) peers.add(line);
                }
            }
            doScan(peers);
        }});
    }

    private void doScan(Set<String> peerEntries){
        scanning = true;
        SwingUtilities.invokeLater(new Runnable(){public void run(){
            scanBtn.setEnabled(false); saveBtn.setEnabled(false);
            scanProgress.setVisible(true); scanProgress.setIndeterminate(true);
            rankModel.setRowCount(0); results.clear();
            scanStatusLbl.setText("  Scanning "+peerEntries.size()+" peers...");
        }});

        // Deduplicate by host:port
        Map<String,String[]> unique = new LinkedHashMap<String,String[]>();
        for(String entry : peerEntries){
            String[] hp = entryToP2P(entry);
            if(hp == null) continue;
            String key = hp[0].toLowerCase()+":"+hp[1];
            unique.put(key, hp);
        }

        log("Scanning "+unique.size()+" unique P2P peers...", C_ACCENT);

        List<Future<ServerResult>> futures = new ArrayList<Future<ServerResult>>();
        for(final String[] hp : unique.values()){
            futures.add(pool.submit(new Callable<ServerResult>(){
                public ServerResult call(){ return probeServer(hp[0], Integer.parseInt(hp[1])); }
            }));
        }

        List<ServerResult> gathered = new ArrayList<ServerResult>();
        for(Future<ServerResult> f : futures){
            try{
                ServerResult r = f.get(15, TimeUnit.SECONDS);
                if(r != null && "Online".equals(r.status)) gathered.add(r);
            }catch(Exception ig){}
        }

        // compute totals
        int totalFiles = 0;
        for(ServerResult r : gathered) totalFiles += r.fileCount;
        for(ServerResult r : gathered) r.computeScore(totalFiles);

        // sort descending by score
        Collections.sort(gathered, new Comparator<ServerResult>(){
            public int compare(ServerResult a, ServerResult b){
                return Double.compare(b.score, a.score);
            }
        });

        // keep max 100
        if(gathered.size() > MAX_RESULTS) gathered = gathered.subList(0, MAX_RESULTS);

        final List<ServerResult> finalList = gathered;
        final int fTotalFiles = totalFiles;

        SwingUtilities.invokeLater(new Runnable(){public void run(){
            results.clear(); results.addAll(finalList);
            rankModel.setRowCount(0);
            for(int i=0; i<finalList.size(); i++){
                ServerResult r = finalList.get(i);
                String pubShort = r.pubKey.length()>20 ? r.pubKey.substring(0,20)+"..." : r.pubKey;
                String pingStr  = r.pingMs >= 0 ? r.pingMs+"ms" : "N/A";
                String pctStr   = String.format("%.1f%%", r.pct);
                String scoreStr = String.format("%.1f", r.score);
                rankModel.addRow(new Object[]{
                    "  #"+(i+1),
                    "  "+r.host+":"+r.port,
                    "  "+r.fileCount,
                    "  "+pctStr,
                    "  "+pingStr,
                    "  "+r.status,
                    "  "+pubShort,
                    "  "+scoreStr
                });
            }
            scanBtn.setEnabled(true); saveBtn.setEnabled(!finalList.isEmpty());
            scanProgress.setVisible(false);
            scanStatusLbl.setText("  "+finalList.size()+" servers ranked  |  "+fTotalFiles+" total files across network");
            log("Scan complete. "+finalList.size()+" online servers ranked, "+fTotalFiles+" total files.", C_OK);
            scanning = false;
        }});
    }

    private ServerResult probeServer(String host, int port){
        ServerResult r = new ServerResult(host, port);
        try{
            // Ping: measure connection time
            long t0 = System.currentTimeMillis();
            Socket s = new Socket();
            s.connect(new InetSocketAddress(host, port), CONNECT_TIMEOUT);
            s.setSoTimeout(READ_TIMEOUT);
            r.pingMs = System.currentTimeMillis() - t0;

            // LIST files
            PrintWriter out = new PrintWriter(s.getOutputStream(), true);
            BufferedReader in  = new BufferedReader(new InputStreamReader(s.getInputStream()));
            out.println(CMD_LIST);
            String line;
            int count = 0;
            while((line=in.readLine())!=null && !line.equals(CMD_END)) count++;
            r.fileCount = count;
            s.close();

            // Fetch public key (separate connection)
            r.pubKey = fetchPubKey(host, port);
            r.status = "Online";
            log("  "+host+":"+port+" \u2714 "+count+" files, "+r.pingMs+"ms", C_OK);
        }catch(Exception e){
            r.status = "Offline";
            r.pingMs = -1;
            log("  "+host+":"+port+" \u2718 "+e.getMessage(), C_MUTED);
        }
        return r;
    }

    private String fetchPubKey(String host, int port){
        try{
            Socket s = new Socket();
            s.connect(new InetSocketAddress(host, port), CONNECT_TIMEOUT);
            s.setSoTimeout(READ_TIMEOUT);
            PrintWriter out = new PrintWriter(s.getOutputStream(), true);
            BufferedReader in  = new BufferedReader(new InputStreamReader(s.getInputStream()));
            out.println(CMD_PUBKEY);
            String resp = in.readLine();
            s.close();
            if(resp!=null && resp.startsWith(CMD_OK+" ")) return resp.substring(CMD_OK.length()+1).trim();
        }catch(Exception ig){}
        return "";
    }

    // -------------------------------------------------------------------------
    //  SAVE TO JSON
    // -------------------------------------------------------------------------
    private void saveJson(){
        if(results.isEmpty()){ log("No results to save.", C_WARN); return; }
        JFileChooser fc = new JFileChooser();
        fc.setSelectedFile(new File("owl_meento_rank_"+new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date())+".json"));
        fc.setBackground(C_CARD); fc.setForeground(C_TEXT);
        if(fc.showSaveDialog(frame) != JFileChooser.APPROVE_OPTION) return;
        File dest = fc.getSelectedFile();
        if(!dest.getName().endsWith(".json")) dest = new File(dest.getAbsolutePath()+".json");
        try{
            PrintWriter pw = new PrintWriter(new FileWriter(dest));
            pw.println("{");
            pw.println("  \"generated\": \""+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date())+"\",");
            pw.println("  \"total_servers\": "+results.size()+",");
            int tf=0; for(ServerResult r:results) tf+=r.fileCount;
            pw.println("  \"total_files\": "+tf+",");
            pw.println("  \"servers\": [");
            for(int i=0;i<results.size();i++){
                pw.print(results.get(i).toJson());
                if(i<results.size()-1) pw.print(",");
                pw.println();
            }
            pw.println("  ]");
            pw.println("}");
            pw.close();
            log("Saved to: "+dest.getAbsolutePath(), C_OK);
            JOptionPane.showMessageDialog(frame, "Saved to:\n"+dest.getAbsolutePath(), "Saved", JOptionPane.INFORMATION_MESSAGE);
        }catch(IOException e){ log("Save failed: "+e.getMessage(), C_ERR); }
    }

    // -------------------------------------------------------------------------
    //  UI CONSTRUCTION
    // -------------------------------------------------------------------------
    private void buildUI(){
        frame = new JFrame("Owl Meento v1.0  \u2014  P2P Server Hunter & Ranker");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1200,780); frame.setMinimumSize(new Dimension(960,600));
        frame.setLocationRelativeTo(null);
        frame.getContentPane().setBackground(C_BG);
        frame.setLayout(new BorderLayout(0,0));
        frame.add(buildHeader(), BorderLayout.NORTH);
        frame.add(buildMainPanel(), BorderLayout.CENTER);
        frame.add(buildStatusBar(), BorderLayout.SOUTH);
    }

    private JPanel buildHeader(){
        JPanel h = new JPanel(new BorderLayout());
        h.setBackground(C_PANEL);
        h.setBorder(new MatteBorder(0,0,1,0,C_BORDER));
        h.setPreferredSize(new Dimension(0,72));

        // Left: logo + subtitle
        JPanel left = new JPanel(new GridLayout(3,1));
        left.setOpaque(false); left.setBorder(new EmptyBorder(6,14,6,0));
        JLabel logo = new JLabel("\uD83E\uDD89  OWL MEENTO  v1.0");
        logo.setFont(new Font("Monospaced",Font.BOLD,15)); logo.setForeground(C_ACCENT);
        JLabel sub  = new JLabel("P2P Server Hunter & Ranker  \u2014  top 100 by file count + ping");
        sub.setFont(new Font("Monospaced",Font.PLAIN,10)); sub.setForeground(C_MUTED);
        dhtStatusLbl = new JLabel("  DHT: initializing...");
        dhtStatusLbl.setFont(new Font("Monospaced",Font.PLAIN,10)); dhtStatusLbl.setForeground(C_CHAIN);
        left.add(logo); left.add(sub); left.add(dhtStatusLbl);
        h.add(left, BorderLayout.WEST);

        // Right: scan button + progress
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT,10,0));
        right.setOpaque(false); right.setBorder(new EmptyBorder(16,0,16,12));
        scanProgress = new JProgressBar();
        scanProgress.setBackground(C_CARD); scanProgress.setForeground(C_ACCENT2);
        scanProgress.setPreferredSize(new Dimension(140,14));
        scanProgress.setBorder(new LineBorder(C_BORDER));
        scanProgress.setVisible(false);
        scanBtn = makeButton("  \u25B6  SCAN NETWORK",C_ACCENT2);
        scanBtn.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){ startScan(); }});
        saveBtn = makeButton("  \u2193  SAVE JSON",C_ACCENT);
        saveBtn.setEnabled(false);
        saveBtn.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){ saveJson(); }});
        right.add(scanProgress); right.add(scanBtn); right.add(saveBtn);
        h.add(right, BorderLayout.EAST);
        return h;
    }

    private JSplitPane buildMainPanel(){
        JSplitPane sp = new JSplitPane(JSplitPane.VERTICAL_SPLIT, buildRankPanel(), buildLogPanel());
        sp.setDividerLocation(500); sp.setDividerSize(4);
        sp.setBackground(C_BG); sp.setBorder(null); sp.setOpaque(false);
        return sp;
    }

    private JPanel buildRankPanel(){
        JPanel p = new JPanel(new BorderLayout(0,0));
        p.setBackground(C_BG);

        // Top bar
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(C_PANEL); bar.setBorder(new MatteBorder(0,0,1,0,C_BORDER));
        JLabel title = new JLabel("  \u25BA  SERVER RANKING  \u2014  descending by score  (files \u00D7 70% + ping bonus \u00D7 30%)");
        title.setFont(new Font("Monospaced",Font.BOLD,11)); title.setForeground(C_MUTED);
        title.setBorder(new EmptyBorder(6,0,6,0));
        scanStatusLbl = new JLabel("  Press SCAN NETWORK to start.");
        scanStatusLbl.setFont(new Font("Monospaced",Font.PLAIN,11)); scanStatusLbl.setForeground(C_ACCENT);
        scanStatusLbl.setBorder(new EmptyBorder(0,0,0,12));
        bar.add(title, BorderLayout.WEST); bar.add(scanStatusLbl, BorderLayout.EAST);
        p.add(bar, BorderLayout.NORTH);

        // Table
        rankModel = new DefaultTableModel(
            new String[]{"  Rank","  Server","  Files","  % of Total","  Ping","  Status","  Public Key (short)","  Score"},0){
            public boolean isCellEditable(int r,int c){ return false; }
        };
        rankTable = buildTable(rankModel);
        rankTable.getColumnModel().getColumn(0).setPreferredWidth(55);
        rankTable.getColumnModel().getColumn(1).setPreferredWidth(210);
        rankTable.getColumnModel().getColumn(2).setPreferredWidth(65);
        rankTable.getColumnModel().getColumn(3).setPreferredWidth(90);
        rankTable.getColumnModel().getColumn(4).setPreferredWidth(70);
        rankTable.getColumnModel().getColumn(5).setPreferredWidth(70);
        rankTable.getColumnModel().getColumn(6).setPreferredWidth(195);
        rankTable.getColumnModel().getColumn(7).setPreferredWidth(70);

        // Rank column: gold/silver/bronze for top 3
        rankTable.getColumnModel().getColumn(0).setCellRenderer(new DefaultTableCellRenderer(){
            public Component getTableCellRendererComponent(JTable t,Object v,boolean sl,boolean fc,int row,int col){
                super.getTableCellRendererComponent(t,v,sl,fc,row,col);
                if(sl){ setBackground(new Color(0x00,0x70,0xA0)); setForeground(Color.WHITE); }
                else{
                    setBackground(row%2==0?C_CARD:C_ROWALT);
                    if(row==0)      setForeground(C_GOLD);
                    else if(row==1) setForeground(C_SILVER);
                    else if(row==2) setForeground(C_BRONZE);
                    else            setForeground(C_MUTED);
                }
                setFont(new Font("Monospaced",Font.BOLD,11)); return this;
            }
        });

        // Files column: accent colour
        rankTable.getColumnModel().getColumn(2).setCellRenderer(new DefaultTableCellRenderer(){
            public Component getTableCellRendererComponent(JTable t,Object v,boolean sl,boolean fc,int row,int col){
                super.getTableCellRendererComponent(t,v,sl,fc,row,col);
                if(sl){ setBackground(new Color(0x00,0x70,0xA0)); setForeground(Color.WHITE); }
                else{ setBackground(row%2==0?C_CARD:C_ROWALT); setForeground(C_ACCENT); }
                setFont(new Font("Monospaced",Font.BOLD,12)); return this;
            }
        });

        // % column
        rankTable.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer(){
            public Component getTableCellRendererComponent(JTable t,Object v,boolean sl,boolean fc,int row,int col){
                super.getTableCellRendererComponent(t,v,sl,fc,row,col);
                if(sl){ setBackground(new Color(0x00,0x70,0xA0)); setForeground(Color.WHITE); }
                else{ setBackground(row%2==0?C_CARD:C_ROWALT); setForeground(C_CHAIN); }
                setFont(new Font("Monospaced",Font.PLAIN,11)); return this;
            }
        });

        // Ping column
        rankTable.getColumnModel().getColumn(4).setCellRenderer(new DefaultTableCellRenderer(){
            public Component getTableCellRendererComponent(JTable t,Object v,boolean sl,boolean fc,int row,int col){
                super.getTableCellRendererComponent(t,v,sl,fc,row,col);
                String val = v==null?"":v.toString().trim();
                if(sl){ setBackground(new Color(0x00,0x70,0xA0)); setForeground(Color.WHITE); }
                else{
                    setBackground(row%2==0?C_CARD:C_ROWALT);
                    long ms = -1;
                    try{ ms = Long.parseLong(val.replace("ms","").trim()); }catch(Exception ig){}
                    if(ms < 0)          setForeground(C_MUTED);
                    else if(ms < 200)   setForeground(C_OK);
                    else if(ms < 1000)  setForeground(C_WARN);
                    else                setForeground(C_ERR);
                }
                setFont(new Font("Monospaced",Font.PLAIN,11)); return this;
            }
        });

        // Status column
        rankTable.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer(){
            public Component getTableCellRendererComponent(JTable t,Object v,boolean sl,boolean fc,int row,int col){
                super.getTableCellRendererComponent(t,v,sl,fc,row,col);
                String val = v==null?"":v.toString().trim();
                if(sl){ setBackground(new Color(0x00,0x70,0xA0)); setForeground(Color.WHITE); }
                else{
                    setBackground(row%2==0?C_CARD:C_ROWALT);
                    if("Online".equals(val))  setForeground(C_OK);
                    else if("Offline".equals(val)) setForeground(C_ERR);
                    else setForeground(C_MUTED);
                }
                setFont(new Font("Monospaced",Font.BOLD,11)); return this;
            }
        });

        // Public key column: muted small
        rankTable.getColumnModel().getColumn(6).setCellRenderer(new DefaultTableCellRenderer(){
            public Component getTableCellRendererComponent(JTable t,Object v,boolean sl,boolean fc,int row,int col){
                super.getTableCellRendererComponent(t,v,sl,fc,row,col);
                if(sl){ setBackground(new Color(0x00,0x70,0xA0)); setForeground(Color.WHITE); }
                else{ setBackground(row%2==0?C_CARD:C_ROWALT); setForeground(C_MUTED); }
                setFont(new Font("Monospaced",Font.PLAIN,10)); return this;
            }
        });

        // Score column: accent2 bold
        rankTable.getColumnModel().getColumn(7).setCellRenderer(new DefaultTableCellRenderer(){
            public Component getTableCellRendererComponent(JTable t,Object v,boolean sl,boolean fc,int row,int col){
                super.getTableCellRendererComponent(t,v,sl,fc,row,col);
                if(sl){ setBackground(new Color(0x00,0x70,0xA0)); setForeground(Color.WHITE); }
                else{ setBackground(row%2==0?C_CARD:C_ROWALT); setForeground(C_ACCENT2); }
                setFont(new Font("Monospaced",Font.BOLD,11)); return this;
            }
        });

        p.add(darkScroll(rankTable), BorderLayout.CENTER);

        // Legend footer
        JPanel legend = new JPanel(new FlowLayout(FlowLayout.LEFT,16,4));
        legend.setBackground(C_PANEL);
        legend.setBorder(new MatteBorder(1,0,0,0,C_BORDER));
        addLegend(legend, "\u25CF Rank",     C_MUTED);
        addLegend(legend, "\u25CF Files",    C_ACCENT);
        addLegend(legend, "\u25CF %",        C_CHAIN);
        addLegend(legend, "\u25CF Ping <200ms", C_OK);
        addLegend(legend, "\u25CF Ping <1s",    C_WARN);
        addLegend(legend, "\u25CF Ping >1s",    C_ERR);
        addLegend(legend, "\u25CF Score = files\u00D770% + ping\u00D730%", C_ACCENT2);
        p.add(legend, BorderLayout.SOUTH);
        return p;
    }

    private JPanel buildLogPanel(){
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(C_BG); p.setMinimumSize(new Dimension(200,80));
        JLabel title = new JLabel("  ACTIVITY LOG");
        title.setFont(new Font("Monospaced",Font.BOLD,11)); title.setForeground(C_MUTED);
        title.setBackground(C_PANEL); title.setOpaque(true);
        title.setBorder(new CompoundBorder(new MatteBorder(1,0,1,0,C_BORDER),new EmptyBorder(4,0,4,0)));
        p.add(title, BorderLayout.NORTH);
        logPane = new JTextPane(); logPane.setEditable(false);
        logPane.setBackground(C_BG); logPane.setFont(new Font("Monospaced",Font.PLAIN,11));
        p.add(darkScroll(logPane), BorderLayout.CENTER);
        JPanel bot = new JPanel(new FlowLayout(FlowLayout.RIGHT,8,4));
        bot.setBackground(C_PANEL); bot.setBorder(new MatteBorder(1,0,0,0,C_BORDER));
        JButton cl = makeButton("CLEAR LOG",C_MUTED);
        cl.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){ logPane.setText(""); }});
        bot.add(cl); p.add(bot, BorderLayout.SOUTH);
        return p;
    }

    private JPanel buildStatusBar(){
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(C_PANEL); bar.setBorder(new MatteBorder(1,0,0,0,C_BORDER));
        bar.setPreferredSize(new Dimension(0,24));
        statusLabel = new JLabel("  Initializing...");
        statusLabel.setFont(new Font("Monospaced",Font.PLAIN,11)); statusLabel.setForeground(C_MUTED);
        JLabel copy = new JLabel("Owl Meento v1.0   ");
        copy.setFont(new Font("Monospaced",Font.PLAIN,10)); copy.setForeground(new Color(0x2A,0x3A,0x4E));
        bar.add(statusLabel, BorderLayout.WEST); bar.add(copy, BorderLayout.EAST);
        return bar;
    }

    // -------------------------------------------------------------------------
    //  UI HELPERS
    // -------------------------------------------------------------------------
    private JButton makeButton(String text, final Color fg){
        JButton b = new JButton(text){
            protected void paintComponent(Graphics g){
                Graphics2D g2 = (Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isArmed()||getModel().isRollover() ? new Color(0x25,0x35,0x48) : C_CARD);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),6,6);
                g2.setColor(fg.darker());
                g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,6,6);
                g2.dispose(); super.paintComponent(g);
            }
        };
        b.setForeground(fg); b.setFont(new Font("Monospaced",Font.BOLD,11));
        b.setFocusPainted(false); b.setBorderPainted(false); b.setContentAreaFilled(false);
        b.setOpaque(false); b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setMargin(new Insets(4,10,4,10));
        return b;
    }

    private JTable buildTable(DefaultTableModel m){
        JTable t = new JTable(m){
            public Component prepareRenderer(TableCellRenderer r, int row, int col){
                Component c = super.prepareRenderer(r,row,col);
                if(isRowSelected(row)){ c.setBackground(new Color(0x00,0x70,0xA0)); c.setForeground(Color.WHITE); }
                else{ c.setBackground(row%2==0?C_CARD:C_ROWALT); c.setForeground(C_TEXT); }
                return c;
            }
        };
        t.setBackground(C_CARD); t.setForeground(C_TEXT);
        t.setFont(new Font("Monospaced",Font.PLAIN,12)); t.setRowHeight(26);
        t.setGridColor(C_BORDER); t.setShowGrid(false);
        t.setIntercellSpacing(new Dimension(0,1));
        t.setSelectionBackground(new Color(0x00,0x60,0x90)); t.setSelectionForeground(Color.WHITE);
        t.setFillsViewportHeight(true);
        JTableHeader h = t.getTableHeader();
        h.setBackground(C_PANEL); h.setForeground(C_MUTED);
        h.setFont(new Font("Monospaced",Font.BOLD,11));
        h.setBorder(new MatteBorder(0,0,1,0,C_BORDER)); h.setReorderingAllowed(false);
        return t;
    }

    private JScrollPane darkScroll(Component c){
        JScrollPane sp = new JScrollPane(c);
        sp.setBorder(null); sp.setBackground(C_BG);
        sp.getViewport().setBackground(C_BG);
        sp.getVerticalScrollBar().setBackground(C_PANEL);
        sp.getHorizontalScrollBar().setBackground(C_PANEL);
        return sp;
    }

    private void addLegend(JPanel panel, String text, Color color){
        JLabel l = new JLabel(text);
        l.setFont(new Font("Monospaced",Font.PLAIN,10)); l.setForeground(color);
        panel.add(l);
    }

    private void log(final String msg, final Color color){
        SwingUtilities.invokeLater(new Runnable(){public void run(){
            try{
                javax.swing.text.StyledDocument doc = logPane.getStyledDocument();
                javax.swing.text.Style st = logPane.addStyle("s",null);
                javax.swing.text.StyleConstants.setForeground(st,C_MUTED);
                javax.swing.text.StyleConstants.setFontFamily(st,"Monospaced");
                javax.swing.text.StyleConstants.setFontSize(st,10);
                String ts = new SimpleDateFormat("HH:mm:ss").format(new Date());
                doc.insertString(doc.getLength(),"["+ts+"] ",st);
                javax.swing.text.StyleConstants.setForeground(st,color);
                javax.swing.text.StyleConstants.setFontSize(st,11);
                doc.insertString(doc.getLength(),msg+"\n",st);
                logPane.setCaretPosition(doc.getLength());
            }catch(Exception ig){}
        }});
    }

    private void setDhtStatus(final String msg){
        SwingUtilities.invokeLater(new Runnable(){public void run(){
            if(dhtStatusLbl!=null) dhtStatusLbl.setText("  "+msg);
            if(statusLabel!=null)  statusLabel.setText("  "+msg);
        }});
    }
}