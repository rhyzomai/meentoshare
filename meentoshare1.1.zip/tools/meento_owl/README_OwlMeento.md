# 🦉 Owl Meento — Server Rank Scanner

A single-file Java GUI application that scans P2P and HTTP servers, collects statistics, and displays them in a ranked table. No external libraries required. Java 8 compatible.

---

## Features

- Scans servers from `servers.txt` and DHT bootstrap URLs
- Supports both **P2P peers** (socket-based) and **HTTP endpoints** (`.php` or `/info`)
- Ranks servers by six criteria, switchable via tabs
- Displays up to 100 results per rank
- Exports the rank to a **JSON file**
- Same dark color scheme as Ant Meento GUI

---

## Requirements

- Java 8 or later (JDK to compile, JRE to run)
- No external libraries or dependencies

---

## Build & Run

```bash
# Compile
javac OwlMeento.java

# Run
java OwlMeento
```

---

## Server List

Owl Meento reads servers from `servers.txt` in the same directory. Each line is one entry. Lines starting with `#` are ignored.

**Accepted formats:**

| Format | Example | Type |
|--------|---------|------|
| `host:port` | `peer.example.com:52525` | P2P peer |
| `hostname` | `peer.example.com` | P2P peer (default port 52525) |
| IPv4 with port | `192.168.1.5:52525` | P2P peer |
| HTTPS URL (PHP) | `https://example.com/servers.php` | HTTP info endpoint |
| HTTP URL (/info) | `http://example.com/info` | HTTP info endpoint |
| Peer-list URL | `https://example.com/servers.txt` | Fetched and resolved once |

**Rejected entries:** plain text, HTML, entries with angle brackets (`< >`), quotes, or whitespace.

At startup, Owl Meento also bootstraps from these DHT URLs and merges any discovered peers:

```
http://meento.atwebpages.com/servers.php
https://meentos.netlify.app/servers.txt
https://meento.neocities.org/servers.txt
https://geocities.ws/meento/servers.txt
```

---

## Scan Logic

### P2P Peers (`host:port`)

1. Opens a TCP socket connection (5 s timeout)
2. Sends `PUBKEY` — retrieves the server's public key
3. Sends `LIST` — retrieves the list of shared files
4. Measures **ping** as the TCP connection time
5. Counts files and their extensions
6. Optionally probes `http://host/info` or `http://host/stats` for a download count

### HTTP Endpoints (`.php` / `/info`)

1. Sends an HTTP GET request
2. Measures ping as the connection time
3. Parses the JSON response body for fields:
   - `files` / `total_files` / `filecount` — total file count
   - `downloads` / `download_count` / `total_downloads` — download count
   - `pubkey` / `public_key` — server public key
   - `extensions` / `top_ext` — dominant file extension

Offline servers (connection refused, timeout, HTTP error) are excluded from the rank.

---

## Ranking Tabs

Switching tabs re-sorts the table instantly. All criteria are **descending** except Ping (ascending — lower is better).

| Tab | Criterion | Description |
|-----|-----------|-------------|
| Score | Weighted score | `files×3 + downloads×2 + (1000−ping)/10 + distinct_extensions×5` |
| Total Files | File count | Servers hosting the most files |
| Downloads | Download count | Most downloaded files (requires `/info` data) |
| Ping (ms) | Latency | Fastest responding servers first |
| Stored Extensions | Extension diversity | Servers with the widest variety of file types |
| % of Total Files | Share of network | Each server's share of all files seen across the network |

Maximum **100 results** are displayed per tab.

---

## Table Columns

| Column | Description |
|--------|-------------|
| `#` | Rank position (🥇🥈🥉 highlighted for top 3) |
| Server | Address or URL |
| Type | `P2P`, `PHP`, or `INFO` |
| Files | Total files hosted |
| Downloads | Download count (if available) |
| % Total | Percentage of all scanned files |
| Ping | Round-trip connection time in ms |
| Top Ext. | Most common file extension (+ count of distinct extensions) |
| Status | `Online`, `HTTP 200`, or error |
| Public Key | First 24 characters of the server's public key |
| Score | Calculated score |

---

## Saving Results

Click **SAVE JSON** to export the current ranked list. The file is named automatically:

```
owl_rank_20250101_123456.json
```

Each entry in the JSON contains all fields shown in the table:

```json
[
  {
    "rank": 1,
    "address": "peer.example.com:52525",
    "host": "peer.example.com",
    "port": 52525,
    "type": "p2p",
    "status": "Online",
    "totalFiles": 142,
    "downloads": 37,
    "pingMs": 84,
    "topExtension": "mp3",
    "extensions": 5,
    "pctOfTotal": 18.45,
    "publicKey": "MIIBIjANBgkqhki...",
    "score": 512
  }
]
```

---

## Relation to Ant Meento

Owl Meento is a **read-only companion** to Ant Meento GUI. It shares the same `servers.txt` file and DHT bootstrap URLs, and uses the same entry validation and P2P protocol commands (`LIST`, `PUBKEY`). It does not send files, record blockchain blocks, or modify `servers.txt`.

---

## License

Same terms as Ant Meento GUI. Use freely within the Meento ecosystem.
