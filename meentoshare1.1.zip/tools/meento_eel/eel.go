package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

// --- Config ------------------------------------------------------------------

var (
	port         = "52525"
	downloadDir  = "download"
	serversFile  = "servers.txt"
	serversJSON  = "servers.json"
)

// --- HTTP Server -------------------------------------------------------------

func startServer() {
	if err := os.MkdirAll(downloadDir, 0755); err != nil {
		fmt.Println("[server] Could not create download dir:", err)
		return
	}

	mux := http.NewServeMux()

	// List files as JSON
	mux.HandleFunc("/list", func(w http.ResponseWriter, r *http.Request) {
		entries, err := os.ReadDir(downloadDir)
		if err != nil {
			http.Error(w, "cannot read dir", 500)
			return
		}
		type FileInfo struct {
			Name string `json:"name"`
			Size int64  `json:"size"`
		}
		var files []FileInfo
		for _, e := range entries {
			if e.IsDir() {
				continue
			}
			info, _ := e.Info()
			files = append(files, FileInfo{Name: e.Name(), Size: info.Size()})
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(files)
	})

	// Serve individual files for download
	mux.Handle("/files/", http.StripPrefix("/files/", http.FileServer(http.Dir(downloadDir))))

	addr := "0.0.0.0:" + port
	fmt.Printf("[server] Listening on %s  (serving ./%s/)\n", addr, downloadDir)
	if err := http.ListenAndServe(addr, mux); err != nil {
		fmt.Println("[server] Fatal:", err)
	}
}

// --- Helpers -----------------------------------------------------------------

func readServers() []string {
	f, err := os.Open(serversFile)
	if err != nil {
		fmt.Printf("[!] Cannot open %s: %v\n", serversFile, err)
		return nil
	}
	defer f.Close()

	var hosts []string
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line != "" && !strings.HasPrefix(line, "#") {
			hosts = append(hosts, line)
		}
	}
	return hosts
}

func normalizeHost(h string) string {
	// strip scheme if present
	h = strings.TrimPrefix(h, "http://")
	h = strings.TrimPrefix(h, "https://")
	// if no port given, append default
	if _, _, err := net.SplitHostPort(h); err != nil {
		h = h + ":" + port
	}
	return h
}

type RemoteFile struct {
	Name string `json:"name"`
	Size int64  `json:"size"`
}

func listRemote(host string) ([]RemoteFile, error) {
	url := "http://" + host + "/list"
	client := &http.Client{Timeout: 8 * time.Second}
	resp, err := client.Get(url)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	var files []RemoteFile
	if err := json.NewDecoder(resp.Body).Decode(&files); err != nil {
		return nil, err
	}
	return files, nil
}

func downloadFile(host, name string) error {
	dest := filepath.Join(downloadDir, name)
	// Skip if already exists
	if _, err := os.Stat(dest); err == nil {
		fmt.Printf("  [skip] %s already exists\n", name)
		return nil
	}

	url := "http://" + host + "/files/" + name
	client := &http.Client{Timeout: 60 * time.Second}
	resp, err := client.Get(url)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		return fmt.Errorf("HTTP %d for %s", resp.StatusCode, url)
	}

	tmp := dest + ".tmp"
	out, err := os.Create(tmp)
	if err != nil {
		return err
	}
	if _, err := io.Copy(out, resp.Body); err != nil {
		out.Close()
		os.Remove(tmp)
		return err
	}
	out.Close()
	return os.Rename(tmp, dest)
}

// --- Commands ----------------------------------------------------------------

func cmdPort(args []string) {
	if len(args) == 0 {
		fmt.Println("Usage: port <number>")
		return
	}
	p, err := strconv.Atoi(args[0])
	if err != nil || p < 1 || p > 65535 {
		fmt.Println("[!] Invalid port number")
		return
	}
	port = args[0]
	fmt.Printf("[+] Port changed to %s (restart required for server)\n", port)
}

func cmdDownload() {
	if err := os.MkdirAll(downloadDir, 0755); err != nil {
		fmt.Println("[!] Cannot create download dir:", err)
		return
	}
	hosts := readServers()
	if len(hosts) == 0 {
		fmt.Println("[!] No servers found in", serversFile)
		return
	}

	var wg sync.WaitGroup
	var mu sync.Mutex

	for _, raw := range hosts {
		host := normalizeHost(raw)
		wg.Add(1)
		go func(h string) {
			defer wg.Done()
			files, err := listRemote(h)
			if err != nil {
				mu.Lock()
				fmt.Printf("  [%s] list error: %v\n", h, err)
				mu.Unlock()
				return
			}
			mu.Lock()
			fmt.Printf("  [%s] %d file(s) found\n", h, len(files))
			mu.Unlock()

			for _, f := range files {
				if err := downloadFile(h, f.Name); err != nil {
					mu.Lock()
					fmt.Printf("  [%s] download error %s: %v\n", h, f.Name, err)
					mu.Unlock()
				} else {
					mu.Lock()
					fmt.Printf("  [%s] downloaded %s\n", h, f.Name)
					mu.Unlock()
				}
			}
		}(host)
	}
	wg.Wait()
	fmt.Println("[+] Download complete.")
}

type ServerRank struct {
	Host      string `json:"host"`
	FileCount int    `json:"file_count"`
	TotalSize int64  `json:"total_size_bytes"`
}

func cmdRank() {
	hosts := readServers()
	if len(hosts) == 0 {
		fmt.Println("[!] No servers found in", serversFile)
		return
	}

	var mu sync.Mutex
	var wg sync.WaitGroup
	var ranks []ServerRank

	for _, raw := range hosts {
		host := normalizeHost(raw)
		wg.Add(1)
		go func(h string) {
			defer wg.Done()
			files, err := listRemote(h)
			if err != nil {
				mu.Lock()
				fmt.Printf("  [%s] unreachable: %v\n", h, err)
				mu.Unlock()
				return
			}
			var total int64
			for _, f := range files {
				total += f.Size
			}
			mu.Lock()
			ranks = append(ranks, ServerRank{
				Host:      h,
				FileCount: len(files),
				TotalSize: total,
			})
			mu.Unlock()
		}(host)
	}
	wg.Wait()

	// Sort descending by file count, then total size
	sort.Slice(ranks, func(i, j int) bool {
		if ranks[i].FileCount != ranks[j].FileCount {
			return ranks[i].FileCount > ranks[j].FileCount
		}
		return ranks[i].TotalSize > ranks[j].TotalSize
	})

	fmt.Printf("\n%-30s  %10s  %15s\n", "HOST", "FILES", "TOTAL SIZE")
	fmt.Println(strings.Repeat("-", 60))
	for idx, r := range ranks {
		fmt.Printf("#%-3d %-26s  %10d  %12s\n",
			idx+1, r.Host, r.FileCount, humanSize(r.TotalSize))
	}
	fmt.Println()

	// Save JSON
	data, _ := json.MarshalIndent(ranks, "", "  ")
	if err := os.WriteFile(serversJSON, data, 0644); err != nil {
		fmt.Println("[!] Could not save", serversJSON, ":", err)
	} else {
		fmt.Println("[+] Saved results to", serversJSON)
	}
}

func humanSize(b int64) string {
	const unit = 1024
	if b < unit {
		return fmt.Sprintf("%d B", b)
	}
	div, exp := int64(unit), 0
	for n := b / unit; n >= unit; n /= unit {
		div *= unit
		exp++
	}
	return fmt.Sprintf("%.1f %cB", float64(b)/float64(div), "KMGTPE"[exp])
}

func cmdHelp() {
	fmt.Println(`
+------------------------------------------+
�          eel meento  �  P2P tool         �
+------------------------------------------+

Commands:
  port <n>    Change port (default 52525)
  download    Download all files from servers listed in servers.txt
  rank        Show servers ranked by file count & total size; save servers.json
  help        Show this help
  exit / quit Stop the program
`)
}

// --- REPL --------------------------------------------------------------------

func repl() {
	sc := bufio.NewScanner(os.Stdin)
	fmt.Println("eel meento  |  type 'help' for commands")
	fmt.Print("> ")

	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			fmt.Print("> ")
			continue
		}
		parts := strings.Fields(line)
		cmd := strings.ToLower(parts[0])
		args := parts[1:]

		switch cmd {
		case "port":
			cmdPort(args)
		case "download":
			cmdDownload()
		case "rank":
			cmdRank()
		case "help":
			cmdHelp()
		case "exit", "quit":
			fmt.Println("bye!")
			os.Exit(0)
		default:
			fmt.Printf("[?] Unknown command: %q  (type 'help')\n", cmd)
		}
		fmt.Print("> ")
	}
}

// --- Main --------------------------------------------------------------------

func main() {
	// Ensure download dir exists
	os.MkdirAll(downloadDir, 0755)

	// Start HTTP server in background
	go startServer()

	// Small pause so the server binding message appears before the prompt
	time.Sleep(100 * time.Millisecond)

	repl()
}