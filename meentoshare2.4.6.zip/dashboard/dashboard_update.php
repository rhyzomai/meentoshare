﻿<?php

// 1. Define file paths
$inputFile = 'rank.txt';
$outputFile = 'stats.json';
$tmpDir = 'tmp_rank/';

// Check if the input file exists before proceeding
if (!file_exists($inputFile)) {
    die("Error: The file '$inputFile' does not exist.\n");
}

// 2. Read contents and generate SHA-256 hash
$fileContent = file_get_contents($inputFile);
$fileHash = hash('sha256', $fileContent);
$hashFilePath = $tmpDir . $fileHash . '.txt';

// Ensure the temporary directory exists
if (!is_dir($tmpDir)) {
    mkdir($tmpDir, 0777, true);
}

// 3. Prevent duplicate insertion using fopen()
// If we can open the file for reading, it already exists, meaning this data is a duplicate.
$checkFile = @fopen($hashFilePath, 'r');
if ($checkFile) {
    fclose($checkFile);
    die("Notice: Data already processed. The hash file '$fileHash' exists.\n");
}

// 4. Parse the `rank.txt` data
$lines = explode("\n", $fileContent);
$isParsingKeys = false;
$extractedData = [];
$currentKey = null;

foreach ($lines as $line) {
    // Detect the start of the Public Keys section
    if (strpos($line, '-- TOP 100 PUBLIC KEYS BY SERVER COUNT') !== false) {
        $isParsingKeys = true;
        continue;
    }

    if ($isParsingKeys) {
        // Stop parsing if we hit the end of the section/file
        if (strpos($line, '======================') !== false) {
            break;
        }

        // Match the rank and ID (e.g., "1. 123" or "2. 54654")
        if (preg_match('/^\s*\d+\.\s+([a-zA-Z0-9]+)/', $line, $matches)) {
            $currentKey = $matches[1];
        }

        // Match the server count (e.g., "1 server(s)")
        // This is done separately because of the line breaks and [source] tags in your file
        if ($currentKey && preg_match('/(\d+)\s+server\(s\)/', $line, $matches)) {
            $extractedData[$currentKey] = (int)$matches[1];
            $currentKey = null; // Reset for the next entry
        }
    }
}

// 5. Read existing stats or initialize a new array
$stats = [];
if (file_exists($outputFile)) {
    $existingData = json_decode(file_get_contents($outputFile), true);
    if (is_array($existingData)) {
        $stats = $existingData;
    }
}

// 6. Update the stats array with the newly parsed data
foreach ($extractedData as $id => $count) {
    $index = -1;
    
    // Check if the public key already exists in our stats
    foreach ($stats as $i => $item) {
        if ($item['id'] === $id) {
            $index = $i;
            break;
        }
    }

    if ($index === -1) {
        // NEW KEY: Initialize matching the dashboard's data structure
        // Generate a random hex color for the dashboard charts
        $color = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
        
        $stats[] = [
            'id' => $id,
            'color' => $color,
            'allTimeStartValue' => $count,
            'history' => [
                'day' => array_fill(0, 24, $count),   // Pad 24 hours
                'week' => array_fill(0, 7, $count),   // Pad 7 days
                'month' => array_fill(0, 30, $count)  // Pad 30 days
            ]
        ];
    } else {
        // EXISTING KEY: Push the new data point and shift off the oldest to maintain chart length
        
        // Update 24h Data
        array_shift($stats[$index]['history']['day']);
        $stats[$index]['history']['day'][] = $count;

        // Update 7-Day Data
        array_shift($stats[$index]['history']['week']);
        $stats[$index]['history']['week'][] = $count;

        // Update 30-Day Data
        array_shift($stats[$index]['history']['month']);
        $stats[$index]['history']['month'][] = $count;
    }
}

// 7. Write the formatted data to stats.json
file_put_contents($outputFile, json_encode($stats, JSON_PRETTY_PRINT));
echo "Success: Data updated in '$outputFile'.\n";

// 8. Create the empty hash file using fopen() to flag this file as completed
$hashFile = fopen($hashFilePath, 'w');
if ($hashFile) {
    fclose($hashFile);
    echo "Success: Lock file created at '$hashFilePath'.\n";
} else {
    echo "Warning: Could not create lock file at '$hashFilePath'.\n";
}

?>