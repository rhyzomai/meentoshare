-- =============================================
-- Variance Dashboard - Database Schema
-- Compatible with MySQL 5.6+
-- =============================================

CREATE DATABASE IF NOT EXISTS variance_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE variance_db;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    balance DECIMAL(18,2) NOT NULL DEFAULT 1000.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Public keys table (the "keys" shown in the dashboard)
CREATE TABLE IF NOT EXISTS public_keys (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    key_id VARCHAR(20) NOT NULL UNIQUE,
    color VARCHAR(10) NOT NULL DEFAULT '#4bc0c0',
    all_time_start_value DECIMAL(18,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Key history (stores daily value snapshots per key)
CREATE TABLE IF NOT EXISTS key_history (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    public_key_id INT UNSIGNED NOT NULL,
    timeframe ENUM('day','week','month') NOT NULL,
    position_index SMALLINT UNSIGNED NOT NULL,
    value DECIMAL(18,4) NOT NULL,
    FOREIGN KEY (public_key_id) REFERENCES public_keys(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Transactions table
CREATE TABLE IF NOT EXISTS transactions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    public_key_id INT UNSIGNED NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    balance_before DECIMAL(18,2) NOT NULL,
    balance_after DECIMAL(18,2) NOT NULL,
    status ENUM('completed','failed') NOT NULL DEFAULT 'completed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (public_key_id) REFERENCES public_keys(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Seed public keys
INSERT IGNORE INTO public_keys (key_id, color, all_time_start_value) VALUES
    ('0x1A2b...89cF', '#ff6384', 50.00),
    ('0x4F5c...32dA', '#36a2eb', 75.00),
    ('0x7E8d...11bB', '#4bc0c0', 100.00),
    ('0x9C2a...77eF', '#ff9f40', 125.00);
