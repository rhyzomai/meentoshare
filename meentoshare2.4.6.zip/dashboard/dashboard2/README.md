# Variance Dashboard — Setup Guide

## Requirements
- PHP 7.0+
- MySQL 5.6+ (or MariaDB 10.x+)
- Web server: Apache or Nginx with PHP-FPM

---

## Installation (3 steps)

### 1. Copy files to your web server
Place all files inside your web root, e.g.:
```
/var/www/html/variance/
htdocs/variance/
```

### 2. Edit `config.php` — set your MySQL credentials
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'variance_db');
define('DB_USER', 'root');    // your MySQL username
define('DB_PASS', '');        // your MySQL password
```

> The MySQL user must have CREATE DATABASE privilege,
> or you can create the database manually first:
> `CREATE DATABASE variance_db;`

### 3. Open the app — everything else is automatic
```
http://localhost/variance/
```

On the very first request, `config.php` will automatically:
- Create the `variance_db` database if it doesn't exist
- Create all 4 tables if they don't exist
- Seed the 4 public keys and their chart history

No need to run schema.sql or seed.php manually.

---

## File Overview

| File | Description |
|---|---|
| `config.php` | DB credentials, auto-install schema, session helpers |
| `auth.php` | Register / Login / Logout POST handler |
| `api.php` | JSON API: stats, balance, transactions, deposit |
| `index.php` | Login & Register page |
| `dashboard.php` | Main dashboard UI |
| `schema.sql` | Optional: manual DB setup reference |
| `seed.php` | Optional: re-seed chart history data |

---

## How It Works

1. **Register** — New accounts receive a **$1,000.00** starting balance.
2. **Dashboard** — View live charts and performance metrics for 4 public keys.
3. **Deposit** — Click **+ Deposit** on any key row to open the deposit modal.
   - Enter an amount (or use quick buttons: $10 / $50 / $100 / $250).
   - If your balance is sufficient, the transaction is confirmed atomically.
   - Your balance updates instantly in the navbar.
4. **History** — All transactions are listed in the Transaction History table.
5. **Timeframe** — Switch between Last 24h / 7 Days / 30 Days for chart data.

---

## Security Notes
- Passwords hashed with `password_hash()` / BCRYPT
- All queries use PDO prepared statements (no SQL injection)
- Deposits use MySQL `FOR UPDATE` row-lock — atomic balance check + deduct
- In production: use a strong DB password and restrict MySQL user privileges
