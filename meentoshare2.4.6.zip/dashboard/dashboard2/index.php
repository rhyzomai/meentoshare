<?php
// =============================================
// index.php — Login / Register page
// =============================================
require_once 'config.php';
sessionStart();

if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit;
}

$tab   = $_GET['tab'] ?? 'login';
$error = $_SESSION['auth_error'] ?? '';
unset($_SESSION['auth_error']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Variance — Sign In</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Space+Mono:ital,wght@0,400;0,700;1,400&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --bg:       #0a0c0e;
            --surface:  #111417;
            --border:   #1f2428;
            --border2:  #2a3038;
            --accent:   #e8ff47;
            --accent2:  #47c8ff;
            --text:     #e2e8f0;
            --muted:    #64748b;
            --danger:   #ff4757;
            --positive: #2ecc71;
            --mono:     'Space Mono', monospace;
            --sans:     'DM Sans', sans-serif;
        }

        body {
            font-family: var(--sans);
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            overflow: hidden;
            position: relative;
        }

        /* Grid background */
        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background-image:
                linear-gradient(rgba(232,255,71,0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(232,255,71,0.03) 1px, transparent 1px);
            background-size: 60px 60px;
            pointer-events: none;
        }

        /* Glow orbs */
        body::after {
            content: '';
            position: fixed;
            width: 600px; height: 600px;
            background: radial-gradient(circle, rgba(232,255,71,0.05) 0%, transparent 70%);
            top: -200px; left: -200px;
            pointer-events: none;
        }

        .orb2 {
            position: fixed;
            width: 400px; height: 400px;
            background: radial-gradient(circle, rgba(71,200,255,0.06) 0%, transparent 70%);
            bottom: -100px; right: -100px;
            pointer-events: none;
            z-index: 0;
        }

        .auth-wrapper {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 420px;
        }

        .brand {
            text-align: center;
            margin-bottom: 36px;
        }

        .brand-logo {
            font-family: var(--mono);
            font-size: 13px;
            color: var(--accent);
            letter-spacing: 4px;
            text-transform: uppercase;
            margin-bottom: 8px;
        }

        .brand-name {
            font-family: var(--mono);
            font-size: 32px;
            font-weight: 700;
            color: var(--text);
            letter-spacing: -1px;
        }

        .brand-name span { color: var(--accent); }

        .brand-tagline {
            font-size: 13px;
            color: var(--muted);
            margin-top: 6px;
            letter-spacing: 0.5px;
        }

        .card {
            background: var(--surface);
            border: 1px solid var(--border2);
            border-radius: 12px;
            overflow: hidden;
        }

        .tabs {
            display: flex;
            border-bottom: 1px solid var(--border2);
        }

        .tab-btn {
            flex: 1;
            padding: 16px;
            font-family: var(--mono);
            font-size: 12px;
            letter-spacing: 2px;
            text-transform: uppercase;
            color: var(--muted);
            background: transparent;
            border: none;
            cursor: pointer;
            transition: all .2s;
        }

        .tab-btn.active {
            color: var(--accent);
            background: rgba(232,255,71,0.04);
            border-bottom: 2px solid var(--accent);
            margin-bottom: -1px;
        }

        .tab-btn:hover:not(.active) { color: var(--text); background: rgba(255,255,255,0.02); }

        .form-panel { padding: 32px; display: none; }
        .form-panel.active { display: block; }

        .error-box {
            background: rgba(255,71,87,0.1);
            border: 1px solid rgba(255,71,87,0.3);
            border-radius: 6px;
            padding: 10px 14px;
            font-size: 13px;
            color: var(--danger);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .field {
            margin-bottom: 18px;
        }

        label {
            display: block;
            font-size: 11px;
            font-family: var(--mono);
            letter-spacing: 1.5px;
            text-transform: uppercase;
            color: var(--muted);
            margin-bottom: 7px;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            background: var(--bg);
            border: 1px solid var(--border2);
            border-radius: 6px;
            padding: 11px 14px;
            font-family: var(--sans);
            font-size: 14px;
            color: var(--text);
            transition: border-color .2s, box-shadow .2s;
            outline: none;
        }

        input:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(232,255,71,0.08);
        }

        input::placeholder { color: #334155; }

        .btn-primary {
            width: 100%;
            padding: 13px;
            background: var(--accent);
            color: #0a0c0e;
            border: none;
            border-radius: 6px;
            font-family: var(--mono);
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            cursor: pointer;
            margin-top: 6px;
            transition: opacity .2s, transform .1s;
        }

        .btn-primary:hover { opacity: .9; transform: translateY(-1px); }
        .btn-primary:active { transform: translateY(0); }

        .starting-balance {
            text-align: center;
            margin-top: 16px;
            font-size: 12px;
            color: var(--muted);
        }

        .starting-balance strong {
            color: var(--positive);
            font-family: var(--mono);
        }

        .footer-note {
            text-align: center;
            margin-top: 20px;
            font-size: 12px;
            color: var(--muted);
        }
    </style>
</head>
<body>
    <div class="orb2"></div>
    <div class="auth-wrapper">
        <div class="brand">
            <div class="brand-logo">∆ Key Analytics</div>
            <div class="brand-name">VARI<span>ANCE</span></div>
            <div class="brand-tagline">Track · Deposit · Analyze</div>
        </div>

        <div class="card">
            <div class="tabs">
                <button class="tab-btn <?= $tab === 'login' ? 'active' : '' ?>"
                        onclick="switchTab('login')">Sign In</button>
                <button class="tab-btn <?= $tab === 'register' ? 'active' : '' ?>"
                        onclick="switchTab('register')">Register</button>
            </div>

            <!-- Login -->
            <div class="form-panel <?= $tab === 'login' ? 'active' : '' ?>" id="panel-login">
                <?php if ($error && $tab !== 'register'): ?>
                <div class="error-box">⚠ <?= htmlspecialchars($error) ?></div>
                <?php endif; ?>
                <form method="POST" action="auth.php">
                    <input type="hidden" name="action" value="login">
                    <div class="field">
                        <label>Username or Email</label>
                        <input type="text" name="username" placeholder="your_handle" required autocomplete="username">
                    </div>
                    <div class="field">
                        <label>Password</label>
                        <input type="password" name="password" placeholder="••••••••" required autocomplete="current-password">
                    </div>
                    <button type="submit" class="btn-primary">Enter Dashboard</button>
                </form>
            </div>

            <!-- Register -->
            <div class="form-panel <?= $tab === 'register' ? 'active' : '' ?>" id="panel-register">
                <?php if ($error && $tab === 'register'): ?>
                <div class="error-box">⚠ <?= htmlspecialchars($error) ?></div>
                <?php endif; ?>
                <form method="POST" action="auth.php">
                    <input type="hidden" name="action" value="register">
                    <div class="field">
                        <label>Username</label>
                        <input type="text" name="username" placeholder="your_handle" required autocomplete="username">
                    </div>
                    <div class="field">
                        <label>Email</label>
                        <input type="email" name="email" placeholder="you@domain.com" required autocomplete="email">
                    </div>
                    <div class="field">
                        <label>Password</label>
                        <input type="password" name="password" placeholder="Min. 6 characters" required autocomplete="new-password">
                    </div>
                    <button type="submit" class="btn-primary">Create Account</button>
                    <div class="starting-balance">
                        New accounts start with <strong>$1,000.00</strong> balance
                    </div>
                </form>
            </div>
        </div>

        <div class="footer-note">Variance Dashboard &copy; <?= date('Y') ?></div>
    </div>

    <script>
        function switchTab(tab) {
            document.querySelectorAll('.tab-btn').forEach((b,i) =>
                b.classList.toggle('active', (i === 0 ? 'login' : 'register') === tab)
            );
            document.querySelectorAll('.form-panel').forEach(p =>
                p.classList.toggle('active', p.id === 'panel-' + tab)
            );
        }
    </script>
</body>
</html>
