﻿<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: auth.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Safe preparation wrapper
$stmt = $conn->prepare("SELECT balance FROM users WHERE id = ?");

if ($stmt === false) {
    // If the prepare failed, this will print the exact reason why MySQL rejected it
    die("MySQL Prepare Error: " . $conn->error); 
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($balance);
$stmt->fetch();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Advanced Key Variance Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* CSS variables and global layout remains identical */
        :root {
            --bg-color: #f4f7f6;
            --card-bg: #ffffff;
            --text-main: #333333;
            --text-muted: #666666;
            --border-color: #e0e0e0;
            --positive: #2ecc71;
            --negative: #e74c3c;
        }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: var(--bg-color); color: var(--text-main); margin: 0; padding: 20px; }
        .dashboard-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 2px solid var(--border-color); }
        .header-titles h1 { margin: 0 0 5px 0; color: #2c3e50; font-size: 24px; }
        .header-titles p { margin: 0; color: var(--text-muted); font-size: 14px; }
        .controls select { padding: 8px 12px; border-radius: 6px; border: 1px solid var(--border-color); font-size: 14px; background-color: white; cursor: pointer; }
        .dashboard-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 20px; margin-bottom: 20px; }
        .card { background-color: var(--card-bg); border-radius: 8px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); border: 1px solid var(--border-color); }
        .card h3 { margin-top: 0; margin-bottom: 15px; font-size: 16px; color: #2c3e50; }
        .chart-container-line { position: relative; height: 350px; width: 100%; }
        .chart-container-pie { position: relative; height: 300px; width: 100%; display: flex; justify-content: center; }
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; text-align: left; font-size: 14px; }
        th, td { padding: 12px 15px; border-bottom: 1px solid var(--border-color); }
        th { background-color: #f9fbfb; color: var(--text-muted); font-weight: 600; }
        .key-id { font-family: monospace; font-weight: bold; }
        .indicator { display: inline-block; width: 10px; height: 10px; border-radius: 50%; margin-right: 8px; }
        .val-positive { color: var(--positive); font-weight: 500; }
        .val-negative { color: var(--negative); font-weight: 500; }

        .user-panel { display: flex; align-items: center; gap: 15px; }
        .balance-badge { background: #2c3e50; color: white; padding: 8px 15px; border-radius: 20px; font-weight: bold; }
        .logout-btn { color: var(--negative); text-decoration: none; font-weight: bold; }
        table tbody tr:hover { background-color: #f1f1f1; cursor: pointer; }
        
        /* Updated Multi-Step Transaction Modal Styles */
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5); }
        .modal-content { background-color: white; margin: 15% auto; padding: 25px; border-radius: 8px; width: 320px; text-align: center; position: relative; box-shadow: 0 5px 15px rgba(0,0,0,0.3); }
        .close { position: absolute; right: 15px; top: 10px; font-size: 24px; cursor: pointer; color: #aaa; }
        .close:hover { color: #333; }
        .modal input { width: 90%; padding: 10px; margin: 15px 0; border: 1px solid #ccc; border-radius: 4px; font-size: 16px; text-align: center; }
        .modal-btn { width: 100%; padding: 11px; margin-top: 10px; border: none; border-radius: 4px; cursor: pointer; font-weight: bold; font-size: 14px; }
        .btn-confirm { background-color: #36a2eb; color: white; }
        .btn-danger { background-color: #e74c3c; color: white; }
        .btn-secondary { background-color: #bbb; color: white; margin-top: 5px; }
        .error-msg { color: #e74c3c; font-size: 13px; margin-top: 10px; font-weight: 500; }
        .success-msg { color: #2ecc71; font-size: 15px; margin-top: 10px; font-weight: bold; }
        .step-view { display: none; }
        .step-view.active { display: block; }
        .confirm-box { background: #f8f9fa; border: 1px dashed #ccc; padding: 15px; border-radius: 6px; margin: 15px 0; text-align: left; font-size: 14px; }
    </style>
</head>
<body>

    <div class="dashboard-header">
        <div class="header-titles">
            <h1>Advanced Variance Dashboard</h1>
            <p id="statusText">Attempting to load data...</p>
        </div>
        <div class="user-panel">
            <div class="balance-badge">Balance: $<span id="userBalance"><?php echo number_format($balance, 2); ?></span></div>
            <a href="auth.php?logout=true" class="logout-btn">Logout</a>
        </div>
        <div class="controls">
            <label for="timeframe" style="font-weight: 500; margin-right: 10px;">Timeframe:</label>
            <select id="timeframe" onchange="handleTimeframeChange()">
                <option value="day">Last 24 Hours</option>
                <option value="week">Last 7 Days</option>
                <option value="month" selected>Last 30 Days</option>
            </select>
        </div>
    </div>

    <div id="depositModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            
            <div id="stepAmount" class="step-view active">
                <h3>Deposit Funds</h3>
                <p style="margin:0; font-size:14px; color:#666;">Target Key: <strong class="target-key-label"></strong></p>
                <input type="number" id="depositAmount" placeholder="Amount (e.g. 100.00)" min="0.01" step="0.01">
                <button class="modal-btn btn-confirm" onclick="goToConfirmation()">Next</button>
                <div id="amountError" class="error-msg"></div>
            </div>

            <div id="stepConfirm" class="step-view">
                <h3>Confirm Transaction</h3>
                <p style="margin:0; font-size:14px; color:#666;">Are you sure you want to proceed?</p>
                <div class="confirm-box">
                    <strong>Target:</strong> <span class="target-key-label" style="font-family: monospace;"></span><br>
                    <strong>Amount:</strong> $<span id="confirmAmountLabel"></span>
                </div>
                <button class="modal-btn btn-danger" onclick="processDeposit()">Yes, Deposit Funds</button>
                <button class="modal-btn btn-secondary" onclick="backToAmount()">Back</button>
                <div id="confirmError" class="error-msg"></div>
            </div>

            <div id="stepSuccess" class="step-view">
                <div style="font-size: 45px; color: #2ecc71; margin-bottom: 10px;">🎉</div>
                <h3>Transaction Successful!</h3>
                <p class="success-msg">Your deposit has been completed.</p>
                <p style="font-size: 13px; color:#777;">The transaction table record has been securely created.</p>
            </div>
        </div>
    </div>

    <div class="dashboard-grid">
        <div class="card">
            <h3>Value Over Time</h3>
            <div class="chart-container-line"><canvas id="lineChart"></canvas></div>
        </div>
        <div class="card">
            <h3>Current Distribution</h3>
            <div class="chart-container-pie"><canvas id="pieChart"></canvas></div>
        </div>
    </div>

    <div class="card" style="margin-top: 20px;">
        <h3>Performance Metrics (Sorted by Current Value) - <span style="color:#36a2eb; font-size:14px;">Click a row to deposit</span></h3>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Public Key</th>
                        <th>Current Value</th>
                        <th>Period Start Value</th>
                        <th>Period Change (%)</th>
                        <th>All-Time Start</th>
                        <th>All-Time Change (%)</th>
                    </tr>
                </thead>
                <tbody id="dataTableBody"></tbody>
            </table>
        </div>
    </div>

    <script>
        let dashboardData = [];
        let lineChartInstance = null;
        let pieChartInstance = null;
        let selectedPublicKey = '';
        let validatedAmount = 0;

        // Base visual walking logic
        function generateWalk(startValue, steps, volatility) {
            let data = [startValue];
            let current = startValue;
            for(let i = 1; i < steps; i++) {
                current += (Math.random() - 0.5) * volatility;
                data.push(Number(current.toFixed(2)));
            }
            return data;
        }

        function generateFallbackData() {
            const keys = [
                { id: '0x1A2b...89cF', color: '#ff6384' },
                { id: '0x4F5c...32dA', color: '#36a2eb' },
                { id: '0x7E8d...11bB', color: '#4bc0c0' },
                { id: '0x9C2a...77eF', color: '#ff9f40' }
            ];
            return keys.map((key, index) => {
                const allTimeStart = 50 + (index * 25);
                const monthData = generateWalk(allTimeStart, 30, 15);
                const currentMonthValue = monthData[monthData.length - 1];
                const weekData = monthData.slice(-7);
                const dayStart = currentMonthValue + ((Math.random() - 0.5) * 10);
                const dayData = generateWalk(dayStart, 23, 3);
                dayData.push(currentMonthValue); 
                return { id: key.id, color: key.color, allTimeStartValue: allTimeStart, history: { day: dayData, week: weekData, month: monthData } };
            });
        }

        async function loadData() {
            const statusText = document.getElementById('statusText');
            try {
                const response = await fetch('stats.json');
                if (!response.ok) throw new Error('File not found');
                dashboardData = await response.json();
                statusText.innerText = "Data loaded successfully";
                statusText.style.color = "var(--positive)";
            } catch (error) {
                dashboardData = generateFallbackData();
                statusText.innerText = "Showing live auto-generated data.";
                statusText.style.color = "var(--text-muted)";
            }
            updateDashboard();
        }

        function calcChange(start, end) { return (((end - start) / start) * 100).toFixed(2); }
        function formatChangeHtml(percent) {
            const num = parseFloat(percent);
            if (num > 0) return `<span class="val-positive">+${percent}%</span>`;
            if (num < 0) return `<span class="val-negative">${percent}%</span>`;
            return `<span>${percent}%</span>`;
        }

        function updateDashboard() {
            const timeframe = document.getElementById('timeframe').value;
            const processedData = dashboardData.map(key => {
                const historyArray = key.history[timeframe];
                const periodStart = historyArray[0];
                const current = historyArray[historyArray.length - 1];
                return { ...key, currentValue: current, periodStartValue: periodStart, periodChange: calcChange(periodStart, current), allTimeChange: calcChange(key.allTimeStartValue, current) };
            });

            processedData.sort((a, b) => b.currentValue - a.currentValue);

            const tbody = document.getElementById('dataTableBody');
            tbody.innerHTML = '';
            processedData.forEach(item => {
                const tr = document.createElement('tr');
                tr.onclick = () => openModal(item.id);
                tr.innerHTML = `
                    <td>
                        <span class="indicator" style="background-color: ${item.color};"></span>
                        <span class="key-id">${item.id}</span>
                    </td>
                    <td style="font-weight: bold;">${item.currentValue.toFixed(2)}</td>
                    <td>${item.periodStartValue.toFixed(2)}</td>
                    <td>${formatChangeHtml(item.periodChange)}</td>
                    <td>${item.allTimeStartValue.toFixed(2)}</td>
                    <td>${formatChangeHtml(item.allTimeChange)}</td>
                `;
                tbody.appendChild(tr);
            });

            const labelsMap = { 'day': Array.from({length: 24}, (_, i) => `T-${24-i}h`), 'week': ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6', 'Today'], 'month': Array.from({length: 30}, (_, i) => `D-${30-i}`) };
            const lineDatasets = dashboardData.map(key => ({ label: key.id, data: key.history[timeframe], borderColor: key.color, backgroundColor: key.color, borderWidth: 2, tension: 0.3, pointRadius: 2 }));

            if (lineChartInstance) lineChartInstance.destroy();
            lineChartInstance = new Chart(document.getElementById('lineChart').getContext('2d'), { type: 'line', data: { labels: labelsMap[timeframe], datasets: lineDatasets }, options: { responsive: true, maintainAspectRatio: false, interaction: { mode: 'index', intersect: false }, plugins: { legend: { position: 'top' } } } });

            const pieData = processedData.map(item => item.currentValue);
            const pieColors = processedData.map(item => item.color);
            const pieLabels = processedData.map(item => item.id);

            if (pieChartInstance) pieChartInstance.destroy();
            pieChartInstance = new Chart(document.getElementById('pieChart').getContext('2d'), { type: 'doughnut', data: { labels: pieLabels, datasets: [{ data: pieData, backgroundColor: pieColors, borderWidth: 1 }] }, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } } });
        }

        function handleTimeframeChange() { updateDashboard(); }
        window.onload = loadData;

        // --- MULTI-STEP MODAL WINDOW WORKFLOW CONTROLLERS ---

        function openModal(publicKey) {
            selectedPublicKey = publicKey;
            
            // Apply targeted UI displays
            const targetLabels = document.querySelectorAll('.target-key-label');
            targetLabels.forEach(el => el.innerText = publicKey);

            document.getElementById('depositAmount').value = '';
            document.getElementById('amountError').innerText = '';
            document.getElementById('confirmError').innerText = '';
            
            // Reset to step 1
            showStep('stepAmount');
            document.getElementById('depositModal').style.display = 'block';
        }

        function closeModal() {
            document.getElementById('depositModal').style.display = 'none';
        }

        window.onclick = function(event) {
            let modal = document.getElementById('depositModal');
            if (event.target == modal) { closeModal(); }
        }

        function showStep(stepId) {
            const steps = document.querySelectorAll('.step-view');
            steps.forEach(step => step.classList.remove('active'));
            document.getElementById(stepId).classList.add('active');
        }

        function goToConfirmation() {
            const amountInput = document.getElementById('depositAmount').value;
            const errorDiv = document.getElementById('amountError');
            errorDiv.innerText = '';

            if (!amountInput || parseFloat(amountInput) <= 0) {
                errorDiv.innerText = "Please enter a valid amount greater than 0.";
                return;
            }

            validatedAmount = parseFloat(amountInput);
            document.getElementById('confirmAmountLabel').innerText = validatedAmount.toFixed(2);
            showStep('stepConfirm');
        }

        function backToAmount() {
            showStep('stepAmount');
        }

        async function processDeposit() {
            const errorDiv = document.getElementById('confirmError');
            errorDiv.innerText = '';

            try {
                const response = await fetch('process_deposit.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `public_key=${encodeURIComponent(selectedPublicKey)}&amount=${encodeURIComponent(validatedAmount)}`
                });
                
                const rawText = await response.text(); 
                
                try {
                    const result = JSON.parse(rawText);

                    if (result.success) {
                        // Update UI balance
                        document.getElementById('userBalance').innerText = parseFloat(result.new_balance).toFixed(2);
                        // Display the custom final success modal state
                        showStep('stepSuccess');
                        setTimeout(closeModal, 2500);
                    } else {
                        errorDiv.innerText = result.message || "The action was declined by the server.";
                    }
} catch (parseError) {
    // THIS WILL TELL YOU EXACTLY WHAT TEXT IS CORRUPTING YOUR JSON:
    alert(rawText);
    
    errorDiv.innerText = "Internal format syntax fault. Verify configuration output context logs.";
    console.error("Format failure data received:", rawText);
}
            } catch (error) {
                errorDiv.innerText = "Network transmission drop occurred.";
            }
        }
    </script>
</body>
</html>