﻿<?php
// Make sure no errors block our JSON output layout
error_reporting(0); 
ini_set('display_errors', 0);

session_start();
header('Content-Type: application/json; charset=utf-8');
require 'db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false, "message" => "Unauthorized. Please log in."]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $public_key = isset($_POST['public_key']) ? trim($_POST['public_key']) : '';
    $amount = isset($_POST['amount']) ? filter_var($_POST['amount'], FILTER_VALIDATE_FLOAT) : false;

    if ($amount === false || $amount <= 0 || empty($public_key)) {
        echo json_encode(["success" => false, "message" => "Invalid transaction data parameters."]);
        exit;
    }

    // Start MySQL transaction
    $conn->begin_transaction();

    try {
        // 1. Fetch balance safely with row-level locking
        $stmt = $conn->prepare("SELECT balance FROM users WHERE id = ? FOR UPDATE");
        if ($stmt === false) {
            throw new Exception("Database prepare fault: " . $conn->error);
        }
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->bind_result($current_balance);
        $stmt->fetch();
        $stmt->close();

        // 2. Check funds
        if ($current_balance < $amount) {
            throw new Exception("Insufficient funds. Your balance is insufficient.");
        }

        $new_balance = $current_balance - $amount;

        // 3. Deduct from balance
        $stmt_update = $conn->prepare("UPDATE users SET balance = ? WHERE id = ?");
        if ($stmt_update === false) {
            throw new Exception("Database update prepare fault: " . $conn->error);
        }
        $stmt_update->bind_param("di", $new_balance, $user_id);
        $stmt_update->execute();
        $stmt_update->close();

        // 4. Insert transaction record
        $stmt_insert = $conn->prepare("INSERT INTO transactions (user_id, public_key, amount) VALUES (?, ?, ?)");
        if ($stmt_insert === false) {
            throw new Exception("Database insert prepare fault: " . $conn->error);
        }
        $stmt_insert->bind_param("isd", $user_id, $public_key, $amount);
        $stmt_insert->execute();
        $stmt_insert->close();

        // 5. Commit everything if clean
        $conn->commit();

        // Output ONLY clean JSON
        echo json_encode([
            "success" => true, 
            "new_balance" => $new_balance,
            "message" => "Transaction complete."
        ]);
        exit;

    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(["success" => false, "message" => $e->getMessage()]);
        exit;
    }
} else {
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
    exit;
}