﻿<?php
$host = 'localhost';
$db   = 'variance_db';
$user = 'root'; // Change if needed
$pass = '';     // Change if needed

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//?>