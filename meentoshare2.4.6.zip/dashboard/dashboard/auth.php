﻿<?php
session_start();
require 'db.php';

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: auth.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if (isset($_POST['register'])) {
        $email = trim($_POST['email']);
        $whatsapp = !empty(trim($_POST['whatsapp'])) ? trim($_POST['whatsapp']) : null;

        // Validation checks
        if (empty($username) || empty($email) || empty($password)) {
            $error = "Please fill in all required fields.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Please enter a valid email address.";
        } elseif (strlen($password) < 8) {
            $error = "Password must be at least 8 characters long.";
        } elseif (!preg_match('/[A-Z]/', $password)) {
            $error = "Password must contain at least one uppercase letter.";
        } elseif (!preg_match('/[^a-zA-Z0-9]/', $password)) {
            $error = "Password must contain at least one special character.";
        } else {
            // Check if username or email already exists
            $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->bind_param("ss", $username, $email);
            $stmt->execute();
            $stmt->store_result();
            
            if ($stmt->num_rows > 0) {
                $error = "Username or Email already registered.";
                $stmt->close();
            } else {
                $stmt->close();
                // Securely hash password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("INSERT INTO users (username, email, whatsapp, password) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("ssss", $username, $email, $whatsapp, $hashed_password);
                
                if ($stmt->execute()) {
                    $success = "Registration successful! You can now login.";
                } else {
                    $error = "An unexpected database error occurred.";
                }
                $stmt->close();
            }
        }
    } elseif (isset($_POST['login'])) {
        $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();
        
        if ($stmt->num_rows > 0) {
            $stmt->bind_result($id, $hashed_password);
            $stmt->fetch();
            if (password_verify($password, $hashed_password)) {
                $_SESSION['user_id'] = $id;
                $_SESSION['username'] = $username;
                header("Location: index.php");
                exit;
            } else {
                $error = "Invalid password.";
            }
        } else {
            $error = "User not found.";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login / Register</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #f4f7f6; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; padding: 20px 0; }
        .auth-container { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); width: 340px; text-align: center; }
        .tabs { display: flex; justify-content: space-around; margin-bottom: 20px; }
        .tab { font-weight: bold; cursor: pointer; color: #aaa; padding-bottom: 5px; }
        .tab.active { color: #36a2eb; border-bottom: 2px solid #36a2eb; }
        input { width: 92%; padding: 10px; margin: 8px 0; border: 1px solid #ccc; border-radius: 4px; font-size: 14px; }
        button { width: 100%; padding: 11px; margin-top: 15px; border: none; border-radius: 4px; cursor: pointer; font-weight: bold; font-size: 14px; color: white; }
        .btn-submit { background-color: #36a2eb; }
        .message { color: #e74c3c; font-size: 14px; margin-bottom: 12px; font-weight: 500; text-align: left; }
        .success { color: #2ecc71; }
        .requirements { font-size: 11px; color: #777; text-align: left; margin: 2px 0 10px 5px; line-height: 1.4; }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="tabs">
            <span id="loginTab" class="tab active" onclick="switchForm('login')">LOGIN</span>
            <span id="registerTab" class="tab" onclick="switchForm('register')">REGISTER</span>
        </div>

        <?php if($error) echo "<div class='message'>⚠️ $error</div>"; ?>
        <?php if($success) echo "<div class='message success'>✅ $success</div>"; ?>

        <form id="loginForm" method="POST" action="">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" name="login" class="btn-submit">Login</button>
        </form>

        <form id="registerForm" method="POST" action="" style="display: none;">
            <input type="text" name="username" placeholder="Username *" required>
            <input type="email" name="email" placeholder="Email Address *" required>
            <input type="text" name="whatsapp" placeholder="WhatsApp Number (Optional)">
            <input type="password" name="password" placeholder="Password *" required>
            <div class="requirements">
                Must be at least 8 characters long, contain 1 uppercase letter and 1 special symbol (e.g. @, #, $, !).
            </div>
            <button type="submit" name="register" class="btn-submit" style="background-color: #2ecc71;">Create Account</button>
        </form>
    </div>

    <script>
        function switchForm(type) {
            if (type === 'register') {
                document.getElementById('loginForm').style.display = 'none';
                document.getElementById('registerForm').style.display = 'block';
                document.getElementById('loginTab').classList.remove('active');
                document.getElementById('registerTab').classList.add('active');
            } else {
                document.getElementById('loginForm').style.display = 'block';
                document.getElementById('registerForm').style.display = 'none';
                document.getElementById('loginTab').classList.add('active');
                document.getElementById('registerTab').classList.remove('active');
            }
        }
        // Retain the register tab if user was attempting to register and run into an error
        <?php if (isset($_POST['register'])): ?>
            switchForm('register');
        <?php endif; ?>
    </script>
</body>
</html>