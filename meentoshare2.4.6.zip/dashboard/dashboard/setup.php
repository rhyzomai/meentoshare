﻿<?php
// 1. Connect to MySQL without choosing a database yet
$host = 'localhost';
$user = 'root'; 
$pass = '';     

$conn = new mysqli($host, $user, $pass);

if ($conn->connect_error) {
    die("<span style='color:red; font-family:sans-serif;'>❌ Connection failed: " . $conn->connect_error . "</span>");
}

echo "<div style='font-family:sans-serif;'>";
echo "🟢 Connected to MySQL Server successfully.<br>";

// 2. Freshly create the database
$conn->query("DROP DATABASE IF EXISTS variance_db");
if ($conn->query("CREATE DATABASE variance_db") === TRUE) {
    echo "✅ Database 'variance_db' created successfully.<br>";
} else {
    die("❌ Error creating database: " . $conn->error . "</div>");
}

// 3. Now explicitly select the database
$conn->select_db("variance_db");

// 4. Create the users table with all required columns
$sql_users = "CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    whatsapp VARCHAR(20) DEFAULT NULL,
    password VARCHAR(255) NOT NULL,
    balance DECIMAL(10, 2) DEFAULT 1000.00
)";

if ($conn->query($sql_users) === TRUE) {
    echo "✅ Table 'users' created successfully.<br>";
} else {
    echo "❌ Error creating table 'users': " . $conn->error . "<br>";
}

// 5. Create the transactions table
$sql_transactions = "CREATE TABLE transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    public_key VARCHAR(100) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
)";

if ($conn->query($sql_transactions) === TRUE) {
    echo "✅ Table 'transactions' created successfully.<br>";
} else {
    echo "❌ Error creating table 'transactions': " . $conn->error . "<br>";
}

$conn->close();
echo "<br><b>🎉 All tables are ready! Open your browser and navigate to <a href='auth.php'>auth.php</a> to register a new user.</b>";
echo "</div>";
?>