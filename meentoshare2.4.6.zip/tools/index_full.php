﻿<?php
// ============================================================
//  Seastar — File Distributor & P2P Node
//
//  TRANSPORT MODES
//  ─────────────────────────────────────────────────────────
//  POST (default) — sends the whole file as a single
//                   multipart upload. Stored verbatim as
//                   files/<md5>.<ext>. Never overwritten.
//
//  GET            — splits the file into small base64 chunks
//                   sent as query-string params (100 B–8 KB
//                   raw per request). Stored as JSON chunks
//                   in base64_hash/ + index in chunks/.
//
//  IP RATE LIMITS
//  ─────────────────────────────────────────────────────────
//  ip_count/<sha256(ip+salt)>  — plain integer, incremented
//  on every accepted file. If count >= limit, new uploads
//  from that IP are rejected.
//  ip_time/<sha256(ip+salt)>   — unix timestamp of last
//  accepted upload. If now - last < interval_seconds, reject.
// ============================================================

define('BASE64_HASH_DIR',   __DIR__ . '/base64_hash');
define('CHUNKS_DIR',        __DIR__ . '/chunks');
define('FILES_DIR',         __DIR__ . '/files');
define('SEEDER_TMPDIR',     __DIR__ . '/seeder_tmp');
define('IP_COUNT_DIR',      __DIR__ . '/ip_count');
define('IP_TIME_DIR',       __DIR__ . '/ip_time');
define('SERVERS_FILE',      __DIR__ . '/servers.txt');
define('PUBLIC_KEY_FILE',   __DIR__ . '/public_key.txt');
define('NODE_INFO_FILE',    __DIR__ . '/node_info.txt');
define('FILES_LIST',        __DIR__ . '/files.txt');
define('SETTINGS_FILE',     __DIR__ . '/settings.json');
define('IP_TIME_CFG',       __DIR__ . '/ip_time.txt');    // stores max interval seconds
define('IP_CHUNKS_CFG',     __DIR__ . '/ip_chunks.txt');  // stores max files per IP
define('PASS_FILE',         __DIR__ . '/pass.txt');       // sha512 hash of reset password
define('MAX_UPLOAD_MB',     200);
define('MAX_IDENTITY_CHARS', 500);
define('GET_CHUNK_MIN',     100);
define('GET_CHUNK_MAX',     8192);

foreach ([BASE64_HASH_DIR, CHUNKS_DIR, FILES_DIR, SEEDER_TMPDIR, IP_COUNT_DIR, IP_TIME_DIR] as $d) {
    if (!is_dir($d)) mkdir($d, 0755, true);
}

// ============================================================
//  ip_time.txt / ip_chunks.txt — single-value config files
//  Each file holds one integer. Once written they lock the
//  field in the UI. Missing or empty = default 0.
// ============================================================

function loadIpTimeCfg(): int {
    if (!file_exists(IP_TIME_CFG)) return 0;
    $v = trim((string)@file_get_contents(IP_TIME_CFG));
    return ($v === '' || !ctype_digit($v)) ? 0 : (int)$v;
}

function loadIpChunksCfg(): int {
    if (!file_exists(IP_CHUNKS_CFG)) return 0;
    $v = trim((string)@file_get_contents(IP_CHUNKS_CFG));
    return ($v === '' || !ctype_digit($v)) ? 0 : (int)$v;
}

function ipTimeCfgLocked(): bool {
    if (!file_exists(IP_TIME_CFG)) return false;
    $v = trim((string)@file_get_contents(IP_TIME_CFG));
    return $v !== '';
}

function ipChunksCfgLocked(): bool {
    if (!file_exists(IP_CHUNKS_CFG)) return false;
    $v = trim((string)@file_get_contents(IP_CHUNKS_CFG));
    return $v !== '';
}

// ============================================================
//  Settings  (salt only persisted in settings.json)
// ============================================================

function loadSettings(): array {
    $salt = '';
    if (file_exists(SETTINGS_FILE)) {
        $raw  = @file_get_contents(SETTINGS_FILE);
        $data = $raw ? json_decode($raw, true) : null;
        $salt = is_array($data) ? ($data['ip_salt'] ?? '') : '';
    }
    if ($salt === '') {
        $salt = bin2hex(random_bytes(16));
        file_put_contents(SETTINGS_FILE, json_encode(['ip_salt' => $salt], JSON_PRETTY_PRINT));
    }
    return [
        'ip_max_files'    => loadIpChunksCfg(),
        'ip_interval_sec' => loadIpTimeCfg(),
        'ip_salt'         => $salt,
    ];
}

// ============================================================
//  pass.txt — sha512 hash for reset password verification
// ============================================================

function verifyResetPassword(string $input): bool {
    if (!file_exists(PASS_FILE)) return false;
    $stored = trim((string)@file_get_contents(PASS_FILE));
    if ($stored === '') return false;
    return hash_equals($stored, hash('sha512', $input));
}

// ============================================================
//  IP rate-limit helpers
// ============================================================

function ipKey(string $ip, string $salt): string {
    return hash('sha256', $ip . $salt);
}

function getClientIp(): string {
    foreach (['HTTP_CF_CONNECTING_IP','HTTP_X_REAL_IP','HTTP_X_FORWARDED_FOR','REMOTE_ADDR'] as $k) {
        if (!empty($_SERVER[$k])) {
            $ip = trim(explode(',', $_SERVER[$k])[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
        }
    }
    return '0.0.0.0';
}

// Returns ['allowed' => bool, 'reason' => string]
function checkIpLimit(string $ip, array $settings): array {
    $key = ipKey($ip, $settings['ip_salt']);

    // Check interval
    if ($settings['ip_interval_sec'] > 0) {
        $timePath = IP_TIME_DIR . '/' . $key;
        if (file_exists($timePath)) {
            $last = (int)trim(@file_get_contents($timePath));
            $wait = $settings['ip_interval_sec'] - (time() - $last);
            if ($wait > 0) {
                return ['allowed' => false,
                        'reason'  => "Rate limited: wait {$wait}s before sending again."];
            }
        }
    }

    // Check count
    if ($settings['ip_max_files'] > 0) {
        $countPath = IP_COUNT_DIR . '/' . $key;
        $count = file_exists($countPath) ? (int)trim(@file_get_contents($countPath)) : 0;
        if ($count >= $settings['ip_max_files']) {
            return ['allowed' => false,
                    'reason'  => "Upload limit reached for your IP ({$settings['ip_max_files']} files)."];
        }
    }

    return ['allowed' => true, 'reason' => ''];
}

function recordIpUpload(string $ip, array $settings): void {
    $key = ipKey($ip, $settings['ip_salt']);

    // Increment counter
    $countPath = IP_COUNT_DIR . '/' . $key;
    $count = file_exists($countPath) ? (int)trim(@file_get_contents($countPath)) : 0;
    file_put_contents($countPath, (string)($count + 1));

    // Record timestamp
    if ($settings['ip_interval_sec'] > 0) {
        file_put_contents(IP_TIME_DIR . '/' . $key, (string)time());
    }
}

// ============================================================
//  files.txt  — regenerated index of files/ directory
// ============================================================

function rebuildFilesList(): void {
    $files = glob(FILES_DIR . '/*') ?: [];
    $lines = [];
    foreach ($files as $f) {
        if (is_file($f)) $lines[] = basename($f);
    }
    sort($lines);
    file_put_contents(FILES_LIST, implode("\n", $lines) . (count($lines) ? "\n" : ''));
}

// ============================================================
//  Identity helpers
// ============================================================

function loadPublicKey(): string {
    if (!file_exists(PUBLIC_KEY_FILE)) return '';
    return trim((string)@file_get_contents(PUBLIC_KEY_FILE));
}

function loadNodeInfo(): string {
    if (!file_exists(NODE_INFO_FILE)) return '';
    return trim((string)@file_get_contents(NODE_INFO_FILE));
}

// ============================================================
//  Server list helpers
// ============================================================

function loadServers(): array {
    if (!file_exists(SERVERS_FILE)) return [];
    $lines = file(SERVERS_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    return array_values(array_unique(array_map('trim', $lines ?: [])));
}

function addServer(string $url): string {
    $url = trim($url);
    if ($url === '') return 'empty';
    $servers = loadServers();
    if (in_array($url, $servers, true)) return 'duplicate';
    $servers[] = $url;
    $fh = fopen(SERVERS_FILE, 'w');
    if (!$fh) return 'write_error';
    foreach ($servers as $s) fwrite($fh, $s . "\n");
    fclose($fh);
    return 'ok';
}

// ============================================================
//  Shared param helper
// ============================================================

function receiveParam(string $key): string {
    if (isset($_POST[$key]) && $_POST[$key] !== '') return $_POST[$key];
    if (isset($_GET[$key])  && $_GET[$key]  !== '') return $_GET[$key];
    return '';
}

// ============================================================
//  Utility
// ============================================================

function formatBytes(int $bytes): string {
    if ($bytes >= 1048576) return round($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024)    return round($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}

// ============================================================
//  API: ?action=receive_file  (POST multipart upload)
// ============================================================

function handleReceiveFile(): void {
    $settings = loadSettings();
    $ip       = getClientIp();
    $check    = checkIpLimit($ip, $settings);

    if (!$check['allowed']) {
        http_response_code(429);
        echo json_encode(['ok' => false, 'error' => $check['reason']]);
        exit;
    }

    if (empty($_FILES['upload_file']) || $_FILES['upload_file']['error'] !== UPLOAD_ERR_OK) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'No file received or upload error']);
        exit;
    }

    $sentHash = strtolower(trim(receiveParam('file_hash')));
    $origName = basename(receiveParam('filename') ?: $_FILES['upload_file']['name']);

    if (!preg_match('/^[a-f0-9]{32}$/', $sentHash)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Missing or invalid file_hash']);
        exit;
    }

    $actualHash = md5_file($_FILES['upload_file']['tmp_name']);
    if ($actualHash !== $sentHash) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'File integrity check failed',
                          'expected' => $sentHash, 'got' => $actualHash]);
        exit;
    }

    $ext      = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
    $ext      = preg_replace('/[^a-z0-9]/', '', $ext);
    $destName = $sentHash . ($ext !== '' ? '.' . $ext : '');
    $destPath = FILES_DIR . '/' . $destName;

    if (file_exists($destPath)) {
        echo json_encode(['ok' => true, 'file' => $destName, 'stored' => 'exists']);
        exit;
    }

    if (!move_uploaded_file($_FILES['upload_file']['tmp_name'], $destPath)) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'Failed to save file']);
        exit;
    }

    recordIpUpload($ip, $settings);
    rebuildFilesList();

    echo json_encode(['ok' => true, 'file' => $destName, 'stored' => 'new']);
    exit;
}

// ============================================================
//  API: ?action=receive_chunk  (GET base64 chunks)
// ============================================================

function handleReceiveChunk(): void {
    $settings = loadSettings();
    $ip       = getClientIp();
    $check    = checkIpLimit($ip, $settings);

    if (!$check['allowed']) {
        http_response_code(429);
        echo json_encode(['ok' => false, 'error' => $check['reason']]);
        exit;
    }

    $required = ['filename','file_hash','chunk_num','chunk_hash','contents','total_chunks'];
    foreach ($required as $k) {
        if (receiveParam($k) === '') {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => "Missing parameter: {$k}"]);
            exit;
        }
    }

    $filename    = basename(receiveParam('filename'));
    $fileHash    = strtolower(preg_replace('/[^a-f0-9]/i', '', receiveParam('file_hash')));
    $chunkNum    = (int)receiveParam('chunk_num');
    $sentHash    = strtolower(trim(receiveParam('chunk_hash')));
    $contents    = receiveParam('contents');
    $publicKey   = substr(receiveParam('public_key'), 0, MAX_IDENTITY_CHARS);
    $nodeInfo    = substr(receiveParam('node_info'),  0, MAX_IDENTITY_CHARS);
    $totalChunks = (int)receiveParam('total_chunks');

    if (!preg_match('/^[a-f0-9]{32}$/', $fileHash)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Invalid file_hash']);
        exit;
    }
    if ($chunkNum < 1 || $chunkNum > $totalChunks) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Invalid chunk_num']);
        exit;
    }

    $actualHash = md5($contents);
    if ($actualHash !== $sentHash) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Chunk integrity check failed',
                          'expected' => $sentHash, 'got' => $actualHash]);
        exit;
    }

    $chunkName     = $fileHash . '.' . $chunkNum . '.' . $sentHash;
    $chunkJsonPath = BASE64_HASH_DIR . '/' . $chunkName . '.json';
    $isNew         = !file_exists($chunkJsonPath);

    if ($isNew) {
        $data = [
            'filename'    => $filename,
            'file_hash'   => $fileHash,
            'chunk_num'   => $chunkNum,
            'chunk_name'  => $chunkName,
            'content'     => $contents,
            'public_key'  => $publicKey,
            'node_info'   => $nodeInfo,
            'received_at' => date('c'),
        ];
        $fh = fopen($chunkJsonPath, 'w');
        if ($fh) {
            fwrite($fh, json_encode($data, JSON_PRETTY_PRINT));
            fclose($fh);
        } else {
            http_response_code(500);
            echo json_encode(['ok' => false, 'error' => 'Failed to write chunk file']);
            exit;
        }
        recordIpUpload($ip, $settings);
    }

    $chunksIndexPath = CHUNKS_DIR . '/' . $fileHash . '.txt';
    $chunkListRaw    = receiveParam('chunk_list');
    if (!file_exists($chunksIndexPath) && $chunkListRaw !== '') {
        $chunkList = array_filter(array_map('trim', explode(',', $chunkListRaw)));
        $fh = fopen($chunksIndexPath, 'x');
        if ($fh) { foreach ($chunkList as $cn) fwrite($fh, $cn . "\n"); fclose($fh); }
    }

    echo json_encode(['ok' => true, 'chunk' => $chunkName, 'stored' => $isNew ? 'new' : 'exists']);
    exit;
}

// ============================================================
//  Send whole file via POST multipart
// ============================================================

function sendFileToServers(string $tmpPath, string $originalName): array {
    $servers   = loadServers();
    $publicKey = substr(loadPublicKey(), 0, MAX_IDENTITY_CHARS);
    $nodeInfo  = substr(loadNodeInfo(),  0, MAX_IDENTITY_CHARS);
    $fileHash  = md5_file($tmpPath);
    $fileSize  = filesize($tmpPath);
    $log       = [];

    $log[] = ['type' => 'info', 'msg' => "File: {$originalName}"];
    $log[] = ['type' => 'info', 'msg' => "MD5: {$fileHash}"];
    $log[] = ['type' => 'info', 'msg' => "Size: " . formatBytes($fileSize)];
    $log[] = ['type' => 'info', 'msg' => "Transport: POST (raw multipart upload)"];
    $log[] = ['type' => 'info', 'msg' => "Servers: " . count($servers)];

    if (empty($servers)) {
        $log[] = ['type' => 'error', 'msg' => 'No servers configured.'];
        return ['success' => false, 'log' => $log, 'file_hash' => $fileHash,
                'total_chunks' => 1, 'new_chunks' => 0, 'skipped' => 0,
                'original_name' => $originalName, 'file_size' => $fileSize];
    }

    $newFiles = 0;
    $skipped  = 0;

    foreach ($servers as $server) {
        $server   = rtrim($server, '/');
        $url      = $server . '/index.php?action=receive_file';
        $boundary = '----SeastarBound' . bin2hex(random_bytes(8));
        $eol      = "\r\n";

        $body = '';
        foreach (['file_hash' => $fileHash, 'filename' => $originalName,
                  'public_key' => $publicKey, 'node_info' => $nodeInfo] as $n => $v) {
            $body .= "--{$boundary}{$eol}Content-Disposition: form-data; name=\"{$n}\"{$eol}{$eol}{$v}{$eol}";
        }
        $mime  = mime_content_type($tmpPath) ?: 'application/octet-stream';
        $body .= "--{$boundary}{$eol}";
        $body .= "Content-Disposition: form-data; name=\"upload_file\"; filename=\""
                 . addslashes($originalName) . "\"{$eol}";
        $body .= "Content-Type: {$mime}{$eol}{$eol}";
        $body .= file_get_contents($tmpPath) . $eol;
        $body .= "--{$boundary}--{$eol}";

        $ctx = stream_context_create(['http' => [
            'method'        => 'POST',
            'header'        => "Content-Type: multipart/form-data; boundary={$boundary}\r\n"
                               . "Content-Length: " . strlen($body) . "\r\n",
            'content'       => $body,
            'timeout'       => 60,
            'ignore_errors' => true,
        ]]);

        $resp    = @file_get_contents($url, false, $ctx);
        $decoded = $resp !== false ? json_decode($resp, true) : null;

        if ($resp === false) {
            $log[] = ['type' => 'error', 'msg' => "→ {$server} FAILED (no response)"];
        } elseif (!empty($decoded['ok'])) {
            if (($decoded['stored'] ?? '') === 'exists') {
                $skipped++;
                $log[] = ['type' => 'skip', 'msg' => "→ {$server} already had this file ({$decoded['file']})"];
            } else {
                $newFiles++;
                $log[] = ['type' => 'ok', 'msg' => "→ {$server} ✓ stored as {$decoded['file']}"];
            }
        } else {
            $err = is_array($decoded) ? ($decoded['error'] ?? $resp) : $resp;
            $log[] = ['type' => 'error', 'msg' => "→ {$server} error: {$err}"];
        }
    }

    $log[] = ['type' => 'ok', 'msg' => "Done. {$newFiles} stored, {$skipped} already existed."];
    return ['success' => true, 'log' => $log, 'file_hash' => $fileHash,
            'total_chunks' => 1, 'new_chunks' => $newFiles, 'skipped' => $skipped,
            'original_name' => $originalName, 'file_size' => $fileSize];
}

// ============================================================
//  Send via GET (base64 chunks)
// ============================================================

function sendChunksToServers(string $tmpPath, string $originalName, int $getChunkBytes): array {
    $servers     = loadServers();
    $publicKey   = substr(loadPublicKey(), 0, MAX_IDENTITY_CHARS);
    $nodeInfo    = substr(loadNodeInfo(),  0, MAX_IDENTITY_CHARS);
    $fileHash    = md5_file($tmpPath);
    $fileSize    = filesize($tmpPath);
    $totalChunks = (int)ceil($fileSize / $getChunkBytes);
    $log         = [];

    $log[] = ['type' => 'info', 'msg' => "File: {$originalName}"];
    $log[] = ['type' => 'info', 'msg' => "MD5: {$fileHash}"];
    $log[] = ['type' => 'info', 'msg' => "Size: " . formatBytes($fileSize)];
    $log[] = ['type' => 'info', 'msg' => "Transport: GET (base64 chunks, " . formatBytes($getChunkBytes) . " raw/chunk)"];
    $log[] = ['type' => 'info', 'msg' => "Total chunks: {$totalChunks}  ·  Servers: " . count($servers)];

    if (empty($servers)) {
        $log[] = ['type' => 'error', 'msg' => 'No servers configured.'];
        return ['success' => false, 'log' => $log, 'file_hash' => $fileHash,
                'total_chunks' => $totalChunks, 'new_chunks' => 0, 'skipped' => 0,
                'original_name' => $originalName, 'file_size' => $fileSize];
    }

    $fh = fopen($tmpPath, 'rb');
    if (!$fh) {
        $log[] = ['type' => 'error', 'msg' => 'Could not open file.'];
        return ['success' => false, 'log' => $log, 'file_hash' => $fileHash,
                'total_chunks' => $totalChunks, 'new_chunks' => 0, 'skipped' => 0,
                'original_name' => $originalName, 'file_size' => $fileSize];
    }

    $chunks = [];
    for ($i = 1; $i <= $totalChunks; $i++) {
        $raw       = fread($fh, $getChunkBytes);
        $encoded   = base64_encode($raw);
        $chunks[]  = ['num' => $i, 'hash' => md5($encoded), 'encoded' => $encoded];
    }
    fclose($fh);

    $chunkNames = array_map(fn($c) => $fileHash . '.' . $c['num'] . '.' . $c['hash'], $chunks);
    $chunkList  = implode(',', $chunkNames);
    $newChunks  = 0;
    $skipped    = 0;

    foreach ($chunks as $c) {
        foreach ($servers as $server) {
            $server  = rtrim($server, '/');
            $payload = ['action' => 'receive_chunk', 'filename' => $originalName,
                        'file_hash' => $fileHash, 'chunk_num' => $c['num'],
                        'chunk_hash' => $c['hash'], 'contents' => $c['encoded'],
                        'public_key' => $publicKey, 'node_info' => $nodeInfo,
                        'total_chunks' => $totalChunks, 'chunk_list' => $chunkList];

            $url     = $server . '/index.php?' . http_build_query($payload);
            $ctx     = stream_context_create(['http' => ['method' => 'GET',
                           'timeout' => 15, 'ignore_errors' => true]]);
            $resp    = @file_get_contents($url, false, $ctx);
            $decoded = $resp !== false ? json_decode($resp, true) : null;

            if ($resp === false) {
                $log[] = ['type' => 'error',
                          'msg'  => "Chunk {$c['num']}/{$totalChunks} → {$server} FAILED"];
            } elseif (!empty($decoded['ok'])) {
                if (($decoded['stored'] ?? '') === 'exists') {
                    $skipped++;
                    $log[] = ['type' => 'skip',
                              'msg'  => "Chunk {$c['num']}/{$totalChunks} → {$server} exists ({$c['hash']})"];
                } else {
                    $newChunks++;
                    $log[] = ['type' => 'ok',
                              'msg'  => "Chunk {$c['num']}/{$totalChunks} → {$server} ✓ ({$c['hash']})"];
                }
            } else {
                $err = is_array($decoded) ? ($decoded['error'] ?? $resp) : $resp;
                $log[] = ['type' => 'error',
                          'msg'  => "Chunk {$c['num']}/{$totalChunks} → {$server} error: {$err}"];
            }
        }
    }

    $log[] = ['type' => 'ok', 'msg' => "Done. {$newChunks} stored, {$skipped} existed."];
    return ['success' => true, 'log' => $log, 'file_hash' => $fileHash,
            'total_chunks' => $totalChunks, 'new_chunks' => $newChunks, 'skipped' => $skipped,
            'original_name' => $originalName, 'file_size' => $fileSize];
}

// ============================================================
//  Local seed — POST mode (copy raw file into files/)
// ============================================================

function seedFileLocally(string $tmpPath, string $originalName): array {
    $fileHash = md5_file($tmpPath);
    $fileSize = filesize($tmpPath);
    $ext      = strtolower(preg_replace('/[^a-z0-9]/', '',
                    pathinfo($originalName, PATHINFO_EXTENSION)));
    $destName = $fileHash . ($ext !== '' ? '.' . $ext : '');
    $destPath = FILES_DIR . '/' . $destName;
    $log      = [
        ['type' => 'info', 'msg' => "File: {$originalName}"],
        ['type' => 'info', 'msg' => "MD5: {$fileHash}"],
        ['type' => 'info', 'msg' => "Size: " . formatBytes($fileSize)],
        ['type' => 'info', 'msg' => "Mode: POST — raw file"],
    ];

    if (file_exists($destPath)) {
        $log[] = ['type' => 'skip', 'msg' => "Already exists: files/{$destName}"];
        return ['success' => true, 'log' => $log, 'file_hash' => $fileHash,
                'total_chunks' => 1, 'new_chunks' => 0, 'skipped' => 1,
                'original_name' => $originalName, 'file_size' => $fileSize];
    }
    if (copy($tmpPath, $destPath)) {
        rebuildFilesList();
        $log[] = ['type' => 'ok', 'msg' => "Seeded: files/{$destName}"];
        return ['success' => true, 'log' => $log, 'file_hash' => $fileHash,
                'total_chunks' => 1, 'new_chunks' => 1, 'skipped' => 0,
                'original_name' => $originalName, 'file_size' => $fileSize];
    }
    $log[] = ['type' => 'error', 'msg' => "Failed to copy to files/{$destName}"];
    return ['success' => false, 'log' => $log, 'file_hash' => $fileHash,
            'total_chunks' => 1, 'new_chunks' => 0, 'skipped' => 0,
            'original_name' => $originalName, 'file_size' => $fileSize];
}

// ============================================================
//  Local seed — GET mode (base64 JSON chunks)
// ============================================================

function chunkAndSeed(string $tmpPath, string $originalName, int $chunkSize): array {
    $publicKey   = substr(loadPublicKey(), 0, MAX_IDENTITY_CHARS);
    $nodeInfo    = substr(loadNodeInfo(),  0, MAX_IDENTITY_CHARS);
    $fileHash    = md5_file($tmpPath);
    $fileSize    = filesize($tmpPath);
    $totalChunks = (int)ceil($fileSize / $chunkSize);
    $existing    = 0;
    $newChunks   = 0;
    $log         = [
        ['type' => 'info', 'msg' => "File: {$originalName}"],
        ['type' => 'info', 'msg' => "MD5: {$fileHash} · Size: " . formatBytes($fileSize)],
        ['type' => 'info', 'msg' => "Chunk size: " . formatBytes($chunkSize) . " · Chunks: {$totalChunks}"],
    ];

    $fh = fopen($tmpPath, 'rb');
    if (!$fh) {
        $log[] = ['type' => 'error', 'msg' => 'Could not open file.'];
        return ['success' => false, 'log' => $log, 'file_hash' => $fileHash, 'total_chunks' => 0,
                'new_chunks' => 0, 'skipped' => 0, 'original_name' => $originalName, 'file_size' => $fileSize];
    }

    $allNames = [];
    for ($i = 1; $i <= $totalChunks; $i++) {
        $encoded   = base64_encode(fread($fh, $chunkSize));
        $cHash     = md5($encoded);
        $cName     = $fileHash . '.' . $i . '.' . $cHash;
        $allNames[]= $cName;
        $dest      = BASE64_HASH_DIR . '/' . $cName . '.json';

        if (file_exists($dest)) {
            $existing++;
            $log[] = ['type' => 'skip', 'msg' => "Chunk {$i}/{$totalChunks} exists ({$cHash})"];
        } else {
            $wh = fopen($dest, 'w');
            if ($wh) {
                fwrite($wh, json_encode(['filename' => $originalName, 'file_hash' => $fileHash,
                    'chunk_num' => $i, 'chunk_name' => $cName, 'content' => $encoded,
                    'public_key' => $publicKey, 'node_info' => $nodeInfo,
                    'received_at' => date('c')], JSON_PRETTY_PRINT));
                fclose($wh);
                $newChunks++;
                $log[] = ['type' => 'ok', 'msg' => "Chunk {$i}/{$totalChunks} seeded ({$cHash})"];
            } else {
                $log[] = ['type' => 'error', 'msg' => "Chunk {$i}/{$totalChunks} write FAILED"];
            }
        }
    }
    fclose($fh);

    $idxPath = CHUNKS_DIR . '/' . $fileHash . '.txt';
    if (!file_exists($idxPath)) {
        $ih = fopen($idxPath, 'x');
        if ($ih) { foreach ($allNames as $n) fwrite($ih, $n . "\n"); fclose($ih);
            $log[] = ['type' => 'ok', 'msg' => "Index created: chunks/{$fileHash}.txt"];
        }
    } else {
        $log[] = ['type' => 'skip', 'msg' => "Index already exists — not modified"];
    }

    $log[] = ['type' => 'ok', 'msg' => "Done. {$newChunks} new, {$existing} skipped."];
    return ['success' => true, 'log' => $log, 'file_hash' => $fileHash,
            'total_chunks' => $totalChunks, 'new_chunks' => $newChunks, 'skipped' => $existing,
            'original_name' => $originalName, 'file_size' => $fileSize];
}

// ============================================================
//  Manage stored files
// ============================================================

function listStoredFiles(): array {
    $files = glob(FILES_DIR . '/*') ?: [];
    $out   = [];
    foreach ($files as $f) {
        if (!is_file($f)) continue;
        $name   = basename($f);
        $parts  = explode('.', $name, 2);
        $out[]  = ['filename' => $name, 'hash' => $parts[0],
                   'ext' => $parts[1] ?? '', 'size' => filesize($f), 'mtime' => filemtime($f)];
    }
    usort($out, fn($a,$b) => $b['mtime'] - $a['mtime']);
    return $out;
}

function listSeededFiles(): array {
    $files  = glob(BASE64_HASH_DIR . '/*.json') ?: [];
    $byFile = [];
    foreach ($files as $f) {
        $fh = fopen($f, 'r');
        if (!$fh) continue;
        $raw = ''; while (!feof($fh)) $raw .= fread($fh, 8192); fclose($fh);
        $d = json_decode($raw, true);
        if (!is_array($d) || !isset($d['file_hash'])) continue;
        $h = $d['file_hash'];
        $byFile[$h]['chunks'][] = $d['chunk_name'] ?? basename($f, '.json');
        $byFile[$h]['filename'] = $d['filename'] ?? '—';
        $byFile[$h]['size']     = ($byFile[$h]['size'] ?? 0) + strlen($d['content'] ?? '');
    }
    foreach ($byFile as $h => &$data) {
        $idx = CHUNKS_DIR . '/' . $h . '.txt';
        if (file_exists($idx)) {
            $lines = array_filter(array_map('trim', file($idx)));
            $data['total'] = count($lines);
        } else { $data['total'] = '?'; }
        $data['count']    = count($data['chunks']);
        $data['complete'] = is_int($data['total']) && $data['count'] === $data['total'];
    }
    unset($data);
    return $byFile;
}

function deleteStoredFile(string $hash): int {
    if (!preg_match('/^[a-f0-9]{32}$/i', $hash)) return 0;
    $m = glob(FILES_DIR . '/' . $hash . '{,.*}', GLOB_BRACE) ?: [];
    foreach ($m as $f) unlink($f);
    rebuildFilesList();
    return count($m);
}

function deleteFileChunks(string $hash): int {
    if (!preg_match('/^[a-f0-9]{32}$/i', $hash)) return 0;
    $files = glob(BASE64_HASH_DIR . '/' . $hash . '.*.*.json') ?: [];
    foreach ($files as $f) unlink($f);
    $idx = CHUNKS_DIR . '/' . $hash . '.txt';
    if (file_exists($idx)) unlink($idx);
    return count($files);
}

// ============================================================
//  IP stats for the settings UI
// ============================================================

function getIpStats(): array {
    $counts = glob(IP_COUNT_DIR . '/*') ?: [];
    $total  = 0;
    foreach ($counts as $f) $total += max(0, (int)trim(@file_get_contents($f)));
    return ['ips' => count($counts), 'total_uploads' => $total];
}

// ============================================================
//  API routing
// ============================================================

$actionParam = receiveParam('action');
if ($actionParam === 'receive_file') {
    header('Content-Type: application/json');
    handleReceiveFile();
    exit;
}
if ($actionParam === 'receive_chunk') {
    header('Content-Type: application/json');
    handleReceiveChunk();
    exit;
}

// ============================================================
//  Load config & form state
// ============================================================

$settings = loadSettings();
$result   = null;
$message  = '';
$msgType  = '';
$tab      = $_POST['tab'] ?? $_GET['tab'] ?? 'seed';

$pubKeyExists  = file_exists(PUBLIC_KEY_FILE);
$nodeInfoExists= file_exists(NODE_INFO_FILE);

// ── Save identity files (only if not already present) ────────
if (isset($_POST['do_save_identity'])) {
    $tab = 'settings';
    if (!$pubKeyExists) {
        $pk = substr(trim($_POST['public_key_content'] ?? ''), 0, MAX_IDENTITY_CHARS);
        if ($pk !== '') {
            file_put_contents(PUBLIC_KEY_FILE, $pk);
            $pubKeyExists = true;
            $message .= 'public_key.txt saved. ';
        }
    }
    if (!$nodeInfoExists) {
        $ni = substr(trim($_POST['node_info_content'] ?? ''), 0, MAX_IDENTITY_CHARS);
        if ($ni !== '') {
            file_put_contents(NODE_INFO_FILE, $ni);
            $nodeInfoExists = true;
            $message .= 'node_info.txt saved. ';
        }
    }
    $message = $message ?: 'Nothing to save (files already exist).';
    $msgType = 'ok';
}

// ── Save IP rate-limit settings ──────────────────────────────
if (isset($_POST['do_save_settings'])) {
    $tab = 'settings';
    $saved = [];

    // ip_chunks.txt — only write if file does not exist / is empty
    if (!ipChunksCfgLocked()) {
        $val = max(0, (int)($_POST['ip_max_files'] ?? 0));
        file_put_contents(IP_CHUNKS_CFG, (string)$val);
        $saved[] = "ip_chunks.txt = {$val}";
    }

    // ip_time.txt — only write if file does not exist / is empty
    if (!ipTimeCfgLocked()) {
        $val = max(0, (int)($_POST['ip_interval_sec'] ?? 0));
        file_put_contents(IP_TIME_CFG, (string)$val);
        $saved[] = "ip_time.txt = {$val}";
    }

    $settings = loadSettings();
    $message  = $saved ? 'Saved: ' . implode(', ', $saved) . '. Fields are now locked.' : 'Settings already locked — no changes made.';
    $msgType  = 'ok';
}

// ── Reset IP counters (requires password) ───────────────────
if (isset($_POST['do_reset_ip'])) {
    $tab      = 'settings';
    $passInput = trim($_POST['reset_password'] ?? '');

    if (!file_exists(PASS_FILE) || trim((string)@file_get_contents(PASS_FILE)) === '') {
        $message = 'Reset blocked: pass.txt is missing or empty. Create it with a sha512 hash of your password.';
        $msgType = 'error';
    } elseif (!verifyResetPassword($passInput)) {
        $message = 'Incorrect password — IP counters were NOT reset.';
        $msgType = 'error';
    } else {
        $files = array_merge(glob(IP_COUNT_DIR . '/*') ?: [], glob(IP_TIME_DIR . '/*') ?: []);
        foreach ($files as $f) if (is_file($f)) unlink($f);
        $message = 'Password verified — all IP counters and timestamps reset.';
        $msgType = 'ok';
    }
}

// ── Seed locally ─────────────────────────────────────────────
if (isset($_POST['do_seed']) && isset($_FILES['upload_file'])) {
    $tab  = 'seed';
    $file = $_FILES['upload_file'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $message = 'Upload error: ' . $file['error']; $msgType = 'error';
    } elseif ($file['size'] > MAX_UPLOAD_MB * 1048576) {
        $message = 'File exceeds ' . MAX_UPLOAD_MB . ' MB.'; $msgType = 'error';
    } else {
        $transport = (($_POST['transport'] ?? 'post') === 'get') ? 'get' : 'post';
        $tmpDest   = SEEDER_TMPDIR . '/' . basename($file['tmp_name']);
        move_uploaded_file($file['tmp_name'], $tmpDest);
        if ($transport === 'get') {
            $gcb    = max(GET_CHUNK_MIN, min(GET_CHUNK_MAX, (int)($_POST['get_chunk_bytes'] ?? 4096)));
            $result = chunkAndSeed($tmpDest, $file['name'], $gcb);
        } else {
            $result = seedFileLocally($tmpDest, $file['name']);
        }
        unlink($tmpDest);
        $message = $result['success'] ? 'Seeded locally.' : 'Seeding failed — see log.';
        $msgType = $result['success'] ? 'ok' : 'error';
    }
}

// ── Distribute to servers ─────────────────────────────────────
if (isset($_POST['do_distribute']) && isset($_FILES['upload_file'])) {
    $tab  = 'seed';
    $file = $_FILES['upload_file'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $message = 'Upload error: ' . $file['error']; $msgType = 'error';
    } elseif ($file['size'] > MAX_UPLOAD_MB * 1048576) {
        $message = 'File exceeds ' . MAX_UPLOAD_MB . ' MB.'; $msgType = 'error';
    } else {
        $transport = (($_POST['transport'] ?? 'post') === 'get') ? 'get' : 'post';
        $tmpDest   = SEEDER_TMPDIR . '/' . basename($file['tmp_name']);
        move_uploaded_file($file['tmp_name'], $tmpDest);
        if ($transport === 'get') {
            $gcb    = max(GET_CHUNK_MIN, min(GET_CHUNK_MAX, (int)($_POST['get_chunk_bytes'] ?? 4096)));
            $result = sendChunksToServers($tmpDest, $file['name'], $gcb);
        } else {
            $result = sendFileToServers($tmpDest, $file['name']);
        }
        unlink($tmpDest);
        $message = $result['success'] ? 'Distribution complete.' : 'Distribution failed — see log.';
        $msgType = $result['success'] ? 'ok' : 'error';
    }
}

// ── Delete POST file ─────────────────────────────────────────
if (isset($_POST['do_delete_file'])) {
    $tab  = 'manage';
    $h    = strtolower(trim($_POST['del_hash'] ?? ''));
    $cnt  = deleteStoredFile($h);
    $message = $cnt ? "Removed {$cnt} file(s) for {$h}." : 'Invalid hash.';
    $msgType = $cnt ? 'ok' : 'error';
}

// ── Delete GET chunks ─────────────────────────────────────────
if (isset($_POST['do_delete'])) {
    $tab  = 'manage';
    $h    = strtolower(trim($_POST['del_hash'] ?? ''));
    $cnt  = deleteFileChunks($h);
    $message = $cnt ? "Removed {$cnt} chunk(s) for {$h}." : 'Invalid hash.';
    $msgType = $cnt ? 'ok' : 'error';
}

// ── Add / remove server ───────────────────────────────────────
if (isset($_POST['do_add_server'])) {
    $tab = 'servers';
    $newUrl = trim($_POST['server_url'] ?? '');
    $res = addServer($newUrl);
    $msgs = ['ok' => "Server added: {$newUrl}", 'duplicate' => "Already listed: {$newUrl}",
             'empty' => 'Enter a URL.', 'write_error' => 'Write error.'];
    $message = $msgs[$res] ?? 'Error.';
    $msgType = ($res === 'ok') ? 'ok' : (($res === 'duplicate') ? 'info' : 'error');
}
if (isset($_POST['do_remove_server'])) {
    $tab = 'servers';
    $ru  = trim($_POST['remove_url'] ?? '');
    $slist = array_values(array_filter(loadServers(), fn($s) => $s !== $ru));
    $fh = fopen(SERVERS_FILE, 'w');
    if ($fh) { foreach ($slist as $s) fwrite($fh, $s . "\n"); fclose($fh); }
    $message = "Removed: {$ru}"; $msgType = 'ok';
}

// ── Rebuild files.txt on manage load ─────────────────────────
rebuildFilesList();

$storedFiles  = listStoredFiles();
$seededFiles  = listSeededFiles();
$servers      = loadServers();
$ipStats      = getIpStats();

$prevTransport     = $_POST['transport']       ?? 'post';
$prevGetChunkBytes = (int)($_POST['get_chunk_bytes'] ?? 4096);

$ipTimeLocked   = ipTimeCfgLocked();
$ipChunksLocked = ipChunksCfgLocked();
$ipTimeVal      = loadIpTimeCfg();
$ipChunksVal    = loadIpChunksCfg();
$passFileExists = file_exists(PASS_FILE) && trim((string)@file_get_contents(PASS_FILE)) !== '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Seastar</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=Space+Grotesk:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
  :root {
    --bg:      #0d0f14;
    --surface: #13161e;
    --border:  #1e2330;
    --accent:  #00e5a0;
    --accent2: #0077ff;
    --yellow:  #f5c400;
    --red:     #ff3f5b;
    --text:    #d4dae8;
    --muted:   #5a6380;
    --mono:    'IBM Plex Mono', monospace;
    --sans:    'Space Grotesk', sans-serif;
    --radius:  6px;
  }
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: var(--bg); color: var(--text); font-family: var(--sans);
         font-size: 14px; min-height: 100vh; padding: 0 0 60px; }

  .header { border-bottom: 1px solid var(--border); padding: 18px 32px;
            display: flex; align-items: center; gap: 16px; background: var(--surface); }
  .header-logo { width: 36px; height: 36px; background: var(--accent); border-radius: 50%;
                 display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
  .header-logo svg { width: 22px; height: 22px; fill: none; stroke: #0d0f14;
                     stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }
  .header-title { font-size: 17px; font-weight: 600; letter-spacing: -.3px; }
  .header-sub   { font-size: 12px; color: var(--muted); font-family: var(--mono); margin-top: 1px; }
  .server-count { margin-left: auto; font-family: var(--mono); font-size: 12px; color: var(--muted);
                  border: 1px solid var(--border); padding: 4px 10px; border-radius: var(--radius); }
  .server-count span { color: var(--accent); }

  .container { max-width: 920px; margin: 0 auto; padding: 32px 24px 0; }

  nav { display: flex; gap: 4px; margin-bottom: 24px; border-bottom: 1px solid var(--border); flex-wrap: wrap; }
  nav button { background: none; border: none; border-bottom: 2px solid transparent;
               color: var(--muted); font-family: var(--sans); font-size: 13px; font-weight: 500;
               padding: 8px 16px; cursor: pointer; margin-bottom: -1px;
               transition: color .15s, border-color .15s; }
  nav button.active { color: var(--accent); border-bottom-color: var(--accent); }
  nav button:hover:not(.active) { color: var(--text); }
  .tab { display: none; }
  .tab.active { display: block; }

  .card { background: var(--surface); border: 1px solid var(--border);
          border-radius: var(--radius); padding: 22px 24px; margin-bottom: 16px; }
  .card-title { font-size: 11px; font-weight: 600; text-transform: uppercase;
                letter-spacing: .1em; color: var(--muted); margin-bottom: 18px; }

  .drop-zone { border: 2px dashed var(--border); border-radius: var(--radius);
               padding: 40px 24px; text-align: center; cursor: pointer; position: relative;
               transition: border-color .2s, background .2s; margin-bottom: 20px; }
  .drop-zone:hover, .drop-zone.dragover { border-color: var(--accent); background: rgba(0,229,160,.04); }
  .drop-zone input[type=file] { position: absolute; inset: 0; opacity: 0; cursor: pointer; width: 100%; height: 100%; }
  .drop-icon  { font-size: 32px; margin-bottom: 10px; }
  .drop-label { color: var(--text); font-size: 14px; font-weight: 500; }
  .drop-hint  { color: var(--muted); font-size: 12px; margin-top: 4px; font-family: var(--mono); }
  .drop-chosen { color: var(--accent); font-size: 13px; margin-top: 8px; font-family: var(--mono); display: none; }

  .field { margin-bottom: 16px; }
  label { display: block; font-size: 12px; color: var(--muted); margin-bottom: 6px; font-family: var(--mono); }

  input[type=text], input[type=url], input[type=number], textarea {
    width: 100%; background: #080a10; border: 1px solid var(--border);
    color: var(--text); font-family: var(--mono); font-size: 13px;
    padding: 9px 12px; border-radius: var(--radius); outline: none;
    transition: border-color .15s;
  }
  input:focus, textarea:focus { border-color: var(--accent); }
  input[disabled], textarea[disabled] {
    opacity: .45; cursor: not-allowed; border-color: var(--border) !important;
  }
  textarea { resize: vertical; min-height: 80px; line-height: 1.6; }

  .char-counter { font-family: var(--mono); font-size: 11px; color: var(--muted);
                  text-align: right; margin-top: 4px; }
  .char-counter.over { color: var(--red); }

  .locked-notice { font-family: var(--mono); font-size: 11px; color: var(--yellow);
                   margin-top: 6px; display: flex; align-items: center; gap: 6px; }

  .range-row { display: flex; align-items: center; gap: 12px; }
  input[type=range] { width: 100%; accent-color: var(--accent); height: 4px; cursor: pointer; }
  .range-val { font-family: var(--mono); font-size: 13px; color: var(--accent); min-width: 70px; text-align: right; }

  .transport-row { display: flex; gap: 8px; margin-bottom: 18px; }
  .transport-btn { flex: 1; padding: 10px 0; border: 1px solid var(--border);
                   border-radius: var(--radius); background: #080a10; color: var(--muted);
                   font-family: var(--mono); font-size: 13px; font-weight: 500;
                   cursor: pointer; text-align: center;
                   transition: border-color .15s, color .15s, background .15s; user-select: none; }
  .transport-btn.selected-post { border-color: var(--accent2); color: var(--accent2); background: rgba(0,119,255,.07); }
  .transport-btn.selected-get  { border-color: var(--accent);  color: var(--accent);  background: rgba(0,229,160,.07); }
  .transport-badge { display: inline-block; font-size: 9px; font-weight: 700;
                     padding: 2px 5px; border-radius: 3px; text-transform: uppercase;
                     letter-spacing: .08em; vertical-align: middle; margin-left: 6px; }
  .badge-default { background: rgba(0,119,255,.2); color: var(--accent2); }

  .info-note { font-family: var(--mono); font-size: 11px; color: var(--muted);
               margin-top: 6px; line-height: 1.6; }
  .info-note strong { color: var(--yellow); }

  .btn-row { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; margin-top: 4px; }

  button[type=submit], .btn {
    background: var(--accent); color: #0d0f14; border: none; border-radius: var(--radius);
    font-family: var(--sans); font-weight: 600; font-size: 13px;
    padding: 9px 20px; cursor: pointer; transition: opacity .15s, transform .1s; white-space: nowrap;
  }
  button[type=submit]:hover, .btn:hover { opacity: .88; }
  button[type=submit]:active { transform: scale(.97); }
  .btn-secondary { background: var(--accent2); color: #fff; }
  .btn-danger    { background: var(--red);     color: #fff; }
  .btn-muted     { background: var(--border);  color: var(--text); }
  .btn-sm        { padding: 5px 12px; font-size: 12px; }

  .banner { padding: 12px 18px; border-radius: var(--radius); margin-bottom: 20px;
            font-size: 13px; font-family: var(--mono); border-left: 3px solid; }
  .banner.ok    { background: rgba(0,229,160,.08);  border-color: var(--accent);  color: var(--accent); }
  .banner.error { background: rgba(255,63,91,.08);   border-color: var(--red);     color: var(--red); }
  .banner.info  { background: rgba(0,119,255,.08);   border-color: var(--accent2); color: var(--accent2); }

  .hash-box { background: #080a10; border: 1px solid var(--accent);
              border-radius: var(--radius); padding: 18px 20px; margin-top: 16px; }
  .hash-label { font-size: 11px; color: var(--muted); font-family: var(--mono); margin-bottom: 6px; }
  .hash-val   { font-family: var(--mono); font-size: 18px; color: var(--accent);
                letter-spacing: .04em; word-break: break-all; }
  .hash-meta  { font-family: var(--mono); font-size: 11px; color: var(--muted); margin-top: 8px; }
  .copy-btn   { background: rgba(0,229,160,.12); color: var(--accent); border: 1px solid var(--accent);
                border-radius: var(--radius); font-family: var(--mono); font-size: 11px;
                padding: 4px 10px; cursor: pointer; margin-top: 10px; transition: background .15s; }
  .copy-btn:hover { background: rgba(0,229,160,.22); }

  .log-box { background: #080a10; border: 1px solid var(--border); border-radius: var(--radius);
             padding: 14px 16px; max-height: 280px; overflow-y: auto;
             font-family: var(--mono); font-size: 12px; line-height: 1.7; }
  .log-line       { padding: 1px 0; }
  .log-line.ok    { color: var(--accent); }
  .log-line.skip  { color: var(--muted); }
  .log-line.error { color: var(--red); }
  .log-line.info  { color: var(--accent2); }

  .stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
               gap: 12px; margin-bottom: 20px; }
  .stat-card { background: var(--surface); border: 1px solid var(--border);
               border-radius: var(--radius); padding: 16px; text-align: center; }
  .stat-val   { font-size: 24px; font-weight: 600; font-family: var(--mono); color: var(--accent); }
  .stat-label { font-size: 11px; color: var(--muted); margin-top: 4px;
                text-transform: uppercase; letter-spacing: .08em; }

  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th { text-align: left; font-size: 11px; font-weight: 600; color: var(--muted);
       text-transform: uppercase; letter-spacing: .08em;
       padding: 0 12px 10px; border-bottom: 1px solid var(--border); }
  td { padding: 10px 12px; border-bottom: 1px solid var(--border); vertical-align: middle; }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: rgba(255,255,255,.02); }

  .mono { font-family: var(--mono); font-size: 12px; }
  .tag  { display: inline-block; font-family: var(--mono); font-size: 10px; font-weight: 600;
          padding: 2px 7px; border-radius: 3px; text-transform: uppercase; letter-spacing: .06em; }
  .tag.green { background: rgba(0,229,160,.15); color: var(--accent);   border: 1px solid rgba(0,229,160,.3); }
  .tag.red   { background: rgba(255,63,91,.12);  color: var(--red);     border: 1px solid rgba(255,63,91,.3); }
  .tag.blue  { background: rgba(0,119,255,.12);  color: var(--accent2); border: 1px solid rgba(0,119,255,.3); }

  .del-form { display: inline; }
  .del-btn  { background: none; border: 1px solid var(--border); color: var(--muted);
              font-size: 11px; font-family: var(--mono); padding: 3px 8px;
              border-radius: var(--radius); cursor: pointer; transition: border-color .15s, color .15s; }
  .del-btn:hover { border-color: var(--red); color: var(--red); }

  .server-item { display: flex; align-items: center; gap: 10px; padding: 10px 0;
                 border-bottom: 1px solid var(--border); font-family: var(--mono);
                 font-size: 12px; color: var(--text); }
  .server-item:last-child { border-bottom: none; }
  .server-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--accent); flex-shrink: 0; }
  .server-url { flex: 1; word-break: break-all; }

  .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
  @media (max-width: 640px) { .two-col { grid-template-columns: 1fr; } }

  ::-webkit-scrollbar { width: 6px; height: 6px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }
</style>
</head>
<body>

<div class="header">
  <div class="header-logo">
    <svg viewBox="0 0 24 24"><path d="M12 2L13.5 8.5L20 7L15.5 12L20 17L13.5 15.5L12 22L10.5 15.5L4 17L8.5 12L4 7L10.5 8.5Z" stroke-width="1.5"/></svg>
  </div>
  <div>
    <div class="header-title">Seastar</div>
    <div class="header-sub">chunk · distribute · receive</div>
  </div>
  <div class="server-count"><span><?= count($servers) ?></span> server<?= count($servers) !== 1 ? 's' : '' ?></div>
</div>

<div class="container">

  <?php if ($message): ?>
  <div class="banner <?= htmlspecialchars($msgType) ?>"><?= htmlspecialchars($message) ?></div>
  <?php endif; ?>

  <nav>
    <button onclick="switchTab('seed',    this)" class="<?= $tab==='seed'    ?'active':'' ?>">Seed &amp; Send</button>
    <button onclick="switchTab('manage',  this)" class="<?= $tab==='manage'  ?'active':'' ?>">Stored (<?= count($storedFiles)+count($seededFiles) ?>)</button>
    <button onclick="switchTab('servers', this)" class="<?= $tab==='servers' ?'active':'' ?>">Servers (<?= count($servers) ?>)</button>
    <button onclick="switchTab('settings',this)" class="<?= $tab==='settings'?'active':'' ?>">Settings</button>
    <button onclick="switchTab('help',    this)" class="<?= $tab==='help'    ?'active':'' ?>">How It Works</button>
  </nav>

  <!-- ══════════════════════════════════════════════════════
       SEED & SEND
  ══════════════════════════════════════════════════════ -->
  <div id="tab-seed" class="tab <?= $tab==='seed'?'active':'' ?>">
    <div class="card">
      <div class="card-title">Upload &amp; Process File</div>
      <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="tab" value="seed">
        <input type="hidden" name="transport" id="transportInput" value="<?= htmlspecialchars($prevTransport) ?>">

        <div class="drop-zone" id="dropZone">
          <input type="file" name="upload_file" id="fileInput" required>
          <div class="drop-icon">⭐</div>
          <div class="drop-label">Drop file here or click to browse</div>
          <div class="drop-hint">Max <?= MAX_UPLOAD_MB ?> MB · Any file type</div>
          <div class="drop-chosen" id="chosenName"></div>
        </div>

        <!-- GET chunk slider — hidden when POST is selected -->
        <div class="field" id="get-chunk-panel">
          <label>Max GET Chunk Size <span style="color:var(--muted)">(raw bytes per request, 100 B – 8 KB)</span></label>
          <div class="range-row">
            <input type="range" name="get_chunk_bytes" id="getChunkRange"
                   min="100" max="8192" step="100" value="<?= max(100,min(8192,$prevGetChunkBytes)) ?>">
            <span class="range-val" id="getChunkLabel">–</span>
          </div>
          <div class="info-note">Raw bytes before base64 encoding. <strong>8 KB raw → ~10.9 KB in URL.</strong></div>
        </div>

        <!-- Transport toggle -->
        <div class="field">
          <label>Transport Method</label>
          <div class="transport-row">
            <div class="transport-btn <?= $prevTransport==='post'?'selected-post':'' ?>" id="btnPost" onclick="setTransport('post')">
              POST <span class="transport-badge badge-default">default</span>
            </div>
            <div class="transport-btn <?= $prevTransport==='get'?'selected-get':'' ?>" id="btnGet" onclick="setTransport('get')">
              GET
            </div>
          </div>
          <div class="info-note" id="note-post" style="<?= $prevTransport!=='post'?'display:none':'' ?>">
            Whole file sent as multipart POST. Stored as <code>files/&lt;md5&gt;.&lt;ext&gt;</code>. No chunking.
          </div>
          <div class="info-note" id="note-get" style="<?= $prevTransport!=='get'?'display:none':'' ?>">
            File split into base64 chunks sent as GET query params. Slider above controls chunk size.
          </div>
        </div>

        <div class="btn-row">
          <button type="submit" name="do_seed">💾 Seed Locally</button>
          <button type="submit" name="do_distribute" class="btn btn-secondary">
            📡 Distribute to <?= count($servers) ?> Server<?= count($servers)!==1?'s':'' ?>
          </button>
        </div>
      </form>
    </div>

    <?php if ($result): ?>
    <?php if ($result['success']): ?>
    <div class="card">
      <div class="card-title">Result</div>
      <div class="hash-box">
        <div class="hash-label">File Hash (MD5)</div>
        <div class="hash-val" id="resultHash"><?= htmlspecialchars($result['file_hash']) ?></div>
        <div class="hash-meta">
          <?= htmlspecialchars($result['original_name']) ?>
          &nbsp;·&nbsp; <?= formatBytes($result['file_size']) ?>
          &nbsp;·&nbsp; <?= $result['total_chunks'] > 1
            ? $result['total_chunks'].' chunks · '.$result['new_chunks'].' new, '.$result['skipped'].' skipped'
            : ($result['new_chunks'] ? 'stored' : 'already existed') ?>
        </div>
        <button class="copy-btn" onclick="copyHash()">Copy Hash</button>
      </div>
    </div>
    <?php endif; ?>
    <div class="card">
      <div class="card-title"><?= $result['success']?'Log':'Error Log' ?></div>
      <div class="log-box">
        <?php foreach ($result['log'] as $e): ?>
        <div class="log-line <?= htmlspecialchars($e['type']) ?>"><?= htmlspecialchars($e['msg']) ?></div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <!-- ══════════════════════════════════════════════════════
       MANAGE
  ══════════════════════════════════════════════════════ -->
  <div id="tab-manage" class="tab <?= $tab==='manage'?'active':'' ?>">

    <?php
    $totalFileSize  = array_sum(array_column($storedFiles, 'size'));
    $totalChunkSize = array_sum(array_column($seededFiles, 'size'));
    ?>
    <div class="stat-grid">
      <div class="stat-card"><div class="stat-val"><?= count($storedFiles) ?></div><div class="stat-label">POST Files</div></div>
      <div class="stat-card"><div class="stat-val"><?= formatBytes($totalFileSize) ?></div><div class="stat-label">POST Size</div></div>
      <div class="stat-card"><div class="stat-val"><?= count($seededFiles) ?></div><div class="stat-label">GET Sets</div></div>
      <div class="stat-card"><div class="stat-val"><?= array_sum(array_column($seededFiles,'count')) ?></div><div class="stat-label">GET Chunks</div></div>
    </div>

    <!-- POST files -->
    <div class="card">
      <div class="card-title">POST — files/ directory
        <span style="color:var(--muted);font-weight:400;text-transform:none;letter-spacing:0">
          &nbsp;(index: <code>files.txt</code>)
        </span>
      </div>
      <?php if (empty($storedFiles)): ?>
      <p class="mono" style="color:var(--muted)">No POST files stored yet.</p>
      <?php else: ?>
      <table>
        <tr><th>Filename</th><th>MD5</th><th>Size</th><th>Stored</th><th></th></tr>
        <?php foreach ($storedFiles as $sf): ?>
        <tr>
          <td class="mono"><?= htmlspecialchars($sf['filename']) ?></td>
          <td class="mono" style="color:var(--muted)"><?= htmlspecialchars(substr($sf['hash'],0,12)) ?>…</td>
          <td class="mono"><?= formatBytes($sf['size']) ?></td>
          <td class="mono" style="color:var(--muted)"><?= date('Y-m-d H:i', $sf['mtime']) ?></td>
          <td>
            <form method="POST" class="del-form" onsubmit="return confirm('Remove file?')">
              <input type="hidden" name="tab" value="manage">
              <input type="hidden" name="del_hash" value="<?= htmlspecialchars($sf['hash']) ?>">
              <button type="submit" name="do_delete_file" class="del-btn">✕</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </table>
      <?php endif; ?>
    </div>

    <!-- GET chunks -->
    <div class="card">
      <div class="card-title">GET — base64_hash/ chunk sets</div>
      <?php if (empty($seededFiles)): ?>
      <p class="mono" style="color:var(--muted)">No GET chunks stored yet.</p>
      <?php else: ?>
      <table>
        <tr><th>Hash</th><th>Filename</th><th>Chunks</th><th>Size (b64)</th><th>Status</th><th></th></tr>
        <?php foreach ($seededFiles as $hash => $data): ?>
        <tr>
          <td class="mono" style="color:var(--muted)"><?= htmlspecialchars(substr($hash,0,12)) ?>…</td>
          <td class="mono"><?= htmlspecialchars($data['filename']) ?></td>
          <td><?= $data['count'] ?>/<?= $data['total'] ?></td>
          <td class="mono"><?= formatBytes($data['size']) ?></td>
          <td><span class="tag <?= $data['complete']?'green':'red' ?>"><?= $data['complete']?'complete':'partial' ?></span></td>
          <td>
            <form method="POST" class="del-form" onsubmit="return confirm('Remove chunks?')">
              <input type="hidden" name="tab" value="manage">
              <input type="hidden" name="del_hash" value="<?= htmlspecialchars($hash) ?>">
              <button type="submit" name="do_delete" class="del-btn">✕</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </table>
      <?php endif; ?>
    </div>

  </div>

  <!-- ══════════════════════════════════════════════════════
       SERVERS
  ══════════════════════════════════════════════════════ -->
  <div id="tab-servers" class="tab <?= $tab==='servers'?'active':'' ?>">
    <div class="card">
      <div class="card-title">Add Server</div>
      <form method="POST">
        <input type="hidden" name="tab" value="servers">
        <div class="field">
          <label>Server URL (base URL of remote Seastar node)</label>
          <input type="url" name="server_url" placeholder="https://example.com/seastar" required>
        </div>
        <button type="submit" name="do_add_server">+ Add Server</button>
      </form>
    </div>
    <div class="card">
      <div class="card-title">Configured Servers (<?= count($servers) ?>)</div>
      <?php if (empty($servers)): ?>
      <p class="mono" style="color:var(--muted)">No servers yet.</p>
      <?php else: ?>
      <?php foreach ($servers as $srv): ?>
      <div class="server-item">
        <div class="server-dot"></div>
        <div class="server-url"><?= htmlspecialchars($srv) ?></div>
        <form method="POST" class="del-form" onsubmit="return confirm('Remove server?')">
          <input type="hidden" name="tab" value="servers">
          <input type="hidden" name="remove_url" value="<?= htmlspecialchars($srv) ?>">
          <button type="submit" name="do_remove_server" class="del-btn">✕</button>
        </form>
      </div>
      <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>

  <!-- ══════════════════════════════════════════════════════
       SETTINGS
  ══════════════════════════════════════════════════════ -->
  <div id="tab-settings" class="tab <?= $tab==='settings'?'active':'' ?>">

    <!-- Identity files -->
    <div class="card">
      <div class="card-title">Node Identity</div>
      <form method="POST">
        <input type="hidden" name="tab" value="settings">
        <div class="two-col">
          <div class="field">
            <label>public_key.txt <span style="color:var(--muted)">(max <?= MAX_IDENTITY_CHARS ?> chars)</span></label>
            <textarea name="public_key_content" id="pkField" maxlength="<?= MAX_IDENTITY_CHARS ?>"
                      placeholder="Paste your public key here…"
                      <?= $pubKeyExists ? 'disabled' : '' ?>><?= $pubKeyExists ? htmlspecialchars(loadPublicKey()) : '' ?></textarea>
            <div class="char-counter" id="pkCounter"><?= $pubKeyExists ? MAX_IDENTITY_CHARS . '/' . MAX_IDENTITY_CHARS : '0/' . MAX_IDENTITY_CHARS ?></div>
            <?php if ($pubKeyExists): ?>
            <div class="locked-notice">🔒 File exists — locked. Delete <code>public_key.txt</code> to change.</div>
            <?php endif; ?>
          </div>
          <div class="field">
            <label>node_info.txt <span style="color:var(--muted)">(max <?= MAX_IDENTITY_CHARS ?> chars)</span></label>
            <textarea name="node_info_content" id="niField" maxlength="<?= MAX_IDENTITY_CHARS ?>"
                      placeholder="Paste node info here…"
                      <?= $nodeInfoExists ? 'disabled' : '' ?>><?= $nodeInfoExists ? htmlspecialchars(loadNodeInfo()) : '' ?></textarea>
            <div class="char-counter" id="niCounter"><?= $nodeInfoExists ? MAX_IDENTITY_CHARS . '/' . MAX_IDENTITY_CHARS : '0/' . MAX_IDENTITY_CHARS ?></div>
            <?php if ($nodeInfoExists): ?>
            <div class="locked-notice">🔒 File exists — locked. Delete <code>node_info.txt</code> to change.</div>
            <?php endif; ?>
          </div>
        </div>
        <?php if (!$pubKeyExists || !$nodeInfoExists): ?>
        <button type="submit" name="do_save_identity">💾 Save Identity Files</button>
        <?php endif; ?>
      </form>
    </div>

    <!-- IP rate limits -->
    <div class="card">
      <div class="card-title">IP Rate Limits</div>
      <div class="info-note" style="margin-bottom:16px">
        Values are loaded from <code>ip_time.txt</code> (interval) and <code>ip_chunks.txt</code> (max files).
        Once a file is saved the field is <strong>locked</strong> — delete the file on the server to change it.
      </div>
      <form method="POST">
        <input type="hidden" name="tab" value="settings">
        <div class="two-col">

          <!-- Max files per IP (ip_chunks.txt) -->
          <div class="field">
            <label>
              Max files per IP
              <span style="color:var(--muted)">(0 = unlimited · <code>ip_chunks.txt</code>)</span>
            </label>
            <input type="number" name="ip_max_files" min="0" step="1"
                   value="<?= $ipChunksVal ?>"
                   <?= $ipChunksLocked ? 'disabled' : '' ?>>
            <?php if ($ipChunksLocked): ?>
            <div class="locked-notice">🔒 <code>ip_chunks.txt</code> exists — field locked (value: <?= $ipChunksVal ?>). Delete the file to change.</div>
            <?php else: ?>
            <div class="info-note">Total uploads allowed per IP before blocking.</div>
            <?php endif; ?>
          </div>

          <!-- Interval (ip_time.txt) -->
          <div class="field">
            <label>
              Min interval between uploads
              <span style="color:var(--muted)">(seconds · <code>ip_time.txt</code>)</span>
            </label>
            <input type="number" name="ip_interval_sec" min="0" step="1"
                   value="<?= $ipTimeVal ?>"
                   <?= $ipTimeLocked ? 'disabled' : '' ?>>
            <?php if ($ipTimeLocked): ?>
            <div class="locked-notice">🔒 <code>ip_time.txt</code> exists — field locked (value: <?= $ipTimeVal ?>s). Delete the file to change.</div>
            <?php else: ?>
            <div class="info-note">Seconds that must pass between accepted uploads from the same IP.</div>
            <?php endif; ?>
          </div>

        </div>
        <?php if (!$ipChunksLocked || !$ipTimeLocked): ?>
        <div class="btn-row">
          <button type="submit" name="do_save_settings">💾 Save &amp; Lock Rate Limits</button>
        </div>
        <?php endif; ?>
      </form>
    </div>

    <!-- IP stats & password-protected reset -->
    <div class="card">
      <div class="card-title">IP Counter Stats &amp; Reset</div>
      <div class="stat-grid" style="margin-bottom:16px">
        <div class="stat-card"><div class="stat-val"><?= $ipStats['ips'] ?></div><div class="stat-label">Unique IPs</div></div>
        <div class="stat-card"><div class="stat-val"><?= $ipStats['total_uploads'] ?></div><div class="stat-label">Total Uploads</div></div>
        <div class="stat-card">
          <div class="stat-val" style="font-size:14px"><?= $ipChunksVal ?: '∞' ?></div>
          <div class="stat-label">Max/IP</div>
        </div>
        <div class="stat-card">
          <div class="stat-val" style="font-size:14px"><?= $ipTimeVal ? $ipTimeVal.'s' : '∞' ?></div>
          <div class="stat-label">Interval</div>
        </div>
      </div>

      <?php if (!$passFileExists): ?>
      <div class="banner info" style="margin-bottom:12px">
        ⚠️ <code>pass.txt</code> not found or empty — reset is disabled.
        Create <code>pass.txt</code> containing the <strong>sha512</strong> hex hash of your chosen password to enable the reset button.
      </div>
      <?php endif; ?>

      <form method="POST">
        <input type="hidden" name="tab" value="settings">
        <div class="field" style="max-width:340px">
          <label>Reset password <span style="color:var(--muted)">(sha512 verified against pass.txt)</span></label>
          <input type="password" name="reset_password" placeholder="Enter password to unlock reset…"
                 <?= !$passFileExists ? 'disabled' : '' ?> autocomplete="off">
        </div>
        <button type="submit" name="do_reset_ip" class="btn btn-danger btn-sm"
                <?= !$passFileExists ? 'disabled' : '' ?>>🗑 Reset All IP Counters</button>
      </form>

      <div class="info-note" style="margin-top:14px">
        Counters: <code>ip_count/sha256(ip+salt)</code> &nbsp;·&nbsp;
        Timestamps: <code>ip_time/sha256(ip+salt)</code> &nbsp;·&nbsp;
        Salt: <code>settings.json</code> (auto-generated once).<br>
        To generate <code>pass.txt</code>: <code>echo -n "yourpassword" | sha512sum | awk '{print $1}' &gt; pass.txt</code>
      </div>
    </div>

  </div>

  <!-- ══════════════════════════════════════════════════════
       HOW IT WORKS
  ══════════════════════════════════════════════════════ -->
  <div id="tab-help" class="tab <?= $tab==='help'?'active':'' ?>">

    <div class="card">
      <div class="card-title">Transport Modes</div>
      <div style="line-height:1.8;font-size:13px">
        <p style="margin-bottom:12px">
          <strong style="color:var(--accent2)">POST (default)</strong> — The whole file is sent as a
          single multipart upload to <code>?action=receive_file</code>. The server verifies the MD5,
          then stores the file as <code>files/&lt;md5&gt;.&lt;ext&gt;</code>. If the file already
          exists it is never overwritten. The <code>files.txt</code> index is rebuilt on every write or delete.
        </p>
        <p>
          <strong style="color:var(--accent)">GET</strong> — The file is split into small chunks
          (100 B – 8 KB raw, ~133 B – 10.9 KB base64). Each chunk is sent as a GET query-string
          request to <code>?action=receive_chunk</code>. Stored as JSON in <code>base64_hash/</code>
          with an index in <code>chunks/</code>.
        </p>
      </div>
    </div>

    <div class="card">
      <div class="card-title">IP Rate Limiting</div>
      <div style="line-height:1.8;font-size:13px">
        <p style="margin-bottom:10px">
          Each incoming IP is identified by <code>sha256(ip + salt)</code>. The salt is
          auto-generated once and saved in <code>settings.json</code> — it prevents reverse
          lookup of IPs from the hash files.
        </p>
        <p style="margin-bottom:10px">
          <strong style="color:var(--yellow)">Max files per IP</strong> — the counter in
          <code>ip_count/&lt;hash&gt;</code> starts at 0 and increments on every accepted upload.
          Once it reaches the limit, further uploads from that IP return HTTP 429.
        </p>
        <p>
          <strong style="color:var(--yellow)">Min interval</strong> — the last-accepted timestamp
          is stored in <code>ip_time/&lt;hash&gt;</code>. If <code>now − last &lt; interval</code>,
          the upload is rejected with a countdown message.
        </p>
      </div>
    </div>

    <div class="card">
      <div class="card-title">Directory Layout</div>
      <div class="log-box" style="max-height:none">
        <div class="log-line info">files/                       ← POST raw files (<code>&lt;md5&gt;.&lt;ext&gt;</code>)</div>
        <div class="log-line info">files.txt                    ← auto-rebuilt index of files/</div>
        <div class="log-line ok">base64_hash/                 ← GET chunk JSON files</div>
        <div class="log-line ok">chunks/                      ← GET chunk index (write-once)</div>
        <div class="log-line skip">ip_count/sha256(ip+salt)     ← integer upload counter per IP</div>
        <div class="log-line skip">ip_time/sha256(ip+salt)      ← unix timestamp of last upload</div>
        <div class="log-line skip">ip_chunks.txt                ← max files per IP (locked once written)</div>
        <div class="log-line skip">ip_time.txt                  ← min interval in seconds (locked once written)</div>
        <div class="log-line skip">pass.txt                     ← sha512 hash of reset password</div>
        <div class="log-line skip">seeder_tmp/                  ← upload staging (auto-cleaned)</div>
        <div class="log-line skip">servers.txt                  ← one server URL per line</div>
        <div class="log-line skip">public_key.txt               ← this node's public key (≤500 chars, locked)</div>
        <div class="log-line skip">node_info.txt                ← this node's info (≤500 chars, locked)</div>
        <div class="log-line skip">settings.json                ← ip_salt (auto-generated once)</div>
      </div>
    </div>

    <div class="card">
      <div class="card-title">POST Receive Endpoint</div>
      <div class="log-box" style="max-height:none">
        <div class="log-line info">POST  index.php?action=receive_file</div>
        <div class="log-line ok">Content-Type: multipart/form-data</div>
        <div class="log-line ok">upload_file  — raw file field</div>
        <div class="log-line ok">file_hash    — md5 of the file</div>
        <div class="log-line ok">filename     — original name (for extension)</div>
        <div class="log-line skip">public_key, node_info — optional, truncated to 500 chars</div>
        <div class="log-line skip">→ {"ok":true,"file":"abc…jpg","stored":"new|exists"}</div>
        <div class="log-line skip">→ HTTP 429 if IP is rate-limited</div>
      </div>
    </div>

    <div class="card">
      <div class="card-title">GET Receive Endpoint</div>
      <div class="log-box" style="max-height:none">
        <div class="log-line info">GET  index.php?action=receive_chunk&amp;…</div>
        <div class="log-line ok">&amp;filename, file_hash, chunk_num, chunk_hash, contents, total_chunks</div>
        <div class="log-line skip">&amp;public_key, node_info, chunk_list — optional</div>
        <div class="log-line skip">→ {"ok":true,"chunk":"…","stored":"new|exists"}</div>
        <div class="log-line skip">→ HTTP 429 if IP is rate-limited</div>
      </div>
    </div>

  </div>

</div>

<script>
function switchTab(name, btn) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('nav button').forEach(b => b.classList.remove('active'));
  document.getElementById('tab-' + name).classList.add('active');
  btn.classList.add('active');
}

function setTransport(mode) {
  document.getElementById('transportInput').value = mode;
  document.getElementById('btnPost').className = 'transport-btn' + (mode==='post'?' selected-post':'');
  document.getElementById('btnGet').className  = 'transport-btn' + (mode==='get' ?' selected-get' :'');
  document.getElementById('get-chunk-panel').style.display = mode==='get' ? '' : 'none';
  document.getElementById('note-post').style.display = mode==='post' ? '' : 'none';
  document.getElementById('note-get').style.display  = mode==='get'  ? '' : 'none';
}
(function(){ setTransport(document.getElementById('transportInput').value || 'post'); })();

// GET chunk slider
const getRange = document.getElementById('getChunkRange');
const getLabel = document.getElementById('getChunkLabel');
function updateGetLabel() {
  const b = parseInt(getRange.value);
  getLabel.textContent = b >= 1024 ? (b/1024).toFixed(1)+' KB' : b+' B';
}
getRange.addEventListener('input', updateGetLabel);
updateGetLabel();

// Drop zone
const fileInput  = document.getElementById('fileInput');
const chosenName = document.getElementById('chosenName');
const dropZone   = document.getElementById('dropZone');
fileInput.addEventListener('change', () => {
  if (fileInput.files.length) { chosenName.style.display='block'; chosenName.textContent='✓ '+fileInput.files[0].name; }
});
dropZone.addEventListener('dragover',  e => { e.preventDefault(); dropZone.classList.add('dragover'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
dropZone.addEventListener('drop', e => {
  e.preventDefault(); dropZone.classList.remove('dragover');
  if (e.dataTransfer.files.length) {
    fileInput.files = e.dataTransfer.files;
    chosenName.style.display='block'; chosenName.textContent='✓ '+e.dataTransfer.files[0].name;
  }
});

// Copy hash
function copyHash() {
  const h = document.getElementById('resultHash');
  if (!h) return;
  navigator.clipboard.writeText(h.textContent.trim()).then(() => {
    const b = document.querySelector('.copy-btn');
    b.textContent='✓ Copied!';
    setTimeout(()=>b.textContent='Copy Hash',1800);
  });
}

// Char counters for identity textareas
const MAX_ID = <?= MAX_IDENTITY_CHARS ?>;
function wireCounter(fieldId, counterId) {
  const field   = document.getElementById(fieldId);
  const counter = document.getElementById(counterId);
  if (!field || !counter) return;
  function update() {
    const len = field.value.length;
    counter.textContent = len + '/' + MAX_ID;
    counter.classList.toggle('over', len > MAX_ID);
  }
  field.addEventListener('input', update);
  update();
}
wireCounter('pkField', 'pkCounter');
wireCounter('niField', 'niCounter');
</script>
</body>
</html>