﻿<?php
// ============================================================
//  P2P Downloader — fetch file by MD5 hash from peers/nodes
//  Drop in the same directory as p2p.php and seeder.php
// ============================================================

define('DHT_FILE',       __DIR__ . '/dht.txt');
define('SERVERS_FILE',   __DIR__ . '/servers.txt');
define('BASE64_DIR',     __DIR__ . '/base64');
define('HASH_CHUNK_DIR', __DIR__ . '/hash_chunck');
define('DOWNLOADED_DIR', __DIR__ . '/downloaded');
define('TIMEOUT',        10);
define('MAX_RETRIES',    2);

foreach ([BASE64_DIR, HASH_CHUNK_DIR, DOWNLOADED_DIR] as $d) {
    if (!is_dir($d)) mkdir($d, 0755, true);
}

// ============================================================
//  Helpers
// ============================================================

function isValidMd5(string $v): bool {
    return (bool) preg_match('/^[a-f0-9]{32}$/i', $v);
}

function formatBytes(int $bytes): string {
    if ($bytes >= 1048576) return round($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024)    return round($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}

function loadPeers(): array {
    $peers = [];
    foreach ([DHT_FILE, SERVERS_FILE] as $f) {
        if (!file_exists($f)) continue;
        foreach (file($f, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
            $url = rtrim(trim($line), '/');
            if ($url && filter_var($url, FILTER_VALIDATE_URL)) $peers[] = $url;
        }
    }
    return array_values(array_unique($peers));
}

function httpGet(string $url): array {
    $ctx  = stream_context_create(['http' => [
        'method'        => 'GET',
        'timeout'       => TIMEOUT,
        'ignore_errors' => true,
    ]]);
    $body = @file_get_contents($url, false, $ctx);
    $code = 0;
    if (!empty($http_response_header)) {
        if (preg_match('#HTTP/\S+\s+(\d+)#', $http_response_header[0], $m))
            $code = (int) $m[1];
    }
    return ['code' => $code, 'body' => ($body !== false) ? $body : ''];
}

function discoverPeers(array $known): array {
    $found = [];
    foreach ($known as $peer) {
        $r = httpGet($peer . '/p2p.php?action=peers');
        if ($r['code'] === 200) {
            $list = @json_decode($r['body'], true);
            if (is_array($list)) {
                foreach ($list as $p) {
                    $p = rtrim(trim($p), '/');
                    if ($p && filter_var($p, FILTER_VALIDATE_URL)) $found[] = $p;
                }
            }
        }
    }
    return array_values(array_unique(array_merge($known, $found)));
}

// ── Look for file directly (whole file, not chunked) ─────────
// Searches: local downloaded/, local base64/ (exact name), then peers
function findWholeFile(string $hash): ?string {
    // 1. Already downloaded
    $dl = DOWNLOADED_DIR . '/' . $hash;
    if (file_exists($dl)) return $dl;

    // 2. Any file in base64/ whose name starts with the hash but has no dots
    //    (unlikely but handle it)
    $exact = BASE64_DIR . '/' . $hash;
    if (file_exists($exact)) return $exact;

    // 3. Scan downloaded/ for files starting with hash
    foreach (glob(DOWNLOADED_DIR . '/' . $hash . '*') ?: [] as $f) {
        if (is_file($f)) return $f;
    }

    return null;
}

// ── Read chunk-hash list from hash_chunck/<hash>.txt ─────────
function readChunkList(string $hash): array {
    $path = HASH_CHUNK_DIR . '/' . $hash . '.txt';
    if (!file_exists($path)) return [];
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    return array_values(array_filter(array_map('trim', $lines), 'strlen'));
}

// ── Fetch one chunk from local storage or peers ───────────────
// Chunk filename: <fileHash>.<chunkNum>.<chunkHash>
function fetchChunk(string $fileHash, int $chunkNum, string $chunkHash, array $peers): array {
    // 1. Local base64/
    $localPath = BASE64_DIR . '/' . $fileHash . '.' . $chunkNum . '.' . $chunkHash;
    if (file_exists($localPath)) {
        $contents = file_get_contents($localPath);
        if ($contents !== false && md5($contents) === $chunkHash) {
            return ['success' => true, 'source' => 'local', 'contents' => $contents];
        }
    }

    // 2. Peers via p2p.php API
    foreach ($peers as $peer) {
        for ($try = 0; $try < MAX_RETRIES; $try++) {
            $url = $peer . '/p2p.php?action=get_chunk&file=' . $fileHash . '&chunk=' . $chunkNum;
            $r   = httpGet($url);
            if ($r['code'] === 200 && $r['body'] !== '') {
                $d = @json_decode($r['body'], true);
                if (isset($d['contents'], $d['chunk_hash']) && $d['chunk_hash'] === $chunkHash) {
                    if (md5($d['contents']) === $chunkHash) {
                        // Cache locally
                        file_put_contents($localPath, $d['contents']);
                        return ['success' => true, 'source' => $peer, 'contents' => $d['contents']];
                    }
                }
            }
        }
    }

    return ['success' => false, 'source' => '', 'contents' => ''];
}

// ============================================================
//  Download logic (called on POST)
// ============================================================

$log      = [];
$error    = '';
$success  = false;
$outFile  = '';
$outSize  = 0;
$outName  = '';
$hash     = '';
$tab      = $_POST['tab'] ?? $_GET['tab'] ?? 'download';
$history  = [];

// Collect already-downloaded files for the history tab
foreach (glob(DOWNLOADED_DIR . '/*') ?: [] as $f) {
    if (is_file($f)) {
        $history[] = [
            'name'  => basename($f),
            'size'  => filesize($f),
            'mtime' => filemtime($f),
            'path'  => $f,
        ];
    }
}
usort($history, fn($a, $b) => $b['mtime'] - $a['mtime']);

if (isset($_POST['do_download'])) {
    $tab  = 'download';
    $hash = strtolower(trim($_POST['file_hash'] ?? ''));

    if (!isValidMd5($hash)) {
        $error = 'Invalid MD5 hash — must be 32 hexadecimal characters.';
    } else {

        // ── Step 1: Check if the whole file is already available ──
        $wholePath = findWholeFile($hash);
        if ($wholePath !== null) {
            $log[]   = ['ok',   'Whole file found locally: ' . basename($wholePath)];
            $outFile = $wholePath;
            $outSize = filesize($wholePath);
            $outName = basename($wholePath);
            $success = true;

        } else {
            // ── Step 2: Look for chunk list ───────────────────────
            $chunkHashes = readChunkList($hash);

            if (empty($chunkHashes)) {
                $log[] = ['info', 'No local chunk list in hash_chunck/' . $hash . '.txt'];
                // Try peers for file_info / list_chunks
                $peers = discoverPeers(loadPeers());
                $log[] = ['info', count($peers) . ' peer(s) available'];

                // Ask peers for total chunks
                $total = 0;
                foreach ($peers as $peer) {
                    $r = httpGet($peer . '/p2p.php?action=file_info&file=' . $hash);
                    if ($r['code'] === 200) {
                        $d = @json_decode($r['body'], true);
                        if (isset($d['total_chunks']) && $d['total_chunks'] > 0) {
                            $total = (int) $d['total_chunks'];
                            $log[] = ['info', 'File info from peer: ' . $peer . ' — ' . $total . ' chunk(s)'];
                            break;
                        }
                    }
                }

                if ($total === 0) {
                    $error = 'File not found — no chunk list locally and no peer knows this hash.';
                } else {
                    // Peers know it but we have no chunk-hash list;
                    // build chunk list from peer list_chunks responses
                    $r2 = null;
                    foreach ($peers as $peer) {
                        $r2 = httpGet($peer . '/p2p.php?action=list_chunks&file=' . $hash);
                        if ($r2['code'] === 200) break;
                    }
                    if ($r2 && $r2['code'] === 200) {
                        $nums = @json_decode($r2['body'], true);
                        if (is_array($nums)) {
                            sort($nums);
                            // We won't have chunkHash from list_chunks, so download via get_chunk
                            // and trust the returned chunk_hash
                            $assembled = '';
                            $failed    = [];
                            foreach ($nums as $n) {
                                $got = false;
                                foreach ($peers as $peer) {
                                    for ($try = 0; $try < MAX_RETRIES; $try++) {
                                        $r3 = httpGet($peer . '/p2p.php?action=get_chunk&file=' . $hash . '&chunk=' . $n);
                                        if ($r3['code'] === 200) {
                                            $d3 = @json_decode($r3['body'], true);
                                            if (isset($d3['contents'], $d3['chunk_hash']) && md5($d3['contents']) === $d3['chunk_hash']) {
                                                $assembled .= $d3['contents'];
                                                $log[] = ['ok', 'Chunk ' . $n . '/' . $total . ' — OK [' . $peer . ']'];
                                                $got = true;
                                                break 2;
                                            }
                                        }
                                    }
                                }
                                if (!$got) { $failed[] = $n; $log[] = ['error', 'Chunk ' . $n . '/' . $total . ' — FAILED']; }
                            }
                            if (!empty($failed)) {
                                $error = 'Incomplete — missing chunks: ' . implode(', ', $failed);
                            } else {
                                $binary  = base64_decode($assembled, true) ?: $assembled;
                                $outFile = DOWNLOADED_DIR . '/' . $hash;
                                file_put_contents($outFile, $binary);
                                $outSize = strlen($binary);
                                $outName = $hash;
                                $log[]   = ['ok', 'Assembled from peers — ' . formatBytes($outSize)];
                                $success = true;
                            }
                        }
                    } else {
                        $error = 'Peers know the file but could not list chunks.';
                    }
                }

            } else {
                // ── Step 3: We have the chunk-hash list ───────────
                $log[]  = ['info', 'Chunk list found: ' . count($chunkHashes) . ' chunk(s)'];
                $peers  = discoverPeers(loadPeers());
                $log[]  = ['info', count($peers) . ' peer(s) available'];

                $assembled = '';
                $failed    = [];

                foreach ($chunkHashes as $idx => $chunkHash) {
                    $chunkNum = $idx + 1;
                    if (!isValidMd5($chunkHash)) {
                        $log[]    = ['error', 'Chunk ' . $chunkNum . ' — invalid hash in list: ' . $chunkHash];
                        $failed[] = $chunkNum;
                        continue;
                    }

                    $result = fetchChunk($hash, $chunkNum, $chunkHash, $peers);
                    if ($result['success']) {
                        $assembled .= $result['contents'];
                        $src = $result['source'] === 'local' ? 'local cache' : $result['source'];
                        $log[] = ['ok', 'Chunk ' . $chunkNum . '/' . count($chunkHashes) . ' — OK [' . $src . ']'];
                    } else {
                        $failed[]  = $chunkNum;
                        $log[]     = ['error', 'Chunk ' . $chunkNum . '/' . count($chunkHashes) . ' — NOT FOUND'];
                    }
                }

                if (!empty($failed)) {
                    $error = 'Download incomplete — could not fetch chunk(s): ' . implode(', ', $failed);
                } else {
                    $binary  = base64_decode($assembled, true) ?: $assembled;
                    $outFile = DOWNLOADED_DIR . '/' . $hash;
                    file_put_contents($outFile, $binary);
                    $outSize = strlen($binary);
                    $outName = $hash;
                    $log[]   = ['ok', 'File assembled — ' . formatBytes($outSize)];
                    $success = true;
                }
            }
        }
    }
}

// ── Serve file for direct download ───────────────────────────
if (isset($_GET['serve'])) {
    $h = strtolower(preg_replace('/[^a-f0-9]/i', '', $_GET['serve']));
    $path = DOWNLOADED_DIR . '/' . $h;
    if (isValidMd5($h) && file_exists($path)) {
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $h . '.bin"');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }
    http_response_code(404);
    exit('Not found');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>P2P Downloader</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=Space+Grotesk:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
  :root {
    --bg:       #0d0f14;
    --surface:  #13161e;
    --border:   #1e2330;
    --accent:   #00e5a0;
    --accent2:  #0077ff;
    --yellow:   #f5c400;
    --red:      #ff3f5b;
    --text:     #d4dae8;
    --muted:    #5a6380;
    --mono:     'IBM Plex Mono', monospace;
    --sans:     'Space Grotesk', sans-serif;
    --radius:   6px;
  }

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: var(--sans);
    font-size: 14px;
    min-height: 100vh;
    padding: 0 0 60px;
  }

  /* ── Header ── */
  .header {
    border-bottom: 1px solid var(--border);
    padding: 18px 32px;
    display: flex;
    align-items: center;
    gap: 16px;
    background: var(--surface);
  }
  .header-logo {
    width: 36px; height: 36px;
    background: var(--accent2);
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
  }
  .header-logo svg { width: 20px; height: 20px; fill: #fff; }
  .header-title { font-size: 17px; font-weight: 600; letter-spacing: -.3px; }
  .header-sub   { font-size: 12px; color: var(--muted); font-family: var(--mono); margin-top: 1px; }
  .header-links { margin-left: auto; display: flex; gap: 8px; }
  .header-link  {
    font-family: var(--mono);
    font-size: 12px;
    color: var(--accent2);
    text-decoration: none;
    border: 1px solid var(--accent2);
    padding: 4px 10px;
    border-radius: var(--radius);
    transition: background .15s;
  }
  .header-link:hover { background: rgba(0,119,255,.12); }

  /* ── Layout ── */
  .container { max-width: 860px; margin: 0 auto; padding: 32px 24px 0; }

  /* ── Tabs ── */
  nav {
    display: flex;
    gap: 4px;
    margin-bottom: 24px;
    border-bottom: 1px solid var(--border);
  }
  nav button {
    background: none;
    border: none;
    border-bottom: 2px solid transparent;
    color: var(--muted);
    font-family: var(--sans);
    font-size: 13px;
    font-weight: 500;
    padding: 8px 16px;
    cursor: pointer;
    margin-bottom: -1px;
    transition: color .15s, border-color .15s;
  }
  nav button.active { color: var(--accent); border-bottom-color: var(--accent); }
  nav button:hover:not(.active) { color: var(--text); }

  .tab { display: none; }
  .tab.active { display: block; }

  /* ── Cards ── */
  .card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 22px 24px;
    margin-bottom: 16px;
  }
  .card-title {
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: .1em;
    color: var(--muted);
    margin-bottom: 18px;
  }

  /* ── Form ── */
  .field { margin-bottom: 16px; }
  label { display: block; font-size: 12px; color: var(--muted); margin-bottom: 6px; font-family: var(--mono); }

  input[type=text] {
    width: 100%;
    background: #080a10;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    color: var(--text);
    font-family: var(--mono);
    font-size: 15px;
    padding: 11px 14px;
    outline: none;
    letter-spacing: .06em;
    transition: border-color .15s;
  }
  input[type=text]:focus { border-color: var(--accent2); }
  input[type=text]::placeholder { color: var(--muted); letter-spacing: .04em; }

  button[type=submit], .btn {
    background: var(--accent);
    color: #0d0f14;
    border: none;
    border-radius: var(--radius);
    font-family: var(--sans);
    font-weight: 600;
    font-size: 13px;
    padding: 9px 22px;
    cursor: pointer;
    transition: opacity .15s, transform .1s;
    white-space: nowrap;
  }
  button[type=submit]:hover, .btn:hover { opacity: .88; }
  button[type=submit]:active { transform: scale(.97); }

  /* ── Banner ── */
  .banner {
    padding: 12px 18px;
    border-radius: var(--radius);
    margin-bottom: 20px;
    font-size: 13px;
    font-family: var(--mono);
    border-left: 3px solid;
  }
  .banner.ok    { background: rgba(0,229,160,.08); border-color: var(--accent);  color: var(--accent); }
  .banner.error { background: rgba(255,63,91,.08);  border-color: var(--red);     color: var(--red); }
  .banner.info  { background: rgba(0,119,255,.08);  border-color: var(--accent2); color: var(--accent2); }

  /* ── Result box ── */
  .result-box {
    background: #080a10;
    border: 1px solid var(--accent);
    border-radius: var(--radius);
    padding: 20px 22px;
    margin-top: 16px;
  }
  .result-box .rl  { font-size: 11px; color: var(--muted); font-family: var(--mono); margin-bottom: 6px; }
  .result-box .rv  { font-family: var(--mono); font-size: 18px; color: var(--accent); word-break: break-all; }
  .result-box .rm  { font-family: var(--mono); font-size: 11px; color: var(--muted); margin-top: 6px; }
  .result-box .dl-btn {
    display: inline-block;
    margin-top: 14px;
    background: var(--accent2);
    color: #fff;
    font-family: var(--mono);
    font-size: 12px;
    font-weight: 600;
    padding: 7px 16px;
    border-radius: var(--radius);
    text-decoration: none;
    transition: opacity .15s;
  }
  .result-box .dl-btn:hover { opacity: .85; }

  /* ── Log box ── */
  .log-box {
    background: #080a10;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 14px 16px;
    max-height: 300px;
    overflow-y: auto;
    font-family: var(--mono);
    font-size: 12px;
    line-height: 1.75;
  }
  .log-line       { padding: 1px 0; }
  .log-line.ok    { color: var(--accent); }
  .log-line.error { color: var(--red); }
  .log-line.info  { color: var(--accent2); }

  /* ── Stats grid ── */
  .stat-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 12px;
    margin-bottom: 20px;
  }
  .stat-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 16px;
    text-align: center;
  }
  .stat-val   { font-size: 26px; font-weight: 600; font-family: var(--mono); color: var(--accent2); }
  .stat-label { font-size: 11px; color: var(--muted); margin-top: 4px; text-transform: uppercase; letter-spacing: .08em; }

  /* ── Table ── */
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th {
    text-align: left;
    font-size: 11px;
    font-weight: 600;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: .08em;
    padding: 0 12px 10px;
    border-bottom: 1px solid var(--border);
  }
  td { padding: 10px 12px; border-bottom: 1px solid var(--border); vertical-align: middle; }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: rgba(255,255,255,.02); }
  .mono { font-family: var(--mono); font-size: 12px; }
  a.dl-link {
    color: var(--accent2);
    font-family: var(--mono);
    font-size: 11px;
    text-decoration: none;
    border: 1px solid var(--accent2);
    padding: 3px 9px;
    border-radius: var(--radius);
    transition: background .15s;
  }
  a.dl-link:hover { background: rgba(0,119,255,.12); }

  /* ── How it works ── */
  .step { display: flex; gap: 16px; margin-bottom: 18px; }
  .step-num {
    width: 26px; height: 26px;
    background: var(--accent2);
    color: #fff;
    border-radius: 50%;
    font-size: 12px;
    font-weight: 700;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
    margin-top: 1px;
  }
  .step-body { line-height: 1.7; font-size: 13px; }
  .step-body strong { color: var(--accent2); }
  code {
    background: #080a10;
    border: 1px solid var(--border);
    border-radius: 3px;
    padding: 1px 5px;
    font-family: var(--mono);
    font-size: 11px;
    color: var(--accent);
  }

  /* ── Scrollbar ── */
  ::-webkit-scrollbar { width: 6px; height: 6px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }
</style>
</head>
<body>

<div class="header">
  <div class="header-logo">
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path d="M4 16v-2.38C4 11.5 2.97 10.43 3 8c.03-2.67 1.81-4.75 4-5.36V2" stroke="#fff" stroke-width="2" stroke-linecap="round" fill="none"/>
      <path d="M20 16v-2.38c0-2.12 1.03-3.19 1-5.62-.03-2.67-1.81-4.75-4-5.36V2" stroke="#fff" stroke-width="2" stroke-linecap="round" fill="none"/>
      <rect x="2" y="16" width="20" height="6" rx="2" fill="white"/>
      <circle cx="7" cy="19" r="1" fill="#0077ff"/>
      <circle cx="12" cy="19" r="1" fill="#0077ff"/>
      <circle cx="17" cy="19" r="1" fill="#0077ff"/>
    </svg>
  </div>
  <div>
    <div class="header-title">P2P Downloader</div>
    <div class="header-sub">fetch · assemble · download</div>
  </div>
  <div class="header-links">
    <a href="seeder.php"  class="header-link">Seeder</a>
    <a href="p2p.php"     class="header-link">p2p.php</a>
  </div>
</div>

<div class="container">

  <?php if ($error): ?>
  <div class="banner error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <!-- ── TABS ── -->
  <nav>
    <button onclick="switchTab('download', this)" class="<?= $tab==='download' ? 'active' : '' ?>">Download</button>
    <button onclick="switchTab('history',  this)" class="<?= $tab==='history'  ? 'active' : '' ?>">
      History (<?= count($history) ?>)
    </button>
    <button onclick="switchTab('howto',    this)" class="<?= $tab==='howto'    ? 'active' : '' ?>">How It Works</button>
  </nav>

  <!-- ══════════════════════════════════════════════════════
       DOWNLOAD TAB
  ══════════════════════════════════════════════════════ -->
  <div id="tab-download" class="tab <?= $tab==='download' ? 'active' : '' ?>">

    <div class="card">
      <div class="card-title">Fetch File by MD5 Hash</div>

      <form method="POST">
        <input type="hidden" name="tab" value="download">
        <div class="field">
          <label for="file_hash">MD5 Hash</label>
          <input
            type="text"
            id="file_hash"
            name="file_hash"
            maxlength="32"
            autocomplete="off"
            spellcheck="false"
            placeholder="dd1b96f27453cca646d161e9408d0877"
            value="<?= htmlspecialchars($hash) ?>"
          >
        </div>
        <button type="submit" name="do_download">⬇ Download</button>
      </form>

      <?php if ($success): ?>
      <div class="result-box">
        <div class="rl">File ready</div>
        <div class="rv"><?= htmlspecialchars($outName) ?></div>
        <div class="rm"><?= formatBytes($outSize) ?> &nbsp;·&nbsp; <?= htmlspecialchars(DOWNLOADED_DIR) ?></div>
        <a class="dl-btn" href="?serve=<?= urlencode($hash) ?>">⬇ Save to disk</a>
      </div>
      <?php endif; ?>
    </div>

    <?php if (!empty($log)): ?>
    <div class="card">
      <div class="card-title">Transfer Log</div>
      <div class="log-box" id="logBox">
        <?php foreach ($log as [$type, $msg]): ?>
        <div class="log-line <?= htmlspecialchars($type) ?>"><?= htmlspecialchars($msg) ?></div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

  </div>

  <!-- ══════════════════════════════════════════════════════
       HISTORY TAB
  ══════════════════════════════════════════════════════ -->
  <div id="tab-history" class="tab <?= $tab==='history' ? 'active' : '' ?>">

    <?php
    $totalHistSize = array_sum(array_column($history, 'size'));
    ?>
    <div class="stat-grid">
      <div class="stat-card">
        <div class="stat-val"><?= count($history) ?></div>
        <div class="stat-label">Files</div>
      </div>
      <div class="stat-card">
        <div class="stat-val"><?= formatBytes($totalHistSize) ?></div>
        <div class="stat-label">Total Size</div>
      </div>
    </div>

    <?php if (empty($history)): ?>
    <div class="card">
      <p style="color:var(--muted); font-family:var(--mono); font-size:13px;">
        No files downloaded yet.
      </p>
    </div>
    <?php else: ?>
    <div class="card">
      <div class="card-title">Downloaded Files</div>
      <table>
        <tr>
          <th>Hash / Filename</th>
          <th>Size</th>
          <th>Date</th>
          <th></th>
        </tr>
        <?php foreach ($history as $f): ?>
        <tr>
          <td class="mono"><?= htmlspecialchars($f['name']) ?></td>
          <td class="mono"><?= formatBytes($f['size']) ?></td>
          <td class="mono" style="color:var(--muted)"><?= date('Y-m-d H:i', $f['mtime']) ?></td>
          <td>
            <?php $h = preg_replace('/\.[^.]+$/', '', $f['name']); ?>
            <?php if (isValidMd5($h)): ?>
            <a class="dl-link" href="?serve=<?= urlencode($h) ?>">⬇ Download</a>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </table>
    </div>
    <?php endif; ?>
  </div>

  <!-- ══════════════════════════════════════════════════════
       HOW IT WORKS TAB
  ══════════════════════════════════════════════════════ -->
  <div id="tab-howto" class="tab <?= $tab==='howto' ? 'active' : '' ?>">
    <div class="card">
      <div class="card-title">Download Logic</div>

      <div class="step">
        <div class="step-num">1</div>
        <div class="step-body">
          <strong>Whole-file check</strong> — Before anything else, the downloader looks for
          <code>downloaded/&lt;hash&gt;</code>. If the file is already there it is served immediately
          without any network calls.
        </div>
      </div>

      <div class="step">
        <div class="step-num">2</div>
        <div class="step-body">
          <strong>Chunk-hash list</strong> — Opens
          <code>hash_chunck/&lt;hash&gt;.txt</code> (written by the Seeder).
          Each line is the MD5 of one chunk, in order.
          Example line: <code>dd1b96f27453cca646d161e9408d0878</code>
        </div>
      </div>

      <div class="step">
        <div class="step-num">3</div>
        <div class="step-body">
          <strong>Local cache first</strong> — For each chunk it checks
          <code>base64/&lt;fileHash&gt;.&lt;n&gt;.&lt;chunkHash&gt;</code>.
          If the file exists and its MD5 matches, no network call is made.
        </div>
      </div>

      <div class="step">
        <div class="step-num">4</div>
        <div class="step-body">
          <strong>Peer fetch</strong> — If not cached locally, it queries all peers via
          <code>?action=get_chunk&amp;file=&lt;hash&gt;&amp;chunk=&lt;n&gt;</code>,
          verifies the returned chunk hash, and caches it locally for future use.
        </div>
      </div>

      <div class="step">
        <div class="step-num">5</div>
        <div class="step-body">
          <strong>Assemble &amp; decode</strong> — All Base64 chunks are concatenated in order,
          decoded to binary, and saved to <code>downloaded/&lt;hash&gt;</code>.
        </div>
      </div>

      <div class="step">
        <div class="step-num">6</div>
        <div class="step-body">
          <strong>Fallback (no chunk list)</strong> — If <code>hash_chunck/</code> has no file for
          this hash, the downloader queries peers via <code>?action=file_info</code> and
          <code>?action=list_chunks</code> and downloads directly from them.
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-title">Directory Layout</div>
      <div class="log-box" style="max-height:none;">
        <div class="log-line info">hash_chunck/                      ← chunk-hash index (from seeder.php)</div>
        <div class="log-line info">  &lt;fileHash&gt;.txt                   ← one chunkHash per line</div>
        <div class="log-line ok">base64/                           ← cached chunk data</div>
        <div class="log-line ok">  &lt;fileHash&gt;.&lt;n&gt;.&lt;chunkHash&gt;     ← individual chunk</div>
        <div class="log-line" style="color:var(--accent2)">downloaded/                       ← assembled binary output</div>
        <div class="log-line" style="color:var(--accent2)">  &lt;fileHash&gt;                     ← complete file</div>
        <div class="log-line" style="color:var(--muted)">dht.txt / servers.txt             ← peer URLs</div>
      </div>
    </div>
  </div>

</div><!-- /container -->

<script>
function switchTab(name, btn) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('nav button').forEach(b => b.classList.remove('active'));
  document.getElementById('tab-' + name).classList.add('active');
  btn.classList.add('active');
}

// Auto-scroll log to bottom
const lb = document.getElementById('logBox');
if (lb) lb.scrollTop = lb.scrollHeight;
</script>
</body>
</html>