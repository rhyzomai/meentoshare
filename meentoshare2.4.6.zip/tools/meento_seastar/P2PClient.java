import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.stream.*;

/**
 * P2PClient.java
 * -------------------------------------------------------------
 * Single-file Java CLI companion to p2p.php / download.php / seeder.php
 * No external libraries � only the Java standard library.
 *
 * Compile:  javac P2PClient.java
 * Run:      java P2PClient
 */
public class P2PClient {

    // -- Config paths (same directory as the PHP files) --------
    static final String DHT_FILE     = "dht.txt";
    static final String SERVERS_FILE = "servers.txt";
    static final String BASE64_DIR   = "base64";
    static final String BLOCKS_DIR   = "json_blocks";
    static final String OUTPUT_DIR   = "downloaded";
    static final int    TIMEOUT_MS   = 10_000;
    static final int    MAX_RETRIES  = 2;
    static final int    DEFAULT_CHUNK_KB = 512;

    static final String RESET  = "\u001B[0m";
    static final String BOLD   = "\u001B[1m";
    static final String GREEN  = "\u001B[32m";
    static final String YELLOW = "\u001B[33m";
    static final String RED    = "\u001B[31m";
    static final String CYAN   = "\u001B[36m";
    static final String DIM    = "\u001B[2m";

    static final Scanner scanner = new Scanner(System.in);

    // ------------------------------------------------------------
    //  ENTRY POINT
    // ------------------------------------------------------------
    public static void main(String[] args) throws Exception {
        ensureDirs();
        clearScreen();
        printBanner();

        while (true) {
            printMenu();
            String choice = prompt("Choose").trim();
            clearScreen();
            switch (choice) {
                case "1": menuDownload(); break;
                case "2": menuSeed();     break;
                case "3": menuPeers();    break;
                case "4": menuBlocks();   break;
                case "5": menuSeeding();  break;
                case "6": menuNodeInfo(); break;
                case "0": println(DIM + "Bye." + RESET); return;
                default:  warn("Unknown option.");        break;
            }
        }
    }

    // ------------------------------------------------------------
    //  MENU SCREENS
    // ------------------------------------------------------------

    // -- 1. Download ----------------------------------------------
    static void menuDownload() throws Exception {
        header("Download File");
        String hash = prompt("Enter MD5 file hash").trim().toLowerCase();
        if (!isValidMd5(hash)) { warn("Invalid MD5 hash."); pause(); return; }

        List<String> peers = loadPeers();
        if (peers.isEmpty()) { warn("No peers found. Add peers first (option 3)."); pause(); return; }

        log("Peers loaded: " + peers.size());

        // Discover
        List<String> discovered = discoverPeers(peers);
        for (String p : discovered) savePeer(p);
        peers = loadPeers();
        log("Peers after discovery: " + peers.size());

        // Query total chunks
        int total = queryTotalChunks(peers, hash);
        if (total == 0) { warn("File not found on any peer."); pause(); return; }
        ok("File found � " + total + " chunk(s)");

        // Download chunks
        Map<Integer, String> chunkMap = new LinkedHashMap<>();
        List<Integer> failed = new ArrayList<>();

        for (int i = 1; i <= total; i++) {
            ChunkResult cr = downloadChunk(peers, hash, i);
            if (cr.success) {
                chunkMap.put(i, cr.contents);
                ok("Chunk " + i + "/" + total + " � OK  [" + cr.peer + "]");
                // Save locally so we seed it too
                String localPath = BASE64_DIR + "/" + hash + "." + i + "." + cr.chunkHash;
                if (!Files.exists(Paths.get(localPath)))
                    Files.writeString(Paths.get(localPath), cr.contents);
                // Record block
                String block = buildBlock(hash, i, cr.chunkHash, cr.peer);
                saveBlock(block);
                // Notify peers
                notifyPeers(peers, block);
            } else {
                failed.add(i);
                warn("Chunk " + i + "/" + total + " � FAILED");
            }
        }

        if (!failed.isEmpty()) {
            warn("Incomplete. Missing chunks: " + failed);
            pause(); return;
        }

        // Assemble
        log("Assembling chunks...");
        StringBuilder assembled = new StringBuilder();
        for (int i = 1; i <= total; i++) assembled.append(chunkMap.get(i));

        // Decode base64 ? binary
        byte[] binary;
        try {
            binary = Base64.getDecoder().decode(assembled.toString());
            log("Base64 decoded to binary.");
        } catch (IllegalArgumentException e) {
            binary = assembled.toString().getBytes();
            log("Content is not base64 � saved raw.");
        }

        String outPath = OUTPUT_DIR + "/" + hash + ".bin";
        Files.write(Paths.get(outPath), binary);
        ok("Saved: " + outPath + " (" + formatBytes(binary.length) + ")");

        // Final block
        String finalBlock = buildFinalBlock(hash, total, binary.length, outPath);
        saveBlock(finalBlock);
        notifyPeers(peers, finalBlock);

        pause();
    }

    // -- 2. Seed a file -------------------------------------------
    static void menuSeed() throws Exception {
        header("Seed a File");
        String filePath = prompt("Path to file").trim();
        if (filePath.isEmpty() || !Files.exists(Paths.get(filePath))) {
            warn("File not found: " + filePath); pause(); return;
        }

        String chunkKbStr = prompt("Chunk size in KB [" + DEFAULT_CHUNK_KB + "]").trim();
        int chunkKb = chunkKbStr.isEmpty() ? DEFAULT_CHUNK_KB : Integer.parseInt(chunkKbStr);
        chunkKb = Math.max(64, Math.min(4096, chunkKb));
        int chunkSize = chunkKb * 1024;

        byte[] data = Files.readAllBytes(Paths.get(filePath));
        String fileHash = md5Hex(data);
        int totalChunks = (int) Math.ceil((double) data.length / chunkSize);

        log("File:   " + Paths.get(filePath).getFileName());
        log("MD5:    " + fileHash);
        log("Size:   " + formatBytes(data.length));
        log("Chunks: " + totalChunks + " � " + chunkKb + " KB");
        println();

        int newChunks = 0, skipped = 0;
        for (int i = 1; i <= totalChunks; i++) {
            int from = (i - 1) * chunkSize;
            int to   = Math.min(from + chunkSize, data.length);
            byte[] chunk   = Arrays.copyOfRange(data, from, to);
            String encoded = Base64.getEncoder().encodeToString(chunk);
            String chunkHash = md5Hex(encoded.getBytes());
            String dest = BASE64_DIR + "/" + fileHash + "." + i + "." + chunkHash;

            if (Files.exists(Paths.get(dest))) {
                println(DIM + "  chunk " + i + "/" + totalChunks + " � already exists, skipped" + RESET);
                skipped++;
            } else {
                Files.writeString(Paths.get(dest), encoded);
                ok("  chunk " + i + "/" + totalChunks + " � seeded (" + chunkHash + ")");
                newChunks++;
            }
        }

        println();
        ok("Done. " + newChunks + " new chunk(s), " + skipped + " skipped.");
        println();
        println(BOLD + "  Share this hash with peers:" + RESET);
        println("  " + CYAN + BOLD + fileHash + RESET);
        pause();
    }

    // -- 3. Peer management ---------------------------------------
    static void menuPeers() throws Exception {
        while (true) {
            header("Peers / DHT");
            List<String> peers = loadPeers();
            if (peers.isEmpty()) println(DIM + "  (no peers yet)" + RESET);
            else for (int i = 0; i < peers.size(); i++)
                println("  " + DIM + (i+1) + "." + RESET + " " + peers.get(i));

            println();
            println("  [A] Add peer     [D] Discover     [B] Back");
            String c = prompt("").trim().toUpperCase();

            if (c.equals("B")) return;

            if (c.equals("A")) {
                String url = prompt("Peer URL (e.g. http://host/p2p.php)").trim();
                url = url.replaceAll("/p2p\\.php$", "").replaceAll("/$", "");
                if (isValidUrl(url)) { savePeer(url); ok("Peer added."); }
                else warn("Invalid URL.");
            }

            if (c.equals("D")) {
                log("Running discovery...");
                List<String> found = discoverPeers(peers);
                int added = 0;
                for (String p : found) {
                    int before = loadPeers().size();
                    savePeer(p);
                    if (loadPeers().size() > before) added++;
                }
                ok("Found " + found.size() + " peer(s), added " + added + " new.");
            }
        }
    }

    // -- 4. Block history -----------------------------------------
    static void menuBlocks() throws Exception {
        header("Transfer Block History");
        File dir = new File(BLOCKS_DIR);
        File[] files = dir.listFiles((d, n) -> n.endsWith(".json"));
        if (files == null || files.length == 0) {
            println(DIM + "  No blocks recorded yet." + RESET);
            pause(); return;
        }
        Arrays.sort(files, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        int show = Math.min(20, files.length);
        println(DIM + "  Showing " + show + " of " + files.length + " block(s)" + RESET);
        println();
        for (int i = 0; i < show; i++) {
            String content = Files.readString(files[i].toPath());
            String type    = jsonField(content, "type");
            String fhash   = jsonField(content, "file_hash");
            String ts      = jsonField(content, "timestamp");
            println("  " + CYAN + files[i].getName().replace(".json", "").substring(0, 8) + "�" + RESET
                + "  " + BOLD + type + RESET
                + "  file=" + fhash.substring(0, Math.min(8, fhash.length())) + "�"
                + "  " + DIM + ts + RESET);
        }
        println();
        String choice = prompt("[V] View block detail  [Enter] Back").trim().toUpperCase();
        if (choice.equals("V")) {
            String id = prompt("Block prefix (first chars)").trim();
            for (File f : files) {
                if (f.getName().startsWith(id)) {
                    println();
                    println(Files.readString(f.toPath()));
                    println();
                    break;
                }
            }
        }
        pause();
    }

    // -- 5. Seeding status ----------------------------------------
    static void menuSeeding() throws Exception {
        header("Seeding Status");
        File dir = new File(BASE64_DIR);
        File[] files = dir.listFiles();
        if (files == null || files.length == 0) {
            println(DIM + "  No chunks being seeded." + RESET);
            pause(); return;
        }

        Map<String, List<Integer>> byFile = new TreeMap<>();
        for (File f : files) {
            String[] parts = f.getName().split("\\.");
            if (parts.length == 3) {
                byFile.computeIfAbsent(parts[0], k -> new ArrayList<>()).add(Integer.parseInt(parts[1]));
            }
        }

        long totalSize = 0;
        for (File f : files) totalSize += f.length();

        println("  Files:       " + byFile.size());
        println("  Chunks:      " + files.length);
        println("  Disk used:   " + formatBytes(totalSize));
        println();

        String fmt = "  %-34s  %6s  %8s  %s%n";
        System.out.printf(BOLD + fmt + RESET, "Hash", "Chunks", "Size", "Status");
        println("  " + "-".repeat(70));

        for (Map.Entry<String, List<Integer>> e : byFile.entrySet()) {
            String hash   = e.getKey();
            List<Integer> chunks = e.getValue();
            int max       = Collections.max(chunks);
            boolean complete = chunks.size() == max;
            long sz = 0;
            for (File f : files) if (f.getName().startsWith(hash)) sz += f.length();

            String status = complete
                ? GREEN + "complete" + RESET
                : YELLOW + "partial " + chunks.size() + "/" + max + RESET;

            System.out.printf(fmt,
                hash.substring(0, 20) + "�",
                chunks.size() + "/" + max,
                formatBytes(sz),
                status);
        }
        pause();
    }

    // -- 6. Node info ---------------------------------------------
    static void menuNodeInfo() throws Exception {
        header("Node Info");
        println("  Java version:   " + System.getProperty("java.version"));
        println("  Working dir:    " + new File(".").getAbsolutePath());
        println("  DHT file:       " + DHT_FILE  + existsMark(DHT_FILE));
        println("  Servers file:   " + SERVERS_FILE + existsMark(SERVERS_FILE));
        println("  Base64 dir:     " + BASE64_DIR + "  (" + countFiles(BASE64_DIR) + " chunks)");
        println("  Blocks dir:     " + BLOCKS_DIR + "  (" + countFiles(BLOCKS_DIR) + " blocks)");
        println("  Output dir:     " + OUTPUT_DIR + "  (" + countFiles(OUTPUT_DIR) + " files)");
        println();
        println("  API actions (compatible with p2p.php):");
        println(DIM + "  ?action=peers" + RESET);
        println(DIM + "  ?action=file_info&file=<md5>" + RESET);
        println(DIM + "  ?action=list_chunks&file=<md5>" + RESET);
        println(DIM + "  ?action=get_chunk&file=<md5>&chunk=<n>" + RESET);
        println(DIM + "  ?action=notify&block=<json>" + RESET);
        pause();
    }

    // ------------------------------------------------------------
    //  CORE LOGIC
    // ------------------------------------------------------------

    static List<String> loadPeers() throws IOException {
        Set<String> set = new LinkedHashSet<>();
        for (String file : new String[]{DHT_FILE, SERVERS_FILE}) {
            Path p = Paths.get(file);
            if (!Files.exists(p)) continue;
            for (String line : Files.readAllLines(p)) {
                String url = line.strip().replaceAll("/$", "");
                if (!url.isEmpty() && isValidUrl(url)) set.add(url);
            }
        }
        return new ArrayList<>(set);
    }

    static void savePeer(String url) throws IOException {
        url = url.strip().replaceAll("/$", "");
        if (!isValidUrl(url)) return;
        List<String> existing = loadPeers();
        if (existing.contains(url)) return;
        Files.writeString(Paths.get(DHT_FILE), url + "\n",
            StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }

    static List<String> discoverPeers(List<String> known) {
        Set<String> found = new LinkedHashSet<>(known);
        for (String peer : known) {
            try {
                String body = httpGet(peer + "/p2p.php?action=peers");
                if (body == null) continue;
                // Parse simple JSON array
                body = body.trim().replaceAll("^\\[|\\]$", "");
                for (String item : body.split(",")) {
                    String url = item.trim().replaceAll("^\"|\"$", "").replaceAll("/$", "");
                    if (!url.isEmpty() && isValidUrl(url)) found.add(url);
                }
            } catch (Exception ignored) {}
        }
        return new ArrayList<>(found);
    }

    static int queryTotalChunks(List<String> peers, String hash) {
        for (String peer : peers) {
            try {
                // Try file_info first
                String body = httpGet(peer + "/p2p.php?action=file_info&file=" + hash);
                if (body != null) {
                    String val = jsonField(body, "total_chunks");
                    if (!val.isEmpty()) { int n = Integer.parseInt(val); if (n > 0) return n; }
                }
                // Fallback: list_chunks
                body = httpGet(peer + "/p2p.php?action=list_chunks&file=" + hash);
                if (body != null) {
                    body = body.trim().replaceAll("^\\[|\\]$", "");
                    int max = 0;
                    for (String s : body.split(",")) {
                        try { max = Math.max(max, Integer.parseInt(s.trim())); } catch (Exception ignored) {}
                    }
                    if (max > 0) return max;
                }
            } catch (Exception ignored) {}
        }
        return 0;
    }

    static ChunkResult downloadChunk(List<String> peers, String hash, int chunkNum) {
        for (String peer : peers) {
            for (int t = 0; t < MAX_RETRIES; t++) {
                try {
                    String body = httpGet(peer + "/p2p.php?action=get_chunk&file=" + hash + "&chunk=" + chunkNum);
                    if (body == null) continue;
                    String contents   = jsonField(body, "contents");
                    String chunkHash  = jsonField(body, "chunk_hash");
                    if (contents.isEmpty() || chunkHash.isEmpty()) continue;
                    if (md5Hex(contents.getBytes()).equals(chunkHash)) {
                        return new ChunkResult(true, peer, contents, chunkHash);
                    }
                } catch (Exception ignored) {}
            }
        }
        return new ChunkResult(false, "", "", "");
    }

    static void notifyPeers(List<String> peers, String blockJson) {
        try {
            String encoded = URLEncoder.encode(blockJson, "UTF-8");
            for (String peer : peers) {
                try { httpGet(peer + "/p2p.php?action=notify&block=" + encoded); }
                catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
    }

    // ------------------------------------------------------------
    //  BLOCK HELPERS
    // ------------------------------------------------------------

    static String buildBlock(String fileHash, int chunk, String chunkHash, String fromPeer) {
        return "{"
            + "\"type\":\"chunk_received\","
            + "\"file_hash\":\"" + fileHash + "\","
            + "\"chunk\":" + chunk + ","
            + "\"chunk_hash\":\"" + chunkHash + "\","
            + "\"from_peer\":\"" + fromPeer + "\","
            + "\"timestamp\":\"" + new Date() + "\""
            + "}";
    }

    static String buildFinalBlock(String fileHash, int totalChunks, int sizeBytes, String outFile) {
        return "{"
            + "\"type\":\"file_assembled\","
            + "\"file_hash\":\"" + fileHash + "\","
            + "\"total_chunks\":" + totalChunks + ","
            + "\"output_file\":\"" + Paths.get(outFile).getFileName() + "\","
            + "\"size_bytes\":" + sizeBytes + ","
            + "\"timestamp\":\"" + new Date() + "\""
            + "}";
    }

    static void saveBlock(String json) {
        try {
            String hash = md5Hex((json + System.nanoTime()).getBytes()).substring(0, 16);
            Files.writeString(Paths.get(BLOCKS_DIR + "/" + hash + ".json"), json);
        } catch (Exception ignored) {}
    }

    // ------------------------------------------------------------
    //  HTTP
    // ------------------------------------------------------------

    static String httpGet(String urlStr) throws Exception {
        URL url = URI.create(urlStr).toURL();
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(TIMEOUT_MS);
        conn.setReadTimeout(TIMEOUT_MS);
        conn.setRequestProperty("User-Agent", "P2PClient-Java/1.0");
        int code = conn.getResponseCode();
        if (code != 200) return null;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
            return br.lines().collect(Collectors.joining("\n"));
        }
    }

    // ------------------------------------------------------------
    //  UTILITIES
    // ------------------------------------------------------------

    static String md5Hex(byte[] data) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] digest = md.digest(data);
        StringBuilder sb = new StringBuilder();
        for (byte b : digest) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    static boolean isValidMd5(String s) {
        return s != null && s.matches("[a-f0-9]{32}");
    }

    static boolean isValidUrl(String s) {
        try { URI.create(s); return s.startsWith("http://") || s.startsWith("https://"); }
        catch (Exception e) { return false; }
    }

    /** Very small JSON string-field extractor � no library needed */
    static String jsonField(String json, String key) {
        // Match "key":"value" or "key":number
        String pattern1 = "\"" + key + "\":\"";
        int idx = json.indexOf(pattern1);
        if (idx >= 0) {
            int start = idx + pattern1.length();
            int end   = json.indexOf('"', start);
            if (end > start) return json.substring(start, end);
        }
        String pattern2 = "\"" + key + "\":";
        idx = json.indexOf(pattern2);
        if (idx >= 0) {
            int start = idx + pattern2.length();
            int end   = start;
            while (end < json.length() && ",}\n".indexOf(json.charAt(end)) < 0) end++;
            return json.substring(start, end).trim();
        }
        return "";
    }

    static String formatBytes(long b) {
        if (b >= 1_048_576) return String.format("%.2f MB", b / 1_048_576.0);
        if (b >= 1_024)     return String.format("%.2f KB", b / 1_024.0);
        return b + " B";
    }

    static int countFiles(String dir) {
        File[] f = new File(dir).listFiles();
        return f == null ? 0 : f.length;
    }

    static String existsMark(String path) {
        return Files.exists(Paths.get(path)) ? "  " + GREEN + "?" + RESET : "  " + DIM + "(not found)" + RESET;
    }

    static void ensureDirs() throws IOException {
        for (String d : new String[]{BASE64_DIR, BLOCKS_DIR, OUTPUT_DIR})
            Files.createDirectories(Paths.get(d));
    }

    // ------------------------------------------------------------
    //  UI HELPERS
    // ------------------------------------------------------------

    static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    static void printBanner() {
        println(CYAN + BOLD);
        println("  ������+ ������+ ������+     ���+   ��+ ������+ ������+ �������+");
        println("  ��+--��++----��+��+--��+    ����+  �����+---��+��+--��+��+----+");
        println("  ������++ �����++������++    ��+��+ ������   ������  ��������+  ");
        println("  ��+---+ ��+---+ ��+---+     ���+��+������   ������  �����+--+  ");
        println("  ���     �������+���          ��� +�����+������++������++�������+");
        println("  +-+     +------++-+          +-+  +---+ +-----+ +-----+ +------+");
        println(RESET + DIM + "  BitTorrent-like file transfer � Java CLI � compatible with p2p.php" + RESET);
        println();
    }

    static void printMenu() {
        println(BOLD + "  Main Menu" + RESET);
        println("  " + "-".repeat(38));
        println("  " + CYAN + "1" + RESET + "  Download file by MD5 hash");
        println("  " + CYAN + "2" + RESET + "  Seed a file (chunk + encode)");
        println("  " + CYAN + "3" + RESET + "  Manage peers / DHT");
        println("  " + CYAN + "4" + RESET + "  Block history");
        println("  " + CYAN + "5" + RESET + "  Seeding status");
        println("  " + CYAN + "6" + RESET + "  Node info");
        println("  " + DIM  + "0  Exit" + RESET);
        println();
    }

    static void header(String title) {
        println(BOLD + CYAN + "  -- " + title + " --" + RESET);
        println();
    }

    static String prompt(String msg) {
        System.out.print("  " + BOLD + msg + (msg.isEmpty() ? "" : ": ") + RESET);
        return scanner.nextLine();
    }

    static void log(String msg)  { println("  " + DIM  + "? " + msg + RESET); }
    static void ok(String msg)   { println("  " + GREEN + "? " + msg + RESET); }
    static void warn(String msg) { println("  " + RED   + "? " + msg + RESET); }
    static void println()        { System.out.println(); }
    static void println(String s){ System.out.println(s); }

    static void pause() throws IOException {
        println();
        System.out.print(DIM + "  Press Enter to continue..." + RESET);
        new BufferedReader(new InputStreamReader(System.in)).readLine();
    }

    // ------------------------------------------------------------
    //  DATA CLASS
    // ------------------------------------------------------------

    static class ChunkResult {
        boolean success;
        String peer, contents, chunkHash;
        ChunkResult(boolean s, String p, String c, String h) {
            success = s; peer = p; contents = c; chunkHash = h;
        }
    }
}