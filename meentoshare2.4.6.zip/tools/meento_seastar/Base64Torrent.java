import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.Base64;
import java.text.SimpleDateFormat;

/**
 * Base64Torrent - A BitTorrent-like file sharing system using HTTP GET + Base64 chunks.
 * Single file, Java 14 compatible, no external dependencies.
 *
 * Directory layout:
 *   files/    - original binary files
 *   base64/   - full base64-encoded versions of files
 *   chunks/   - individual chunk files  (md5full.chunkNum.md5chunk)
 *   hash64/   - index files            (md5full.txt  =>  one md5chunk per line)
 *   json64/   - blockchain-style transfer log
 *
 * Chunk filename: <md5_of_full_base64>.<chunkIndex>.<md5_of_chunk_data>
 */
public class Base64Torrent extends JFrame {

    // -- directories ------------------------------------------------------------
    static final String DIR_FILES   = "files";
    static final String DIR_BASE64  = "base64";
    static final String DIR_CHUNKS  = "chunks";
    static final String DIR_HASH64  = "hash64";
    static final String DIR_JSON64  = "json64";
    static final String SERVERS_TXT = "servers.txt";
    static final String PUBKEY_FILE = "pub.key";

    // -- state ------------------------------------------------------------------
    private int chunkSize = 500;
    private com.sun.net.httpserver.HttpServer httpServer;
    private int httpPort = 8080;
    private final ExecutorService executor = Executors.newCachedThreadPool();
    private String publicKey = "";

    // -- UI components ----------------------------------------------------------
    private JTextArea logArea;
    private JTextField searchField;
    private JTextField chunkSizeField;
    private JTextField portField;
    private JTable progressTable;
    private DefaultTableModel progressModel;
    private JLabel serverStatusLabel;

    // -- constructor ------------------------------------------------------------
    public Base64Torrent() {
        super("Base64Torrent");
        ensureDirectories();
        loadPublicKey();
        initUI();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 750);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    // --------------------------------------------------------------------------
    // UI BOOTSTRAP
    // --------------------------------------------------------------------------
    private void initUI() {
        setLayout(new BorderLayout(6, 6));
        ((JPanel) getContentPane()).setBorder(new EmptyBorder(8, 8, 8, 8));

        // -- TOP TOOLBAR --
        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 4));
        toolbar.setBorder(BorderFactory.createTitledBorder("Actions"));

        JButton btnListFiles   = btn("?? List Files ? Base64",      e -> listFilesToBase64());
        JButton btnListBase64  = btn("?? List Base64 ? Chunks",     e -> listBase64ToChunks());
        JButton btnStartServer = btn("?? Start HTTP Server",         e -> toggleHttpServer());
        JButton btnSearch      = btn("?? Search / Download",         e -> searchAndDownload());

        chunkSizeField = new JTextField(String.valueOf(chunkSize), 5);
        portField      = new JTextField(String.valueOf(httpPort),  5);
        serverStatusLabel = new JLabel("Server: OFF");
        serverStatusLabel.setForeground(Color.RED);

        toolbar.add(btnListFiles);
        toolbar.add(btnListBase64);
        toolbar.add(new JLabel("  Chunk size:"));
        toolbar.add(chunkSizeField);
        toolbar.add(btnStartServer);
        toolbar.add(new JLabel("  Port:"));
        toolbar.add(portField);
        toolbar.add(serverStatusLabel);

        // -- SEARCH BAR --
        JPanel searchPanel = new JPanel(new BorderLayout(6, 0));
        searchPanel.setBorder(BorderFactory.createTitledBorder("Search / Hash MD5 Download"));
        searchField = new JTextField();
        searchPanel.add(new JLabel("Filename or MD5: "), BorderLayout.WEST);
        searchPanel.add(searchField, BorderLayout.CENTER);
        searchPanel.add(btnSearch, BorderLayout.EAST);

        JPanel topSection = new JPanel(new BorderLayout(0, 4));
        topSection.add(toolbar,      BorderLayout.NORTH);
        topSection.add(searchPanel,  BorderLayout.SOUTH);
        add(topSection, BorderLayout.NORTH);

        // -- PROGRESS TABLE --
        String[] cols = {"File", "Size", "Chunks", "Downloaded", "Progress %", "Status"};
        progressModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        progressTable = new JTable(progressModel);
        progressTable.setFillsViewportHeight(true);
        progressTable.getColumnModel().getColumn(4).setCellRenderer(new ProgressCellRenderer());
        JScrollPane tableScroll = new JScrollPane(progressTable);
        tableScroll.setBorder(BorderFactory.createTitledBorder("Download Progress"));
        tableScroll.setPreferredSize(new Dimension(0, 200));

        // -- LOG --
        logArea = new JTextArea();
        logArea.setEditable(false);
        logArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        JScrollPane logScroll = new JScrollPane(logArea);
        logScroll.setBorder(BorderFactory.createTitledBorder("Log"));

        JSplitPane center = new JSplitPane(JSplitPane.VERTICAL_SPLIT, tableScroll, logScroll);
        center.setResizeWeight(0.35);
        add(center, BorderLayout.CENTER);

        // -- STATUS BAR --
        JPanel statusBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statusBar.setBorder(new EtchedBorder());
        statusBar.add(new JLabel("Public key: " + (publicKey.isEmpty() ? "NOT LOADED" : publicKey.length() + " chars")));
        add(statusBar, BorderLayout.SOUTH);
    }

    private JButton btn(String label, ActionListener al) {
        JButton b = new JButton(label);
        b.addActionListener(al);
        return b;
    }

    // --------------------------------------------------------------------------
    // DIRECTORY & KEY SETUP
    // --------------------------------------------------------------------------
    private void ensureDirectories() {
        for (String d : new String[]{DIR_FILES, DIR_BASE64, DIR_CHUNKS, DIR_HASH64, DIR_JSON64})
            new File(d).mkdirs();
    }

    private void loadPublicKey() {
        File f = new File(PUBKEY_FILE);
        if (!f.exists()) { log("pub.key not found � public key not loaded."); return; }
        if (f.length() > 500 * 1024) { log("pub.key exceeds 500 KB limit � ignored."); return; }
        try {
            publicKey = new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8).trim();
            log("pub.key loaded (" + publicKey.length() + " chars).");
        } catch (IOException e) { log("Error loading pub.key: " + e.getMessage()); }
    }

    // --------------------------------------------------------------------------
    // STEP 1 � LIST files/ ? encode to base64/
    // --------------------------------------------------------------------------
    private void listFilesToBase64() {
        executor.submit(() -> {
            File dir = new File(DIR_FILES);
            File[] items = dir.listFiles(f -> f.isFile());
            if (items == null || items.length == 0) { log("No files found in '" + DIR_FILES + "'."); return; }
            log("Encoding " + items.length + " file(s) to base64...");
            for (File f : items) {
                try {
                    byte[] raw = Files.readAllBytes(f.toPath());
                    String b64 = Base64.getEncoder().encodeToString(raw);
                    File out = new File(DIR_BASE64, f.getName() + ".b64");
                    Files.write(out.toPath(), b64.getBytes(StandardCharsets.UTF_8));
                    log("  ? " + f.getName() + " ? " + out.getName() + " (" + b64.length() + " chars)");
                } catch (IOException e) { log("  ? " + f.getName() + ": " + e.getMessage()); }
            }
            log("Done encoding.");
        });
    }

    // --------------------------------------------------------------------------
    // STEP 2 � LIST base64/ ? split into chunks/  +  write hash64/
    // --------------------------------------------------------------------------
    private void listBase64ToChunks() {
        // read chunk size from field
        try { chunkSize = Integer.parseInt(chunkSizeField.getText().trim()); }
        catch (NumberFormatException ex) { log("Invalid chunk size � using " + chunkSize); }

        executor.submit(() -> {
            File dir = new File(DIR_BASE64);
            File[] items = dir.listFiles(f -> f.isFile());
            if (items == null || items.length == 0) { log("No files found in '" + DIR_BASE64 + "'."); return; }
            log("Splitting " + items.length + " base64 file(s) into chunks of " + chunkSize + " chars...");
            for (File f : items) {
                try {
                    String content = new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
                    String fullHash = md5(content);
                    File hashFile  = new File(DIR_HASH64, fullHash + ".txt");
                    List<String> lines = new ArrayList<>();
                    int total = (int) Math.ceil((double) content.length() / chunkSize);
                    for (int i = 0; i < total; i++) {
                        int start = i * chunkSize;
                        int end   = Math.min(start + chunkSize, content.length());
                        String piece     = content.substring(start, end);
                        String pieceHash = md5(piece);
                        String chunkName = fullHash + "." + (i + 1) + "." + pieceHash;
                        File chunkFile   = new File(DIR_CHUNKS, chunkName);
                        Files.write(chunkFile.toPath(), piece.getBytes(StandardCharsets.UTF_8));
                        lines.add(pieceHash);
                    }
                    Files.write(hashFile.toPath(),
                        String.join("\n", lines).getBytes(StandardCharsets.UTF_8));
                    log("  ? " + f.getName() + " ? " + total + " chunks  [hash=" + fullHash + "]");
                } catch (IOException e) { log("  ? " + f.getName() + ": " + e.getMessage()); }
            }
            log("Done splitting.");
        });
    }

    // --------------------------------------------------------------------------
    // STEP 3 � SEARCH & DOWNLOAD
    // --------------------------------------------------------------------------
    private void searchAndDownload() {
        String query = searchField.getText().trim();
        if (query.isEmpty()) { log("Enter a filename or MD5 hash to search."); return; }
        List<String> servers = loadServers();
        if (servers.isEmpty()) { log("No servers in servers.txt"); return; }

        executor.submit(() -> {
            log("=== Searching for: " + query + " on " + servers.size() + " server(s) ===");
            boolean isMd5 = query.matches("[a-fA-F0-9]{32}");

            // -- 1. Check files/ on servers ----------------------------------
            for (String srv : servers) {
                String url = srv + "/" + DIR_FILES + "/" + query;
                log("Trying direct download from " + url);
                try {
                    byte[] data = httpGet(url);
                    if (data != null) {
                        String ext = inferExtension(data);
                        File out = new File(DIR_FILES, query + ext);
                        Files.write(out.toPath(), data);
                        log("? Direct file download: " + out.getName());
                        notifyServers(servers, query, "direct_file", data.length);
                        return;
                    }
                } catch (Exception ignored) {}
            }

            // -- 2. Check base64/ on servers (if MD5 supplied) ---------------
            if (isMd5) {
                for (String srv : servers) {
                    String url = srv + "/" + DIR_BASE64 + "/" + query;
                    log("Trying base64 download from " + url);
                    try {
                        byte[] data = httpGet(url);
                        if (data != null) {
                            String b64str = new String(data, StandardCharsets.UTF_8);
                            byte[] raw = Base64.getDecoder().decode(b64str);
                            String ext = inferExtension(raw);
                            File out = new File(DIR_FILES, query + ext);
                            Files.write(out.toPath(), raw);
                            // save base64 locally too
                            Files.write(new File(DIR_BASE64, query + ".b64").toPath(), data);
                            log("? Base64 download assembled: " + out.getName());
                            notifyServers(servers, query, "base64_file", raw.length);
                            return;
                        }
                    } catch (Exception ignored) {}
                }

                // -- 3. Chunk-based download from hash64 index ----------------
                downloadByChunks(query, servers);
            } else {
                // name-based: search files/ listing
                searchFilesByName(query, servers);
            }
        });
    }

    /** Download by reassembling chunks guided by hash64/<md5>.txt */
    private void downloadByChunks(String fileHash, List<String> servers) {
        log("Attempting chunk-based download for hash: " + fileHash);

        // find hash index on any server
        List<String> chunkHashes = null;
        String indexServer = null;
        for (String srv : servers) {
            String url = srv + "/" + DIR_HASH64 + "/" + fileHash + ".txt";
            try {
                byte[] data = httpGet(url);
                if (data != null) {
                    chunkHashes = Arrays.asList(
                        new String(data, StandardCharsets.UTF_8).split("\\r?\\n"));
                    indexServer = srv;
                    log("Found index on " + srv + " � " + chunkHashes.size() + " chunks");
                    break;
                }
            } catch (Exception ignored) {}
        }

        if (chunkHashes == null || chunkHashes.isEmpty()) {
            log("? Hash index not found on any server for: " + fileHash);
            return;
        }

        int total = chunkHashes.size();
        int rowIdx = addProgressRow(fileHash, "?", total);
        StringBuilder assembled = new StringBuilder();
        AtomicInteger downloaded = new AtomicInteger(0);

        for (int i = 0; i < total; i++) {
            String pieceHash  = chunkHashes.get(i).trim();
            if (pieceHash.isEmpty()) continue;
            String chunkName  = fileHash + "." + (i + 1) + "." + pieceHash;
            File   localChunk = new File(DIR_CHUNKS, chunkName);

            // check local cache first
            if (localChunk.exists()) {
                try {
                    assembled.append(new String(Files.readAllBytes(localChunk.toPath()), StandardCharsets.UTF_8));
                    downloaded.incrementAndGet();
                    updateProgress(rowIdx, downloaded.get(), total, "cached");
                    continue;
                } catch (IOException ignored) {}
            }

            // download from servers
            boolean got = false;
            for (String srv : servers) {
                String url = srv + "/" + DIR_CHUNKS + "/" + chunkName;
                try {
                    byte[] data = httpGet(url);
                    if (data != null) {
                        String piece = new String(data, StandardCharsets.UTF_8);
                        // verify chunk hash
                        if (!md5(piece).equals(pieceHash)) {
                            log("  ? Chunk hash mismatch for " + chunkName);
                            continue;
                        }
                        Files.write(localChunk.toPath(), data);
                        assembled.append(piece);
                        downloaded.incrementAndGet();
                        updateProgress(rowIdx, downloaded.get(), total, "downloading");
                        got = true;
                        break;
                    }
                } catch (Exception ex) { log("  ? " + srv + " � " + ex.getMessage()); }
            }
            if (!got) { log("  ? Could not download chunk " + (i+1) + "/" + total); }
        }

        if (downloaded.get() < total) {
            updateProgress(rowIdx, downloaded.get(), total, "INCOMPLETE");
            log("? Could only get " + downloaded.get() + "/" + total + " chunks.");
            return;
        }

        // reassemble
        try {
            String b64content = assembled.toString();
            byte[] raw = Base64.getDecoder().decode(b64content);
            String ext = inferExtension(raw);
            File outFile  = new File(DIR_FILES,  fileHash + ext);
            File outB64   = new File(DIR_BASE64, fileHash + ".b64");
            Files.write(outFile.toPath(), raw);
            Files.write(outB64.toPath(),  b64content.getBytes(StandardCharsets.UTF_8));
            updateProgress(rowIdx, total, total, "DONE � " + outFile.getName());
            log("? Assembled: " + outFile.getName() + " (" + raw.length + " bytes)");
            notifyServers(servers, fileHash, "chunk_assembled", raw.length);
        } catch (Exception e) {
            updateProgress(rowIdx, downloaded.get(), total, "ERROR");
            log("? Assembly error: " + e.getMessage());
        }
    }

    /** Name-based search: list /files/ on each server and match substring */
    private void searchFilesByName(String query, List<String> servers) {
        log("Searching by name '" + query + "' across servers...");
        for (String srv : servers) {
            String url = srv + "/list/files";
            try {
                byte[] data = httpGet(url);
                if (data == null) continue;
                String listing = new String(data, StandardCharsets.UTF_8);
                for (String line : listing.split("\\r?\\n")) {
                    if (line.toLowerCase().contains(query.toLowerCase())) {
                        log("  Found match: " + line + " on " + srv);
                        String dlUrl = srv + "/" + DIR_FILES + "/" + line.trim();
                        byte[] file  = httpGet(dlUrl);
                        if (file != null) {
                            File out = new File(DIR_FILES, line.trim());
                            Files.write(out.toPath(), file);
                            log("  ? Downloaded: " + out.getName());
                            List<String> srvList = loadServers();
                            notifyServers(srvList, line.trim(), "name_search", file.length);
                            return;
                        }
                    }
                }
            } catch (Exception ex) { log("  ? " + srv + ": " + ex.getMessage()); }
        }
        log("No match found for '" + query + "'.");
    }

    // --------------------------------------------------------------------------
    // HTTP SERVER
    // --------------------------------------------------------------------------
    private void toggleHttpServer() {
        if (httpServer != null) {
            httpServer.stop(0);
            httpServer = null;
            serverStatusLabel.setText("Server: OFF");
            serverStatusLabel.setForeground(Color.RED);
            log("HTTP server stopped.");
            return;
        }
        try {
            httpPort = Integer.parseInt(portField.getText().trim());
        } catch (NumberFormatException ex) { log("Invalid port � using " + httpPort); }

        try {
            // Use reflection to access com.sun.net.httpserver on Java 14
            httpServer = com.sun.net.httpserver.HttpServer.create(
                new InetSocketAddress(httpPort), 0);

            // serve files, base64, chunks
            for (String dir : new String[]{DIR_FILES, DIR_BASE64, DIR_CHUNKS, DIR_HASH64}) {
                final String d = dir;
                httpServer.createContext("/" + dir, exchange -> {
                    String path = exchange.getRequestURI().getPath();
                    String name = path.substring(("/" + d + "/").length());
                    serveFile(exchange, new File(d, name));
                });
            }

            // listing endpoints
            httpServer.createContext("/list/files",  ex -> serveList(ex, DIR_FILES));
            httpServer.createContext("/list/base64", ex -> serveList(ex, DIR_BASE64));
            httpServer.createContext("/list/chunks", ex -> serveList(ex, DIR_CHUNKS));

            // root � HTML index
            httpServer.createContext("/", exchange -> {
                StringBuilder sb = new StringBuilder();
                sb.append("<html><head><title>Base64Torrent</title></head><body>");
                sb.append("<h1>Base64Torrent Node</h1>");
                sb.append("<p>Public key: <code>").append(escHtml(publicKey.length() > 80 ?
                    publicKey.substring(0, 80) + "�" : publicKey)).append("</code></p>");
                for (String d : new String[]{DIR_FILES, DIR_BASE64, DIR_CHUNKS}) {
                    sb.append("<h2>").append(d).append("/</h2><ul>");
                    File dir = new File(d);
                    File[] items = dir.listFiles();
                    if (items != null) for (File f : items)
                        sb.append("<li><a href='/").append(d).append("/")
                          .append(escHtml(f.getName())).append("'>")
                          .append(escHtml(f.getName())).append("</a> (")
                          .append(f.length()).append(" bytes)</li>");
                    sb.append("</ul>");
                }
                sb.append("</body></html>");
                byte[] resp = sb.toString().getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
                exchange.sendResponseHeaders(200, resp.length);
                exchange.getResponseBody().write(resp);
                exchange.getResponseBody().close();
            });

            httpServer.setExecutor(Executors.newFixedThreadPool(8));
            httpServer.start();
            serverStatusLabel.setText("Server: ON :" + httpPort);
            serverStatusLabel.setForeground(new Color(0, 150, 0));
            log("HTTP server started on port " + httpPort);
        } catch (IOException e) {
            log("Failed to start HTTP server: " + e.getMessage());
        }
    }

    private void serveFile(com.sun.net.httpserver.HttpExchange exchange, File f) throws IOException {
        if (!f.exists() || !f.isFile()) {
            String msg = "404 Not Found";
            exchange.sendResponseHeaders(404, msg.length());
            exchange.getResponseBody().write(msg.getBytes());
            exchange.getResponseBody().close();
            return;
        }
        byte[] data = Files.readAllBytes(f.toPath());
        exchange.getResponseHeaders().set("Content-Type", "application/octet-stream");
        exchange.getResponseHeaders().set("Content-Disposition", "attachment; filename=\"" + f.getName() + "\"");
        exchange.sendResponseHeaders(200, data.length);
        exchange.getResponseBody().write(data);
        exchange.getResponseBody().close();
    }

    private void serveList(com.sun.net.httpserver.HttpExchange exchange, String dir) throws IOException {
        File d = new File(dir);
        StringBuilder sb = new StringBuilder();
        File[] items = d.listFiles();
        if (items != null) for (File f : items) sb.append(f.getName()).append("\n");
        byte[] data = sb.toString().getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/plain; charset=utf-8");
        exchange.sendResponseHeaders(200, data.length);
        exchange.getResponseBody().write(data);
        exchange.getResponseBody().close();
    }

    // --------------------------------------------------------------------------
    // BLOCKCHAIN NOTIFICATION
    // --------------------------------------------------------------------------
    private void notifyServers(List<String> servers, String fileRef, String type, long size) {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'").format(new Date());
        String prevHash  = getLastBlockHash();
        String payload   = buildBlockJson(fileRef, type, size, timestamp, prevHash);
        // save locally
        saveBlock(payload, prevHash);
        // notify all servers via GET
        for (String srv : servers) {
            String encoded;
            try { encoded = URLEncoder.encode(payload, "UTF-8"); }
            catch (Exception e) { encoded = ""; }
            String notifUrl = srv + "/notify?data=" + encoded;
            executor.submit(() -> {
                try { httpGet(notifUrl); }
                catch (Exception ignored) {}
            });
        }
        log("Blockchain notification sent: type=" + type + " file=" + fileRef);
    }

    private String buildBlockJson(String fileRef, String type, long size,
                                   String timestamp, String prevHash) {
        String body = "{" +
            "\"fileRef\":\"" + esc(fileRef) + "\"," +
            "\"type\":\""    + esc(type)    + "\"," +
            "\"size\":"      + size         + ","   +
            "\"timestamp\":\"" + timestamp  + "\"," +
            "\"publicKey\":\"" + esc(publicKey.length() > 200 ?
                publicKey.substring(0, 200) : publicKey) + "\"," +
            "\"prevHash\":\"" + prevHash    + "\"" +
            "}";
        String blockHash = md5(body);
        return "{\"hash\":\"" + blockHash + "\"," +
               "\"data\":"    + body      + "}";
    }

    private String getLastBlockHash() {
        File dir = new File(DIR_JSON64);
        File[] files = dir.listFiles(f -> f.getName().endsWith(".json"));
        if (files == null || files.length == 0) return "0000000000000000000000000000000000000000";
        Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());
        try {
            String content = new String(Files.readAllBytes(files[0].toPath()), StandardCharsets.UTF_8);
            int idx = content.indexOf("\"hash\":\"");
            if (idx >= 0) {
                int s = idx + 8, e = content.indexOf("\"", s);
                if (e > s) return content.substring(s, e);
            }
        } catch (IOException ignored) {}
        return "0000000000000000000000000000000000000000";
    }

    private void saveBlock(String json, String prevHash) {
        String name = md5(json + System.nanoTime()) + ".json";
        try {
            Files.write(new File(DIR_JSON64, name).toPath(),
                json.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) { log("Failed to save block: " + e.getMessage()); }
    }

    // --------------------------------------------------------------------------
    // PROGRESS TABLE HELPERS
    // --------------------------------------------------------------------------
    private int addProgressRow(String name, String size, int totalChunks) {
        final Object[] row = {name, size, totalChunks, 0, 0, "starting"};
        SwingUtilities.invokeLater(() -> progressModel.addRow(row));
        return progressModel.getRowCount(); // approximate; updated below
    }

    private void updateProgress(int approxRow, int done, int total, String status) {
        SwingUtilities.invokeLater(() -> {
            int row = progressModel.getRowCount() - 1; // last inserted row
            if (row < 0) return;
            int pct = total > 0 ? (done * 100 / total) : 0;
            progressModel.setValueAt(done + "/" + total, row, 3);
            progressModel.setValueAt(pct,                row, 4);
            progressModel.setValueAt(status,             row, 5);
        });
    }

    // --------------------------------------------------------------------------
    // HTTP GET UTILITY
    // --------------------------------------------------------------------------
    private byte[] httpGet(String urlStr) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(10000);
        conn.setRequestProperty("User-Agent", "Base64Torrent/1.0");
        int code = conn.getResponseCode();
        if (code != 200) return null;
        try (InputStream is = conn.getInputStream()) {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) != -1) baos.write(buf, 0, n);
            return baos.toByteArray();
        }
    }

    // --------------------------------------------------------------------------
    // UTILITY � MD5
    // --------------------------------------------------------------------------
    static String md5(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] hash = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) { return "00000000000000000000000000000000"; }
    }

    // --------------------------------------------------------------------------
    // UTILITY � INFER EXTENSION FROM MAGIC BYTES
    // --------------------------------------------------------------------------
    private String inferExtension(byte[] data) {
        if (data.length < 4) return ".bin";
        int b0 = data[0] & 0xFF, b1 = data[1] & 0xFF,
            b2 = data[2] & 0xFF, b3 = data[3] & 0xFF;
        // PNG
        if (b0==0x89 && b1=='P' && b2=='N' && b3=='G') return ".png";
        // JPEG
        if (b0==0xFF && b1==0xD8) return ".jpg";
        // GIF
        if (b0=='G' && b1=='I' && b2=='F') return ".gif";
        // PDF
        if (b0=='%' && b1=='P' && b2=='D' && b3=='F') return ".pdf";
        // ZIP / DOCX / XLSX / JAR
        if (b0=='P' && b1=='K' && b2==0x03 && b3==0x04) return ".zip";
        // MP4 / MOV (ftyp box at offset 4)
        if (data.length > 8) {
            int b4=data[4]&0xFF, b5=data[5]&0xFF, b6=data[6]&0xFF, b7=data[7]&0xFF;
            if (b4=='f' && b5=='t' && b6=='y' && b7=='p') return ".mp4";
        }
        // MP3
        if (b0==0xFF && (b1==0xFB || b1==0xF3 || b1==0xF2)) return ".mp3";
        // WEBP
        if (b0=='R' && b1=='I' && b2=='F' && b3=='F' && data.length > 11
            && data[8]=='W' && data[9]=='E' && data[10]=='B' && data[11]=='P') return ".webp";
        // text heuristic
        boolean isText = true;
        int check = Math.min(data.length, 512);
        for (int i = 0; i < check; i++) {
            int c = data[i] & 0xFF;
            if (c < 9 || (c > 13 && c < 32 && c != 27)) { isText = false; break; }
        }
        return isText ? ".txt" : ".bin";
    }

    // --------------------------------------------------------------------------
    // UTILITY � SERVERS LIST
    // --------------------------------------------------------------------------
    private List<String> loadServers() {
        List<String> list = new ArrayList<>();
        File f = new File(SERVERS_TXT);
        if (!f.exists()) { log("servers.txt not found."); return list; }
        try {
            for (String line : Files.readAllLines(f.toPath())) {
                line = line.trim();
                if (!line.isEmpty() && !line.startsWith("#"))
                    list.add(line.replaceAll("/$", ""));
            }
        } catch (IOException e) { log("Error reading servers.txt: " + e.getMessage()); }
        return list;
    }

    // --------------------------------------------------------------------------
    // UTILITY � LOG
    // --------------------------------------------------------------------------
    private void log(String msg) {
        String ts = new SimpleDateFormat("HH:mm:ss").format(new Date());
        SwingUtilities.invokeLater(() -> {
            logArea.append("[" + ts + "] " + msg + "\n");
            logArea.setCaretPosition(logArea.getDocument().getLength());
        });
    }

    // --------------------------------------------------------------------------
    // UTILITY � HTML / JSON ESCAPING
    // --------------------------------------------------------------------------
    private String escHtml(String s) {
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");
    }
    private String esc(String s) {
        return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n");
    }

    // --------------------------------------------------------------------------
    // PROGRESS BAR CELL RENDERER
    // --------------------------------------------------------------------------
    static class ProgressCellRenderer extends JProgressBar implements TableCellRenderer {
        ProgressCellRenderer() {
            super(0, 100);
            setStringPainted(true);
        }
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean selected, boolean focused, int row, int col) {
            int v = value instanceof Integer ? (Integer) value : 0;
            setValue(v);
            setString(v + "%");
            setForeground(v == 100 ? new Color(0, 160, 0) : new Color(30, 100, 200));
            return this;
        }
    }

    // --------------------------------------------------------------------------
    // MAIN
    // --------------------------------------------------------------------------
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}
        SwingUtilities.invokeLater(Base64Torrent::new);
    }
}