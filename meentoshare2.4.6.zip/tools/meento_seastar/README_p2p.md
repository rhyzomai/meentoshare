# P2P Chunk Downloader

A single-file PHP application that implements BitTorrent-like file transfer over HTTP GET. Files are split into Base64-encoded chunks, distributed across peer nodes, and reassembled on download — with optional public-key tagging and a blockchain-inspired transfer log.

---

## Features

- **Chunked file transfer** — files are split, Base64-encoded, and served piece by piece
- **Multi-peer downloads** — chunks are fetched from whichever peer has them, with retry logic
- **DHT-style peer discovery** — nodes share their peer lists so the network self-expands
- **Transfer blocks** — every chunk received is recorded as a JSON block (audit trail)
- **Peer notification** — all known peers are notified when a chunk is received
- **Public key tagging** — optional RSA/PEM public key attached to transfer blocks
- **Web UI** — tabbed dashboard for downloading, peer management, block history, seeding status, and node info
- **REST API** — JSON endpoints consumed by other nodes in the network

---

## Requirements

- PHP 7.4+ (no extensions beyond standard `file_get_contents`, `stream_context_create`)
- A web server (Apache, Nginx, etc.) with PHP enabled
- Write access to the directory where `p2p.php` lives

---

## Directory Structure

After first run, the script auto-creates these directories alongside `p2p.php`:

```
base64_chuncks/   # (reserved, currently unused by core logic)
base64/           # chunk files stored as  <file_md5>.<chunk_num>.<chunk_md5>
json_blocks/      # JSON transfer-block records
downloaded/       # fully assembled output files
```

Configuration files (created manually):

```
dht.txt           # one peer URL per line (auto-appended by discovery)
servers.txt       # static seed list of peer URLs (read-only)
pub.key.txt       # optional PEM public key attached to transfer blocks
```

---

## Installation

1. Copy `p2p.php` to your web root (or any web-accessible directory).
2. Ensure the directory is writable by the web server process.
3. *(Optional)* Create `servers.txt` with one trusted peer URL per line.
4. *(Optional)* Create `pub.key.txt` containing your PEM public key.
5. Open `https://your-server.com/p2p.php` in a browser.

---

## Configuration Constants

| Constant       | Default              | Description                                  |
|----------------|----------------------|----------------------------------------------|
| `DHT_FILE`     | `./dht.txt`          | Dynamic peer list (auto-updated)             |
| `SERVERS_FILE` | `./servers.txt`      | Static seed peer list                        |
| `CHUNKS_DIR`   | `./base64_chuncks`   | Reserved chunks directory                    |
| `BASE64_DIR`   | `./base64`           | Live chunk storage                           |
| `BLOCKS_DIR`   | `./json_blocks`      | Transfer block records                       |
| `PUBKEY_FILE`  | `./pub.key.txt`      | PEM public key for block signing             |
| `OUTPUT_DIR`   | `./downloaded`       | Assembled file output                        |
| `TIMEOUT`      | `10`                 | HTTP request timeout in seconds              |
| `MAX_RETRIES`  | `2`                  | Per-chunk download retry attempts            |

---

## REST API

All endpoints return `Content-Type: application/json`.

| Action        | URL                                              | Description                               |
|---------------|--------------------------------------------------|-------------------------------------------|
| `peers`       | `?action=peers`                                  | Returns this node's known peer list       |
| `file_info`   | `?action=file_info&file=<md5>`                   | Returns total chunk count for a file      |
| `list_chunks` | `?action=list_chunks&file=<md5>`                 | Returns available chunk numbers           |
| `get_chunk`   | `?action=get_chunk&file=<md5>&chunk=<n>`         | Returns a single chunk as JSON            |
| `notify`      | `?action=notify&block=<url-encoded-json>`        | Receives and stores a transfer block      |

### Example: fetch chunk 3 of a file

```
GET /p2p.php?action=get_chunk&file=d41d8cd98f00b204e9800998ecf8427e&chunk=3
```

```json
{
  "status": "ok",
  "file": "d41d8cd98f00b204e9800998ecf8427e",
  "chunk": 3,
  "chunk_hash": "5d41402abc4b2a76b9719d911017c592",
  "contents": "<base64-encoded data>"
}
```

Chunk integrity is verified by comparing `md5(contents)` against `chunk_hash`.

---

## Web UI Tabs

| Tab        | Purpose                                                        |
|------------|----------------------------------------------------------------|
| Download   | Enter a file MD5 hash to fetch and assemble it from peers      |
| DHT/Peers  | Add peer URLs manually or trigger auto-discovery               |
| Blocks     | View the 20 most recent transfer block records                 |
| Seeding    | See which file chunks this node is currently serving           |
| Node Info  | View node URL, PHP version, directory paths, and API reference |

---

## Seeding a File

To make a file available for others to download:

1. Split the file into chunks and Base64-encode each one.
2. Name each chunk file: `<file_md5>.<chunk_number>.<chunk_md5>`  
   Example: `d41d8cd98f00b204e9800998ecf8427e.1.5d41402abc4b2a76b9719d911017c592`
3. Place the chunk files in the `base64/` directory.
4. The node will start serving them immediately.

> The file hash used throughout must be the **MD5 of the full original file**. Chunk numbers start at **1**.

---

## Download Flow

When a download is triggered via the UI:

1. Known peers are loaded from `dht.txt` and `servers.txt`.
2. Auto-discovery runs — each peer is asked for its own peer list.
3. File info is queried to determine total chunk count.
4. Each chunk is downloaded sequentially, with up to `MAX_RETRIES` attempts per peer.
5. Each received chunk is saved locally (enabling this node to seed it) and recorded as a JSON block.
6. All peers are notified of each received chunk.
7. Once all chunks are collected, they are concatenated and Base64-decoded to produce the final binary file, saved to `downloaded/<file_md5>`.

---

## Security Notes

- There is **no authentication** on the API endpoints — any peer can query or notify this node.
- The public key in `pub.key.txt` is attached to blocks as metadata only; it is **not used for encryption or signature verification** in the current implementation.
- Run behind HTTPS and restrict access to trusted networks if deploying in a sensitive environment.
- Input is validated (MD5 format checks, URL validation) but the script should not be exposed to untrusted public internet without additional hardening.

---

## License

No license is specified. Treat as proprietary unless the author states otherwise.
