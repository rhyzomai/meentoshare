﻿<?php
// ============================================================
//  download.php — P2P File Downloader by MD5 Hash
//  Drop in the same directory as p2p.php.
//  No external dependencies. No modifications to p2p.php.
// ============================================================

define('SERVERS_FILE', __DIR__ . '/servers.txt');
define('DHT_FILE',     __DIR__ . '/dht.txt');
define('OUTPUT_DIR',   __DIR__ . '/downloaded');
define('TIMEOUT',      10);
define('MAX_RETRIES',  2);

if (!is_dir(OUTPUT_DIR)) mkdir(OUTPUT_DIR, 0755, true);

// ============================================================
//  Helpers
// ============================================================

function isValidMd5(string $v): bool {
    return (bool) preg_match('/^[a-f0-9]{32}$/i', $v);
}

function loadPeers(): array {
    $peers = [];
    foreach ([DHT_FILE, SERVERS_FILE] as $f) {
        if (!file_exists($f)) continue;
        foreach (file($f, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
            $url = rtrim(trim($line), '/');
            if ($url && filter_var($url, FILTER_VALIDATE_URL)) {
                $peers[] = $url;
            }
        }
    }
    return array_values(array_unique($peers));
}

function httpGet(string $url): array {
    $ctx  = stream_context_create(['http' => [
        'method'        => 'GET',
        'timeout'       => TIMEOUT,
        'ignore_errors' => true,
    ]]);
    $body = @file_get_contents($url, false, $ctx);
    $code = 0;
    if (!empty($http_response_header)) {
        if (preg_match('#HTTP/\S+\s+(\d+)#', $http_response_header[0], $m)) {
            $code = (int) $m[1];
        }
    }
    return ['code' => $code, 'body' => ($body !== false) ? $body : ''];
}

function discoverPeers(array $known): array {
    $found = [];
    foreach ($known as $peer) {
        $r = httpGet($peer . '/p2p.php?action=peers');
        if ($r['code'] === 200) {
            $list = @json_decode($r['body'], true);
            if (is_array($list)) {
                foreach ($list as $p) {
                    $p = rtrim(trim($p), '/');
                    if ($p && filter_var($p, FILTER_VALIDATE_URL)) $found[] = $p;
                }
            }
        }
    }
    return array_values(array_unique(array_merge($known, $found)));
}

function queryTotalChunks(array $peers, string $hash): int {
    foreach ($peers as $peer) {
        $r = httpGet($peer . '/p2p.php?action=file_info&file=' . $hash);
        if ($r['code'] === 200) {
            $d = @json_decode($r['body'], true);
            if (isset($d['total_chunks']) && $d['total_chunks'] > 0) return (int) $d['total_chunks'];
        }
        // fallback: list_chunks
        $r2 = httpGet($peer . '/p2p.php?action=list_chunks&file=' . $hash);
        if ($r2['code'] === 200) {
            $list = @json_decode($r2['body'], true);
            if (is_array($list) && count($list) > 0) return max($list);
        }
    }
    return 0;
}

function downloadAllChunks(array $peers, string $hash, int $total): array {
    $chunks = [];
    $failed = [];
    for ($i = 1; $i <= $total; $i++) {
        $got = false;
        foreach ($peers as $peer) {
            for ($try = 0; $try < MAX_RETRIES; $try++) {
                $r = httpGet($peer . '/p2p.php?action=get_chunk&file=' . $hash . '&chunk=' . $i);
                if ($r['code'] === 200 && $r['body'] !== '') {
                    $d = @json_decode($r['body'], true);
                    if (isset($d['contents'], $d['chunk_hash']) && md5($d['contents']) === $d['chunk_hash']) {
                        $chunks[$i] = $d['contents'];
                        $got = true;
                        break 2;
                    }
                }
            }
        }
        if (!$got) $failed[] = $i;
    }
    return ['chunks' => $chunks, 'failed' => $failed];
}

function formatBytes(int $b): string {
    if ($b >= 1048576) return round($b / 1048576, 2) . ' MB';
    if ($b >= 1024)    return round($b / 1024, 2) . ' KB';
    return $b . ' B';
}

// ============================================================
//  Handle POST — run the download
// ============================================================

$log      = [];
$error    = '';
$success  = false;
$outFile  = '';
$fileSize = 0;
$hash     = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $hash = strtolower(trim($_POST['hash'] ?? ''));

    if (!isValidMd5($hash)) {
        $error = 'Invalid MD5 hash. Must be 32 hexadecimal characters.';
    } else {
        // 1. Load peers
        $peers = loadPeers();
        if (empty($peers)) {
            $error = 'No peers found. Add peer URLs to servers.txt or dht.txt.';
        } else {
            $log[] = ['ok',   count($peers) . ' peer(s) loaded'];

            // 2. Discover more peers
            $peers = discoverPeers($peers);
            $log[] = ['info', count($peers) . ' peer(s) after discovery'];

            // 3. Query total chunks
            $total = queryTotalChunks($peers, $hash);
            if ($total === 0) {
                $error = 'File not found on any peer. Hash: ' . $hash;
                $log[] = ['err',  'No peer reported chunks for this hash'];
            } else {
                $log[] = ['ok',   "File found — {$total} chunk(s) to download"];

                // 4. Download all chunks
                $result = downloadAllChunks($peers, $hash, $total);

                foreach ($result['chunks'] as $n => $_) {
                    $log[] = ['ok', "Chunk {$n}/{$total} — OK"];
                }
                foreach ($result['failed'] as $n) {
                    $log[] = ['err', "Chunk {$n}/{$total} — FAILED"];
                }

                if (!empty($result['failed'])) {
                    $error = 'Download incomplete. Missing chunks: ' . implode(', ', $result['failed']);
                } else {
                    // 5. Assemble
                    ksort($result['chunks']);
                    $assembled = implode('', $result['chunks']);
                    $log[] = ['info', 'All chunks assembled'];

                    // 6. Base64 decode → binary
                    $binary = base64_decode($assembled, true);
                    if ($binary === false) {
                        $binary = $assembled;
                        $log[] = ['info', 'Content is not base64 — saved raw'];
                    } else {
                        $log[] = ['ok', 'Base64 decoded to binary'];
                    }

                    // 7. Save
                    $outFile  = OUTPUT_DIR . '/' . $hash . '.bin';
                    file_put_contents($outFile, $binary);
                    $fileSize = strlen($binary);
                    $log[]    = ['ok', 'Saved: ' . basename($outFile) . ' (' . formatBytes($fileSize) . ')'];
                    $success  = true;
                }
            }
        }
    }
}

// ============================================================
//  List already downloaded files
// ============================================================
$downloaded = glob(OUTPUT_DIR . '/*.bin') ?: [];
usort($downloaded, fn($a, $b) => filemtime($b) - filemtime($a));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>P2P Downloader</title>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }

body {
    font-family: monospace;
    font-size: 13px;
    background: #111;
    color: #ccc;
    padding: 40px 20px 60px;
}

.wrap { max-width: 640px; margin: 0 auto; }

h1 {
    font-size: 16px;
    font-weight: normal;
    color: #fff;
    margin-bottom: 4px;
    letter-spacing: .04em;
}
.sub {
    color: #555;
    font-size: 12px;
    margin-bottom: 32px;
}
.sub a { color: #555; text-decoration: none; }
.sub a:hover { color: #aaa; }

/* form */
label { display: block; color: #666; font-size: 11px; margin-bottom: 6px; }

input[type=text] {
    width: 100%;
    background: #1a1a1a;
    border: 1px solid #2a2a2a;
    border-radius: 3px;
    color: #e0e0e0;
    font-family: monospace;
    font-size: 14px;
    padding: 10px 12px;
    outline: none;
    transition: border-color .15s;
    letter-spacing: .06em;
}
input[type=text]:focus { border-color: #444; }
input[type=text]::placeholder { color: #333; }

button {
    margin-top: 10px;
    background: #e0e0e0;
    color: #111;
    border: none;
    border-radius: 3px;
    font-family: monospace;
    font-size: 12px;
    font-weight: bold;
    padding: 8px 18px;
    cursor: pointer;
    letter-spacing: .04em;
    transition: background .15s;
}
button:hover { background: #fff; }
button:active { background: #bbb; }

/* messages */
.msg {
    margin-top: 20px;
    padding: 10px 14px;
    border-radius: 3px;
    font-size: 12px;
    border-left: 3px solid;
}
.msg.ok  { background: #0f1f16; border-color: #2a6; color: #3d9; }
.msg.err { background: #1f0f0f; border-color: #622; color: #d44; }

/* log */
.log {
    margin-top: 20px;
    background: #0d0d0d;
    border: 1px solid #1e1e1e;
    border-radius: 3px;
    padding: 12px 14px;
    max-height: 240px;
    overflow-y: auto;
    line-height: 1.8;
}
.log .ok   { color: #2a6; }
.log .err  { color: #d44; }
.log .info { color: #555; }

/* result box */
.result-box {
    margin-top: 20px;
    background: #0d0d0d;
    border: 1px solid #2a6;
    border-radius: 3px;
    padding: 14px 16px;
}
.result-box .rl { color: #555; font-size: 11px; margin-bottom: 4px; }
.result-box .rv { color: #3d9; font-size: 13px; word-break: break-all; }
.result-box .rm { color: #444; font-size: 11px; margin-top: 6px; }

/* section divider */
.sect {
    color: #333;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: .1em;
    border-top: 1px solid #1e1e1e;
    padding-top: 24px;
    margin-top: 32px;
    margin-bottom: 12px;
}

/* downloaded table */
table { width: 100%; border-collapse: collapse; font-size: 12px; }
td, th { padding: 7px 0; border-bottom: 1px solid #1a1a1a; text-align: left; }
th { color: #444; font-size: 10px; text-transform: uppercase; letter-spacing: .08em; font-weight: normal; }
td:last-child { text-align: right; }
tr:last-child td { border-bottom: none; }

a.dl { color: #3d9; text-decoration: none; font-size: 11px; }
a.dl:hover { text-decoration: underline; }
a.back { color: #555; text-decoration: none; font-size: 11px; }
a.back:hover { color: #aaa; }

/* scrollbar */
::-webkit-scrollbar { width: 4px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: #222; border-radius: 2px; }
</style>
</head>
<body>
<div class="wrap">

  <h1>P2P Downloader</h1>
  <p class="sub">
    Enter an MD5 hash — chunks will be fetched from all known peers, assembled, and saved as a binary file.
    &nbsp;·&nbsp; <a href="p2p.php">p2p.php</a>
  </p>

  <form method="POST">
    <label for="hash">MD5 File Hash</label>
    <input
      type="text"
      id="hash"
      name="hash"
      maxlength="32"
      autocomplete="off"
      spellcheck="false"
      placeholder="d41d8cd98f00b204e9800998ecf8427e"
      value="<?= htmlspecialchars($hash) ?>"
    >
    <button type="submit">Download</button>
  </form>

  <?php if ($error): ?>
  <div class="msg err"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <?php if (!empty($log)): ?>
  <div class="log">
    <?php foreach ($log as [$type, $msg]): ?>
    <div class="<?= $type ?>"><?= htmlspecialchars($msg) ?></div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <?php if ($success): ?>
  <div class="result-box">
    <div class="rl">Saved to</div>
    <div class="rv"><?= htmlspecialchars(basename($outFile)) ?></div>
    <div class="rm"><?= formatBytes($fileSize) ?> &nbsp;·&nbsp; <?= htmlspecialchars(OUTPUT_DIR) ?></div>
  </div>
  <?php endif; ?>

  <?php if (!empty($downloaded)): ?>
  <div class="sect">Downloaded Files</div>
  <table>
    <tr>
      <th>Filename</th>
      <th>Size</th>
      <th>Date</th>
      <th></th>
    </tr>
    <?php foreach ($downloaded as $f): ?>
    <tr>
      <td><?= htmlspecialchars(basename($f)) ?></td>
      <td><?= formatBytes(filesize($f)) ?></td>
      <td><?= date('Y-m-d H:i', filemtime($f)) ?></td>
      <td>
        <a class="dl" href="<?= htmlspecialchars('downloaded/' . basename($f)) ?>" download>download</a>
      </td>
    </tr>
    <?php endforeach; ?>
  </table>
  <?php endif; ?>

</div>
</body>
</html>