﻿<?php
// ============================================================
//  fetch.php — P2P Chunk Downloader
//  - Reads servers from servers.txt
//  - Reads chunk list from hash_chunks/<hash>.txt
//  - Downloads each chunk from servers at /chunks/<filename>
//  - Assembles, base64-decodes, infers file extension
//  - Falls back to direct download if no chunk list / single entry
// ============================================================

define('SERVERS_FILE',   __DIR__ . '/servers.txt');
define('HASH_CHUNK_DIR', __DIR__ . '/hash_chunks');
define('LOCAL_CHUNK_DIR',__DIR__ . '/chunks');
define('DOWNLOADED_DIR', __DIR__ . '/downloaded');
define('TIMEOUT',        12);
define('MAX_RETRIES',    2);

foreach ([LOCAL_CHUNK_DIR, HASH_CHUNK_DIR, DOWNLOADED_DIR] as $d) {
    if (!is_dir($d)) mkdir($d, 0755, true);
}

// ============================================================
//  Utilities
// ============================================================

function isValidMd5(string $v): bool {
    return (bool) preg_match('/^[a-f0-9]{32}$/i', $v);
}

function formatBytes(int $b): string {
    if ($b >= 1048576) return round($b / 1048576, 2) . ' MB';
    if ($b >= 1024)    return round($b / 1024, 2) . ' KB';
    return $b . ' B';
}

function loadServers(): array {
    if (!file_exists(SERVERS_FILE)) return [];
    $out = [];
    foreach (file(SERVERS_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $l) {
        $u = rtrim(trim($l), '/');
        if ($u && filter_var($u, FILTER_VALIDATE_URL)) $out[] = $u;
    }
    return array_values(array_unique($out));
}

function httpFetch(string $url): ?string {
    $ctx  = stream_context_create(['http' => [
        'method'        => 'GET',
        'timeout'       => TIMEOUT,
        'ignore_errors' => true,
        'header'        => "User-Agent: P2P-Fetcher/1.0\r\n",
    ]]);
    $body = @file_get_contents($url, false, $ctx);
    if ($body === false || empty($http_response_header)) return null;
    if (!preg_match('#HTTP/\S+\s+200#', $http_response_header[0])) return null;
    return $body;
}

// ── Infer file extension from binary magic bytes ──────────────
function inferExtension(string $bin): string {
    $h = substr($bin, 0, 16);

    if (str_starts_with($h, "\xFF\xD8\xFF"))                                   return 'jpg';
    if (str_starts_with($h, "\x89PNG\r\n\x1A\n"))                              return 'png';
    if (str_starts_with($h, 'GIF87a') || str_starts_with($h, 'GIF89a'))       return 'gif';
    if (str_starts_with($h, 'RIFF') && substr($bin,8,4)==='WEBP')              return 'webp';
    if (str_starts_with($h, 'BM'))                                              return 'bmp';
    if (str_starts_with($h, "\x00\x00\x01\x00"))                               return 'ico';
    if (str_starts_with($h, "\x1A\x45\xDF\xA3"))                               return 'mkv';
    if (str_starts_with($h, 'RIFF') && substr($bin,8,4)==='AVI ')              return 'avi';
    if (str_starts_with($h, 'FLV'))                                             return 'flv';
    if (str_starts_with($h, "\x00\x00\x00") && in_array(substr($h,4,4),['ftyp','moov','mdat'])) return 'mp4';
    if (str_starts_with($h, "\x00\x00\x00\x1C\x66\x74\x79\x70"))              return 'mp4';
    if (str_starts_with($h, 'ID3') || (strlen($h)>1 && ord($h[0])===0xFF && (ord($h[1])&0xE0)===0xE0)) return 'mp3';
    if (str_starts_with($h, 'RIFF') && substr($bin,8,4)==='WAVE')              return 'wav';
    if (str_starts_with($h, 'fLaC'))                                            return 'flac';
    if (str_starts_with($h, 'OggS'))                                            return 'ogg';
    if (str_starts_with($h, '%PDF'))                                            return 'pdf';
    if (str_starts_with($h, 'PK'))                                              return 'zip';
    if (str_starts_with($h, "\xD0\xCF\x11\xE0"))                               return 'doc';
    if (str_starts_with($h, "\x1F\x8B"))                                        return 'gz';
    if (str_starts_with($h, 'BZh'))                                             return 'bz2';
    if (str_starts_with($h, "\xFD\x37\x7A\x58\x5A\x00"))                      return 'xz';
    if (str_starts_with($h, "7z\xBC\xAF'\x1C"))                                return '7z';
    if (str_starts_with($h, 'Rar!'))                                            return 'rar';
    if (str_starts_with($h, "\x7FELF"))                                         return 'elf';
    if (str_starts_with($h, 'MZ'))                                              return 'exe';
    if (str_starts_with($h, "SQLite"))                                          return 'sqlite';
    if (str_starts_with($h, "\xCA\xFE\xBA\xBE"))                               return 'class';

    // Text-based detection
    $sample = substr($bin, 0, 512);
    if (mb_detect_encoding($sample, 'UTF-8', true) !== false) {
        $t = ltrim($sample);
        if (str_starts_with($t, '<?php'))                return 'php';
        if (str_starts_with($t, '<?xml'))                return 'xml';
        if (str_starts_with($t, '<!DOCTYPE') || str_starts_with($t, '<html')) return 'html';
        if (str_starts_with($t, '{') || str_starts_with($t, '['))             return 'json';
        return 'txt';
    }
    return 'bin';
}

// ── Read chunk-hash index ─────────────────────────────────────
function readChunkIndex(string $hash): array {
    $path = HASH_CHUNK_DIR . '/' . $hash . '.txt';
    if (!file_exists($path)) return [];
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    return array_values(array_filter(array_map('trim', $lines), 'isValidMd5'));
}

// ── Find whole file already on disk ───────────────────────────
function findLocalFile(string $hash): ?string {
    foreach ([DOWNLOADED_DIR, LOCAL_CHUNK_DIR] as $dir) {
        foreach (glob($dir . '/' . $hash . '*') ?: [] as $f) {
            if (is_file($f)) return $f;
        }
    }
    return null;
}

// ── Fetch one chunk: local cache first, then each server ──────
// Filename convention: <fileHash>.<lineNum>.<chunkHash>
function fetchChunk(string $fileHash, int $lineNum, string $chunkHash, array $servers): array {
    $filename  = $fileHash . '.' . $lineNum . '.' . $chunkHash;
    $localPath = LOCAL_CHUNK_DIR . '/' . $filename;

    if (file_exists($localPath)) {
        $d = file_get_contents($localPath);
        if ($d !== false && md5($d) === $chunkHash)
            return ['ok' => true, 'data' => $d, 'src' => 'local'];
    }

    foreach ($servers as $server) {
        for ($t = 0; $t < MAX_RETRIES; $t++) {
            $body = httpFetch(rtrim($server, '/') . '/chunks/' . $filename);
            if ($body !== null && md5($body) === $chunkHash) {
                file_put_contents($localPath, $body);
                return ['ok' => true, 'data' => $body, 'src' => $server];
            }
        }
    }
    return ['ok' => false, 'data' => '', 'src' => ''];
}

// ── Try direct whole-file download from servers ───────────────
function fetchDirect(string $hash, array $servers): ?string {
    foreach ($servers as $server) {
        for ($t = 0; $t < MAX_RETRIES; $t++) {
            $body = httpFetch(rtrim($server, '/') . '/chunks/' . $hash);
            if ($body !== null) return $body;
        }
    }
    return null;
}

// ============================================================
//  Serve downloaded file to browser
// ============================================================
if (isset($_GET['serve'])) {
    $h = preg_replace('/[^a-f0-9]/i', '', $_GET['serve'] ?? '');
    if (!isValidMd5($h)) { http_response_code(400); exit('Bad hash'); }
    foreach (glob(DOWNLOADED_DIR . '/' . $h . '*') ?: [] as $f) {
        if (is_file($f)) {
            $ext = pathinfo($f, PATHINFO_EXTENSION) ?: 'bin';
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . $h . '.' . $ext . '"');
            header('Content-Length: ' . filesize($f));
            readfile($f);
            exit;
        }
    }
    http_response_code(404); exit('Not found');
}

// ============================================================
//  Main
// ============================================================
$log     = [];
$error   = '';
$success = false;
$outPath = '';
$outExt  = '';
$outSize = 0;
$hash    = '';
$tab     = $_POST['tab'] ?? $_GET['tab'] ?? 'download';

$history = [];
foreach (glob(DOWNLOADED_DIR . '/*') ?: [] as $f) {
    if (is_file($f))
        $history[] = ['path'=>$f,'name'=>basename($f),'size'=>filesize($f),'mtime'=>filemtime($f)];
}
usort($history, fn($a,$b) => $b['mtime'] - $a['mtime']);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['do_fetch'])) {
    $tab  = 'download';
    $hash = strtolower(trim($_POST['file_hash'] ?? ''));

    if (!isValidMd5($hash)) {
        $error = 'Invalid MD5 hash — must be exactly 32 hex characters.';
    } else {
        $servers = loadServers();
        $log[]   = empty($servers)
            ? ['info', 'No servers in servers.txt — local cache only']
            : ['info', count($servers) . ' server(s) loaded from servers.txt'];

        $binary = null;
        $method = '';

        // ── Step 1: already on disk ───────────────────────────
        $local = findLocalFile($hash);
        if ($local !== null) {
            $log[]  = ['ok', 'Found locally: ' . basename($local) . ' — no download needed'];
            $binary = file_get_contents($local);
            $method = 'local';
        }

        // ── Step 2: chunk index ───────────────────────────────
        if ($binary === null) {
            $chunks = readChunkIndex($hash);

            if (count($chunks) > 1) {
                $log[]     = ['info', 'Chunk index loaded — ' . count($chunks) . ' piece(s)'];
                $assembled = '';
                $failed    = [];

                foreach ($chunks as $idx => $chunkHash) {
                    $n      = $idx + 1;
                    $result = fetchChunk($hash, $n, $chunkHash, $servers);
                    if ($result['ok']) {
                        $assembled .= $result['data'];
                        $src = $result['src'] === 'local'
                            ? 'local cache'
                            : (parse_url($result['src'], PHP_URL_HOST) ?: $result['src']);
                        $log[] = ['ok', "Chunk {$n}/" . count($chunks) . " [{$chunkHash}] — OK ({$src})"];
                    } else {
                        $failed[] = $n;
                        $log[]    = ['error', "Chunk {$n}/" . count($chunks) . " [{$chunkHash}] — NOT FOUND"];
                    }
                }

                if (!empty($failed)) {
                    $error = 'Incomplete — missing chunk(s): ' . implode(', ', $failed);
                } else {
                    $dec    = base64_decode($assembled, true);
                    $binary = ($dec !== false) ? $dec : $assembled;
                    $method = 'chunked';
                    $log[]  = ['ok', 'All chunks assembled and decoded'];
                }

            } else {
                // ── Step 3: no index or single-entry → direct download ──
                $reason = count($chunks) === 1
                    ? 'Single entry in chunk index'
                    : 'No chunk index found';
                $log[] = ['info', $reason . ' — trying direct download'];

                $raw = fetchDirect($hash, $servers);
                if ($raw !== null) {
                    $dec    = base64_decode($raw, true);
                    $binary = ($dec !== false) ? $dec : $raw;
                    $method = 'direct';
                    $log[]  = ['ok', 'Downloaded directly from server'];
                } else {
                    $error = 'File not found on any server and no local data available.';
                }
            }
        }

        // ── Step 4: infer extension and save ─────────────────
        if ($binary !== null && $error === '') {
            $outExt  = inferExtension($binary);
            $outPath = DOWNLOADED_DIR . '/' . $hash . '.' . $outExt;
            file_put_contents($outPath, $binary);
            $outSize = strlen($binary);
            $log[]   = ['ok', "Saved: {$hash}.{$outExt} (" . formatBytes($outSize) . ") via {$method}"];
            $success = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>P2P Fetch</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=Space+Grotesk:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
  :root {
    --bg:       #0d0f14;
    --surface:  #13161e;
    --border:   #1e2330;
    --accent:   #00e5a0;
    --accent2:  #0077ff;
    --yellow:   #f5c400;
    --red:      #ff3f5b;
    --text:     #d4dae8;
    --muted:    #5a6380;
    --mono:     'IBM Plex Mono', monospace;
    --sans:     'Space Grotesk', sans-serif;
    --radius:   6px;
  }

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: var(--sans);
    font-size: 14px;
    min-height: 100vh;
    padding: 0 0 60px;
  }

  .header {
    border-bottom: 1px solid var(--border);
    padding: 18px 32px;
    display: flex;
    align-items: center;
    gap: 16px;
    background: var(--surface);
  }
  .header-logo {
    width: 36px; height: 36px;
    background: var(--accent2);
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
  }
  .header-logo svg { width: 20px; height: 20px; }
  .header-title { font-size: 17px; font-weight: 600; letter-spacing: -.3px; }
  .header-sub   { font-size: 12px; color: var(--muted); font-family: var(--mono); margin-top: 1px; }
  .header-link  {
    margin-left: auto;
    font-family: var(--mono);
    font-size: 12px;
    color: var(--accent2);
    text-decoration: none;
    border: 1px solid var(--accent2);
    padding: 4px 10px;
    border-radius: var(--radius);
    transition: background .15s;
  }
  .header-link:hover { background: rgba(0,119,255,.12); }

  .container { max-width: 860px; margin: 0 auto; padding: 32px 24px 0; }

  nav {
    display: flex;
    gap: 4px;
    margin-bottom: 24px;
    border-bottom: 1px solid var(--border);
    padding-bottom: 0;
  }
  nav button {
    background: none;
    border: none;
    border-bottom: 2px solid transparent;
    color: var(--muted);
    font-family: var(--sans);
    font-size: 13px;
    font-weight: 500;
    padding: 8px 16px;
    cursor: pointer;
    margin-bottom: -1px;
    transition: color .15s, border-color .15s;
  }
  nav button.active { color: var(--accent); border-bottom-color: var(--accent); }
  nav button:hover:not(.active) { color: var(--text); }

  .tab { display: none; }
  .tab.active { display: block; }

  .card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 22px 24px;
    margin-bottom: 16px;
  }
  .card-title {
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: .1em;
    color: var(--muted);
    margin-bottom: 18px;
  }

  .field { margin-bottom: 16px; }
  label  { display: block; font-size: 12px; color: var(--muted); margin-bottom: 6px; font-family: var(--mono); }

  input[type=text] {
    width: 100%;
    background: #080a10;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    color: var(--text);
    font-family: var(--mono);
    font-size: 15px;
    padding: 11px 14px;
    outline: none;
    letter-spacing: .06em;
    transition: border-color .15s;
  }
  input[type=text]:focus { border-color: var(--accent2); }
  input[type=text]::placeholder { color: var(--muted); font-size: 13px; letter-spacing: .03em; }

  button[type=submit], .btn {
    background: var(--accent);
    color: #0d0f14;
    border: none;
    border-radius: var(--radius);
    font-family: var(--sans);
    font-weight: 600;
    font-size: 13px;
    padding: 9px 20px;
    cursor: pointer;
    transition: opacity .15s, transform .1s;
    white-space: nowrap;
  }
  button[type=submit]:hover, .btn:hover { opacity: .88; }
  button[type=submit]:active { transform: scale(.97); }

  .banner {
    padding: 12px 18px;
    border-radius: var(--radius);
    margin-bottom: 20px;
    font-size: 13px;
    font-family: var(--mono);
    border-left: 3px solid;
  }
  .banner.ok    { background: rgba(0,229,160,.08); border-color: var(--accent);  color: var(--accent); }
  .banner.error { background: rgba(255,63,91,.08);  border-color: var(--red);     color: var(--red); }
  .banner.info  { background: rgba(0,119,255,.08);  border-color: var(--accent2); color: var(--accent2); }

  .result-box {
    background: #080a10;
    border: 1px solid var(--accent);
    border-radius: var(--radius);
    padding: 18px 20px;
    margin-top: 16px;
    display: flex;
    align-items: flex-start;
    gap: 20px;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  .result-box .rl { font-size: 11px; color: var(--muted); font-family: var(--mono); margin-bottom: 6px; }
  .result-box .rv { font-family: var(--mono); font-size: 16px; color: var(--accent); word-break: break-all; }
  .result-box .rm { font-family: var(--mono); font-size: 11px; color: var(--muted); margin-top: 6px; }
  .result-box .dl-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: var(--accent2);
    color: #fff;
    font-family: var(--mono);
    font-size: 12px;
    font-weight: 600;
    padding: 9px 18px;
    border-radius: var(--radius);
    text-decoration: none;
    white-space: nowrap;
    transition: opacity .15s;
    align-self: center;
  }
  .result-box .dl-btn:hover { opacity: .85; }

  .log-box {
    background: #080a10;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 14px 16px;
    max-height: 280px;
    overflow-y: auto;
    font-family: var(--mono);
    font-size: 12px;
    line-height: 1.7;
  }
  .log-line        { padding: 1px 0; }
  .log-line.ok     { color: var(--accent); }
  .log-line.ok::before    { content: '✓  '; }
  .log-line.error  { color: var(--red); }
  .log-line.error::before { content: '✗  '; }
  .log-line.info   { color: var(--accent2); }
  .log-line.info::before  { content: '→  '; }

  .stat-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 12px;
    margin-bottom: 20px;
  }
  .stat-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 16px;
    text-align: center;
  }
  .stat-val   { font-size: 26px; font-weight: 600; font-family: var(--mono); color: var(--accent); }
  .stat-label { font-size: 11px; color: var(--muted); margin-top: 4px; text-transform: uppercase; letter-spacing: .08em; }

  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th {
    text-align: left; font-size: 11px; font-weight: 600; color: var(--muted);
    text-transform: uppercase; letter-spacing: .08em; padding: 0 12px 10px;
    border-bottom: 1px solid var(--border);
  }
  td { padding: 10px 12px; border-bottom: 1px solid var(--border); vertical-align: middle; }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: rgba(255,255,255,.02); }
  .mono { font-family: var(--mono); font-size: 12px; }

  .tag {
    display: inline-block; font-family: var(--mono); font-size: 10px; font-weight: 600;
    padding: 2px 7px; border-radius: 3px; text-transform: uppercase; letter-spacing: .06em;
  }
  .tag.green  { background: rgba(0,229,160,.15); color: var(--accent);  border: 1px solid rgba(0,229,160,.3); }
  .tag.blue   { background: rgba(0,119,255,.15); color: var(--accent2); border: 1px solid rgba(0,119,255,.3); }
  .tag.yellow { background: rgba(245,196,0,.12); color: var(--yellow);  border: 1px solid rgba(245,196,0,.3); }
  .tag.red    { background: rgba(255,63,91,.12); color: var(--red);     border: 1px solid rgba(255,63,91,.3); }

  a.dl-link {
    color: var(--accent2); font-family: var(--mono); font-size: 11px; text-decoration: none;
    border: 1px solid var(--accent2); padding: 3px 9px; border-radius: var(--radius);
    transition: background .15s;
  }
  a.dl-link:hover { background: rgba(0,119,255,.12); }

  .steps { display: flex; flex-direction: column; gap: 14px; }
  .step  { display: flex; gap: 14px; }
  .step-n {
    width: 24px; height: 24px; border-radius: 50%; background: var(--accent2); color: #fff;
    font-size: 11px; font-weight: 700; display: flex; align-items: center; justify-content: center;
    flex-shrink: 0; margin-top: 2px;
  }
  .step-body { font-size: 13px; line-height: 1.75; }
  .step-body strong { color: var(--accent2); }
  code {
    background: #080a10; border: 1px solid var(--border); border-radius: 3px;
    padding: 1px 5px; font-family: var(--mono); font-size: 11px; color: var(--accent);
  }

  ::-webkit-scrollbar { width: 6px; height: 6px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }
</style>
</head>
<body>

<div class="header">
  <div class="header-logo">
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 2L2 7l10 5 10-5-10-5z" stroke="#fff" stroke-width="2" stroke-linejoin="round"/>
      <path d="M2 17l10 5 10-5" stroke="#fff" stroke-width="2" stroke-linecap="round"/>
      <path d="M2 12l10 5 10-5" stroke="#fff" stroke-width="2" stroke-linecap="round"/>
    </svg>
  </div>
  <div>
    <div class="header-title">P2P Fetch</div>
    <div class="header-sub">chunks · assemble · decode · infer</div>
  </div>
  <a href="seeder.php" class="header-link">← Seeder</a>
</div>

<div class="container">

  <?php if ($error): ?>
  <div class="banner error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <nav>
    <button onclick="switchTab('download',this)" class="<?= $tab==='download'?'active':'' ?>">Fetch File</button>
    <button onclick="switchTab('history', this)" class="<?= $tab==='history' ?'active':'' ?>">History (<?= count($history) ?>)</button>
    <button onclick="switchTab('howto',   this)" class="<?= $tab==='howto'   ?'active':'' ?>">How It Works</button>
  </nav>

  <!-- ══════════════════════════════════════════════════════
       FETCH TAB
  ══════════════════════════════════════════════════════ -->
  <div id="tab-download" class="tab <?= $tab==='download'?'active':'' ?>">
    <div class="card">
      <div class="card-title">Fetch File by MD5 Hash</div>
      <form method="POST">
        <input type="hidden" name="tab" value="download">
        <div class="field">
          <label for="file_hash">MD5 File Hash</label>
          <input
            type="text" id="file_hash" name="file_hash"
            maxlength="32" autocomplete="off" spellcheck="false"
            placeholder="dd1b96f27453cca646d161e9408d0877"
            value="<?= htmlspecialchars($hash) ?>"
          >
        </div>
        <button type="submit" name="do_fetch">⬇ Fetch</button>
      </form>

      <?php if ($success): ?>
      <div class="result-box">
        <div>
          <div class="rl">File ready</div>
          <div class="rv"><?= htmlspecialchars(basename($outPath)) ?></div>
          <div class="rm">
            <?= formatBytes($outSize) ?>
            &nbsp;·&nbsp; <span style="color:var(--accent)">.<?= htmlspecialchars($outExt) ?></span>
            &nbsp;·&nbsp; <?= htmlspecialchars(DOWNLOADED_DIR) ?>
          </div>
        </div>
        <a class="dl-btn" href="?serve=<?= urlencode($hash) ?>">⬇ Save File</a>
      </div>
      <?php endif; ?>
    </div>

    <?php if (!empty($log)): ?>
    <div class="card">
      <div class="card-title">Transfer Log</div>
      <div class="log-box" id="logBox">
        <?php foreach ($log as [$type, $msg]): ?>
        <div class="log-line <?= htmlspecialchars($type) ?>"><?= htmlspecialchars($msg) ?></div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <!-- ══════════════════════════════════════════════════════
       HISTORY TAB
  ══════════════════════════════════════════════════════ -->
  <div id="tab-history" class="tab <?= $tab==='history'?'active':'' ?>">
    <div class="stat-grid">
      <div class="stat-card">
        <div class="stat-val"><?= count($history) ?></div>
        <div class="stat-label">Files</div>
      </div>
      <div class="stat-card">
        <div class="stat-val"><?= formatBytes(array_sum(array_column($history,'size'))) ?></div>
        <div class="stat-label">Total Size</div>
      </div>
    </div>

    <?php if (empty($history)): ?>
    <div class="card">
      <p style="color:var(--muted);font-family:var(--mono);font-size:13px;">No files downloaded yet.</p>
    </div>
    <?php else: ?>
    <div class="card">
      <div class="card-title">Downloaded Files</div>
      <table>
        <tr><th>Filename</th><th>Type</th><th>Size</th><th>Date</th><th></th></tr>
        <?php foreach ($history as $f):
          $ext    = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
          $imgExts   = ['jpg','jpeg','png','gif','webp','bmp','ico'];
          $vidExts   = ['mp4','mkv','avi','flv','mov','wmv'];
          $audioExts = ['mp3','wav','flac','ogg','aac','m4a'];
          $docExts   = ['pdf','doc','docx','xls','xlsx','ppt','pptx'];
          $tagCls = 'green';
          if (in_array($ext, $vidExts))   $tagCls = 'yellow';
          elseif (in_array($ext, $audioExts)) $tagCls = 'blue';
          elseif (in_array($ext, $docExts))   $tagCls = 'red';
          $baseHash = preg_replace('/\.[^.]+$/', '', $f['name']);
        ?>
        <tr>
          <td class="mono" style="max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
            <?= htmlspecialchars($f['name']) ?></td>
          <td><?php if ($ext): ?><span class="tag <?= $tagCls ?>">.<?= htmlspecialchars($ext) ?></span><?php endif; ?></td>
          <td class="mono"><?= formatBytes($f['size']) ?></td>
          <td class="mono" style="color:var(--muted)"><?= date('Y-m-d H:i', $f['mtime']) ?></td>
          <td><?php if (isValidMd5($baseHash)): ?>
            <a class="dl-link" href="?serve=<?= urlencode($baseHash) ?>">⬇ Download</a>
          <?php endif; ?></td>
        </tr>
        <?php endforeach; ?>
      </table>
    </div>
    <?php endif; ?>
  </div>

  <!-- ══════════════════════════════════════════════════════
       HOW IT WORKS TAB
  ══════════════════════════════════════════════════════ -->
  <div id="tab-howto" class="tab <?= $tab==='howto'?'active':'' ?>">
    <div class="card">
      <div class="card-title">Fetch Logic — Step by Step</div>
      <div class="steps">
        <div class="step"><div class="step-n">1</div><div class="step-body">
          <strong>Local check</strong> — Scans <code>downloaded/</code> and <code>chunks/</code>
          for any file starting with the hash. If found, serves it immediately — zero network calls.
        </div></div>
        <div class="step"><div class="step-n">2</div><div class="step-body">
          <strong>Chunk index</strong> — Opens <code>hash_chunks/&lt;hash&gt;.txt</code>.
          Each line is the MD5 hash of one chunk, in assembly order.
          If the file is missing or has only one entry, falls through to direct download.
        </div></div>
        <div class="step"><div class="step-n">3</div><div class="step-body">
          <strong>Chunk fetch</strong> — For each line, builds the chunk filename:
          <code>&lt;fileHash&gt;.&lt;lineNumber&gt;.&lt;chunkHash&gt;</code>
          and requests it from each server at <code>&lt;server&gt;/chunks/&lt;filename&gt;</code>.
          MD5 of the received data is verified against the chunk hash. Cached locally in <code>chunks/</code>.
        </div></div>
        <div class="step"><div class="step-n">4</div><div class="step-body">
          <strong>Direct download fallback</strong> — If no chunk index (or single entry),
          fetches <code>&lt;server&gt;/chunks/&lt;hash&gt;</code> directly from each server.
        </div></div>
        <div class="step"><div class="step-n">5</div><div class="step-body">
          <strong>Assemble &amp; decode</strong> — Concatenates all Base64 chunks in line order,
          then decodes the full string to binary. If base64_decode fails, raw content is saved.
        </div></div>
        <div class="step"><div class="step-n">6</div><div class="step-body">
          <strong>Extension inference</strong> — Inspects the first 16 bytes for magic signatures:
          JPEG <code>FF D8 FF</code>, PNG <code>89 50 4E 47</code>, ZIP/DOCX <code>50 4B</code>,
          PDF <code>25 50 44 46</code>, MP3 <code>49 44 33</code>, MKV <code>1A 45 DF A3</code>, etc.
          Falls back to UTF-8 text detection (<code>.json</code>, <code>.html</code>, <code>.php</code>, <code>.txt</code>)
          and finally <code>.bin</code> for unknown binary.
        </div></div>
      </div>
    </div>
    <div class="card">
      <div class="card-title">Expected Directory Layout</div>
      <div class="log-box" style="max-height:none;">
        <div class="log-line info">servers.txt                              ← one server base URL per line</div>
        <div class="log-line info">hash_chunks/                             ← chunk-hash index (written by seeder)</div>
        <div class="log-line info">  &lt;fileHash&gt;.txt                       ← one MD5 chunkHash per line</div>
        <div class="log-line ok">chunks/                                  ← local chunk cache</div>
        <div class="log-line ok">  &lt;fileHash&gt;.&lt;n&gt;.&lt;chunkHash&gt;         ← individual chunk (base64)</div>
        <div class="log-line" style="color:var(--accent)">downloaded/                              ← assembled output</div>
        <div class="log-line" style="color:var(--accent)">  &lt;fileHash&gt;.&lt;inferred_ext&gt;           ← complete binary file</div>
        <br>
        <div class="log-line" style="color:var(--muted)">Remote servers expose:</div>
        <div class="log-line" style="color:var(--muted)">  &lt;server&gt;/chunks/&lt;fileHash&gt;.&lt;n&gt;.&lt;chunkHash&gt;</div>
      </div>
    </div>
  </div>

</div>

<script>
function switchTab(name, btn) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('nav button').forEach(b => b.classList.remove('active'));
  document.getElementById('tab-' + name).classList.add('active');
  btn.classList.add('active');
}
const lb = document.getElementById('logBox');
if (lb) lb.scrollTop = lb.scrollHeight;
</script>
</body>
</html>