﻿<?php
/**
 * Base64Torrent – PHP/HTML/JS single-file edition
 * BitTorrent-like file sharing over HTTP GET using Base64 chunks.
 *
 * Directory layout (relative to this file):
 *   files/    original binary files
 *   base64/   full Base64-encoded copies (.b64)
 *   chunks/   chunk files  → <md5full>.<n>.<md5chunk>
 *   hash64/   index files  → <md5full>.txt  (one chunk-hash per line)
 *   json64/   blockchain-style transfer log (.json)
 *
 * Drop this file in a PHP-enabled web root and open it in a browser.
 * No external libraries required.
 */

// ─────────────────────────────────────────────────────────────────────────────
// CONSTANTS
// ─────────────────────────────────────────────────────────────────────────────
define('DIR_FILES',   __DIR__ . '/files');
define('DIR_BASE64',  __DIR__ . '/base64');
define('DIR_CHUNKS',  __DIR__ . '/chunks');
define('DIR_HASH64',  __DIR__ . '/hash64');
define('DIR_JSON64',  __DIR__ . '/json64');
define('SERVERS_TXT', __DIR__ . '/servers.txt');
define('PUBKEY_FILE', __DIR__ . '/pub.key');
define('MAX_PUBKEY',  500 * 1024);  // 500 KB

// ─────────────────────────────────────────────────────────────────────────────
// BOOTSTRAP – ensure directories exist
// ─────────────────────────────────────────────────────────────────────────────
foreach ([DIR_FILES, DIR_BASE64, DIR_CHUNKS, DIR_HASH64, DIR_JSON64] as $d) {
    if (!is_dir($d)) mkdir($d, 0755, true);
}

// ─────────────────────────────────────────────────────────────────────────────
// AJAX / API HANDLER  (?action=…)
// ─────────────────────────────────────────────────────────────────────────────
if (isset($_GET['action'])) {
    header('Content-Type: application/json; charset=utf-8');
    $action = $_GET['action'];

    // ── serve a file for download ────────────────────────────────────────────
    if ($action === 'download') {
        $dir  = basename($_GET['dir']  ?? '');
        $name = basename($_GET['name'] ?? '');
        $map  = ['files' => DIR_FILES, 'base64' => DIR_BASE64,
                 'chunks' => DIR_CHUNKS, 'hash64' => DIR_HASH64];
        if (!isset($map[$dir]) || $name === '') { http_response_code(400); exit; }
        $path = $map[$dir] . '/' . $name;
        if (!is_file($path)) { http_response_code(404); exit; }
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $name . '"');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }

    // ── list directory ───────────────────────────────────────────────────────
    if ($action === 'list') {
        $dir = $_GET['dir'] ?? 'files';
        $map = ['files' => DIR_FILES, 'base64' => DIR_BASE64,
                'chunks' => DIR_CHUNKS, 'hash64' => DIR_HASH64, 'json64' => DIR_JSON64];
        if (!isset($map[$dir])) { echo json_encode([]); exit; }
        $items = [];
        foreach (scandir($map[$dir]) as $f) {
            if ($f === '.' || $f === '..') continue;
            $fp = $map[$dir] . '/' . $f;
            if (is_file($fp)) $items[] = ['name' => $f, 'size' => filesize($fp)];
        }
        echo json_encode($items);
        exit;
    }

    // ── encode files/ → base64/ ──────────────────────────────────────────────
    if ($action === 'encode_files') {
        $results = [];
        foreach (scandir(DIR_FILES) as $f) {
            if ($f === '.' || $f === '..') continue;
            $fp = DIR_FILES . '/' . $f;
            if (!is_file($fp)) continue;
            $raw  = file_get_contents($fp);
            $b64  = base64_encode($raw);
            $out  = DIR_BASE64 . '/' . $f . '.b64';
            file_put_contents($out, $b64);
            $results[] = ['file' => $f, 'out' => $f . '.b64', 'chars' => strlen($b64)];
        }
        echo json_encode(['ok' => true, 'results' => $results]);
        exit;
    }

    // ── split base64/ → chunks/ + hash64/ ───────────────────────────────────
    if ($action === 'make_chunks') {
        $chunkSize = max(1, (int)($_GET['chunk_size'] ?? 500));
        $results   = [];
        foreach (scandir(DIR_BASE64) as $f) {
            if ($f === '.' || $f === '..') continue;
            $fp = DIR_BASE64 . '/' . $f;
            if (!is_file($fp)) continue;
            $content   = file_get_contents($fp);
            $fullHash  = md5($content);
            $total     = (int)ceil(strlen($content) / $chunkSize);
            $hashes    = [];
            for ($i = 0; $i < $total; $i++) {
                $piece      = substr($content, $i * $chunkSize, $chunkSize);
                $pieceHash  = md5($piece);
                $chunkName  = $fullHash . '.' . ($i + 1) . '.' . $pieceHash;
                file_put_contents(DIR_CHUNKS . '/' . $chunkName, $piece);
                $hashes[]   = $pieceHash;
            }
            file_put_contents(DIR_HASH64 . '/' . $fullHash . '.txt', implode("\n", $hashes));
            $results[] = ['file' => $f, 'hash' => $fullHash, 'chunks' => $total];
        }
        echo json_encode(['ok' => true, 'results' => $results]);
        exit;
    }

    // ── search servers for a filename (name-based listing) ──────────────────
    if ($action === 'search_name') {
        $query   = trim($_GET['q'] ?? '');
        $servers = load_servers();
        $matches = [];
        foreach ($servers as $srv) {
            $url  = rtrim($srv, '/') . '/?action=list&dir=files';
            $data = http_get($url);
            if ($data === false) continue;
            $items = json_decode($data, true);
            if (!is_array($items)) continue;
            foreach ($items as $item) {
                if (stripos($item['name'], $query) !== false) {
                    $matches[] = ['server' => $srv, 'name' => $item['name'], 'size' => $item['size']];
                }
            }
        }
        echo json_encode(['ok' => true, 'matches' => $matches]);
        exit;
    }

    // ── download a single file by name from a specific server ────────────────
    if ($action === 'dl_file') {
        $server = $_GET['server'] ?? '';
        $name   = basename($_GET['name'] ?? '');
        $dir    = $_GET['dir'] ?? 'files';
        if (!$server || !$name) { echo json_encode(['ok'=>false,'err'=>'Missing params']); exit; }
        $url  = rtrim($server, '/') . '/?action=download&dir=' . urlencode($dir) . '&name=' . urlencode($name);
        $data = http_get($url);
        if ($data === false) { echo json_encode(['ok'=>false,'err'=>'Fetch failed']); exit; }
        if ($dir === 'files') {
            $ext  = infer_extension($data);
            $out  = DIR_FILES . '/' . $name;
            file_put_contents($out, $data);
            notify_servers(load_servers(), $name, 'direct_file', strlen($data));
            echo json_encode(['ok'=>true,'saved'=>$name,'bytes'=>strlen($data)]);
        } elseif ($dir === 'base64') {
            $raw  = base64_decode($data);
            $ext  = infer_extension($raw);
            $b64n = $name;
            file_put_contents(DIR_BASE64 . '/' . $b64n, $data);
            $outn = preg_replace('/\.b64$/', '', $name) . $ext;
            file_put_contents(DIR_FILES . '/' . $outn, $raw);
            notify_servers(load_servers(), $name, 'base64_file', strlen($raw));
            echo json_encode(['ok'=>true,'saved'=>$outn,'bytes'=>strlen($raw)]);
        }
        exit;
    }

    // ── fetch chunk index from a server ──────────────────────────────────────
    if ($action === 'get_index') {
        $hash    = preg_replace('/[^a-f0-9]/', '', strtolower($_GET['hash'] ?? ''));
        $servers = load_servers();
        foreach ($servers as $srv) {
            $url  = rtrim($srv, '/') . '/?action=download&dir=hash64&name=' . urlencode($hash . '.txt');
            $data = http_get($url);
            if ($data !== false) {
                $lines = array_filter(array_map('trim', explode("\n", $data)));
                echo json_encode(['ok'=>true,'server'=>$srv,'hash'=>$hash,'chunks'=>array_values($lines)]);
                exit;
            }
        }
        echo json_encode(['ok'=>false,'err'=>'Index not found on any server']);
        exit;
    }

    // ── download one chunk ───────────────────────────────────────────────────
    if ($action === 'dl_chunk') {
        $fullHash  = preg_replace('/[^a-f0-9]/', '', strtolower($_GET['full_hash']  ?? ''));
        $idx       = (int)($_GET['idx']       ?? 0);
        $pieceHash = preg_replace('/[^a-f0-9]/', '', strtolower($_GET['piece_hash'] ?? ''));
        $servers   = load_servers();
        $chunkName = $fullHash . '.' . $idx . '.' . $pieceHash;
        $localPath = DIR_CHUNKS . '/' . $chunkName;
        // cache hit
        if (is_file($localPath)) {
            echo json_encode(['ok'=>true,'cached'=>true,'name'=>$chunkName]);
            exit;
        }
        foreach ($servers as $srv) {
            $url  = rtrim($srv, '/') . '/?action=download&dir=chunks&name=' . urlencode($chunkName);
            $data = http_get($url);
            if ($data === false) continue;
            if (md5($data) !== $pieceHash) continue; // integrity check
            file_put_contents($localPath, $data);
            echo json_encode(['ok'=>true,'cached'=>false,'name'=>$chunkName,'server'=>$srv]);
            exit;
        }
        echo json_encode(['ok'=>false,'err'=>'Chunk not found: '.$chunkName]);
        exit;
    }

    // ── assemble chunks into a file ──────────────────────────────────────────
    if ($action === 'assemble') {
        $hash   = preg_replace('/[^a-f0-9]/', '', strtolower($_GET['hash'] ?? ''));
        $chunks = json_decode($_GET['chunks'] ?? '[]', true);
        if (!$hash || !is_array($chunks)) {
            echo json_encode(['ok'=>false,'err'=>'Bad params']); exit;
        }
        $b64 = '';
        foreach ($chunks as $i => $pieceHash) {
            $name  = $hash . '.' . ($i + 1) . '.' . $pieceHash;
            $cpath = DIR_CHUNKS . '/' . $name;
            if (!is_file($cpath)) {
                echo json_encode(['ok'=>false,'err'=>'Missing chunk '.$name]); exit;
            }
            $b64 .= file_get_contents($cpath);
        }
        $raw = base64_decode($b64);
        $ext = infer_extension($raw);
        $outName = $hash . $ext;
        file_put_contents(DIR_FILES  . '/' . $outName, $raw);
        file_put_contents(DIR_BASE64 . '/' . $hash . '.b64', $b64);
        notify_servers(load_servers(), $hash, 'chunk_assembled', strlen($raw));
        echo json_encode(['ok'=>true,'file'=>$outName,'bytes'=>strlen($raw)]);
        exit;
    }

    // ── check if file/base64 already exists on any server ────────────────────
    if ($action === 'check_exists') {
        $name    = basename($_GET['name'] ?? '');
        $servers = load_servers();
        $found   = [];
        foreach ($servers as $srv) {
            foreach (['files','base64'] as $dir) {
                $url  = rtrim($srv, '/') . '/?action=list&dir=' . $dir;
                $data = http_get($url);
                if ($data === false) continue;
                $items = json_decode($data, true);
                if (!is_array($items)) continue;
                foreach ($items as $item) {
                    if ($item['name'] === $name) {
                        $found[] = ['server'=>$srv,'dir'=>$dir,'size'=>$item['size']];
                    }
                }
            }
        }
        echo json_encode(['ok'=>true,'found'=>$found]);
        exit;
    }

    // ── blockchain notification receiver ─────────────────────────────────────
    if ($action === 'notify') {
        $data = $_GET['data'] ?? '';
        if ($data) {
            $block = json_decode($data, true);
            if (is_array($block)) {
                $fname = DIR_JSON64 . '/' . md5($data . microtime()) . '.json';
                file_put_contents($fname, json_encode($block, JSON_PRETTY_PRINT));
            }
        }
        echo json_encode(['ok'=>true]);
        exit;
    }

    // ── load pub.key ──────────────────────────────────────────────────────────
    if ($action === 'pubkey') {
        if (!is_file(PUBKEY_FILE)) { echo json_encode(['ok'=>false,'key'=>'']); exit; }
        if (filesize(PUBKEY_FILE) > MAX_PUBKEY) { echo json_encode(['ok'=>false,'key'=>'TOO_LARGE']); exit; }
        $key = trim(file_get_contents(PUBKEY_FILE));
        echo json_encode(['ok'=>true,'key'=>$key,'len'=>strlen($key)]);
        exit;
    }

    // ── load servers.txt ─────────────────────────────────────────────────────
    if ($action === 'servers') {
        echo json_encode(['ok'=>true,'servers'=>load_servers()]);
        exit;
    }

    http_response_code(400);
    echo json_encode(['error'=>'Unknown action']);
    exit;
}

// ─────────────────────────────────────────────────────────────────────────────
// PHP HELPER FUNCTIONS
// ─────────────────────────────────────────────────────────────────────────────
function load_servers() {
    if (!is_file(SERVERS_TXT)) return [];
    $lines = file(SERVERS_TXT, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    return array_values(array_filter(array_map(function($l) {
        $l = trim($l);
        return ($l === '' || $l[0] === '#') ? null : rtrim($l, '/');
    }, $lines)));
}

function http_get($url) {
    $ctx = stream_context_create(['http'=>[
        'method'          => 'GET',
        'timeout'         => 8,
        'ignore_errors'   => true,
        'header'          => "User-Agent: Base64Torrent-PHP/1.0\r\n",
    ], 'ssl'=>['verify_peer'=>false,'verify_peer_name'=>false]]);
    $data = @file_get_contents($url, false, $ctx);
    if ($data === false) return false;
    // check HTTP status
    if (isset($http_response_header)) {
        foreach ($http_response_header as $h) {
            if (preg_match('#^HTTP/\S+\s+(\d+)#', $h, $m) && (int)$m[1] !== 200) return false;
        }
    }
    return $data;
}

function infer_extension($raw) {
    if (strlen($raw) < 4) return '.bin';
    $b = array_values(unpack('C*', substr($raw, 0, 12)));
    if ($b[0]===0x89 && $b[1]===0x50 && $b[2]===0x4E && $b[3]===0x47) return '.png';
    if ($b[0]===0xFF && $b[1]===0xD8)                                    return '.jpg';
    if ($b[0]===0x47 && $b[1]===0x49 && $b[2]===0x46)                   return '.gif';
    if ($b[0]===0x25 && $b[1]===0x50 && $b[2]===0x44 && $b[3]===0x46)  return '.pdf';
    if ($b[0]===0x50 && $b[1]===0x4B && $b[2]===0x03 && $b[3]===0x04)  return '.zip';
    if (count($b)>=8 && $b[4]===0x66 && $b[5]===0x74 && $b[6]===0x79 && $b[7]===0x70) return '.mp4';
    if ($b[0]===0xFF && in_array($b[1],[0xFB,0xF3,0xF2]))                return '.mp3';
    if ($b[0]===0x52 && $b[1]===0x49 && $b[2]===0x46 && $b[3]===0x46
        && count($b)>=12 && $b[8]===0x57 && $b[9]===0x45 && $b[10]===0x42 && $b[11]===0x50) return '.webp';
    // text heuristic
    $check = substr($raw, 0, min(strlen($raw), 512));
    for ($i = 0; $i < strlen($check); $i++) {
        $c = ord($check[$i]);
        if ($c < 9 || ($c > 13 && $c < 32 && $c !== 27)) return '.bin';
    }
    return '.txt';
}

function notify_servers($servers, $fileRef, $type, $size) {
    $prevHash  = get_last_block_hash();
    $ts        = gmdate("Y-m-d\TH:i:s\Z");
    $pubkey    = '';
    if (is_file(PUBKEY_FILE) && filesize(PUBKEY_FILE) <= MAX_PUBKEY)
        $pubkey = substr(trim(file_get_contents(PUBKEY_FILE)), 0, 200);
    $body = json_encode([
        'fileRef'   => $fileRef,
        'type'      => $type,
        'size'      => $size,
        'timestamp' => $ts,
        'publicKey' => $pubkey,
        'prevHash'  => $prevHash,
    ]);
    $hash  = md5($body);
    $block = json_encode(['hash'=>$hash,'data'=>json_decode($body)], JSON_PRETTY_PRINT);
    // save locally
    file_put_contents(DIR_JSON64 . '/' . md5($block . microtime()) . '.json', $block);
    // notify peers
    foreach ($servers as $srv) {
        $url = rtrim($srv, '/') . '/?action=notify&data=' . urlencode($block);
        @file_get_contents($url, false, stream_context_create(['http'=>[
            'method'=>'GET','timeout'=>3,'ignore_errors'=>true
        ],'ssl'=>['verify_peer'=>false]]));
    }
}

function get_last_block_hash() {
    $files = glob(DIR_JSON64 . '/*.json');
    if (!$files) return str_repeat('0', 40);
    usort($files, function($a, $b) { return filemtime($b) - filemtime($a); });
    $content = file_get_contents($files[0]);
    $data = json_decode($content, true);
    return $data['hash'] ?? str_repeat('0', 40);
}

// ─────────────────────────────────────────────────────────────────────────────
// HTML OUTPUT  (only reached when no ?action= present)
// ─────────────────────────────────────────────────────────────────────────────
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Base64Torrent</title>
<style>
/* ── RESET & BASE ── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
:root {
  --bg:        #0f1117;
  --bg2:       #181c27;
  --bg3:       #1e2336;
  --border:    #2a3050;
  --accent:    #4f8ef7;
  --accent2:   #7c5fe6;
  --green:     #2ecc71;
  --red:       #e74c3c;
  --yellow:    #f39c12;
  --text:      #d0d8f0;
  --text2:     #8090b8;
  --mono:      'Fira Mono', 'Consolas', monospace;
  --radius:    8px;
}
body {
  font-family: 'Segoe UI', system-ui, sans-serif;
  background: var(--bg);
  color: var(--text);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

/* ── HEADER ── */
header {
  background: linear-gradient(135deg, #1a1f35 0%, #141827 100%);
  border-bottom: 1px solid var(--border);
  padding: 14px 24px;
  display: flex;
  align-items: center;
  gap: 16px;
}
header h1 { font-size: 1.4rem; font-weight: 700; color: var(--accent); letter-spacing: 1px; }
header h1 span { color: var(--accent2); }
#pubkey-badge {
  margin-left: auto;
  font-size: .75rem;
  background: var(--bg3);
  border: 1px solid var(--border);
  border-radius: 20px;
  padding: 4px 12px;
  color: var(--text2);
}

/* ── LAYOUT ── */
.main-grid {
  display: grid;
  grid-template-columns: 260px 1fr;
  grid-template-rows: auto 1fr;
  gap: 0;
  flex: 1;
  min-height: 0;
}
.sidebar {
  grid-row: 1 / 3;
  background: var(--bg2);
  border-right: 1px solid var(--border);
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  overflow-y: auto;
}
.top-bar {
  background: var(--bg2);
  border-bottom: 1px solid var(--border);
  padding: 14px 20px;
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  align-items: center;
}
.content {
  padding: 16px 20px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

/* ── BUTTONS ── */
.btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 8px 16px;
  border-radius: var(--radius);
  border: none;
  cursor: pointer;
  font-size: .85rem;
  font-weight: 600;
  transition: filter .15s, transform .1s;
}
.btn:active { transform: scale(.97); }
.btn:hover  { filter: brightness(1.15); }
.btn-primary  { background: var(--accent);  color: #fff; }
.btn-purple   { background: var(--accent2); color: #fff; }
.btn-green    { background: var(--green);   color: #000; }
.btn-red      { background: var(--red);     color: #fff; }
.btn-gray     { background: var(--bg3);     color: var(--text); border: 1px solid var(--border); }
.btn-sm       { padding: 5px 10px; font-size: .78rem; }

/* ── INPUTS ── */
.input-group { display: flex; align-items: center; gap: 8px; }
.input-group label { font-size: .8rem; color: var(--text2); white-space: nowrap; }
input[type=text], input[type=number] {
  background: var(--bg3);
  border: 1px solid var(--border);
  border-radius: 6px;
  color: var(--text);
  padding: 6px 10px;
  font-size: .85rem;
  outline: none;
  transition: border-color .2s;
}
input[type=text]:focus, input[type=number]:focus { border-color: var(--accent); }
#search-input { flex: 1; min-width: 200px; }

/* ── PANELS ── */
.panel {
  background: var(--bg2);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  overflow: hidden;
}
.panel-header {
  background: var(--bg3);
  padding: 8px 14px;
  font-size: .8rem;
  font-weight: 700;
  color: var(--text2);
  letter-spacing: .5px;
  text-transform: uppercase;
  display: flex;
  align-items: center;
  gap: 8px;
}
.panel-body { padding: 12px 14px; }

/* ── SERVER STATUS ── */
#server-dot {
  width: 10px; height: 10px;
  border-radius: 50%;
  background: var(--red);
  display: inline-block;
  transition: background .3s;
  box-shadow: 0 0 6px var(--red);
}
#server-dot.on { background: var(--green); box-shadow: 0 0 8px var(--green); }
#server-label  { font-size: .82rem; }

/* ── SIDEBAR SECTIONS ── */
.sidebar-section { display: flex; flex-direction: column; gap: 6px; }
.sidebar-title   { font-size: .72rem; font-weight: 700; color: var(--text2); text-transform: uppercase; letter-spacing: .5px; margin-bottom: 2px; }

/* ── FILE LIST ── */
.file-list { list-style: none; display: flex; flex-direction: column; gap: 4px; max-height: 220px; overflow-y: auto; }
.file-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 8px;
  border-radius: 6px;
  background: var(--bg3);
  font-size: .78rem;
  cursor: default;
}
.file-item:hover { background: #252b42; }
.file-name { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.file-size { color: var(--text2); flex-shrink: 0; font-size: .72rem; }
.file-dl   { color: var(--accent); cursor: pointer; flex-shrink: 0; font-size: .85rem; text-decoration: none; }
.file-dl:hover { color: #fff; }

/* ── SERVERS LIST ── */
.server-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 5px 8px;
  border-radius: 6px;
  background: var(--bg3);
  font-size: .78rem;
  font-family: var(--mono);
}
.server-dot { width: 7px; height: 7px; border-radius: 50%; background: var(--text2); flex-shrink: 0; }
.server-dot.ok { background: var(--green); }

/* ── PROGRESS TABLE ── */
.progress-table { width: 100%; border-collapse: collapse; font-size: .8rem; }
.progress-table th {
  background: var(--bg3);
  padding: 7px 10px;
  text-align: left;
  color: var(--text2);
  font-weight: 600;
  font-size: .75rem;
  text-transform: uppercase;
  letter-spacing: .3px;
  border-bottom: 1px solid var(--border);
}
.progress-table td {
  padding: 7px 10px;
  border-bottom: 1px solid #1a1f2e;
  vertical-align: middle;
  color: var(--text);
}
.progress-table tr:last-child td { border-bottom: none; }
.progress-table tr:hover td { background: rgba(79,142,247,.05); }
.progress-bar-wrap {
  background: var(--bg3);
  border-radius: 10px;
  height: 10px;
  overflow: hidden;
  min-width: 80px;
}
.progress-bar-fill {
  height: 100%;
  border-radius: 10px;
  background: linear-gradient(90deg, var(--accent), var(--accent2));
  transition: width .3s;
}
.progress-bar-fill.done { background: linear-gradient(90deg, var(--green), #27ae60); }
.badge {
  display: inline-block;
  padding: 2px 7px;
  border-radius: 10px;
  font-size: .7rem;
  font-weight: 700;
}
.badge-blue   { background: rgba(79,142,247,.2); color: var(--accent); }
.badge-green  { background: rgba(46,204,113,.2); color: var(--green);  }
.badge-yellow { background: rgba(243,156,18,.2);  color: var(--yellow); }
.badge-red    { background: rgba(231,76,60,.2);   color: var(--red);    }

/* ── LOG ── */
#log-area {
  font-family: var(--mono);
  font-size: .76rem;
  line-height: 1.6;
  height: 260px;
  overflow-y: auto;
  padding: 10px;
  color: #a0b0d0;
}
.log-time    { color: #4a5580; }
.log-ok      { color: var(--green);  }
.log-err     { color: var(--red);    }
.log-warn    { color: var(--yellow); }
.log-info    { color: var(--accent); }

/* ── SEARCH RESULTS ── */
.search-result {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 10px;
  background: var(--bg3);
  border-radius: 6px;
  font-size: .82rem;
  cursor: default;
}
.search-result:hover { background: #252b42; }
#search-results      { display: flex; flex-direction: column; gap: 6px; }

/* ── TABS ── */
.tabs        { display: flex; gap: 4px; border-bottom: 1px solid var(--border); margin-bottom: 12px; }
.tab         { padding: 7px 16px; border-radius: 6px 6px 0 0; cursor: pointer; font-size: .82rem; color: var(--text2); border: 1px solid transparent; border-bottom: none; }
.tab:hover   { color: var(--text); background: var(--bg3); }
.tab.active  { color: var(--text); background: var(--bg2); border-color: var(--border); margin-bottom: -1px; }
.tab-panel   { display: none; }
.tab-panel.active { display: block; }

/* ── SCROLLBAR ── */
::-webkit-scrollbar       { width: 6px; height: 6px; }
::-webkit-scrollbar-track { background: var(--bg2); }
::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }

/* ── MISC ── */
.empty-msg  { color: var(--text2); font-size: .82rem; padding: 12px 0; text-align: center; }
.mono       { font-family: var(--mono); font-size: .78rem; }
hr.sep      { border: none; border-top: 1px solid var(--border); margin: 8px 0; }
</style>
</head>
<body>

<!-- ══════════════════════════════════════════════════════════════════════════
     HEADER
══════════════════════════════════════════════════════════════════════════ -->
<header>
  <h1>Base64<span>Torrent</span></h1>
  <div id="pubkey-badge">🔑 pub.key: <span id="pubkey-status">loading…</span></div>
</header>

<!-- ══════════════════════════════════════════════════════════════════════════
     TOP BAR – ACTION BUTTONS
══════════════════════════════════════════════════════════════════════════ -->
<div class="top-bar">
  <button class="btn btn-primary"  onclick="encodeFiles()">📁 List Files → Base64</button>
  <button class="btn btn-purple"   onclick="makeChunks()">🔀 List Base64 → Chunks</button>

  <div class="input-group">
    <label>Chunk size:</label>
    <input type="number" id="chunk-size" value="500" min="1" style="width:70px">
  </div>

  <hr style="border:none;border-left:1px solid var(--border);height:28px">

  <button class="btn btn-green" id="server-btn" onclick="refreshServerFiles()">🌐 Refresh Server Listing</button>
  <span id="server-dot" title="HTTP server is PHP-hosted (always on)"></span>
  <span id="server-label">PHP server active</span>
</div>

<!-- ══════════════════════════════════════════════════════════════════════════
     MAIN GRID
══════════════════════════════════════════════════════════════════════════ -->
<div class="main-grid">

  <!-- ── SIDEBAR ── -->
  <aside class="sidebar">

    <!-- Search -->
    <div class="sidebar-section">
      <div class="sidebar-title">🔍 Search &amp; Download</div>
      <div class="input-group" style="flex-direction:column; align-items:stretch; gap:6px">
        <input type="text" id="search-input" placeholder="Filename or MD5 hash…">
        <button class="btn btn-primary" style="width:100%" onclick="searchAndDownload()">Search / Download</button>
      </div>
    </div>

    <hr class="sep">

    <!-- Servers -->
    <div class="sidebar-section">
      <div class="sidebar-title">🖧 Servers <button class="btn btn-gray btn-sm" style="float:right" onclick="loadServers()">↻</button></div>
      <ul id="servers-list" class="file-list" style="max-height:140px">
        <li class="empty-msg">Loading…</li>
      </ul>
    </div>

    <hr class="sep">

    <!-- Local dirs quick-view -->
    <div class="sidebar-section">
      <div class="sidebar-title">📂 Local Files</div>
      <div class="tabs" style="flex-wrap:wrap">
        <span class="tab active" onclick="switchSideTab(this,'files')">files</span>
        <span class="tab" onclick="switchSideTab(this,'base64')">base64</span>
        <span class="tab" onclick="switchSideTab(this,'chunks')">chunks</span>
        <span class="tab" onclick="switchSideTab(this,'hash64')">hash64</span>
      </div>
      <div id="side-files"  class="tab-panel active"><ul id="list-files"  class="file-list"><li class="empty-msg">Loading…</li></ul></div>
      <div id="side-base64" class="tab-panel"><ul id="list-base64" class="file-list"><li class="empty-msg">–</li></ul></div>
      <div id="side-chunks" class="tab-panel"><ul id="list-chunks" class="file-list"><li class="empty-msg">–</li></ul></div>
      <div id="side-hash64" class="tab-panel"><ul id="list-hash64" class="file-list"><li class="empty-msg">–</li></ul></div>
      <button class="btn btn-gray btn-sm" style="width:100%;margin-top:6px" onclick="refreshAllLists()">↻ Refresh</button>
    </div>

  </aside>

  <!-- ── TOP CONTENT BAR (search results) ── -->
  <div style="padding:16px 20px 0; border-bottom:1px solid var(--border)">
    <div class="panel">
      <div class="panel-header">🔎 Search Results</div>
      <div class="panel-body">
        <div id="search-results"><div class="empty-msg">Enter a filename or MD5 hash and click Search / Download.</div></div>
      </div>
    </div>
  </div>

  <!-- ── MAIN CONTENT ── -->
  <div class="content">

    <!-- Downloads progress -->
    <div class="panel">
      <div class="panel-header">⬇ Download Progress</div>
      <div class="panel-body" style="padding:0">
        <div style="overflow-x:auto">
          <table class="progress-table">
            <thead>
              <tr>
                <th>File / Hash</th>
                <th>Bytes</th>
                <th>Chunks</th>
                <th>Downloaded</th>
                <th style="min-width:120px">Progress</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody id="progress-tbody">
              <tr><td colspan="6" class="empty-msg" style="text-align:center;padding:16px">No downloads yet.</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Log -->
    <div class="panel" style="flex:1;display:flex;flex-direction:column;min-height:220px">
      <div class="panel-header">
        📋 Log
        <button class="btn btn-gray btn-sm" style="margin-left:auto" onclick="clearLog()">Clear</button>
      </div>
      <div id="log-area"></div>
    </div>

    <!-- Blockchain viewer -->
    <div class="panel">
      <div class="panel-header">
        ⛓ Blockchain Transfer Log
        <button class="btn btn-gray btn-sm" style="margin-left:auto" onclick="loadChain()">↻ Refresh</button>
      </div>
      <div class="panel-body">
        <div id="chain-list" style="font-family:var(--mono);font-size:.74rem;color:var(--text2);max-height:180px;overflow-y:auto">
          <div class="empty-msg">No blocks yet.</div>
        </div>
      </div>
    </div>

  </div><!-- /.content -->
</div><!-- /.main-grid -->

<!-- ══════════════════════════════════════════════════════════════════════════
     JAVASCRIPT
══════════════════════════════════════════════════════════════════════════ -->
<script>
'use strict';

// ── API wrapper ──────────────────────────────────────────────────────────────
async function api(params) {
  const qs = new URLSearchParams(params).toString();
  const r  = await fetch('?' + qs);
  return r.json();
}

// ── Log ──────────────────────────────────────────────────────────────────────
function log(msg, type = 'info') {
  const el   = document.getElementById('log-area');
  const ts   = new Date().toLocaleTimeString();
  const cls  = { ok:'log-ok', err:'log-err', warn:'log-warn', info:'log-info' }[type] ?? 'log-info';
  const line = document.createElement('div');
  line.innerHTML = `<span class="log-time">[${ts}]</span> <span class="${cls}">${escHtml(msg)}</span>`;
  el.appendChild(line);
  el.scrollTop = el.scrollHeight;
}
function clearLog() { document.getElementById('log-area').innerHTML = ''; }

function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function fmtSize(bytes) {
  if (bytes < 1024)          return bytes + ' B';
  if (bytes < 1024*1024)     return (bytes/1024).toFixed(1) + ' KB';
  return (bytes/(1024*1024)).toFixed(2) + ' MB';
}

// ── Pub key ──────────────────────────────────────────────────────────────────
async function loadPubKey() {
  const d = await api({action:'pubkey'});
  const el = document.getElementById('pubkey-status');
  if (d.ok && d.key) el.textContent = d.len + ' chars loaded';
  else if (d.key === 'TOO_LARGE') { el.textContent = 'TOO LARGE (>500KB)'; el.style.color='var(--red)'; }
  else { el.textContent = 'NOT LOADED'; el.style.color='var(--yellow)'; }
}

// ── Servers ──────────────────────────────────────────────────────────────────
async function loadServers() {
  const d  = await api({action:'servers'});
  const ul = document.getElementById('servers-list');
  if (!d.ok || !d.servers.length) {
    ul.innerHTML = '<li class="empty-msg">No servers in servers.txt</li>';
    return;
  }
  ul.innerHTML = d.servers.map(s =>
    `<li class="server-item"><span class="server-dot" id="dot-${btoa(s).replace(/=/g,'')}"></span>
     <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escHtml(s)}</span></li>`
  ).join('');
  // ping each
  d.servers.forEach(async srv => {
    try {
      const r = await fetch(srv + '/?action=list&dir=files', {signal: AbortSignal.timeout(4000)});
      const id = 'dot-' + btoa(srv).replace(/=/g,'');
      const dot = document.getElementById(id);
      if (dot) dot.classList.toggle('ok', r.ok);
    } catch {}
  });
}

// ── List local files ─────────────────────────────────────────────────────────
async function loadDir(dir) {
  const d  = await api({action:'list', dir});
  const ul = document.getElementById('list-' + dir);
  if (!ul) return;
  if (!d || !d.length) { ul.innerHTML = '<li class="empty-msg">Empty</li>'; return; }
  ul.innerHTML = d.map(f => `
    <li class="file-item" title="${escHtml(f.name)}">
      <span class="file-name">${escHtml(f.name)}</span>
      <span class="file-size">${fmtSize(f.size)}</span>
      <a class="file-dl" title="Download" href="?action=download&dir=${dir}&name=${encodeURIComponent(f.name)}" download="${escHtml(f.name)}">⬇</a>
    </li>`).join('');
}

async function refreshAllLists() {
  await Promise.all(['files','base64','chunks','hash64'].map(loadDir));
  log('Directory listings refreshed.', 'info');
}

function switchSideTab(el, dir) {
  document.querySelectorAll('.sidebar .tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.sidebar .tab-panel').forEach(p => p.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('side-' + dir).classList.add('active');
  loadDir(dir);
}

// ── Refresh server file listing (show in sidebar) ────────────────────────────
async function refreshServerFiles() {
  log('Refreshing server status…','info');
  await loadServers();
}

// ── Encode files/ → base64/ ──────────────────────────────────────────────────
async function encodeFiles() {
  log('Encoding files/ → base64/ …','info');
  const d = await api({action:'encode_files'});
  if (!d.ok) { log('Encode failed.','err'); return; }
  if (!d.results.length) { log('No files found in files/.','warn'); return; }
  d.results.forEach(r => log(`✔ ${r.file} → ${r.out} (${r.chars} chars)`,'ok'));
  await loadDir('base64');
}

// ── Split base64/ → chunks/ + hash64/ ───────────────────────────────────────
async function makeChunks() {
  const cs = parseInt(document.getElementById('chunk-size').value) || 500;
  log(`Splitting base64/ into chunks of ${cs} chars…`,'info');
  const d = await api({action:'make_chunks', chunk_size:cs});
  if (!d.ok) { log('Split failed.','err'); return; }
  if (!d.results.length) { log('No .b64 files found in base64/.','warn'); return; }
  d.results.forEach(r => log(`✔ ${r.file} → ${r.chunks} chunks [${r.hash}]`,'ok'));
  await Promise.all([loadDir('chunks'), loadDir('hash64')]);
}

// ── Progress table ────────────────────────────────────────────────────────────
let progressRows = {};
function addProgressRow(id, label) {
  const tbody = document.getElementById('progress-tbody');
  // remove placeholder
  const ph = tbody.querySelector('[colspan="6"]');
  if (ph) ph.parentElement.remove();
  const tr = document.createElement('tr');
  tr.id  = 'pr-' + id;
  tr.innerHTML = `
    <td class="mono" title="${escHtml(label)}" style="max-width:180px;overflow:hidden;text-overflow:ellipsis">${escHtml(label.length>28?label.slice(0,26)+'…':label)}</td>
    <td id="pr-${id}-size">–</td>
    <td id="pr-${id}-total">–</td>
    <td id="pr-${id}-done">0</td>
    <td><div class="progress-bar-wrap"><div class="progress-bar-fill" id="pr-${id}-bar" style="width:0%"></div></div></td>
    <td><span class="badge badge-blue" id="pr-${id}-status">starting</span></td>`;
  tbody.appendChild(tr);
  progressRows[id] = true;
}
function updateProgress(id, done, total, status, bytes) {
  const pct  = total > 0 ? Math.round(done * 100 / total) : 0;
  const bar  = document.getElementById('pr-'+id+'-bar');
  const st   = document.getElementById('pr-'+id+'-status');
  const dn   = document.getElementById('pr-'+id+'-done');
  const tot  = document.getElementById('pr-'+id+'-total');
  const sz   = document.getElementById('pr-'+id+'-size');
  if (bar) { bar.style.width = pct+'%'; if (pct===100) bar.classList.add('done'); }
  if (st) {
    const cls = {DONE:'badge-green',ERROR:'badge-red',INCOMPLETE:'badge-red',cached:'badge-yellow'}[status] ?? 'badge-blue';
    st.className = 'badge ' + cls;
    st.textContent = status;
  }
  if (dn)  dn.textContent  = done + '/' + total;
  if (tot) tot.textContent = total;
  if (sz && bytes) sz.textContent = fmtSize(bytes);
}

// ── Search & Download ─────────────────────────────────────────────────────────
async function searchAndDownload() {
  const query   = document.getElementById('search-input').value.trim();
  if (!query)   { log('Enter a filename or MD5 hash.','warn'); return; }
  const isMd5   = /^[a-fA-F0-9]{32}$/.test(query);
  const resultsEl = document.getElementById('search-results');
  resultsEl.innerHTML = '<div class="empty-msg">Searching…</div>';
  log(`=== Searching: "${query}" (${isMd5?'MD5':'name'}) ===`,'info');

  // ── 1. Try direct file match on servers ──────────────────────────────────
  const srvData = await api({action:'servers'});
  const servers = srvData.servers ?? [];

  // check local first
  const localFiles = await api({action:'list', dir:'files'});
  if (Array.isArray(localFiles)) {
    for (const f of localFiles) {
      if (f.name === query || (isMd5 && f.name.startsWith(query))) {
        log(`Already have "${f.name}" locally in files/.`,'ok');
        resultsEl.innerHTML = renderResult(f.name, 'LOCAL/files', f.size, null, null);
        return;
      }
    }
  }

  let found = [];

  if (isMd5) {
    // ── 2. Check base64/ on servers ────────────────────────────────────────
    for (const srv of servers) {
      try {
        const items = await fetchJSON(srv + '/?action=list&dir=base64');
        if (!items) continue;
        for (const f of items) {
          if (f.name === query + '.b64' || f.name.startsWith(query)) {
            found.push({srv, dir:'base64', name:f.name, size:f.size});
          }
        }
      } catch {}
    }

    if (found.length) {
      log(`Found base64 match on ${found[0].srv}`,'ok');
      renderSearchResults(found, resultsEl);
    } else {
      // ── 3. Try chunk index ─────────────────────────────────────────────
      log('No base64 match – trying chunk-based download…','info');
      await downloadByChunks(query, servers, resultsEl);
    }

  } else {
    // name-based search
    const d = await api({action:'search_name', q:query});
    if (d.ok && d.matches.length) {
      d.matches.forEach(m => found.push({srv:m.server, dir:'files', name:m.name, size:m.size}));
      renderSearchResults(found, resultsEl);
    } else {
      resultsEl.innerHTML = '<div class="empty-msg">No matches found.</div>';
      log('No matches found.','warn');
    }
  }
}

function renderSearchResults(items, el) {
  el.innerHTML = items.map(m => renderResult(m.name, m.srv + '/' + m.dir, m.size, m.srv, m.dir)).join('');
}

function renderResult(name, location, size, srv, dir) {
  const dlBtn = srv
    ? `<button class="btn btn-green btn-sm" onclick="directDownload('${escHtml(srv)}','${escHtml(dir)}','${escHtml(name)}')">⬇ Download</button>`
    : `<a class="btn btn-gray btn-sm" href="?action=download&dir=files&name=${encodeURIComponent(name)}" download>⬇ Open</a>`;
  return `<div class="search-result">
    <span style="font-size:1rem">📄</span>
    <span class="mono" style="flex:1;overflow:hidden;text-overflow:ellipsis">${escHtml(name)}</span>
    <span style="color:var(--text2);font-size:.75rem">${fmtSize(size||0)}</span>
    <span style="color:var(--text2);font-size:.72rem">${escHtml(location)}</span>
    ${dlBtn}
  </div>`;
}

async function directDownload(srv, dir, name) {
  log(`Downloading ${name} from ${srv}/${dir}…`,'info');
  const d = await api({action:'dl_file', server:srv, dir:dir, name:name});
  if (d.ok) {
    log(`✔ Saved as ${d.saved} (${fmtSize(d.bytes)})`,'ok');
    await loadDir('files');
  } else {
    log(`✘ Download failed: ${d.err}`,'err');
  }
}

// ── Chunk-based download ──────────────────────────────────────────────────────
async function downloadByChunks(hash, servers, resultsEl) {
  log(`Fetching chunk index for ${hash}…`,'info');
  const idx = await api({action:'get_index', hash});
  if (!idx.ok) {
    log('✘ ' + idx.err,'err');
    resultsEl.innerHTML = '<div class="empty-msg">Not found on any server.</div>';
    return;
  }
  const chunks = idx.chunks;
  const total  = chunks.length;
  log(`Index found on ${idx.server} – ${total} chunks`,'ok');
  addProgressRow(hash, hash);
  updateProgress(hash, 0, total, 'downloading');
  resultsEl.innerHTML = `<div class="search-result"><span>⬇ Downloading ${total} chunks for <b>${escHtml(hash)}</b>…</span></div>`;

  let done = 0;
  for (let i = 0; i < total; i++) {
    const d = await api({
      action:     'dl_chunk',
      full_hash:  hash,
      idx:        i + 1,
      piece_hash: chunks[i]
    });
    if (d.ok) {
      done++;
      updateProgress(hash, done, total, d.cached ? 'cached' : 'downloading');
      log(`  ${d.cached?'[cache]':'[dl]'} chunk ${i+1}/${total}: ${d.name}`,'info');
    } else {
      log(`  ✘ chunk ${i+1}/${total}: ${d.err}`,'err');
    }
  }

  if (done < total) {
    updateProgress(hash, done, total, 'INCOMPLETE');
    log(`✘ Only got ${done}/${total} chunks.`,'err');
    return;
  }

  // assemble
  log('Assembling chunks…','info');
  const asm = await api({action:'assemble', hash, chunks: JSON.stringify(chunks)});
  if (asm.ok) {
    updateProgress(hash, total, total, 'DONE', asm.bytes);
    log(`✔ Assembled: ${asm.file} (${fmtSize(asm.bytes)})`,'ok');
    resultsEl.innerHTML = renderResult(asm.file, 'LOCAL/files', asm.bytes, null, null);
    await loadDir('files');
    await loadChain();
  } else {
    updateProgress(hash, done, total, 'ERROR');
    log(`✘ Assembly error: ${asm.err}`,'err');
  }
}

// ── Blockchain log ────────────────────────────────────────────────────────────
async function loadChain() {
  const d   = await api({action:'list', dir:'json64'});
  const el  = document.getElementById('chain-list');
  if (!d || !d.length) { el.innerHTML = '<div class="empty-msg">No blocks yet.</div>'; return; }
  // fetch and display last 10
  const recent = d.slice(-10).reverse();
  el.innerHTML = recent.map(f =>
    `<div style="padding:4px 0;border-bottom:1px solid var(--border)">
       <span style="color:var(--accent)">${escHtml(f.name)}</span>
       <span style="float:right;color:var(--text2)">${fmtSize(f.size)}</span>
       <a style="color:var(--text2);font-size:.7rem;text-decoration:none" href="?action=download&dir=json64&name=${encodeURIComponent(f.name)}" download>⬇</a>
     </div>`
  ).join('');
}

// ── Helpers ───────────────────────────────────────────────────────────────────
async function fetchJSON(url) {
  try {
    const r = await fetch(url, {signal: AbortSignal.timeout(5000)});
    if (!r.ok) return null;
    return await r.json();
  } catch { return null; }
}

// ── INIT ──────────────────────────────────────────────────────────────────────
(async () => {
  await loadPubKey();
  await loadServers();
  await refreshAllLists();
  await loadChain();
  // mark server as always-on (PHP handles requests)
  document.getElementById('server-dot').classList.add('on');
  document.getElementById('server-label').textContent = 'PHP server active';
  log('Base64Torrent ready.','ok');
})();
</script>
</body>
</html>