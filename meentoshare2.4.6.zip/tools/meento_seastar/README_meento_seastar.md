# Seastar

A self-hosted PHP file distribution node. Upload a file once, and Seastar seeds it to every peer in your network — either chunked over GET/POST or sent whole as a raw file upload.

---

## Requirements

- PHP 7.4+ with `fileinfo` extension (for `mime_content_type`)
- cURL extension recommended for POST direct-file mode
- Write permissions on the server directory

---

## Installation

1. Copy `index.php` to your web root (or any subdirectory).
2. Ensure PHP has write access to the directory — Seastar auto-creates all required folders on first run.
3. Optionally create `public_key.txt` and `node_info.txt` to identify this node to peers.

---

## Directory Layout

```
index.php               ← the entire application
base64_hash/            ← chunk JSON files (GET/POST chunk mode)
  <hash>.<n>.<chunkHash>.json
chunks/                 ← write-once chunk index files
  <file_hash>.txt
files/                  ← raw files received via POST direct mode
  <md5>.<ext>
seeder_tmp/             ← upload staging area, auto-cleaned
servers.txt             ← one peer URL per line
public_key.txt          ← this node's public key (optional)
node_info.txt           ← this node's metadata (optional)
```

---

## Transport Modes

### GET (default)
File data is split into small chunks, each Base64-encoded and sent as a URL query-string parameter to `?action=receive_chunk`. The **Max GET Chunk Size** slider (100 B – 8 KB raw) controls how much raw data goes into each request. Base64 adds ~33% overhead, so 8 KB raw becomes ~10.9 KB in the URL — safely within most server limits.

### POST — chunk mode (legacy)
Same chunking logic as GET but the payload travels in the HTTP request body, allowing larger per-request sizes without URL-length concerns.

### POST — direct file mode
No chunking or Base64 encoding at all. The raw file is sent as a single `multipart/form-data` POST to `?action=receive_file` and stored in `files/<md5>.<ext>`. The **Chunk Size slider is hidden** in this mode. Existing files are never overwritten.

---

## API Endpoints

### `?action=receive_chunk`
Accepts GET or POST. Used by chunk-mode distribution.

| Parameter | Description |
|---|---|
| `filename` | Original filename |
| `file_hash` | MD5 of the full file (32 hex chars) |
| `chunk_num` | 1-based chunk index |
| `chunk_hash` | MD5 of the Base64-encoded chunk content |
| `contents` | Base64-encoded chunk data |
| `public_key` | Sender's public key |
| `node_info` | Sender's node metadata |
| `total_chunks` | Total number of chunks |
| `chunk_list` | Comma-separated list of all chunk names (optional, written once) |

Response:
```json
{ "ok": true, "chunk": "<chunkName>", "stored": "new|exists" }
```

Integrity check: `md5(contents)` must equal `chunk_hash` or the request is rejected with HTTP 400.

---

### `?action=receive_file`
Accepts POST only (`multipart/form-data`). Used by POST direct-file distribution.

| Field | Description |
|---|---|
| `file` | Raw file binary |
| `public_key` | Sender's public key (optional) |
| `node_info` | Sender's node metadata (optional) |

Stored as `files/<md5_of_file>.<ext>`. If the file already exists it is **never overwritten**.

Response:
```json
{ "ok": true, "file": "<md5>.<ext>", "stored": "new|exists", "hash": "<md5>" }
```

---

## Tabs

### Seed & Send
Upload a file and either seed it locally or distribute it to all configured peers. Choosing **POST** transport hides the chunk-size slider and sends the file as a single raw upload per server.

### Stored
Lists all locally stored chunk sets. Shows chunk count, completeness, and allows deletion by file hash.

### Servers
Add or remove peer node URLs. Each URL should be the base URL of a remote Seastar instance (e.g. `https://node2.example.com`).

### How It Works
In-app reference for transport modes, directory layout, and endpoint parameters.

---

## File Naming

| Mode | Storage path | Name format |
|---|---|---|
| Chunk (GET or POST) | `base64_hash/` | `<file_md5>.<chunk_num>.<chunk_md5>.json` |
| Chunk index | `chunks/` | `<file_md5>.txt` |
| Direct POST | `files/` | `<file_md5>.<original_ext>` |

The MD5 of the full file is the permanent file identifier shared across all nodes.

---

## Node Identity

Create these files in the same directory as `index.php` to identify this node to peers:

- `public_key.txt` — any string representing this node's public key
- `node_info.txt` — any freeform metadata (name, location, contact, etc.)

Both are sent along with every chunk or file transmission and stored by receiving nodes.

---

## Security Notes

- There is no authentication. Deploy behind HTTP basic auth or restrict access by IP if the node should not be publicly writable.
- Chunk integrity is verified on receipt (`md5(contents) === chunk_hash`). Tampered chunks are rejected.
- Files received via POST direct mode are stored by their own MD5 hash, making accidental collision overwrites impossible and duplicate submissions a no-op.
- `seeder_tmp/` is cleaned automatically after each upload.
