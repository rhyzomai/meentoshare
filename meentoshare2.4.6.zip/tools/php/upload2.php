﻿<?php
// ============================================================
//  Meento Uploader
//  Stores files in files/ using SHA-256 as filename.
//  Optionally saves metadata JSON in info/<sha256>.json
// ============================================================

define('FILES_DIR', __DIR__ . '/files');
define('INFO_DIR',  __DIR__ . '/info');
define('MAX_INFO',  512000); // 500 KB

foreach ([FILES_DIR, INFO_DIR] as $d) {
    if (!is_dir($d)) mkdir($d, 0755, true);
}

// ============================================================
//  Helpers
// ============================================================

function formatBytes(int $bytes): string {
    if ($bytes >= 1048576) return round($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024)    return round($bytes / 1024,    2) . ' KB';
    return $bytes . ' B';
}

function listFiles(): array {
    $out = [];
    foreach (glob(FILES_DIR . '/*') ?: [] as $f) {
        if (!is_file($f)) continue;
        $hash    = basename($f);
        $infoPath = INFO_DIR . '/' . $hash . '.json';
        $info    = null;
        if (file_exists($infoPath)) {
            $dec = @json_decode(file_get_contents($infoPath), true);
            if (is_array($dec)) $info = $dec;
        }
        $out[] = [
            'hash'  => $hash,
            'size'  => filesize($f),
            'mtime' => filemtime($f),
            'info'  => $info,
        ];
    }
    usort($out, function($a, $b) { return $b['mtime'] - $a['mtime']; });
    return $out;
}

// ============================================================
//  Action handling
// ============================================================

$tab     = $_POST['tab'] ?? $_GET['tab'] ?? 'upload';
$banners = []; // [type, msg]

if (isset($_POST['do_upload'])) {
    $tab = 'upload';

    // ── 1. File validation ────────────────────────────────────
    if (empty($_FILES['upload_file']['name'])) {
        $banners[] = ['error', 'No file selected.'];
    } else {
        $origName = $_FILES['upload_file']['name'];
        $tmpPath  = $_FILES['upload_file']['tmp_name'];
        $uploadErr = $_FILES['upload_file']['error'];

        if ($uploadErr !== UPLOAD_ERR_OK) {
            $banners[] = ['error', 'Upload error code: ' . $uploadErr];
        } elseif (strtolower(pathinfo($origName, PATHINFO_EXTENSION)) === 'php') {
            $banners[] = ['error', 'PHP files are not allowed.'];
        } else {
            $hash    = hash_file('sha256', $tmpPath);
            $dest    = FILES_DIR . '/' . $hash;
            $existed = file_exists($dest);

            if ($existed) {
                $banners[] = ['info', 'File already stored — hash: ' . $hash];
            } else {
                if (!move_uploaded_file($tmpPath, $dest)) {
                    $banners[] = ['error', 'Failed to move uploaded file.'];
                    $hash = '';
                } else {
                    $banners[] = ['ok', 'File stored — hash: ' . $hash];
                }
            }

            // ── 2. Info / metadata ────────────────────────────
            if ($hash && !empty($_POST['enable_info'])) {
                $infoPath = INFO_DIR . '/' . $hash . '.json';

                if (file_exists($infoPath)) {
                    $banners[] = ['info', 'Metadata already exists — not overwritten.'];
                } else {
                    $mode    = $_POST['info_mode'] ?? 'json';
                    $jsonStr = '';
                    $infoErr = '';

                    if ($mode === 'raw') {
                        $raw = $_POST['raw_info'] ?? '';
                        if (strlen($raw) > MAX_INFO) {
                            $infoErr = 'Raw info exceeds 500 KB limit.';
                        } else {
                            // Validate it is valid JSON
                            $test = @json_decode($raw, true);
                            if ($test === null) {
                                $infoErr = 'Raw content is not valid JSON.';
                            } else {
                                $jsonStr = $raw;
                            }
                        }
                    } else {
                        // JSON field builder
                        $keys   = $_POST['field_keys']   ?? [];
                        $vals   = $_POST['field_vals']   ?? [];
                        $obj    = [];
                        $seen   = [];
                        foreach ($keys as $i => $k) {
                            $k = trim($k);
                            if ($k === '' || isset($seen[$k])) continue;
                            $seen[$k] = true;
                            $obj[$k]  = $vals[$i] ?? '';
                        }
                        if (empty($obj)) {
                            $infoErr = 'No fields provided — metadata not saved.';
                        } else {
                            $jsonStr = json_encode($obj, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
                            if (strlen($jsonStr) > MAX_INFO) {
                                $infoErr = 'Serialised JSON exceeds 500 KB limit.';
                                $jsonStr = '';
                            }
                        }
                    }

                    if ($infoErr) {
                        $banners[] = ['error', 'Metadata: ' . $infoErr];
                    } elseif ($jsonStr !== '') {
                        file_put_contents($infoPath, $jsonStr);
                        $banners[] = ['ok', 'Metadata saved — info/' . $hash . '.json'];
                    }
                }
            }
        }
    }
}

// Serve file for download
if (isset($_GET['serve'])) {
    $h = preg_replace('/[^a-f0-9]/i', '', $_GET['serve']);
    $p = FILES_DIR . '/' . $h;
    if (strlen($h) === 64 && file_exists($p)) {
        $infoPath = INFO_DIR . '/' . $h . '.json';
        $fname    = $h;
        if (file_exists($infoPath)) {
            $meta = @json_decode(file_get_contents($infoPath), true);
            if (isset($meta['filename']) && $meta['filename'] !== '') {
                $fname = basename($meta['filename']);
            }
        }
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . addslashes($fname) . '"');
        header('Content-Length: ' . filesize($p));
        readfile($p);
        exit;
    }
    http_response_code(404);
    exit('Not found');
}

$files = listFiles();
$totalSize = array_sum(array_column($files, 'size'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Meento Uploader</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=Space+Grotesk:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
  :root {
    --bg:      #0d0f14;
    --surface: #13161e;
    --border:  #1e2330;
    --accent:  #00e5a0;
    --accent2: #0077ff;
    --yellow:  #f5c400;
    --red:     #ff3f5b;
    --text:    #d4dae8;
    --muted:   #5a6380;
    --mono:    'IBM Plex Mono', monospace;
    --sans:    'Space Grotesk', sans-serif;
    --radius:  6px;
  }

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: var(--sans);
    font-size: 14px;
    min-height: 100vh;
    padding: 0 0 60px;
  }

  /* ── Header ── */
  .header {
    border-bottom: 1px solid var(--border);
    padding: 18px 32px;
    display: flex;
    align-items: center;
    gap: 16px;
    background: var(--surface);
  }
  .header-logo {
    width: 36px; height: 36px;
    background: var(--accent);
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
  }
  .header-logo svg { width: 20px; height: 20px; }
  .header-title { font-size: 17px; font-weight: 600; letter-spacing: -.3px; }
  .header-sub   { font-size: 12px; color: var(--muted); font-family: var(--mono); margin-top: 1px; }
  .header-links { margin-left: auto; display: flex; gap: 8px; }
  .header-link  {
    font-family: var(--mono);
    font-size: 12px;
    color: var(--accent2);
    text-decoration: none;
    border: 1px solid var(--accent2);
    padding: 4px 10px;
    border-radius: var(--radius);
    transition: background .15s;
  }
  .header-link:hover { background: rgba(0,119,255,.12); }

  /* ── Layout ── */
  .container { max-width: 860px; margin: 0 auto; padding: 32px 24px 0; }

  /* ── Tabs ── */
  nav {
    display: flex;
    gap: 4px;
    margin-bottom: 24px;
    border-bottom: 1px solid var(--border);
  }
  nav button {
    background: none;
    border: none;
    border-bottom: 2px solid transparent;
    color: var(--muted);
    font-family: var(--sans);
    font-size: 13px;
    font-weight: 500;
    padding: 8px 16px;
    cursor: pointer;
    margin-bottom: -1px;
    transition: color .15s, border-color .15s;
  }
  nav button.active { color: var(--accent); border-bottom-color: var(--accent); }
  nav button:hover:not(.active) { color: var(--text); }

  .tab { display: none; }
  .tab.active { display: block; }

  /* ── Cards ── */
  .card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 22px 24px;
    margin-bottom: 16px;
  }
  .card-title {
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: .1em;
    color: var(--muted);
    margin-bottom: 18px;
  }

  /* ── Form ── */
  .field { margin-bottom: 16px; }
  label { display: block; font-size: 12px; color: var(--muted); margin-bottom: 6px; font-family: var(--mono); }

  input[type=text], input[type=file], textarea, select {
    width: 100%;
    background: #080a10;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    color: var(--text);
    font-family: var(--mono);
    font-size: 13px;
    padding: 10px 14px;
    outline: none;
    transition: border-color .15s;
  }
  input[type=text]:focus,
  textarea:focus { border-color: var(--accent2); }
  input[type=file] {
    padding: 8px 12px;
    cursor: pointer;
    font-size: 13px;
  }
  input[type=file]::file-selector-button {
    background: var(--accent2);
    color: #fff;
    border: none;
    border-radius: 4px;
    padding: 5px 12px;
    font-family: var(--sans);
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    margin-right: 12px;
    transition: opacity .15s;
  }
  input[type=file]::file-selector-button:hover { opacity: .85; }
  textarea {
    resize: vertical;
    min-height: 140px;
    font-size: 12px;
    line-height: 1.6;
  }

  button[type=submit], .btn {
    background: var(--accent);
    color: #0d0f14;
    border: none;
    border-radius: var(--radius);
    font-family: var(--sans);
    font-weight: 600;
    font-size: 13px;
    padding: 9px 22px;
    cursor: pointer;
    transition: opacity .15s, transform .1s;
    white-space: nowrap;
  }
  button[type=submit]:hover, .btn:hover { opacity: .88; }
  button[type=submit]:active { transform: scale(.97); }

  .btn-ghost {
    background: none;
    border: 1px solid var(--border);
    color: var(--muted);
    font-family: var(--mono);
    font-size: 11px;
    padding: 5px 12px;
    border-radius: var(--radius);
    cursor: pointer;
    transition: border-color .15s, color .15s;
  }
  .btn-ghost:hover { border-color: var(--text); color: var(--text); }

  .btn-danger {
    background: none;
    border: 1px solid var(--red);
    color: var(--red);
    font-family: var(--mono);
    font-size: 11px;
    padding: 4px 10px;
    border-radius: var(--radius);
    cursor: pointer;
    transition: background .15s;
  }
  .btn-danger:hover { background: rgba(255,63,91,.12); }

  /* ── Banner ── */
  .banner {
    padding: 12px 18px;
    border-radius: var(--radius);
    margin-bottom: 12px;
    font-size: 13px;
    font-family: var(--mono);
    border-left: 3px solid;
  }
  .banner.ok    { background: rgba(0,229,160,.08);  border-color: var(--accent);  color: var(--accent); }
  .banner.error { background: rgba(255,63,91,.08);  border-color: var(--red);     color: var(--red); }
  .banner.info  { background: rgba(0,119,255,.08);  border-color: var(--accent2); color: var(--accent2); }

  /* ── Drop zone ── */
  .drop-zone {
    border: 2px dashed var(--border);
    border-radius: var(--radius);
    padding: 32px 24px;
    text-align: center;
    transition: border-color .2s, background .2s;
    cursor: pointer;
    margin-bottom: 16px;
    position: relative;
  }
  .drop-zone.drag-over {
    border-color: var(--accent);
    background: rgba(0,229,160,.04);
  }
  .drop-zone input[type=file] {
    position: absolute; inset: 0;
    opacity: 0; cursor: pointer;
    width: 100%; height: 100%;
    padding: 0;
  }
  .drop-icon { font-size: 30px; margin-bottom: 10px; }
  .drop-label { font-size: 13px; color: var(--muted); font-family: var(--mono); }
  .drop-label span { color: var(--accent2); }
  .drop-selected { font-size: 12px; color: var(--accent); margin-top: 8px; font-family: var(--mono); display: none; }

  /* ── Toggle switch ── */
  .toggle-row {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 16px;
    cursor: pointer;
    user-select: none;
  }
  .toggle-track {
    width: 38px; height: 20px;
    background: var(--border);
    border-radius: 10px;
    position: relative;
    transition: background .2s;
    flex-shrink: 0;
  }
  .toggle-track.on { background: var(--accent); }
  .toggle-knob {
    width: 14px; height: 14px;
    background: #fff;
    border-radius: 50%;
    position: absolute;
    top: 3px; left: 3px;
    transition: left .2s;
  }
  .toggle-track.on .toggle-knob { left: 21px; }
  .toggle-label { font-size: 13px; color: var(--muted); }
  .toggle-label.on { color: var(--text); }

  /* ── Info panel ── */
  .info-panel {
    display: none;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    overflow: hidden;
    margin-bottom: 16px;
  }
  .info-panel.visible { display: block; }

  .mode-tabs {
    display: flex;
    border-bottom: 1px solid var(--border);
    background: #080a10;
  }
  .mode-tab {
    flex: 1;
    padding: 10px;
    text-align: center;
    font-family: var(--mono);
    font-size: 12px;
    color: var(--muted);
    cursor: pointer;
    border: none;
    background: none;
    border-bottom: 2px solid transparent;
    transition: color .15s, border-color .15s;
  }
  .mode-tab.active { color: var(--accent); border-bottom-color: var(--accent); }

  .mode-body { padding: 20px; background: var(--surface); }

  /* ── JSON field builder ── */
  .field-list { display: flex; flex-direction: column; gap: 8px; margin-bottom: 12px; }
  .field-row {
    display: grid;
    grid-template-columns: 1fr 1.6fr auto;
    gap: 8px;
    align-items: center;
  }
  .field-row input[type=text] {
    padding: 7px 10px;
    font-size: 12px;
  }
  .field-row .auto-badge {
    font-family: var(--mono);
    font-size: 10px;
    color: var(--muted);
    background: #080a10;
    border: 1px solid var(--border);
    border-radius: 3px;
    padding: 2px 6px;
    white-space: nowrap;
  }
  .add-field-row {
    display: flex;
    gap: 8px;
  }

  /* ── Counter ── */
  .byte-counter {
    font-family: var(--mono);
    font-size: 11px;
    color: var(--muted);
    margin-top: 6px;
    text-align: right;
  }
  .byte-counter.warn  { color: var(--yellow); }
  .byte-counter.over  { color: var(--red); }

  /* ── Stats grid ── */
  .stat-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 12px;
    margin-bottom: 20px;
  }
  .stat-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 16px;
    text-align: center;
  }
  .stat-val   { font-size: 26px; font-weight: 600; font-family: var(--mono); color: var(--accent2); }
  .stat-label { font-size: 11px; color: var(--muted); margin-top: 4px; text-transform: uppercase; letter-spacing: .08em; }

  /* ── Table ── */
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th {
    text-align: left;
    font-size: 11px;
    font-weight: 600;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: .08em;
    padding: 0 12px 10px;
    border-bottom: 1px solid var(--border);
  }
  td { padding: 10px 12px; border-bottom: 1px solid var(--border); vertical-align: middle; }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: rgba(255,255,255,.02); }
  .mono { font-family: var(--mono); font-size: 12px; }
  a.dl-link {
    color: var(--accent2);
    font-family: var(--mono);
    font-size: 11px;
    text-decoration: none;
    border: 1px solid var(--accent2);
    padding: 3px 9px;
    border-radius: var(--radius);
    transition: background .15s;
  }
  a.dl-link:hover { background: rgba(0,119,255,.12); }

  /* ── Info pill ── */
  .has-info {
    display: inline-block;
    font-family: var(--mono);
    font-size: 10px;
    color: var(--accent);
    border: 1px solid var(--accent);
    border-radius: 3px;
    padding: 1px 5px;
    margin-left: 6px;
  }

  /* ── Hash display ── */
  .hash-display {
    font-family: var(--mono);
    font-size: 11px;
    color: var(--muted);
    word-break: break-all;
    letter-spacing: .04em;
  }

  /* ── How it works ── */
  .step { display: flex; gap: 16px; margin-bottom: 18px; }
  .step-num {
    width: 26px; height: 26px;
    background: var(--accent);
    color: #0d0f14;
    border-radius: 50%;
    font-size: 12px;
    font-weight: 700;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
    margin-top: 1px;
  }
  .step-body { line-height: 1.7; font-size: 13px; }
  .step-body strong { color: var(--accent); }
  code {
    background: #080a10;
    border: 1px solid var(--border);
    border-radius: 3px;
    padding: 1px 5px;
    font-family: var(--mono);
    font-size: 11px;
    color: var(--accent);
  }

  /* ── JSON preview ── */
  .json-preview {
    background: #080a10;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 14px 16px;
    font-family: var(--mono);
    font-size: 12px;
    color: var(--accent);
    margin-top: 12px;
    white-space: pre-wrap;
    word-break: break-all;
    max-height: 180px;
    overflow-y: auto;
    display: none;
  }

  /* ── Scrollbar ── */
  ::-webkit-scrollbar { width: 6px; height: 6px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }
</style>
</head>
<body>

<!-- ── Header ────────────────────────────────────────────────── -->
<div class="header">
  <div class="header-logo">
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 3v12M12 3l-4 4M12 3l4 4" stroke="#0d0f14" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
      <rect x="3" y="16" width="18" height="5" rx="2" fill="#0d0f14" opacity=".9"/>
      <circle cx="7.5" cy="18.5" r="1" fill="#00e5a0"/>
      <circle cx="12"  cy="18.5" r="1" fill="#00e5a0"/>
      <circle cx="16.5" cy="18.5" r="1" fill="#00e5a0"/>
    </svg>
  </div>
  <div>
    <div class="header-title">Meento Uploader</div>
    <div class="header-sub">sha256 · store · tag</div>
  </div>
  <div class="header-links">
    <a href="downloader.php" class="header-link">Downloader</a>
  </div>
</div>

<div class="container">

  <!-- ── Banners ── -->
  <?php foreach ($banners as [$type, $msg]): ?>
  <div class="banner <?= htmlspecialchars($type) ?>"><?= htmlspecialchars($msg) ?></div>
  <?php endforeach; ?>

  <!-- ── Tabs ── -->
  <nav>
    <button onclick="switchTab('upload', this)" class="<?= $tab==='upload' ? 'active' : '' ?>">Upload</button>
    <button onclick="switchTab('files',  this)" class="<?= $tab==='files'  ? 'active' : '' ?>">
      Files (<?= count($files) ?>)
    </button>
    <button onclick="switchTab('howto',  this)" class="<?= $tab==='howto'  ? 'active' : '' ?>">How It Works</button>
  </nav>

  <!-- ════════════════════════════════════════════════════════════
       UPLOAD TAB
  ════════════════════════════════════════════════════════════ -->
  <div id="tab-upload" class="tab <?= $tab==='upload' ? 'active' : '' ?>">

    <form method="POST" enctype="multipart/form-data" id="uploadForm">
      <input type="hidden" name="tab" value="upload">

      <!-- Drop zone -->
      <div class="card">
        <div class="card-title">Select File</div>

        <div class="drop-zone" id="dropZone">
          <input type="file" name="upload_file" id="fileInput" onchange="onFileSelected(this)">
          <div class="drop-icon">&#8679;</div>
          <div class="drop-label">Drop a file here or <span>click to browse</span></div>
          <div class="drop-label" style="margin-top:4px; font-size:11px;">.php files are not allowed</div>
          <div class="drop-selected" id="dropSelected"></div>
        </div>

        <button type="submit" name="do_upload" id="submitBtn">&#8679; Upload File</button>
      </div>

      <!-- Metadata toggle -->
      <div class="card">
        <div class="card-title">File Information <span style="font-weight:400; text-transform:none; letter-spacing:0; color:var(--muted);">(optional · max 500 KB)</span></div>

        <div class="toggle-row" onclick="toggleInfo()" id="toggleRow">
          <div class="toggle-track" id="toggleTrack">
            <div class="toggle-knob"></div>
          </div>
          <span class="toggle-label" id="toggleLabel">Add metadata to this file</span>
        </div>
        <input type="hidden" name="enable_info" id="enableInfo" value="">

        <!-- Info panel -->
        <div class="info-panel" id="infoPanel">
          <div class="mode-tabs">
            <button type="button" class="mode-tab active" id="tabJson" onclick="switchMode('json')">JSON Builder</button>
            <button type="button" class="mode-tab"        id="tabRaw"  onclick="switchMode('raw')">Raw JSON</button>
          </div>

          <!-- ── JSON builder ── -->
          <div class="mode-body" id="bodyJson">
            <input type="hidden" name="info_mode" id="infoMode" value="json">

            <div class="field-list" id="fieldList">
              <!-- Default fields injected by JS -->
            </div>

            <div class="add-field-row">
              <input type="text" id="newKey"   placeholder="field name"  style="flex:1">
              <input type="text" id="newVal"   placeholder="value"       style="flex:1.6">
              <button type="button" class="btn-ghost" onclick="addField()">+ Add</button>
            </div>

            <div id="jsonPreview" class="json-preview"></div>
            <div class="byte-counter" id="jsonCounter">0 B / 500 KB</div>
          </div>

          <!-- ── Raw JSON ── -->
          <div class="mode-body" id="bodyRaw" style="display:none">
            <div class="field">
              <label for="raw_info">Paste raw JSON content</label>
              <textarea name="raw_info" id="rawInfo" placeholder='{"filename":"example.pdf","author":"Alice","tag":"report"}'></textarea>
              <div class="byte-counter" id="rawCounter">0 B / 500 KB</div>
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>

  <!-- ════════════════════════════════════════════════════════════
       FILES TAB
  ════════════════════════════════════════════════════════════ -->
  <div id="tab-files" class="tab <?= $tab==='files' ? 'active' : '' ?>">

    <div class="stat-grid">
      <div class="stat-card">
        <div class="stat-val"><?= count($files) ?></div>
        <div class="stat-label">Files</div>
      </div>
      <div class="stat-card">
        <div class="stat-val"><?= formatBytes($totalSize) ?></div>
        <div class="stat-label">Total Size</div>
      </div>
      <div class="stat-card">
        <div class="stat-val"><?= count(array_filter($files, function($f){ return $f['info'] !== null; })) ?></div>
        <div class="stat-label">With Metadata</div>
      </div>
    </div>

    <?php if (empty($files)): ?>
    <div class="card">
      <p style="color:var(--muted); font-family:var(--mono); font-size:13px;">No files uploaded yet.</p>
    </div>
    <?php else: ?>
    <div class="card">
      <div class="card-title">Stored Files</div>
      <table>
        <tr>
          <th>SHA-256 / Name</th>
          <th>Size</th>
          <th>Date</th>
          <th></th>
        </tr>
        <?php foreach ($files as $f): ?>
        <?php
          $displayName = $f['hash'];
          if (isset($f['info']['filename']) && $f['info']['filename'] !== '')
              $displayName = htmlspecialchars($f['info']['filename']);
        ?>
        <tr>
          <td>
            <div style="font-family:var(--mono); font-size:12px; color:var(--text);">
              <?= $displayName ?>
              <?php if ($f['info'] !== null): ?>
              <span class="has-info">info</span>
              <?php endif; ?>
            </div>
            <div class="hash-display"><?= htmlspecialchars($f['hash']) ?></div>
          </td>
          <td class="mono"><?= formatBytes($f['size']) ?></td>
          <td class="mono" style="color:var(--muted)"><?= date('Y-m-d H:i', $f['mtime']) ?></td>
          <td style="white-space:nowrap">
            <a class="dl-link" href="?serve=<?= urlencode($f['hash']) ?>">&#8659; Download</a>
          </td>
        </tr>
        <?php if ($f['info'] !== null): ?>
        <tr>
          <td colspan="4" style="padding:0 12px 12px; border-bottom: 1px solid var(--border);">
            <div style="background:#080a10; border:1px solid var(--border); border-radius:var(--radius); padding:10px 14px; font-family:var(--mono); font-size:11px; color:var(--muted); white-space:pre-wrap; max-height:120px; overflow-y:auto;"><?= htmlspecialchars(json_encode($f['info'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) ?></div>
          </td>
        </tr>
        <?php endif; ?>
        <?php endforeach; ?>
      </table>
    </div>
    <?php endif; ?>
  </div>

  <!-- ════════════════════════════════════════════════════════════
       HOW IT WORKS TAB
  ════════════════════════════════════════════════════════════ -->
  <div id="tab-howto" class="tab <?= $tab==='howto' ? 'active' : '' ?>">
    <div class="card">
      <div class="card-title">Upload Logic</div>

      <div class="step">
        <div class="step-num">1</div>
        <div class="step-body">
          <strong>SHA-256 hash</strong> — Once uploaded, the file's SHA-256 is computed with
          <code>hash_file('sha256', $tmpPath)</code>. This becomes the permanent filename stored in <code>files/</code>.
        </div>
      </div>

      <div class="step">
        <div class="step-num">2</div>
        <div class="step-body">
          <strong>Deduplication</strong> — If <code>files/&lt;sha256&gt;</code> already exists the file
          is not written again. Identical content always maps to the same hash.
        </div>
      </div>

      <div class="step">
        <div class="step-num">3</div>
        <div class="step-body">
          <strong>PHP blocked</strong> — Any file whose extension is <code>.php</code> is rejected before
          touching the filesystem.
        </div>
      </div>

      <div class="step">
        <div class="step-num">4</div>
        <div class="step-body">
          <strong>Optional metadata</strong> — Toggle the info panel to attach a JSON document.
          Choose the <em>JSON Builder</em> (key-value editor with auto-filled
          <code>filename</code>, <code>date</code>, <code>hash</code> fields) or paste
          <em>Raw JSON</em> directly.
        </div>
      </div>

      <div class="step">
        <div class="step-num">5</div>
        <div class="step-body">
          <strong>Metadata storage</strong> — Saved as <code>info/&lt;sha256&gt;.json</code>.
          If a metadata file for that hash already exists it is never overwritten.
          Total info size is capped at <strong>500 KB</strong>.
        </div>
      </div>

      <div class="step">
        <div class="step-num">6</div>
        <div class="step-body">
          <strong>Download</strong> — Click the download button in the Files tab.
          If a <code>filename</code> field exists in the metadata it is used as the
          suggested download name; otherwise the SHA-256 hash is used.
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-title">Directory Layout</div>
      <div style="background:#080a10; border:1px solid var(--border); border-radius:var(--radius); padding:14px 16px; font-family:var(--mono); font-size:12px; line-height:1.8;">
        <div style="color:var(--accent);">files/                         &larr; stored files (no extension)</div>
        <div style="color:var(--accent);">  &lt;sha256hex&gt;                  &larr; raw file bytes</div>
        <div style="color:var(--accent2); margin-top:4px;">info/                          &larr; optional metadata</div>
        <div style="color:var(--accent2);">  &lt;sha256hex&gt;.json             &larr; JSON document</div>
      </div>
    </div>
  </div>

</div><!-- /container -->

<script>
// ── Tab switching ────────────────────────────────────────────
function switchTab(name, btn) {
  document.querySelectorAll('.tab').forEach(function(t){ t.classList.remove('active'); });
  document.querySelectorAll('nav button').forEach(function(b){ b.classList.remove('active'); });
  document.getElementById('tab-' + name).classList.add('active');
  btn.classList.add('active');
}

// ── Drop-zone drag feedback ──────────────────────────────────
var dz = document.getElementById('dropZone');
dz.addEventListener('dragover', function(e){ e.preventDefault(); dz.classList.add('drag-over'); });
dz.addEventListener('dragleave', function(){ dz.classList.remove('drag-over'); });
dz.addEventListener('drop', function(e){ dz.classList.remove('drag-over'); });

function onFileSelected(input) {
  var sel = document.getElementById('dropSelected');
  if (input.files && input.files[0]) {
    var f = input.files[0];
    sel.style.display = 'block';
    sel.textContent = f.name + '  (' + formatBytes(f.size) + ')';
  } else {
    sel.style.display = 'none';
  }
}

function formatBytes(b) {
  if (b >= 1048576) return (b/1048576).toFixed(2) + ' MB';
  if (b >= 1024)    return (b/1024).toFixed(2) + ' KB';
  return b + ' B';
}

// ── Info toggle ──────────────────────────────────────────────
var infoOpen = false;
function toggleInfo() {
  infoOpen = !infoOpen;
  var track = document.getElementById('toggleTrack');
  var label = document.getElementById('toggleLabel');
  var panel = document.getElementById('infoPanel');
  var inp   = document.getElementById('enableInfo');
  track.classList.toggle('on', infoOpen);
  label.classList.toggle('on', infoOpen);
  panel.classList.toggle('visible', infoOpen);
  inp.value = infoOpen ? '1' : '';
}

// ── Mode switching (JSON builder / Raw) ──────────────────────
var currentMode = 'json';
function switchMode(mode) {
  currentMode = mode;
  document.getElementById('infoMode').value = mode;
  document.getElementById('tabJson').classList.toggle('active', mode === 'json');
  document.getElementById('tabRaw').classList.toggle('active',  mode === 'raw');
  document.getElementById('bodyJson').style.display = mode === 'json' ? '' : 'none';
  document.getElementById('bodyRaw').style.display  = mode === 'raw'  ? '' : 'none';
}

// ── JSON field builder ───────────────────────────────────────
var fields = []; // [{key, val, auto}]

function initDefaultFields() {
  var now = new Date().toISOString().slice(0,10);
  fields = [
    { key: 'filename', val: '', auto: true },
    { key: 'date',     val: now, auto: true },
    { key: 'hash',     val: '(computed on upload)', auto: true },
  ];
  renderFields();
}

function renderFields() {
  var list = document.getElementById('fieldList');
  list.innerHTML = '';
  fields.forEach(function(f, i) {
    var row = document.createElement('div');
    row.className = 'field-row';

    var keyIn = document.createElement('input');
    keyIn.type = 'text'; keyIn.name = 'field_keys[]';
    keyIn.value = f.key;
    keyIn.placeholder = 'key';
    keyIn.oninput = function(){ fields[i].key = this.value; updatePreview(); };

    var valIn = document.createElement('input');
    valIn.type = 'text'; valIn.name = 'field_vals[]';
    valIn.value = f.val;
    valIn.placeholder = f.auto ? '(auto-filled)' : 'value';
    valIn.oninput = function(){ fields[i].val = this.value; updatePreview(); };

    var del = document.createElement('button');
    del.type = 'button';
    del.className = 'btn-danger';
    del.textContent = '×';
    del.onclick = function(){ fields.splice(i,1); renderFields(); updatePreview(); };

    if (f.auto) {
      var badge = document.createElement('span');
      badge.className = 'auto-badge';
      badge.textContent = 'auto';
      row.appendChild(keyIn);
      row.appendChild(valIn);
      row.appendChild(del);
    } else {
      row.appendChild(keyIn);
      row.appendChild(valIn);
      row.appendChild(del);
    }
    list.appendChild(row);
  });
  updatePreview();
}

function addField() {
  var k = document.getElementById('newKey').value.trim();
  var v = document.getElementById('newVal').value.trim();
  if (!k) return;
  fields.push({ key: k, val: v, auto: false });
  document.getElementById('newKey').value = '';
  document.getElementById('newVal').value = '';
  renderFields();
}

function updatePreview() {
  var obj = {};
  fields.forEach(function(f){
    if (f.key.trim()) obj[f.key.trim()] = f.val;
  });
  var str = JSON.stringify(obj, null, 2);
  var preview = document.getElementById('jsonPreview');
  preview.style.display = fields.length ? 'block' : 'none';
  preview.textContent = str;

  var bytes = new TextEncoder().encode(str).length;
  var counter = document.getElementById('jsonCounter');
  counter.textContent = formatBytes(bytes) + ' / 500 KB';
  counter.className = 'byte-counter' + (bytes > 512000 ? ' over' : bytes > 400000 ? ' warn' : '');
}

// ── Raw counter ──────────────────────────────────────────────
document.getElementById('rawInfo').addEventListener('input', function() {
  var bytes = new TextEncoder().encode(this.value).length;
  var counter = document.getElementById('rawCounter');
  counter.textContent = formatBytes(bytes) + ' / 500 KB';
  counter.className = 'byte-counter' + (bytes > 512000 ? ' over' : bytes > 400000 ? ' warn' : '');
});

// ── File input → auto-fill filename field ────────────────────
document.getElementById('fileInput').addEventListener('change', function() {
  if (!this.files || !this.files[0]) return;
  var name = this.files[0].name;
  var ff = fields.find(function(f){ return f.key === 'filename'; });
  if (ff && ff.val === '') {
    ff.val = name;
    renderFields();
  }
});

// ── Init ─────────────────────────────────────────────────────
initDefaultFields();
</script>
</body>
</html>