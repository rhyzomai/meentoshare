﻿// 1. At the top (after the define block)
//require_once __DIR__ . '/blockchain.php';
//(new MeshBlockchain())->handlePeerPushRequest();

//2. Or just before the final jsonOut in the upload handler
$chain    = new MeshBlockchain();
$bcResult = $chain->handleSuccessfulUpload(
    $local, $peerResults,
    $upload['name'], $description, $publicKey, $nodeInfo,
    $servers
);