﻿<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  MESH REWARDS — Decentralized reputation scoring
//
//  Score formula:
//    score(pubkey) = Σ files_owned × W_FILE
//                 + Σ (servers_hosting_file × W_HOST) per file
//
//  W_FILE  = 10   pts  — reward for each unique file uploaded
//  W_HOST  = 5    pts  — reward per additional node that hosts the file
//
//  All data is derived from local info/*.json + querying peers via HTTP.
//  No central authority. Any node can compute any pubkey's score independently.
// ═══════════════════════════════════════════════════════════════════════════════

define('FILES_DIR',     __DIR__ . '/files');
define('INFO_DIR',      __DIR__ . '/info');
define('SERVERS_FILE',  __DIR__ . '/servers.txt');
define('SCORE_CACHE',   __DIR__ . '/scores.json');   // local cache (optional)
define('W_FILE',        10);   // points per file owned
define('W_HOST',        5);    // points per peer hosting the file
define('PEER_TIMEOUT',  8);    // seconds per peer HTTP call

// ── helpers ───────────────────────────────────────────────────────────────────

function loadServers(): array {
    if (!file_exists(SERVERS_FILE)) return [];
    $lines = file(SERVERS_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $out = [];
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '') continue;
        if (!preg_match('#^https?://#i', $line)) $line = 'http://' . $line;
        $out[] = rtrim($line, '/');
    }
    return array_unique($out);
}

function jsonOut(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// ── local data ────────────────────────────────────────────────────────────────

/**
 * Scan INFO_DIR and return a map:
 *   [ hash => [ 'public_key' => ..., 'extension' => ..., 'size' => ..., ... ] ]
 */
function localInfoMap(): array {
    $map = [];
    if (!is_dir(INFO_DIR)) return $map;
    foreach (glob(INFO_DIR . '/*.json') as $path) {
        $hash = basename($path, '.json');
        $raw  = @file_get_contents($path);
        if ($raw === false) continue;
        $info = json_decode($raw, true);
        if (!is_array($info)) continue;
        $map[$hash] = $info;
    }
    return $map;
}

/**
 * Group local hashes by public_key.
 * Returns: [ pubkey => [ hash, hash, ... ] ]
 */
function localFilesByKey(array $infoMap): array {
    $byKey = [];
    foreach ($infoMap as $hash => $info) {
        $pk = trim($info['public_key'] ?? '');
        if ($pk === '') $pk = '__anonymous__';
        $byKey[$pk][] = $hash;
    }
    return $byKey;
}

// ── peer queries ──────────────────────────────────────────────────────────────

/**
 * Ask a peer node which of the given hashes it holds locally.
 * Calls: GET {peer}/rewards.php?check_hashes=1&hashes[]=hash1&hashes[]=hash2…
 *
 * Returns array of hashes the peer confirmed it has, or [] on failure.
 */
function peerHasHashes(string $peer, array $hashes): array {
    if (empty($hashes)) return [];

    $qs  = http_build_query(['check_hashes' => '1', 'hashes' => $hashes]);
    $url = rtrim($peer, '/') . '/rewards.php?' . $qs;

    $ctx = stream_context_create([
        'http' => [
            'method'        => 'GET',
            'header'        => "X-Mesh-Node: 1\r\n",
            'timeout'       => PEER_TIMEOUT,
            'ignore_errors' => true,
        ],
        'ssl' => [
            'verify_peer'      => false, // TODO: enable with proper CA bundle
            'verify_peer_name' => false,
        ],
    ]);

    $raw = @file_get_contents($url, false, $ctx);
    if ($raw === false) return [];

    $decoded = json_decode($raw, true);
    if (!isset($decoded['present']) || !is_array($decoded['present'])) return [];

    return $decoded['present'];
}

/**
 * Ask a peer for its full scores.json snapshot (for cross-node leaderboard merging).
 * Returns array or [] on failure.
 */
function fetchPeerScores(string $peer): array {
    $url = rtrim($peer, '/') . '/rewards.php?get_scores=1';
    $ctx = stream_context_create([
        'http' => ['method' => 'GET', 'timeout' => PEER_TIMEOUT, 'ignore_errors' => true],
        'ssl'  => ['verify_peer' => false, 'verify_peer_name' => false],
    ]);
    $raw = @file_get_contents($url, false, $ctx);
    if ($raw === false) return [];
    $decoded = json_decode($raw, true);
    return (is_array($decoded) && isset($decoded['scores'])) ? $decoded['scores'] : [];
}

// ── score computation ─────────────────────────────────────────────────────────

/**
 * Compute full scores for all public keys visible on this node,
 * querying all known peers for replication counts.
 *
 * Returns:
 * [
 *   'pubkey_fingerprint' => [
 *     'public_key'   => full key string,
 *     'file_count'   => N,
 *     'total_replicas' => M,   // sum of peer-hosting counts across all files
 *     'score'        => int,
 *     'files'        => [ hash => ['replicas'=>int, 'pts'=>int], ... ]
 *   ], ...
 * ]
 */
function computeScores(bool $queryPeers = true): array {
    $infoMap  = localInfoMap();
    $byKey    = localFilesByKey($infoMap);
    $servers  = $queryPeers ? loadServers() : [];
    $scores   = [];

    // For each public key, score each file
    foreach ($byKey as $pubKey => $hashes) {
        $fileDetails   = [];
        $totalReplicas = 0;
        $totalScore    = 0;

        foreach ($hashes as $hash) {
            $replicaCount = 0;

            // Ask each peer if it has this hash
            foreach ($servers as $peer) {
                $present = peerHasHashes($peer, [$hash]);
                if (in_array($hash, $present, true)) {
                    $replicaCount++;
                }
            }

            $filePts = W_FILE + ($replicaCount * W_HOST);
            $totalReplicas += $replicaCount;
            $totalScore    += $filePts;

            $info = $infoMap[$hash] ?? [];
            $fileDetails[$hash] = [
                'original_filename' => $info['original_filename'] ?? '',
                'extension'         => $info['extension'] ?? '',
                'size'              => $info['size'] ?? 0,
                'replicas'          => $replicaCount,
                'pts'               => $filePts,
            ];
        }

        // Fingerprint: first 16 chars of pubkey for display (full key stored separately)
        $fp = ($pubKey !== '__anonymous__')
            ? substr(preg_replace('/\s+/', '', $pubKey), 0, 16)
            : '__anonymous__';

        $scores[$fp] = [
            'public_key'     => $pubKey,
            'file_count'     => count($hashes),
            'total_replicas' => $totalReplicas,
            'score'          => $totalScore,
            'files'          => $fileDetails,
        ];
    }

    // Sort descending by score
    uasort($scores, function($a, $b) { return $b['score'] <=> $a['score']; });

    return $scores;
}

// ── cache helpers ─────────────────────────────────────────────────────────────

function readCache(): ?array {
    if (!file_exists(SCORE_CACHE)) return null;
    $raw = @file_get_contents(SCORE_CACHE);
    if ($raw === false) return null;
    $d = json_decode($raw, true);
    if (!is_array($d) || !isset($d['computed_at'], $d['scores'])) return null;
    return $d;
}

function writeCache(array $scores): void {
    $payload = json_encode([
        'computed_at' => time(),
        'scores'      => $scores,
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    @file_put_contents(SCORE_CACHE, $payload, LOCK_EX);
}

// ═══════════════════════════════════════════════════════════════════════════════
//  REQUEST ROUTING
// ═══════════════════════════════════════════════════════════════════════════════

// ── 1. Peer probe: which of these hashes do we hold? ─────────────────────────
if (isset($_GET['check_hashes']) && is_array($_GET['hashes'] ?? null)) {
    $requested = array_map('strval', $_GET['hashes']);
    $present   = [];
    foreach ($requested as $h) {
        // Validate: sha256 is 64 lowercase hex chars
        if (!preg_match('/^[a-f0-9]{64}$/', $h)) continue;
        // Check any file with that hash (any extension)
        $glob = glob(FILES_DIR . '/' . $h . '.*');
        if (!empty($glob) || file_exists(FILES_DIR . '/' . $h)) {
            $present[] = $h;
        }
    }
    jsonOut(['present' => $present]);
}

// ── 2. Serve cached scores snapshot to peers ─────────────────────────────────
if (isset($_GET['get_scores'])) {
    $cache = readCache();
    if ($cache) {
        jsonOut($cache);
    } else {
        jsonOut(['scores' => [], 'computed_at' => 0]);
    }
}

// ── 3. Trigger a fresh score computation (can be cron or manual) ─────────────
if (isset($_GET['compute']) && $_SERVER['REQUEST_METHOD'] === 'GET') {
    // Simple protection: only localhost or nodes with a shared secret may trigger
    $secret = trim((string) @file_get_contents(__DIR__ . '/reward_secret.txt'));
    $provided = $_GET['secret'] ?? '';
    $localReq = in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true);

    if (!$localReq && ($secret === '' || !hash_equals($secret, $provided))) {
        jsonOut(['ok' => false, 'error' => 'Unauthorized'], 403);
    }

    $scores = computeScores(true);
    writeCache($scores);
    jsonOut(['ok' => true, 'computed_at' => time(), 'scores' => $scores]);
}

// ── 4. Public leaderboard API ─────────────────────────────────────────────────
if (isset($_GET['leaderboard'])) {
    $cache = readCache();
    if (!$cache) {
        jsonOut(['ok' => false, 'error' => 'No scores computed yet. Call ?compute first.'], 503);
    }
    jsonOut([
        'ok'          => true,
        'computed_at' => $cache['computed_at'],
        'node'        => gethostname(),
        'weights'     => ['per_file' => W_FILE, 'per_replica' => W_HOST],
        'scores'      => $cache['scores'],
    ]);
}

// ── 5. Score for a single public key (query string or POST body) ──────────────
if (isset($_GET['score_for'])) {
    $pubKey = trim(urldecode($_GET['score_for']));
    $cache  = readCache();
    if (!$cache) {
        jsonOut(['ok' => false, 'error' => 'No scores computed yet.'], 503);
    }

    // Match by fingerprint or by full key substring
    foreach ($cache['scores'] as $fp => $entry) {
        if ($fp === $pubKey || strpos($entry['public_key'], $pubKey) !== false) {
            jsonOut(['ok' => true, 'fingerprint' => $fp] + $entry);
        }
    }
    jsonOut(['ok' => false, 'error' => 'Public key not found.'], 404);
}

// ── 6. Federated leaderboard: merge scores from all known peers ───────────────
if (isset($_GET['global_leaderboard'])) {
    $local  = readCache()['scores'] ?? [];
    $merged = $local;

    foreach (loadServers() as $peer) {
        $peerScores = fetchPeerScores($peer);
        foreach ($peerScores as $fp => $entry) {
            if (!isset($merged[$fp]) || $entry['score'] > $merged[$fp]['score']) {
                // Take the higher score (more data wins)
                $merged[$fp] = $entry;
            }
        }
    }

    uasort($merged, function($a, $b) { return $b['score'] <=> $a['score']; });

    jsonOut([
        'ok'      => true,
        'source'  => 'federated',
        'peers'   => count(loadServers()),
        'weights' => ['per_file' => W_FILE, 'per_replica' => W_HOST],
        'scores'  => $merged,
    ]);
}

// ── Default: HTML dashboard ───────────────────────────────────────────────────
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Mesh Rewards</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=DM+Sans:wght@300;400;600&display=swap');

:root {
  --bg: #0a0a0f;
  --surface: #13131a;
  --border: #1e1e2e;
  --accent: #7c3aed;
  --accent2: #06b6d4;
  --gold: #f59e0b;
  --silver: #94a3b8;
  --bronze: #cd7c4a;
  --text: #e2e8f0;
  --muted: #64748b;
  --green: #10b981;
  --red: #ef4444;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
  background: var(--bg);
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  min-height: 100vh;
  overflow-x: hidden;
}

/* grid bg */
body::before {
  content: '';
  position: fixed;
  inset: 0;
  background-image:
    linear-gradient(rgba(124,58,237,.04) 1px, transparent 1px),
    linear-gradient(90deg, rgba(124,58,237,.04) 1px, transparent 1px);
  background-size: 40px 40px;
  pointer-events: none;
  z-index: 0;
}

.wrap { max-width: 900px; margin: 0 auto; padding: 2.5rem 1.5rem; position: relative; z-index: 1; }

/* ── header ── */
header { margin-bottom: 2.5rem; display: flex; align-items: flex-start; justify-content: space-between; flex-wrap: wrap; gap: 1rem; }
.logo { font-family: 'Space Mono', monospace; font-size: 1.4rem; font-weight: 700; letter-spacing: -0.03em; }
.logo span { color: var(--accent); }
.logo small { display: block; font-size: 0.65rem; font-weight: 400; color: var(--muted); letter-spacing: 0.12em; text-transform: uppercase; margin-top: 0.2rem; }
.hdr-actions { display: flex; gap: 0.6rem; flex-wrap: wrap; }
.btn { padding: 0.45rem 1rem; border-radius: 6px; font-size: 0.8rem; font-weight: 600; cursor: pointer; border: none; transition: all .18s; font-family: inherit; }
.btn-outline { background: transparent; border: 1px solid var(--border); color: var(--muted); }
.btn-outline:hover { border-color: var(--accent); color: var(--accent); }
.btn-primary { background: var(--accent); color: #fff; }
.btn-primary:hover { opacity: 0.85; }
.btn-primary.busy { opacity: 0.5; pointer-events: none; }

/* ── stat cards ── */
.stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
.stat-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 1.1rem 1.2rem;
  position: relative;
  overflow: hidden;
}
.stat-card::after {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 2px;
  background: linear-gradient(90deg, var(--accent), var(--accent2));
  opacity: 0;
  transition: opacity .25s;
}
.stat-card:hover::after { opacity: 1; }
.stat-label { font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.1em; color: var(--muted); margin-bottom: 0.5rem; }
.stat-val { font-family: 'Space Mono', monospace; font-size: 1.7rem; font-weight: 700; color: var(--text); }
.stat-val.accent { color: var(--accent); }
.stat-val.cyan { color: var(--accent2); }
.stat-val.gold { color: var(--gold); }

/* ── formula ── */
.formula-box {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 1rem 1.4rem;
  margin-bottom: 2rem;
  display: flex;
  align-items: center;
  gap: 1.5rem;
  flex-wrap: wrap;
}
.formula-label { font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.1em; color: var(--muted); }
.formula-text { font-family: 'Space Mono', monospace; font-size: 0.88rem; color: var(--accent2); }
.weight-pills { display: flex; gap: 0.5rem; margin-left: auto; flex-wrap: wrap; }
.wpill { font-size: 0.75rem; padding: 0.25rem 0.7rem; border-radius: 999px; background: rgba(124,58,237,.15); border: 1px solid rgba(124,58,237,.3); color: var(--accent); font-family: 'Space Mono', monospace; }
.wpill.cyan { background: rgba(6,182,212,.1); border-color: rgba(6,182,212,.3); color: var(--accent2); }

/* ── leaderboard ── */
.section-title {
  font-size: 0.72rem;
  text-transform: uppercase;
  letter-spacing: 0.12em;
  color: var(--muted);
  margin-bottom: 1rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
.section-title::after {
  content: '';
  flex: 1;
  height: 1px;
  background: var(--border);
}

.leaderboard { display: flex; flex-direction: column; gap: 0.6rem; margin-bottom: 2rem; }

.entry {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 10px;
  overflow: hidden;
  transition: border-color .18s;
}
.entry:hover { border-color: rgba(124,58,237,.4); }
.entry-head {
  display: grid;
  grid-template-columns: 2.4rem 1fr auto auto;
  align-items: center;
  gap: 1rem;
  padding: 0.85rem 1.1rem;
  cursor: pointer;
}
.rank {
  font-family: 'Space Mono', monospace;
  font-size: 0.85rem;
  font-weight: 700;
  text-align: center;
  width: 2rem;
  height: 2rem;
  border-radius: 6px;
  display: grid;
  place-items: center;
}
.rank.r1 { background: rgba(245,158,11,.15); color: var(--gold); border: 1px solid rgba(245,158,11,.3); }
.rank.r2 { background: rgba(148,163,184,.1); color: var(--silver); border: 1px solid rgba(148,163,184,.3); }
.rank.r3 { background: rgba(205,124,74,.1); color: var(--bronze); border: 1px solid rgba(205,124,74,.3); }
.rank.rn { background: rgba(100,116,139,.08); color: var(--muted); border: 1px solid var(--border); }

.entry-key { min-width: 0; }
.key-fp { font-family: 'Space Mono', monospace; font-size: 0.82rem; color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.key-sub { font-size: 0.72rem; color: var(--muted); margin-top: 0.15rem; }

.entry-meta { display: flex; gap: 0.5rem; align-items: center; }
.badge { font-size: 0.72rem; padding: 0.2rem 0.55rem; border-radius: 4px; font-family: 'Space Mono', monospace; white-space: nowrap; }
.badge-files { background: rgba(6,182,212,.1); color: var(--accent2); border: 1px solid rgba(6,182,212,.2); }
.badge-rep { background: rgba(16,185,129,.1); color: var(--green); border: 1px solid rgba(16,185,129,.2); }

.entry-score { font-family: 'Space Mono', monospace; font-size: 1.1rem; font-weight: 700; color: var(--accent); white-space: nowrap; }

/* expand chevron */
.entry-head .chev { display: inline-block; transition: transform .2s; color: var(--muted); font-size: 0.8rem; }
.entry.open .chev { transform: rotate(90deg); }

/* file list */
.file-list {
  display: none;
  border-top: 1px solid var(--border);
  padding: 0.6rem 1.1rem 0.8rem;
  background: rgba(0,0,0,.2);
}
.entry.open .file-list { display: block; }
.file-row {
  display: grid;
  grid-template-columns: 2rem 1fr auto auto;
  align-items: center;
  gap: 0.8rem;
  padding: 0.45rem 0;
  border-bottom: 1px solid rgba(30,30,46,.6);
  font-size: 0.8rem;
}
.file-row:last-child { border-bottom: none; }
.file-ext { font-family: 'Space Mono', monospace; font-size: 0.65rem; padding: 0.1rem 0.35rem; border-radius: 3px; background: var(--border); color: var(--muted); text-transform: uppercase; text-align: center; }
.file-name { color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; min-width: 0; }
.file-rep { color: var(--green); font-family: 'Space Mono', monospace; white-space: nowrap; font-size: 0.75rem; }
.file-pts { color: var(--accent); font-family: 'Space Mono', monospace; font-size: 0.75rem; white-space: nowrap; }

/* ── empty / loading ── */
.state-msg { text-align: center; padding: 3rem 1rem; color: var(--muted); font-size: 0.9rem; }
.spinner { display: inline-block; width: 1.2rem; height: 1.2rem; border: 2px solid var(--border); border-top-color: var(--accent); border-radius: 50%; animation: spin .7s linear infinite; vertical-align: middle; margin-right: 0.5rem; }
@keyframes spin { to { transform: rotate(360deg); } }

.toast {
  position: fixed; bottom: 1.5rem; right: 1.5rem;
  background: var(--surface); border: 1px solid var(--border);
  border-radius: 8px; padding: 0.7rem 1.2rem;
  font-size: 0.82rem; z-index: 999;
  animation: fadeUp .25s ease;
  max-width: 280px;
}
.toast.ok { border-color: var(--green); color: var(--green); }
.toast.err { border-color: var(--red); color: var(--red); }
@keyframes fadeUp { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }

/* ── footer ── */
footer { font-size: 0.72rem; color: var(--muted); border-top: 1px solid var(--border); padding-top: 1.2rem; margin-top: 1rem; display: flex; justify-content: space-between; flex-wrap: wrap; gap: 0.5rem; }
footer a { color: var(--muted); text-decoration: none; }
footer a:hover { color: var(--accent); }

@media (max-width: 560px) {
  .entry-head { grid-template-columns: 2rem 1fr auto; }
  .entry-meta { display: none; }
}
</style>
</head>
<body>
<div class="wrap">

<header>
  <div class="logo">
    Mesh<span>·</span>Rewards
    <small>Decentralized Reputation Scoring</small>
  </div>
  <div class="hdr-actions">
    <a href="index.php" class="btn btn-outline">← Node</a>
    <button class="btn btn-outline" id="btn-global">🌐 Global</button>
    <button class="btn btn-primary" id="btn-compute">⚙ Compute</button>
  </div>
</header>

<div class="stats">
  <div class="stat-card">
    <div class="stat-label">Nodes in network</div>
    <div class="stat-val accent" id="s-peers">—</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Unique identities</div>
    <div class="stat-val cyan" id="s-keys">—</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Total files scored</div>
    <div class="stat-val" id="s-files">—</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Top score</div>
    <div class="stat-val gold" id="s-top">—</div>
  </div>
</div>

<div class="formula-box">
  <div>
    <div class="formula-label">Scoring formula</div>
    <div class="formula-text">score = Σ (W_FILE + replicas × W_HOST)</div>
  </div>
  <div class="weight-pills">
    <span class="wpill" id="w-file">W_FILE = <?= W_FILE ?></span>
    <span class="wpill cyan" id="w-host">W_HOST = <?= W_HOST ?></span>
  </div>
</div>

<div class="section-title">Leaderboard</div>
<div class="leaderboard" id="board">
  <div class="state-msg"><span class="spinner"></span>Loading scores…</div>
</div>

</div><!-- .wrap -->

<footer class="wrap">
  <span>Mesh Rewards · computed at <span id="computed-at">—</span></span>
  <span>PHP <?= PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION ?></span>
</footer>

<script>
(function(){
'use strict';

const board      = document.getElementById('board');
const sPeers     = document.getElementById('s-peers');
const sKeys      = document.getElementById('s-keys');
const sFiles     = document.getElementById('s-files');
const sTop       = document.getElementById('s-top');
const compAt     = document.getElementById('computed-at');
const btnCompute = document.getElementById('btn-compute');
const btnGlobal  = document.getElementById('btn-global');

const rankClass = i => i === 0 ? 'r1' : i === 1 ? 'r2' : i === 2 ? 'r3' : 'rn';
const fmt  = n => Number(n).toLocaleString();
const fmtDate = ts => ts ? new Date(ts*1000).toLocaleString() : '—';
const truncKey = k => k === '__anonymous__' ? '— anonymous —' : (k.length > 40 ? k.slice(0,20)+'…'+k.slice(-12) : k);

function toast(msg, type='ok'){
  const t = document.createElement('div');
  t.className = 'toast ' + type;
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(()=>t.remove(), 3200);
}

function renderBoard(data){
  const scores = data.scores || {};
  const entries = Object.entries(scores);

  // Stats
  sPeers.textContent = fmt(data.peers ?? '—');
  sKeys.textContent  = fmt(entries.length);
  compAt.textContent = fmtDate(data.computed_at);

  let totalFiles = 0, topScore = 0;
  entries.forEach(([,e])=>{ totalFiles += e.file_count||0; topScore = Math.max(topScore, e.score||0); });
  sFiles.textContent = fmt(totalFiles);
  sTop.textContent   = fmt(topScore) + ' pts';

  if (entries.length === 0){
    board.innerHTML = '<div class="state-msg">No scores yet. Click <b>Compute</b> to calculate.</div>';
    return;
  }

  board.innerHTML = '';
  entries.forEach(([fp, entry], idx) => {
    const div = document.createElement('div');
    div.className = 'entry';

    const fileRows = Object.entries(entry.files||{}).map(([hash, f])=>`
      <div class="file-row">
        <span class="file-ext">${esc(f.extension||'—')}</span>
        <span class="file-name" title="${esc(hash)}">${esc(f.original_filename||hash)}</span>
        <span class="file-rep">⬡ ${f.replicas} replica${f.replicas!==1?'s':''}</span>
        <span class="file-pts">+${fmt(f.pts)} pts</span>
      </div>`).join('');

    div.innerHTML = `
      <div class="entry-head" role="button" tabindex="0">
        <div class="rank ${rankClass(idx)}">${idx+1}</div>
        <div class="entry-key">
          <div class="key-fp">${esc(truncKey(entry.public_key||fp))}</div>
          <div class="key-sub">fingerprint: ${esc(fp)}</div>
        </div>
        <div class="entry-meta">
          <span class="badge badge-files">📄 ${fmt(entry.file_count)} file${entry.file_count!==1?'s':''}</span>
          <span class="badge badge-rep">⬡ ${fmt(entry.total_replicas)} rep.</span>
        </div>
        <div style="display:flex;align-items:center;gap:.7rem">
          <div class="entry-score">${fmt(entry.score)} <span style="font-size:.65rem;color:var(--muted)">pts</span></div>
          <span class="chev">›</span>
        </div>
      </div>
      <div class="file-list">${fileRows || '<div style="color:var(--muted);font-size:.8rem;padding:.3rem 0">No file details available.</div>'}</div>
    `;

    const head = div.querySelector('.entry-head');
    head.addEventListener('click', ()=> div.classList.toggle('open'));
    head.addEventListener('keydown', e=>{ if(e.key==='Enter'||e.key===' ') div.classList.toggle('open'); });
    board.appendChild(div);
  });
}

function esc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

// Load cached leaderboard on page open
fetch('rewards.php?leaderboard=1')
  .then(r=>r.json())
  .then(d=>{
    if(!d.ok){ board.innerHTML='<div class="state-msg">No scores cached yet. Click <b>Compute</b>.</div>'; return; }
    renderBoard(d);
    toast('Scores loaded from cache');
  })
  .catch(()=>{ board.innerHTML='<div class="state-msg">Could not reach rewards API.</div>'; });

// Compute button — triggers fresh peer-querying computation
btnCompute.addEventListener('click', ()=>{
  const secret = prompt('Enter reward_secret.txt (leave blank if localhost):','');
  btnCompute.classList.add('busy');
  btnCompute.textContent = '⏳ Computing…';
  const qs = secret ? '?compute=1&secret='+encodeURIComponent(secret) : '?compute=1';
  fetch('rewards.php'+qs)
    .then(r=>r.json())
    .then(d=>{
      btnCompute.classList.remove('busy');
      btnCompute.textContent = '⚙ Compute';
      if(!d.ok){ toast('Error: '+(d.error||'unknown'), 'err'); return; }
      renderBoard(d);
      toast('Scores recomputed ✓');
    })
    .catch(()=>{ btnCompute.classList.remove('busy'); btnCompute.textContent='⚙ Compute'; toast('Compute failed','err'); });
});

// Global button — fetches federated scores from all peers
btnGlobal.addEventListener('click', ()=>{
  btnGlobal.textContent = '⏳ Fetching…';
  fetch('rewards.php?global_leaderboard=1')
    .then(r=>r.json())
    .then(d=>{
      btnGlobal.textContent = '🌐 Global';
      if(!d.ok){ toast('Error: '+(d.error||'unknown'),'err'); return; }
      renderBoard(d);
      toast('Global leaderboard loaded · '+d.peers+' peer(s) queried');
    })
    .catch(()=>{ btnGlobal.textContent='🌐 Global'; toast('Global fetch failed','err'); });
});

})();
</script>
</body>
</html>