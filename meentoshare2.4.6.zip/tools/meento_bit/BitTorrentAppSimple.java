import java.io.*;
import java.math.BigInteger;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/**
 * -------------------------------------------------------------------
 *  BitTorrent-style P2P App  v2.0  �  with Blockchain & RSA Keys
 * -------------------------------------------------------------------
 *
 *  COMMANDS
 *  -----------------------------------------------------------------
 *  port <n>        Change listening port (default 52525)
 *  download        Download all files from peers in servers.txt
 *  peers           List known peers
 *  list            List local files in ./download/
 *  chain           Print the local blockchain
 *  verify          Verify integrity of the local blockchain
 *  whoami          Show your public key (node identity)
 *  status          Show port, server state, active downloads
 *  help            Show this help
 *  exit            Quit
 *
 *  P2P PROTOCOL  (plain TCP)
 *  -----------------------------------------------------------------
 *  LIST                         ? file list
 *  GET  <filename>              ? file bytes
 *  BLOCK <json>                 ? receive + store a new block
 *  BLOCKS                       ? send full chain as newline-delimited JSON
 *
 *  BLOCKCHAIN
 *  -----------------------------------------------------------------
 *  � Each successful download creates a block (JSON file) in ./light_block/
 *  � Block filename  = SHA-256 of block contents (content-addressed)
 *  � Each block links to the previous block hash (genesis = "0"�64)
 *  � Block is signed with the downloader's RSA-512 private key
 *  � Block is broadcast to all peers immediately after creation
 *  � Peers validate signature + chain linkage before accepting
 *
 *  IDENTITY
 *  -----------------------------------------------------------------
 *  � RSA key pair generated on first run, saved to keys/private.key
 *    and keys/public.key (Base64-encoded, custom minimal RSA impl)
 *  � Public key = node identity / "address" shown in blocks
 */
public class BitTorrentApp {

    // -- Constants -------------------------------------------------------------
    private static final int    DEFAULT_PORT    = 52525;
    private static final String SERVERS_FILE    = "servers.txt";
    private static final String DOWNLOAD_DIR    = "download";
    private static final String BLOCK_DIR       = "light_block";
    private static final String KEYS_DIR        = "keys";
    private static final String PRIVATE_KEY_FILE = KEYS_DIR + File.separator + "private.key";
    private static final String PUBLIC_KEY_FILE  = KEYS_DIR + File.separator + "public.key";
    private static final int    CHUNK_SIZE      = 64 * 1024;
    private static final int    CONNECT_TIMEOUT = 5_000;
    private static final int    READ_TIMEOUT    = 30_000;

    // -- Shared state ----------------------------------------------------------
    private static final AtomicInteger   port         = new AtomicInteger(DEFAULT_PORT);
    private static volatile ServerSocket serverSocket = null;
    private static volatile boolean      running      = true;
    private static final Set<String>     activeDLs    = ConcurrentHashMap.newKeySet();

    // -- RSA Identity ----------------------------------------------------------
    private static RsaKey privateKey;
    private static RsaKey publicKey;
    private static String publicKeyB64;   // canonical node identity string

    // -- Blockchain state ------------------------------------------------------
    private static final Object chainLock    = new Object();
    private static String       latestHash   = "0000000000000000000000000000000000000000000000000000000000000000";

    // -------------------------------------------------------------------------
    //  ENTRY POINT
    // -------------------------------------------------------------------------
    public static void main(String[] args) throws Exception {
        ensureDirs();
        loadOrGenerateKeys();
        loadChainHead();
        startServer();
        printBanner();
        runConsole();
    }

    // -------------------------------------------------------------------------
    //  CONSOLE REPL
    // -------------------------------------------------------------------------
    private static void runConsole() throws IOException {
        BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
        String line;
        System.out.print("> ");
        while (running && (line = stdin.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) { System.out.print("> "); continue; }
            String[] parts = line.split("\\s+", 2);
            String cmd = parts[0].toLowerCase();
            switch (cmd) {
                case "port":     handlePort(parts);   break;
                case "download": handleDownload();     break;
                case "peers":    handlePeers();        break;
                case "list":     handleList();         break;
                case "chain":    handleChain();        break;
                case "verify":   handleVerify();       break;
                case "whoami":   handleWhoami();       break;
                case "status":   handleStatus();       break;
                case "help":     printHelp();          break;
                case "exit":
                case "quit":
                    running = false;
                    closeServer();
                    log("Bye!");
                    return;
                default:
                    log("Unknown command: " + cmd + "  (type 'help')");
            }
            System.out.print("> ");
        }
    }

    // -------------------------------------------------------------------------
    //  COMMAND HANDLERS
    // -------------------------------------------------------------------------

    private static void handlePort(String[] parts) {
        if (parts.length < 2) { log("Usage: port <number>"); return; }
        try {
            int n = Integer.parseInt(parts[1].trim());
            if (n < 1 || n > 65535) throw new NumberFormatException();
            port.set(n);
            closeServer();
            startServer();
            log("Listening port changed to " + n);
        } catch (NumberFormatException e) { log("Invalid port number."); }
    }

    private static void handleDownload() {
        List<String> peers = loadPeers();
        if (peers.isEmpty()) { log("No peers found in " + SERVERS_FILE); return; }
        log("Starting download from " + peers.size() + " peer(s)...");
        ExecutorService pool = Executors.newFixedThreadPool(Math.min(peers.size(), 8));
        for (String peer : peers) pool.submit(() -> downloadFromPeer(peer));
        pool.shutdown();
        try { pool.awaitTermination(10, TimeUnit.MINUTES); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        log("Download session complete.");
    }

    private static void handlePeers() {
        List<String> peers = loadPeers();
        if (peers.isEmpty()) log("No peers in " + SERVERS_FILE);
        else { log("Known peers (" + peers.size() + "):"); peers.forEach(p -> log("  " + p)); }
    }

    private static void handleList() {
        File dir = new File(DOWNLOAD_DIR);
        File[] files = dir.listFiles(File::isFile);
        if (files == null || files.length == 0) log("No files in ./" + DOWNLOAD_DIR + "/");
        else {
            log("Local files in ./" + DOWNLOAD_DIR + "/:");
            for (File f : files)
                log(String.format("  %-40s  %s", f.getName(), humanSize(f.length())));
        }
    }

    private static void handleChain() {
        List<Block> chain = loadFullChain();
        if (chain.isEmpty()) { log("Blockchain is empty."); return; }
        log("--- Blockchain (" + chain.size() + " block(s)) ---------------------------");
        for (int i = 0; i < chain.size(); i++) {
            Block b = chain.get(i);
            log(String.format("[%d] hash     : %s", i, b.hash));
            log(String.format("    prev     : %s", b.previousHash));
            log(String.format("    date     : %s", b.date));
            log(String.format("    file     : %s  (%s)", b.filename, humanSize(b.filesize)));
            log(String.format("    filehash : %s", b.filehash));
            log(String.format("    sender   : %s�", b.sender.length() > 32 ? b.sender.substring(0, 32) : b.sender));
            log(String.format("    receiver : %s�", b.receiver.length() > 32 ? b.receiver.substring(0, 32) : b.receiver));
            log("");
        }
    }

    private static void handleVerify() {
        List<Block> chain = loadFullChain();
        if (chain.isEmpty()) { log("Blockchain is empty � nothing to verify."); return; }
        boolean ok = true;
        String prevHash = "0000000000000000000000000000000000000000000000000000000000000000";
        for (int i = 0; i < chain.size(); i++) {
            Block b = chain.get(i);
            // 1. Verify hash linkage
            if (!b.previousHash.equals(prevHash)) {
                log("[FAIL] Block " + i + " broken link: expected prev=" + prevHash + " got=" + b.previousHash);
                ok = false;
            }
            // 2. Verify content hash == filename
            String expectedHash = sha256OfString(b.toCanonicalJson());
            if (!b.hash.equals(expectedHash)) {
                log("[FAIL] Block " + i + " content hash mismatch");
                ok = false;
            }
            // 3. Verify signature (skip if sender is a raw peer address without a public key)
            if (b.sender.startsWith("peer:")) {
                log("[SKIP] Block " + i + " sender is a peer address - no public key to verify");
            } else {
                try {
                    RsaKey senderKey = RsaKey.fromBase64(b.sender);
                    byte[] sigBytes  = hexToBytes(b.signature);
                    String payload   = b.signaturePayload();
                    boolean sigOk    = RsaKey.verify(payload.getBytes(StandardCharsets.UTF_8), sigBytes, senderKey);
                    if (!sigOk) { log("[FAIL] Block " + i + " bad signature"); ok = false; }
                    else        { log("[OK]   Block " + i + " signature valid"); }
                } catch (Exception e) {
                    log("[FAIL] Block " + i + " signature error: " + e.getMessage()); ok = false;
                }
            }
            prevHash = b.hash;
        }
        if (ok) log("[OK] Blockchain valid � " + chain.size() + " block(s) verified.");
    }

    private static void handleWhoami() {
        log("Public key (node identity):");
        log(publicKeyB64);
    }

    private static void handleStatus() {
        log("Port      : " + port.get());
        log("Server    : " + (serverSocket != null && !serverSocket.isClosed() ? "running" : "stopped"));
        log("DL Dir    : ./" + DOWNLOAD_DIR + "/");
        log("Block Dir : ./" + BLOCK_DIR + "/");
        log("Chain tip : " + latestHash);
        if (!activeDLs.isEmpty()) log("Active DLs: " + activeDLs);
    }

    // -------------------------------------------------------------------------
    //  SERVER
    // -------------------------------------------------------------------------

    private static void startServer() {
        Thread t = new Thread(() -> {
            try {
                serverSocket = new ServerSocket(port.get());
                log("[Server] Listening on port " + port.get());
                while (!serverSocket.isClosed()) {
                    try {
                        Socket client = serverSocket.accept();
                        Thread ct = new Thread(() -> handleClient(client));
                        ct.setDaemon(true);
                        ct.start();
                    } catch (SocketException ignored) {}
                }
            } catch (IOException e) {
                log("[Server] Failed to bind port " + port.get() + ": " + e.getMessage());
            }
        });
        t.setDaemon(true);
        t.start();
    }

    private static void closeServer() {
        try { if (serverSocket != null && !serverSocket.isClosed()) serverSocket.close(); }
        catch (IOException ignored) {}
    }

    private static void handleClient(Socket socket) {
        try {
            socket.setSoTimeout(READ_TIMEOUT);
            BufferedReader  reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            OutputStream    rawOut = socket.getOutputStream();
            PrintWriter     pw     = new PrintWriter(new OutputStreamWriter(rawOut), true);

            String req = reader.readLine();
            if (req == null) return;
            req = req.trim();

            if (req.equalsIgnoreCase("LIST")) {
                serveList(pw);
            } else if (req.toUpperCase().startsWith("GET ")) {
                serveFile(pw, rawOut, req.substring(4).trim());
            } else if (req.toUpperCase().startsWith("BLOCK ")) {
                String json = req.substring(6).trim();
                receiveBlock(json, pw);
            } else if (req.equalsIgnoreCase("BLOCKS")) {
                serveBlocks(pw);
            } else {
                pw.println("ERR Unknown command");
            }
        } catch (IOException ignored) {
        } finally {
            try { socket.close(); } catch (IOException ignored) {}
        }
    }

    private static void serveList(PrintWriter pw) {
        File dir   = new File(DOWNLOAD_DIR);
        File[] fls = dir.listFiles(File::isFile);
        if (fls == null) fls = new File[0];
        pw.println(fls.length);
        for (File f : fls) pw.println(f.getName() + "\t" + f.length() + "\t" + sha256OfFile(f));
        pw.flush();
    }

    private static void serveFile(PrintWriter pw, OutputStream rawOut, String filename) throws IOException {
        filename = new File(filename).getName(); // strip traversal
        File f = new File(DOWNLOAD_DIR, filename);
        if (!f.exists() || !f.isFile()) { pw.println("ERR File not found: " + filename); return; }
        pw.println("OK " + f.length());
        pw.flush();
        try (FileInputStream fis = new FileInputStream(f)) {
            byte[] buf = new byte[CHUNK_SIZE]; int read;
            while ((read = fis.read(buf)) != -1) rawOut.write(buf, 0, read);
            rawOut.flush();
        }
    }

    /** Receive a block broadcast from a peer, validate, store if new */
    private static void receiveBlock(String json, PrintWriter pw) {
        try {
            Block b = Block.fromJson(json);
            if (acceptBlock(b)) {
                pw.println("OK accepted");
                log("[Chain] Received and stored block: " + b.hash.substring(0, 16) + "�");
            } else {
                pw.println("OK duplicate_or_invalid");
            }
        } catch (Exception e) {
            pw.println("ERR " + e.getMessage());
        }
    }

    /** Send all local blocks (one JSON per line) */
    private static void serveBlocks(PrintWriter pw) {
        File dir   = new File(BLOCK_DIR);
        File[] fls = dir.listFiles(f -> f.isFile() && f.getName().endsWith(".json"));
        if (fls == null) fls = new File[0];
        // Sort by filename (which is hash) deterministically; real order is by chain linkage
        Arrays.sort(fls, Comparator.comparing(File::getName));
        pw.println(fls.length);
        for (File f : fls) {
            try {
                String json = new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8)
                        .replace("\n", "").replace("\r", "");
                pw.println(json);
            } catch (IOException ignored) {}
        }
        pw.flush();
    }

    // -------------------------------------------------------------------------
    //  CLIENT / DOWNLOAD
    // -------------------------------------------------------------------------

    private static void downloadFromPeer(String peerAddress) {
        String host; int peerPort;
        try {
            if (peerAddress.contains(":")) {
                String[] hp = peerAddress.split(":", 2);
                host = hp[0]; peerPort = Integer.parseInt(hp[1].trim());
            } else { host = peerAddress; peerPort = DEFAULT_PORT; }
        } catch (Exception e) { log("[Client] Bad peer address: " + peerAddress); return; }

        log("[Client] Connecting to " + host + ":" + peerPort);
        List<RemoteFile> remoteFiles;
        try { remoteFiles = fetchFileList(host, peerPort); }
        catch (IOException e) {
            log("[Client] Could not list files from " + host + ":" + peerPort + " � " + e.getMessage());
            return;
        }
        if (remoteFiles.isEmpty()) { log("[Client] " + host + ":" + peerPort + " has no files."); return; }
        log("[Client] " + host + ":" + peerPort + " offers " + remoteFiles.size() + " file(s).");

        // Also sync blockchain from peer
        syncChainFromPeer(host, peerPort);

        for (RemoteFile rf : remoteFiles) {
            File local = new File(DOWNLOAD_DIR, rf.name);
            if (local.exists()) { log("[Client] Skipping (exists): " + rf.name); continue; }
            downloadFile(host, peerPort, rf);
        }
    }

    private static List<RemoteFile> fetchFileList(String host, int peerPort) throws IOException {
        List<RemoteFile> list = new ArrayList<>();
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(host, peerPort), CONNECT_TIMEOUT);
            s.setSoTimeout(READ_TIMEOUT);
            PrintWriter    pw = new PrintWriter(new OutputStreamWriter(s.getOutputStream()), true);
            BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
            pw.println("LIST");
            String countLine = br.readLine();
            if (countLine == null) return list;
            int count = Integer.parseInt(countLine.trim());
            for (int i = 0; i < count; i++) {
                String entry = br.readLine();
                if (entry == null) break;
                String[] p = entry.split("\t", 3);
                if (p.length < 2) continue;
                list.add(new RemoteFile(p[0], Long.parseLong(p[1]), p.length >= 3 ? p[2] : ""));
            }
        }
        return list;
    }

    private static void downloadFile(String host, int peerPort, RemoteFile rf) {
        String key = host + ":" + peerPort + "/" + rf.name;
        if (!activeDLs.add(key)) return;
        log("[Client] Downloading: " + rf.name + " (" + humanSize(rf.size) + ") from " + host + ":" + peerPort);
        File tmp  = new File(DOWNLOAD_DIR, rf.name + ".tmp");
        File dest = new File(DOWNLOAD_DIR, rf.name);
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(host, peerPort), CONNECT_TIMEOUT);
            s.setSoTimeout(READ_TIMEOUT);
            // Use a single InputStream and read the text header byte-by-byte to avoid
            // BufferedReader pre-consuming binary file bytes into its internal buffer.
            PrintWriter pw    = new PrintWriter(new OutputStreamWriter(s.getOutputStream()), true);
            InputStream rawIn = s.getInputStream();

            pw.println("GET " + rf.name);
            String resp = readLine(rawIn);
            if (resp == null)                    { log("[Client] No response for: " + rf.name); return; }
            if (resp.startsWith("ERR"))          { log("[Client] Server err: " + resp); return; }
            if (!resp.startsWith("OK "))         { log("[Client] Unexpected: " + resp); return; }
            long fileSize = Long.parseLong(resp.substring(3).trim());

            try (FileOutputStream fos = new FileOutputStream(tmp)) {
                byte[] buf = new byte[CHUNK_SIZE]; long remaining = fileSize;
                while (remaining > 0) {
                    int toRead = (int) Math.min(buf.length, remaining);
                    int read   = rawIn.read(buf, 0, toRead);
                    if (read == -1) break;
                    fos.write(buf, 0, read);
                    remaining -= read;
                }
            }

            // Verify SHA-256
            String localHash = sha256OfFile(tmp);
            if (!rf.hash.isEmpty() && !localHash.equalsIgnoreCase(rf.hash)) {
                log("[Client] Hash mismatch for " + rf.name + " � discarding.");
                tmp.delete(); return;
            }

            if (dest.exists()) {
                log("[Client] Skipping (appeared during download): " + rf.name);
                tmp.delete();
            } else {
                try { Files.move(tmp.toPath(), dest.toPath(), StandardCopyOption.ATOMIC_MOVE); }
                catch (IOException e) { tmp.renameTo(dest); }
                log("[Client] Saved: " + rf.name);

                // -- BLOCKCHAIN: create and broadcast a block ---------------
                // Determine sender = peer's public key (use peer address as fallback identifier)
                String senderId = "peer:" + host + ":" + peerPort; // peer public key unknown ? address
                createAndBroadcastBlock(senderId, rf.name, dest.length(), localHash);
            }
        } catch (IOException e) {
            log("[Client] Error downloading " + rf.name + ": " + e.getMessage());
            tmp.delete();
        } finally { activeDLs.remove(key); }
    }

    // -------------------------------------------------------------------------
    //  BLOCKCHAIN
    // -------------------------------------------------------------------------

    /** Create a block, sign it, store it locally, then broadcast to all peers */
    private static void createAndBroadcastBlock(String sender, String filename, long filesize, String filehash) {
        synchronized (chainLock) {
            try {
                String date      = isoNow();
                String receiver  = publicKeyB64;   // we are the downloader / receiver
                String prevHash  = latestHash;

                // Build block (unsigned first to compute signature payload)
                Block b = new Block();
                b.sender       = sender;
                b.receiver     = receiver;
                b.date         = date;
                b.filename     = filename;
                b.filesize     = filesize;
                b.filehash     = filehash;
                b.previousHash = prevHash;

                // Sign payload with our private key
                byte[] sigBytes = RsaKey.sign(b.signaturePayload().getBytes(StandardCharsets.UTF_8), privateKey);
                b.signature    = bytesToHex(sigBytes);

                // Compute block hash = SHA-256 of canonical JSON (without the hash field itself)
                b.hash         = sha256OfString(b.toCanonicalJson());

                // Persist
                String json    = b.toPrettyJson();
                File   bf      = new File(BLOCK_DIR, b.hash + ".json");
                Files.write(bf.toPath(), json.getBytes(StandardCharsets.UTF_8));
                latestHash = b.hash;

                log("[Chain] Block created: " + b.hash.substring(0, 16) + "� (prev: " + prevHash.substring(0, 16) + "�)");

                // Broadcast to peers (fire-and-forget)
                String singleLineJson = json.replace("\n", "").replace("\r", "");
                List<String> peers = loadPeers();
                for (String peer : peers) {
                    final String p = peer;
                    final String j = singleLineJson;
                    new Thread(() -> broadcastBlock(p, j)).start();
                }
            } catch (Exception e) {
                log("[Chain] Failed to create block: " + e.getMessage());
            }
        }
    }

    /** Send BLOCK <json> to a peer */
    private static void broadcastBlock(String peerAddress, String singleLineJson) {
        String host; int peerPort;
        try {
            if (peerAddress.contains(":")) {
                String[] hp = peerAddress.split(":", 2);
                host = hp[0]; peerPort = Integer.parseInt(hp[1].trim());
            } else { host = peerAddress; peerPort = DEFAULT_PORT; }
        } catch (Exception e) { return; }
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(host, peerPort), CONNECT_TIMEOUT);
            s.setSoTimeout(READ_TIMEOUT);
            PrintWriter pw = new PrintWriter(new OutputStreamWriter(s.getOutputStream()), true);
            BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
            pw.println("BLOCK " + singleLineJson);
            br.readLine(); // consume response
        } catch (IOException ignored) {}
    }

    /** Validate and store an incoming block from the network */
    private static boolean acceptBlock(Block b) {
        // 1. Check if we already have it
        File bf = new File(BLOCK_DIR, b.hash + ".json");
        if (bf.exists()) return false;

        // 2. Verify content hash matches claimed hash
        String expectedHash = sha256OfString(b.toCanonicalJson());
        if (!b.hash.equals(expectedHash)) {
            log("[Chain] Rejected block � content hash mismatch");
            return false;
        }

        // 3. Verify signature (only if sender is a real public key, not a peer: address)
        if (!b.sender.startsWith("peer:")) {
            try {
                RsaKey senderKey = RsaKey.fromBase64(b.sender);
                byte[] sigBytes  = hexToBytes(b.signature);
                boolean ok       = RsaKey.verify(b.signaturePayload().getBytes(StandardCharsets.UTF_8), sigBytes, senderKey);
                if (!ok) { log("[Chain] Rejected block � invalid signature"); return false; }
            } catch (Exception e) {
                log("[Chain] Rejected block � signature error: " + e.getMessage()); return false;
            }
        }

        // 4. Store and update chain tip
        synchronized (chainLock) {
            try {
                Files.write(bf.toPath(), b.toPrettyJson().getBytes(StandardCharsets.UTF_8));
                // Update latestHash only if this block links to our current tip
                if (b.previousHash.equals(latestHash)) latestHash = b.hash;
                return true;
            } catch (IOException e) {
                log("[Chain] Could not save block: " + e.getMessage()); return false;
            }
        }
    }

    /** Pull all blocks from a peer and integrate missing ones */
    private static void syncChainFromPeer(String host, int peerPort) {
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(host, peerPort), CONNECT_TIMEOUT);
            s.setSoTimeout(READ_TIMEOUT);
            PrintWriter    pw = new PrintWriter(new OutputStreamWriter(s.getOutputStream()), true);
            BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
            pw.println("BLOCKS");
            String countLine = br.readLine();
            if (countLine == null) return;
            int count = Integer.parseInt(countLine.trim());
            int imported = 0;
            for (int i = 0; i < count; i++) {
                String json = br.readLine();
                if (json == null) break;
                try {
                    Block b = Block.fromJson(json);
                    if (acceptBlock(b)) imported++;
                } catch (Exception ignored) {}
            }
            if (imported > 0) log("[Chain] Synced " + imported + " new block(s) from " + host + ":" + peerPort);
        } catch (IOException ignored) {}
    }

    /** Walk the chain from genesis to tip and return ordered list */
    private static List<Block> loadFullChain() {
        File dir   = new File(BLOCK_DIR);
        File[] fls = dir.listFiles(f -> f.isFile() && f.getName().endsWith(".json"));
        if (fls == null || fls.length == 0) return new ArrayList<>();

        // Build map hash ? block
        Map<String, Block> byHash = new LinkedHashMap<>();
        for (File f : fls) {
            try {
                String json = new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
                Block b = Block.fromJson(json);
                byHash.put(b.hash, b);
            } catch (Exception ignored) {}
        }

        // Build map prevHash ? block (to walk forward)
        Map<String, Block> byPrev = new LinkedHashMap<>();
        for (Block b : byHash.values()) byPrev.put(b.previousHash, b);

        // Walk from genesis
        List<Block> chain = new ArrayList<>();
        String genesis = "0000000000000000000000000000000000000000000000000000000000000000";
        Block cur = byPrev.get(genesis);
        while (cur != null) {
            chain.add(cur);
            cur = byPrev.get(cur.hash);
        }
        return chain;
    }

    /** Scan block dir to find the latest hash (tip of chain) */
    private static void loadChainHead() {
        List<Block> chain = loadFullChain();
        if (!chain.isEmpty()) {
            latestHash = chain.get(chain.size() - 1).hash;
            log("[Chain] Loaded " + chain.size() + " block(s). Tip: " + latestHash.substring(0, 16) + "�");
        } else {
            log("[Chain] No existing blocks � starting fresh.");
        }
    }

    // -------------------------------------------------------------------------
    //  RSA KEY MANAGEMENT  (minimal pure-Java, no external libs)
    // -------------------------------------------------------------------------

    private static void loadOrGenerateKeys() throws Exception {
        File priv = new File(PRIVATE_KEY_FILE);
        File pub  = new File(PUBLIC_KEY_FILE);
        if (priv.exists() && pub.exists()) {
            privateKey   = RsaKey.load(PRIVATE_KEY_FILE);
            publicKey    = RsaKey.load(PUBLIC_KEY_FILE);
            publicKeyB64 = publicKey.toBase64();
            log("[Keys] Loaded existing RSA key pair.");
        } else {
            log("[Keys] Generating RSA key pair (first run)�");
            RsaKey[] pair = RsaKey.generatePair(512);
            privateKey    = pair[0];
            publicKey     = pair[1];
            publicKeyB64  = publicKey.toBase64();
            privateKey.save(PRIVATE_KEY_FILE);
            publicKey.save(PUBLIC_KEY_FILE);
            log("[Keys] Key pair saved to ./" + KEYS_DIR + "/");
        }
    }

    // -------------------------------------------------------------------------
    //  RSA INNER CLASS  (textbook RSA-512, no padding, pure BigInteger)
    // -------------------------------------------------------------------------

    /**
     * Minimal RSA implementation using BigInteger.
     * Stores (exponent, modulus) as Base64 strings separated by "|".
     * Private key: (d, n)   Public key: (e, n)
     *
     * Signing: sig = SHA-256(msg) ^ d mod n
     * Verifying: SHA-256(msg) == sig ^ e mod n
     */
    static class RsaKey {
        BigInteger exponent;
        BigInteger modulus;

        static final BigInteger E = BigInteger.valueOf(65537);

        static RsaKey[] generatePair(int bits) throws NoSuchAlgorithmException {
            SecureRandom rng = new SecureRandom();
            BigInteger p, q, n, phi, d;
            do {
                p   = BigInteger.probablePrime(bits / 2, rng);
                q   = BigInteger.probablePrime(bits / 2, rng);
                n   = p.multiply(q);
                phi = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE));
            } while (!E.gcd(phi).equals(BigInteger.ONE));
            d = E.modInverse(phi);

            RsaKey priv = new RsaKey(); priv.exponent = d; priv.modulus = n;
            RsaKey pub  = new RsaKey(); pub.exponent  = E; pub.modulus  = n;
            return new RsaKey[]{priv, pub};
        }

        static byte[] sign(byte[] message, RsaKey privateKey) throws NoSuchAlgorithmException {
            byte[] hash  = sha256Raw(message);
            BigInteger m = new BigInteger(1, hash);
            BigInteger s = m.modPow(privateKey.exponent, privateKey.modulus);
            return toFixedBytes(s, privateKey.modulus.bitLength() / 8 + 1);
        }

        static boolean verify(byte[] message, byte[] signature, RsaKey publicKey) throws NoSuchAlgorithmException {
            byte[] hash    = sha256Raw(message);
            BigInteger h   = new BigInteger(1, hash);
            BigInteger sig = new BigInteger(1, signature);
            BigInteger dec = sig.modPow(publicKey.exponent, publicKey.modulus);
            return h.equals(dec);
        }

        String toBase64() {
            String e64 = Base64.getEncoder().encodeToString(exponent.toByteArray());
            String n64 = Base64.getEncoder().encodeToString(modulus.toByteArray());
            return e64 + "|" + n64;
        }

        static RsaKey fromBase64(String s) {
            String[] parts = s.split("\\|", 2);
            RsaKey k = new RsaKey();
            k.exponent = new BigInteger(1, Base64.getDecoder().decode(parts[0]));
            k.modulus  = new BigInteger(1, Base64.getDecoder().decode(parts[1]));
            return k;
        }

        void save(String path) throws IOException {
            Files.write(Paths.get(path), toBase64().getBytes(StandardCharsets.UTF_8));
        }

        static RsaKey load(String path) throws IOException {
            String s = new String(Files.readAllBytes(Paths.get(path)), StandardCharsets.UTF_8).trim();
            return fromBase64(s);
        }

        /** Pad/truncate to exactly `len` bytes (big-endian unsigned) */
        private static byte[] toFixedBytes(BigInteger v, int len) {
            byte[] raw = v.toByteArray();
            if (raw.length == len) return raw;
            byte[] out = new byte[len];
            if (raw.length < len) System.arraycopy(raw, 0, out, len - raw.length, raw.length);
            else System.arraycopy(raw, raw.length - len, out, 0, len);
            return out;
        }
    }

    // -------------------------------------------------------------------------
    //  BLOCK  (JSON serialized by hand � no external libs)
    // -------------------------------------------------------------------------

    static class Block {
        String hash;          // SHA-256 of toCanonicalJson() � also the filename
        String previousHash;
        String date;          // ISO-8601
        String filename;
        long   filesize;
        String filehash;      // SHA-256 of the transferred file
        String sender;        // public key B64 or "peer:host:port"
        String receiver;      // public key B64 of the downloader
        String signature;     // hex-encoded RSA signature of signaturePayload()

        /** Fields that are signed (everything except hash itself) */
        String signaturePayload() {
            return previousHash + "|" + date + "|" + filename + "|" + filesize + "|" + filehash
                    + "|" + sender + "|" + receiver;
        }

        /**
         * Canonical JSON: deterministic field order, no whitespace variation.
         * This string is hashed to produce the block filename.
         * The "hash" field is intentionally EXCLUDED (bootstrapping problem).
         */
        String toCanonicalJson() {
            return "{\"previousHash\":\"" + esc(previousHash)
                    + "\",\"date\":\"" + esc(date)
                    + "\",\"filename\":\"" + esc(filename)
                    + "\",\"filesize\":" + filesize
                    + ",\"filehash\":\"" + esc(filehash)
                    + "\",\"sender\":\"" + esc(sender)
                    + "\",\"receiver\":\"" + esc(receiver)
                    + "\",\"signature\":\"" + esc(signature)
                    + "\"}";
        }

        /** Pretty JSON for storage (includes hash field) */
        String toPrettyJson() {
            return "{\n"
                    + "  \"hash\": \""         + esc(hash)         + "\",\n"
                    + "  \"previousHash\": \"" + esc(previousHash) + "\",\n"
                    + "  \"date\": \""         + esc(date)         + "\",\n"
                    + "  \"filename\": \""     + esc(filename)     + "\",\n"
                    + "  \"filesize\": "       + filesize          + ",\n"
                    + "  \"filehash\": \""     + esc(filehash)     + "\",\n"
                    + "  \"sender\": \""       + esc(sender)       + "\",\n"
                    + "  \"receiver\": \""     + esc(receiver)     + "\",\n"
                    + "  \"signature\": \""    + esc(signature)    + "\"\n"
                    + "}";
        }

        /** Minimal JSON parser � reads only the fields we need */
        static Block fromJson(String json) {
            Block b = new Block();
            b.hash         = jsonGet(json, "hash");
            b.previousHash = jsonGet(json, "previousHash");
            b.date         = jsonGet(json, "date");
            b.filename     = jsonGet(json, "filename");
            b.filesize     = Long.parseLong(jsonGet(json, "filesize"));
            b.filehash     = jsonGet(json, "filehash");
            b.sender       = jsonGet(json, "sender");
            b.receiver     = jsonGet(json, "receiver");
            b.signature    = jsonGet(json, "signature");
            return b;
        }

        // -- tiny JSON helpers ---------------------------------------------
        private static String jsonGet(String json, String key) {
            // Handles both "key": "value"  and  "key": 1234
            String strPat = "\"" + key + "\"";
            int ki = json.indexOf(strPat);
            if (ki < 0) return "";
            int colon = json.indexOf(':', ki + strPat.length());
            if (colon < 0) return "";
            int start = colon + 1;
            while (start < json.length() && (json.charAt(start) == ' ' || json.charAt(start) == '\n'
                    || json.charAt(start) == '\r' || json.charAt(start) == '\t')) start++;
            if (start >= json.length()) return "";
            if (json.charAt(start) == '"') {
                // String value
                int vs = start + 1;
                int ve = vs;
                while (ve < json.length()) {
                    if (json.charAt(ve) == '\\') { ve += 2; continue; }
                    if (json.charAt(ve) == '"')  break;
                    ve++;
                }
                return json.substring(vs, ve).replace("\\\"", "\"").replace("\\\\", "\\");
            } else {
                // Numeric value
                int ve = start;
                while (ve < json.length() && "0123456789.-".indexOf(json.charAt(ve)) >= 0) ve++;
                return json.substring(start, ve);
            }
        }

        private static String esc(String s) {
            if (s == null) return "";
            return s.replace("\\", "\\\\").replace("\"", "\\\"");
        }
    }

    // -------------------------------------------------------------------------
    //  HELPERS
    // -------------------------------------------------------------------------

    /** Read a newline-terminated line from a raw InputStream (no buffering). */
    private static String readLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int b;
        while ((b = in.read()) != -1) {
            if (b == '\n') break;
            if (b != '\r') sb.append((char) b);
        }
        return sb.length() == 0 && b == -1 ? null : sb.toString();
    }

    private static void ensureDirs() {
        for (String d : new String[]{DOWNLOAD_DIR, BLOCK_DIR, KEYS_DIR}) {
            File dir = new File(d);
            if (!dir.exists()) { dir.mkdirs(); log("Created directory: ./" + d + "/"); }
        }
    }

    private static List<String> loadPeers() {
        List<String> peers = new ArrayList<>();
        File f = new File(SERVERS_FILE);
        if (!f.exists()) {
            log("'" + SERVERS_FILE + "' not found. Creating empty file.");
            try { f.createNewFile(); } catch (IOException ignored) {}
            return peers;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty() && !line.startsWith("#")) peers.add(line);
            }
        } catch (IOException e) { log("Could not read " + SERVERS_FILE + ": " + e.getMessage()); }
        return peers;
    }

    private static String sha256OfFile(File f) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            try (FileInputStream fis = new FileInputStream(f)) {
                byte[] buf = new byte[CHUNK_SIZE]; int read;
                while ((read = fis.read(buf)) != -1) md.update(buf, 0, read);
            }
            return bytesToHex(md.digest());
        } catch (Exception e) { return ""; }
    }

    private static String sha256OfString(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return bytesToHex(md.digest(s.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) { return ""; }
    }

    private static byte[] sha256Raw(byte[] data) throws NoSuchAlgorithmException {
        return MessageDigest.getInstance("SHA-256").digest(data);
    }

    private static String bytesToHex(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    private static byte[] hexToBytes(String hex) {
        int len = hex.length();
        byte[] out = new byte[len / 2];
        for (int i = 0; i < len; i += 2)
            out[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                               +  Character.digit(hex.charAt(i + 1), 16));
        return out;
    }

    private static String isoNow() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return sdf.format(new Date());
    }

    private static String humanSize(long bytes) {
        if (bytes < 1024)           return bytes + " B";
        double kb = bytes / 1024.0;
        if (kb   < 1024)            return String.format("%.1f KB", kb);
        double mb = kb   / 1024.0;
        if (mb   < 1024)            return String.format("%.1f MB", mb);
        return                             String.format("%.1f GB", mb / 1024.0);
    }

    private static void log(String msg) { System.out.println(msg); }

    private static void printBanner() {
        log("+----------------------------------------------+");
        log("�   BitTorrent P2P + Blockchain  v2.0          �");
        log("�----------------------------------------------�");
        log("�  Port      : " + padRight(String.valueOf(port.get()), 33) + "�");
        log("�  DL Dir    : ./" + padRight(DOWNLOAD_DIR + "/", 31) + "�");
        log("�  Block Dir : ./" + padRight(BLOCK_DIR + "/", 31) + "�");
        log("�  Keys Dir  : ./" + padRight(KEYS_DIR + "/", 31) + "�");
        log("�  Identity  : " + padRight(publicKeyB64.substring(0, Math.min(32, publicKeyB64.length())) + "�", 33) + "�");
        log("+----------------------------------------------+");
        log("Type 'help' for available commands.");
    }

    private static void printHelp() {
        log("--- Commands ----------------------------------------------");
        log("  port <n>   Change listening port (current: " + port.get() + ")");
        log("  download   Download all files from peers in " + SERVERS_FILE);
        log("  peers      List peers from " + SERVERS_FILE);
        log("  list       List local files in ./" + DOWNLOAD_DIR + "/");
        log("  chain      Print the local blockchain");
        log("  verify     Verify blockchain integrity (links + signatures)");
        log("  whoami     Show your public key (node identity)");
        log("  status     Show port, server state, chain tip");
        log("  help       Show this help");
        log("  exit       Quit");
        log("-----------------------------------------------------------");
        log("servers.txt format (one per line):  host:port  or  host");
        log("  Example:  192.168.1.10:52525");
        log("            mypeer.local");
        log("");
        log("Blockchain files stored in ./" + BLOCK_DIR + "/<sha256>.json");
        log("Key pair stored in ./" + KEYS_DIR + "/private.key  and  public.key");
    }

    private static String padRight(String s, int len) {
        if (s.length() >= len) return s.substring(0, len);
        return s + " ".repeat(len - s.length());
    }

    // -- Inner class: RemoteFile -----------------------------------------------
    private static class RemoteFile {
        final String name;
        final long   size;
        final String hash; // SHA-256
        RemoteFile(String name, long size, String hash) {
            this.name = name; this.size = size; this.hash = hash;
        }
    }
}