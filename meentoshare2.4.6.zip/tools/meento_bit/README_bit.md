# BitTorrentApp v2.0

A peer-to-peer file sharing application written in a **single Java file** with **no external libraries**. It combines a BitTorrent-style download protocol with a built-in blockchain ledger and RSA identity system.

---

## Features

- **Dual client/server** — every node simultaneously serves and downloads files
- **Peer list** loaded from `servers.txt`
- **Blockchain ledger** — every successful transfer is recorded as a cryptographically linked JSON block
- **RSA key pair** — auto-generated on first run; your public key is your node identity
- **Block broadcasting** — new blocks are pushed to all peers immediately after creation
- **Chain sync** — pulls missing blocks from peers on every `download` session
- **SHA-256 file verification** — downloaded files are verified before being saved
- **Skip existing files** — never overwrites files already present in `./download/`
- **Zero dependencies** — pure Java standard library only

---

## Requirements

- Java 11 or higher

---

## Quick Start

```bash
# 1. Compile
javac BitTorrentApp.java

# 2. Run
java BitTorrentApp
```

On first run, the app will:
1. Create `./download/`, `./light_block/`, and `./keys/` directories
2. Generate an RSA key pair and save it to `./keys/`
3. Load any existing blockchain blocks from `./light_block/`
4. Start a TCP server on port `52525`

---

## Directory Structure

```
.
├── BitTorrentApp.java       # Single source file — the entire application
├── servers.txt              # List of known peers (host:port, one per line)
├── download/                # Files served to peers AND saved downloads
├── light_block/             # Blockchain — one <sha256>.json file per block
└── keys/
    ├── private.key          # Your RSA private key (keep secret)
    └── public.key           # Your RSA public key (your node identity)
```

> **To share files:** place them inside `./download/`. Any peer can then download them.

---

## servers.txt Format

One peer per line. Lines starting with `#` are treated as comments.

```
# My peers
192.168.1.10:52525
192.168.1.20            # uses default port 52525
mypeer.local:9000
```

---

## Commands

| Command | Description |
|---|---|
| `port <n>` | Change the listening port (restarts the server). Default: `52525` |
| `download` | Download all files from every peer listed in `servers.txt` |
| `peers` | List all known peers from `servers.txt` |
| `list` | List files available locally in `./download/` |
| `chain` | Print the full local blockchain in chronological order |
| `verify` | Verify blockchain integrity: hash linkage, content hashes, RSA signatures |
| `whoami` | Display your public key (node identity) |
| `status` | Show current port, server state, and chain tip hash |
| `help` | Show the help screen |
| `exit` | Quit |

---

## Network Protocol

All communication uses plain TCP. The server handles four commands:

| Client sends | Server responds |
|---|---|
| `LIST` | `<count>\n<name>\t<size>\t<sha256>\n…` |
| `GET <filename>` | `OK <size>\n<raw bytes>` or `ERR <message>` |
| `BLOCK <json>` | `OK accepted` or `OK duplicate_or_invalid` or `ERR <message>` |
| `BLOCKS` | `<count>\n<json>\n…` (one block per line) |

File bytes are streamed raw after the `OK <size>` response header. The header is read byte-by-byte to avoid a `BufferedReader` consuming file data into its internal buffer.

---

## Blockchain

Every successful download creates a **light block** — a small JSON file stored in `./light_block/`. Blocks are content-addressed: the filename is the SHA-256 hash of the block's canonical JSON content.

### Block Fields

| Field | Description |
|---|---|
| `hash` | SHA-256 of the block's canonical JSON — used as the filename |
| `previousHash` | Hash of the preceding block (64 zeros for the genesis block) |
| `date` | ISO-8601 UTC timestamp of the transfer |
| `filename` | Name of the file that was transferred |
| `filesize` | File size in bytes |
| `filehash` | SHA-256 of the actual file content |
| `sender` | Public key (Base64) of the serving node, or `peer:host:port` if unknown |
| `receiver` | Public key (Base64) of the downloading node (you) |
| `signature` | RSA signature over all fields above (hex-encoded) |

### Example Block

```json
{
  "hash": "0af5791dc6171bf95168bc76b83f0c31674d139e733349ce066c65cf9ea8827c",
  "previousHash": "0b9f11eb79a095396d6db74378d62aeb313cf041bd58330bf3f97b708b321129",
  "date": "2026-05-02T23:09:15Z",
  "filename": "hello.txt",
  "filesize": 7,
  "filehash": "b22b009134622b6508d756f1062455d71a7026594eacb0badf81f4f677929ebe",
  "sender": "peer:localhost:60071",
  "receiver": "AQAB|ANit1KyXEfUmDUT09nQvksa6aLg5WrYaIFSXPmMR+...",
  "signature": "00090b4180e6b2a07af890989478a085676f6e93..."
}
```

### Chain Integrity

The `verify` command checks three things for every block:

1. **Hash linkage** — `previousHash` must match the hash of the preceding block
2. **Content integrity** — the block's `hash` field must equal `SHA-256(canonicalJson)`
3. **RSA signature** — the signature must be valid against the sender's public key (skipped if sender is a raw `peer:` address)

### Block Broadcasting

After each successful download, the new block is sent to all peers via `BLOCK <json>`. Peers validate the block before storing it. On every `download` session, the client also pulls the full chain from each peer via `BLOCKS` and imports any blocks it does not yet have.

---

## RSA Identity System

Keys are generated on first run using a minimal pure-Java RSA implementation (textbook RSA-512 over `BigInteger`). No `java.security.KeyPairGenerator` is used.

```
Signing:    signature = SHA-256(message) ^ d  mod n
Verifying:  SHA-256(message) == signature ^ e  mod n
```

Keys are stored as Base64-encoded `exponent|modulus` strings:

```
# keys/public.key
AQAB|ANit1KyXEfUmDUT09nQvksa6aLg5WrYaIFSXPmMR+Cz/...
```

Your **public key is your node identity**. It appears in the banner on startup and is embedded as the `receiver` field in every block you create. Keep `private.key` secret — it is used to sign every block you produce.

---

## Running Multiple Nodes Locally

```bash
# Terminal 1 — Node A (serves files on port 60001)
mkdir node_a && cd node_a
mkdir download && echo "hello" > download/hello.txt
echo "localhost:60001" > servers.txt   # (point to self or leave empty)
java -cp .. BitTorrentApp
> port 60001

# Terminal 2 — Node B (downloads from Node A)
mkdir node_b && cd node_b
echo "localhost:60001" > servers.txt
java -cp .. BitTorrentApp
> port 60002
> download
> chain
> verify
```

---

## Security Notes

- RSA-512 is used for demonstration purposes. For production use, increase the key size to 2048+ bits by changing the `generatePair(512)` call.
- The `sender` field uses a `peer:host:port` fallback when the serving peer's public key is not known. In that case, the signature covers the receiver's actions only and cannot be attributed to the sender cryptographically.
- No IP addresses are stored in any block field.

---

## Implementation Notes

- All logic lives in `BitTorrentApp.java` — a single file with no external dependencies
- JSON is serialized and parsed manually with no reflection or third-party library
- SHA-256 is used for file hashing and block content addressing via `java.security.MessageDigest`
- Downloads are written to a `.tmp` file first, verified, then atomically renamed
- The server runs on a daemon thread; each client connection spawns its own thread
- Block broadcasts are fire-and-forget on separate threads to avoid blocking downloads
