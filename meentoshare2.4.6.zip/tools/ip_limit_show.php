﻿<?php
// ── config ────────────────────────────────────────────────────────────────────
define('LIMIT_FILE',   __DIR__ . '/file_upload_limit.txt');
define('IP_HASH_DIR',  __DIR__ . '/tmp_user_ip_hash_date/');
define('SALT',         'rK#8wP@5mX!jN2qY');   // ← change to your own secret salt

define('INTERVALS', array(
    'none'  => array('label' => 'No restriction', 'seconds' => 0),
    '1min'  => array('label' => '1 Minute',        'seconds' => 60),
    '10min' => array('label' => '10 Minutes',       'seconds' => 600),
    '1hour' => array('label' => '1 Hour',           'seconds' => 3600),
    '1day'  => array('label' => '1 Day',            'seconds' => 86400),
    '1week' => array('label' => '1 Week',           'seconds' => 604800),
));

// ── helpers ───────────────────────────────────────────────────────────────────
function getUserIP()
{
    foreach (array('HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR') as $k) {
        if (!empty($_SERVER[$k])) {
            return trim(explode(',', $_SERVER[$k])[0]);
        }
    }
    return '0.0.0.0';
}

function ipHashFile($ip)
{
    return IP_HASH_DIR . hash('sha256', SALT . $ip) . '.json';
}

function readLimit()
{
    if (!file_exists(LIMIT_FILE)) {
        return null;
    }
    $raw = trim(file_get_contents(LIMIT_FILE));
    if ($raw === '') {
        return null;
    }
    $d = json_decode($raw, true);
    return is_array($d) ? $d : null;
}

function ensureHashDir()
{
    if (!is_dir(IP_HASH_DIR)) {
        mkdir(IP_HASH_DIR, 0750, true);
    }
}

function getUserRecord($ip)
{
    $f = ipHashFile($ip);
    if (!file_exists($f)) {
        return null;
    }
    $d = json_decode(file_get_contents($f), true);
    return is_array($d) ? $d : null;
}

function saveUserRecord($ip)
{
    ensureHashDir();
    $data = array(
        'hash'        => hash('sha256', SALT . $ip),
        'salt_hint'   => substr(SALT, 0, 3) . '***',
        'accessed_at' => date('Y-m-d H:i:s'),
        'timestamp'   => time(),
    );
    file_put_contents(ipHashFile($ip), json_encode($data, JSON_PRETTY_PRINT));
}

function secondsRemaining($record, $intervalSeconds)
{
    if ($intervalSeconds === 0) {
        return 0;
    }
    $elapsed = time() - $record['timestamp'];
    return max(0, $intervalSeconds - $elapsed);
}

function formatDuration($secs)
{
    if ($secs <= 0)    return '0 seconds';
    if ($secs < 60)    return $secs . ' second' . ($secs !== 1 ? 's' : '');
    if ($secs < 3600)  { $m = (int)($secs / 60);   return $m . ' minute' . ($m !== 1 ? 's' : ''); }
    if ($secs < 86400) { $h = (int)($secs / 3600);  return $h . ' hour'   . ($h !== 1 ? 's' : ''); }
    $d = (int)($secs / 86400);
    return $d . ' day' . ($d !== 1 ? 's' : '');
}

// ── main logic ────────────────────────────────────────────────────────────────

$limitData = readLimit();

// File is empty or missing — no limit configured, do nothing and let page continue.
if ($limitData === null) {
    return; // silently stop this include; the rest of the page loads normally
}

$intervals   = INTERVALS;
$intervalKey = isset($limitData['interval']) ? $limitData['interval'] : 'none';
$intervalSec = isset($intervals[$intervalKey]['seconds']) ? $intervals[$intervalKey]['seconds'] : 0;

$ip         = getUserIP();
$userRecord = getUserRecord($ip);
$secsLeft   = 0;

if ($intervalSec === 0) {
    // "No restriction" — just record the visit and let through
    saveUserRecord($ip);
    return;
}

if ($userRecord !== null) {
    $secsLeft = secondsRemaining($userRecord, $intervalSec);
    if ($secsLeft > 0) {
        // ── LIMIT REACHED — show block and stop ──────────────────────────────
        ?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Access Restricted</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{min-height:100%;background:#fff;color:#111;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
body{display:flex;align-items:center;justify-content:center;padding:2rem 1.5rem}

.restricted-container{
    max-width:26rem;
    width:100%;
    border:1px solid #e8c0c0;
    border-radius:8px;
    overflow:hidden;
    box-shadow:0 2px 12px rgba(0,0,0,.06);
}

.restricted-head{
    display:flex;
    align-items:center;
    gap:.75rem;
    padding:.9rem 1.1rem;
    background:#fff5f5;
    border-bottom:1px solid #f0d0d0;
}

.restricted-icon{
    display:flex;
    align-items:center;
    justify-content:center;
    width:2rem;
    height:2rem;
    background:#fde8e8;
    border-radius:50%;
    flex-shrink:0;
}

.restricted-icon svg{
    width:1rem;
    height:1rem;
    stroke:#c00;
    fill:none;
    stroke-width:2.2;
    stroke-linecap:round;
    stroke-linejoin:round;
}

.restricted-title{
    font-weight:700;
    font-size:1rem;
    color:#c00;
    letter-spacing:-.01em;
}

.restricted-body{
    padding:1.25rem 1.1rem;
    background:#fff;
}

.restricted-body p{
    font-size:.9rem;
    line-height:1.6;
    color:#444;
    margin-bottom:.9rem;
}

.restricted-body p:last-child{margin-bottom:0}

.countdown-label{
    font-size:.75rem;
    text-transform:uppercase;
    letter-spacing:.06em;
    color:#999;
    margin-bottom:.35rem;
}

.countdown-timer{
    font-size:1.6rem;
    font-weight:700;
    color:#c00;
    font-variant-numeric:tabular-nums;
    letter-spacing:-.02em;
}

.interval-note{
    margin-top:.75rem;
    font-size:.78rem;
    color:#aaa;
}
</style>
</head>
<body>

<div class="restricted-container">
    <div class="restricted-head">
        <div class="restricted-icon">
            <svg viewBox="0 0 24 24">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
            </svg>
        </div>
        <span class="restricted-title">Access Restricted</span>
    </div>

    <div class="restricted-body">
        <p>You have already accessed this content. Please wait before trying again.</p>

        <div class="countdown-label">Time remaining</div>
        <div class="countdown-timer" id="cd-timer"><?php echo formatDuration($secsLeft); ?></div>

        <div class="interval-note">
            Interval: <?php echo htmlspecialchars($intervals[$intervalKey]['label']); ?>
        </div>
    </div>
</div>

<script>
var secs = <?php echo (int)$secsLeft; ?>;
var el   = document.getElementById('cd-timer');

function fmt(s) {
    if (s <= 0)    return '0 seconds';
    if (s < 60)    return s + (s === 1 ? ' second' : ' seconds');
    if (s < 3600)  { var m = Math.floor(s / 60);   var rs = s % 60;            return m + (m === 1 ? ' minute' : ' minutes') + (rs ? ' ' + rs + 's' : ''); }
    if (s < 86400) { var h = Math.floor(s / 3600);  var rm = Math.floor((s % 3600) / 60); return h + (h === 1 ? ' hour'   : ' hours')   + (rm ? ' ' + rm + 'm' : ''); }
    var d = Math.floor(s / 86400); var rh = Math.floor((s % 86400) / 3600);
    return d + (d === 1 ? ' day' : ' days') + (rh ? ' ' + rh + 'h' : '');
}

var t = setInterval(function () {
    secs--;
    if (secs <= 0) {
        el.textContent = '0 seconds';
        clearInterval(t);
        location.reload();
        return;
    }
    el.textContent = fmt(secs);
}, 1000);
</script>
</body>
</html>
<?php
        die();
    }

    // Interval has passed — refresh record and allow through
    saveUserRecord($ip);
    return;
}

// First visit — record it and allow through
saveUserRecord($ip);