<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  Meento Share — Redis Module
//  Drop-in sidecar: include this file at the TOP of index_full.php (line 2),
//  or use the auto-loader (see README).  Zero changes to index_full.php.
//
//  require_once __DIR__ . '/redis_module.php';
//
//  What this module does (all transparent to the rest of the code):
//    1. Account read/write cache   — loadByKey / safeWrite hit Redis first
//    2. Distributed locks          — prevents race conditions on concurrent uploads
//    3. Session tokens             — replaces the daily nonce with a real token
//    4. Rate limiting              — login brute-force protection
//    5. Pub/Sub event bus          — broadcasts upload/sync events to listeners
//    6. Re-verification queue      — schedules periodic server re-checks
//    7. IP-hash dedup cache        — fast DNS resolution cache
//    8. Node status heartbeat      — TTL-based peer liveness tracking
//
//  Configuration — edit the section below or define constants before including:
//    define('REDIS_HOST', '127.0.0.1');
//    define('REDIS_PORT', 6379);
//    define('REDIS_PASSWORD', 'secret');   // omit or '' for no auth
//    define('REDIS_DB', 0);
//    define('REDIS_PREFIX', 'meento:');
//    define('REDIS_ACCOUNT_TTL', 300);     // account cache TTL in seconds
//    define('REDIS_SESSION_TTL', 86400);   // session token TTL
//    define('REDIS_LOCK_TTL', 5);          // distributed lock TTL
//    define('REDIS_RATE_WINDOW', 300);     // rate limit window (seconds)
//    define('REDIS_RATE_LIMIT', 10);       // max login attempts per window
//    define('REDIS_REVERIF_INTERVAL', 604800); // re-verify interval (1 week)
//    define('REDIS_ENABLED', true);        // set false to disable entirely
// ═══════════════════════════════════════════════════════════════════════════════

// ── Default configuration (overridable by defining constants before include) ──
if (!defined('REDIS_HOST'))            define('REDIS_HOST',            '127.0.0.1');
if (!defined('REDIS_PORT'))            define('REDIS_PORT',            6379);
if (!defined('REDIS_PASSWORD'))        define('REDIS_PASSWORD',        '');
if (!defined('REDIS_DB'))              define('REDIS_DB',              0);
if (!defined('REDIS_PREFIX'))          define('REDIS_PREFIX',          'meento:');
if (!defined('REDIS_ACCOUNT_TTL'))     define('REDIS_ACCOUNT_TTL',     300);
if (!defined('REDIS_SESSION_TTL'))     define('REDIS_SESSION_TTL',     86400);
if (!defined('REDIS_LOCK_TTL'))        define('REDIS_LOCK_TTL',        5);
if (!defined('REDIS_RATE_WINDOW'))     define('REDIS_RATE_WINDOW',     300);
if (!defined('REDIS_RATE_LIMIT'))      define('REDIS_RATE_LIMIT',      10);
if (!defined('REDIS_REVERIF_INTERVAL'))define('REDIS_REVERIF_INTERVAL',604800);
if (!defined('REDIS_ENABLED'))         define('REDIS_ENABLED',         true);

// ══════════════════════════════════════════════════════════════════════════════
//  MeentoRedis — singleton connection + all Redis operations
// ══════════════════════════════════════════════════════════════════════════════
class MeentoRedis
{
    private static ?MeentoRedis $instance = null;
    private ?\Redis $r = null;
    private bool $available = false;

    private function __construct()
    {
        if (!REDIS_ENABLED) return;
        if (!extension_loaded('redis')) {
            error_log('[MeentoRedis] php-redis extension not loaded — running without Redis.');
            return;
        }
        try {
            $this->r = new \Redis();
            $connected = $this->r->connect(REDIS_HOST, REDIS_PORT, 2.0);
            if (!$connected) throw new \RuntimeException('connect() returned false');
            if (REDIS_PASSWORD !== '') $this->r->auth(REDIS_PASSWORD);
            $this->r->select(REDIS_DB);
            $this->r->setOption(\Redis::OPT_PREFIX, REDIS_PREFIX);
            $this->r->setOption(\Redis::OPT_SERIALIZER, \Redis::SERIALIZER_NONE);
            $this->available = true;
        } catch (\Throwable $e) {
            error_log('[MeentoRedis] Connection failed: ' . $e->getMessage() . ' — running without Redis.');
            $this->r = null;
        }
    }

    public static function get(): self
    {
        if (self::$instance === null) self::$instance = new self();
        return self::$instance;
    }

    public function available(): bool { return $this->available; }
    public function raw(): ?\Redis    { return $this->r; }

    // ── Key builders ─────────────────────────────────────────────────────────
    private function k(string ...$parts): string
    {
        // prefix is set via OPT_PREFIX, so we only need the local key part
        return implode(':', $parts);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  1. Account cache
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Load account from Redis cache.
     * Returns the decoded array or null on miss / unavailable.
     */
    public function accountGet(string $publicKey): ?array
    {
        if (!$this->available) return null;
        try {
            $raw = $this->r->get($this->k('account', $publicKey));
            if ($raw === false || $raw === null) return null;
            $data = json_decode($raw, true);
            return is_array($data) ? $data : null;
        } catch (\Throwable $e) {
            error_log('[MeentoRedis] accountGet error: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Store account in Redis cache with TTL.
     * Also invalidates the old nonce so it can't be replayed after a write.
     */
    public function accountSet(string $publicKey, array $data): void
    {
        if (!$this->available) return;
        try {
            $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($json === false) return;
            $this->r->setex($this->k('account', $publicKey), REDIS_ACCOUNT_TTL, $json);
        } catch (\Throwable $e) {
            error_log('[MeentoRedis] accountSet error: ' . $e->getMessage());
        }
    }

    /**
     * Invalidate (delete) the cached account.
     * Call this whenever the account file on disk changes.
     */
    public function accountInvalidate(string $publicKey): void
    {
        if (!$this->available) return;
        try {
            $this->r->del($this->k('account', $publicKey));
        } catch (\Throwable $e) {}
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  2. Distributed locks
    //  Uses SET NX EX (atomic) — no separate SETNX+EXPIRE race condition.
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Acquire a lock for the given resource (e.g. account write).
     * Returns a token string on success, null on failure.
     * Always call releaseLock() with the token after the critical section.
     */
    public function acquireLock(string $resource, int $ttl = REDIS_LOCK_TTL): ?string
    {
        if (!$this->available) return 'no-redis'; // degrade gracefully
        try {
            $token = bin2hex(random_bytes(16));
            $key   = $this->k('lock', $resource);
            // SET key token NX EX ttl
            $ok = $this->r->set($key, $token, ['NX', 'EX' => $ttl]);
            return $ok ? $token : null;
        } catch (\Throwable $e) {
            error_log('[MeentoRedis] acquireLock error: ' . $e->getMessage());
            return 'no-redis';
        }
    }

    /**
     * Acquire a lock, retrying for up to $waitMs milliseconds.
     */
    public function acquireLockWait(string $resource, int $waitMs = 2000, int $ttl = REDIS_LOCK_TTL): ?string
    {
        $deadline = microtime(true) * 1000 + $waitMs;
        do {
            $token = $this->acquireLock($resource, $ttl);
            if ($token !== null) return $token;
            usleep(50_000); // 50 ms
        } while (microtime(true) * 1000 < $deadline);
        return null;
    }

    /**
     * Release a lock. Only releases if the token matches (prevents releasing
     * someone else's lock after TTL expiry).
     */
    public function releaseLock(string $resource, string $token): void
    {
        if (!$this->available || $token === 'no-redis') return;
        try {
            $key = $this->k('lock', $resource);
            // Lua script for atomic check-and-delete
            $lua = <<<'LUA'
if redis.call("get", KEYS[1]) == ARGV[1] then
    return redis.call("del", KEYS[1])
else
    return 0
end
LUA;
            $this->r->eval($lua, [$key], 1);
        } catch (\Throwable $e) {
            error_log('[MeentoRedis] releaseLock error: ' . $e->getMessage());
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  3. Session tokens
    //  Replaces the daily nonce with a per-login random token.
    //  The old nonce is still accepted as a fallback for compatibility.
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Create a new session token for the given public key after a successful login.
     * Returns the token string.
     */
    public function sessionCreate(string $publicKey): string
    {
        $token = bin2hex(random_bytes(32));
        if ($this->available) {
            try {
                $this->r->setex(
                    $this->k('session', hash('sha256', $token)),
                    REDIS_SESSION_TTL,
                    $publicKey
                );
            } catch (\Throwable $e) {
                error_log('[MeentoRedis] sessionCreate error: ' . $e->getMessage());
            }
        }
        return $token;
    }

    /**
     * Validate a session token.
     * Returns the public key the token belongs to, or null if invalid/expired.
     */
    public function sessionValidate(string $token): ?string
    {
        if (!$this->available || $token === '') return null;
        try {
            $pk = $this->r->get($this->k('session', hash('sha256', $token)));
            return ($pk !== false && $pk !== null) ? (string)$pk : null;
        } catch (\Throwable $e) {
            error_log('[MeentoRedis] sessionValidate error: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Refresh the TTL of an active session (sliding expiry).
     */
    public function sessionTouch(string $token): void
    {
        if (!$this->available) return;
        try {
            $this->r->expire(
                $this->k('session', hash('sha256', $token)),
                REDIS_SESSION_TTL
            );
        } catch (\Throwable $e) {}
    }

    /**
     * Destroy a session (logout).
     */
    public function sessionDestroy(string $token): void
    {
        if (!$this->available || $token === '') return;
        try {
            $this->r->del($this->k('session', hash('sha256', $token)));
        } catch (\Throwable $e) {}
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  4. Rate limiting  (sliding window counter using INCR + EXPIRE)
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Record an attempt and return [allowed: bool, attempts: int, reset_in: int].
     * $identifier — e.g. 'login:' . $publicKey  or  'login_ip:' . $_SERVER['REMOTE_ADDR']
     */
    public function rateCheck(string $identifier, int $limit = REDIS_RATE_LIMIT, int $window = REDIS_RATE_WINDOW): array
    {
        if (!$this->available) return ['allowed' => true, 'attempts' => 0, 'reset_in' => 0];
        try {
            $key      = $this->k('rate', $identifier);
            $attempts = (int)$this->r->incr($key);
            if ($attempts === 1) $this->r->expire($key, $window);
            $ttl     = max(0, (int)$this->r->ttl($key));
            return [
                'allowed'  => $attempts <= $limit,
                'attempts' => $attempts,
                'reset_in' => $ttl,
            ];
        } catch (\Throwable $e) {
            error_log('[MeentoRedis] rateCheck error: ' . $e->getMessage());
            return ['allowed' => true, 'attempts' => 0, 'reset_in' => 0];
        }
    }

    /**
     * Reset rate counter (call on successful login to clear failed attempts).
     */
    public function rateReset(string $identifier): void
    {
        if (!$this->available) return;
        try {
            $this->r->del($this->k('rate', $identifier));
        } catch (\Throwable $e) {}
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  5. Event pub/sub
    //  Publishers call eventPublish(); listeners run as a separate process
    //  (see redis_listener.php).
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Publish an event to the meento:events channel.
     * $type — 'upload', 'sync', 'verify', 'login', 'register', 'reverif_done'
     * $payload — any serialisable array
     */
    public function eventPublish(string $type, array $payload): void
    {
        if (!$this->available) return;
        try {
            $msg = json_encode([
                'type'      => $type,
                'ts'        => time(),
                'node'      => gethostname(),
                'payload'   => $payload,
            ], JSON_UNESCAPED_SLASHES);
            $this->r->publish($this->k('events'), $msg);
            // Also append to a capped list for late subscribers (last 500 events)
            $listKey = $this->k('event_log');
            $this->r->lPush($listKey, $msg);
            $this->r->lTrim($listKey, 0, 499);
        } catch (\Throwable $e) {
            error_log('[MeentoRedis] eventPublish error: ' . $e->getMessage());
        }
    }

    /**
     * Read the last N events from the in-memory log (without blocking).
     */
    public function eventLog(int $count = 50): array
    {
        if (!$this->available) return [];
        try {
            $raw = $this->r->lRange($this->k('event_log'), 0, $count - 1);
            return array_map(fn($v) => json_decode($v, true), $raw ?: []);
        } catch (\Throwable $e) {
            return [];
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  6. Re-verification queue
    //  Items: { public_key, server_url, file_hash, filename, enqueued_at }
    //  Consumer: redis_worker.php  (runs as cron or daemon)
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Enqueue a re-verification task.
     * Uses a sorted set keyed by next-check timestamp so the worker can
     * efficiently pop only items that are due.
     */
    public function reverifEnqueue(string $publicKey, string $serverUrl, string $fileHash, string $filename): void
    {
        if (!$this->available) return;
        try {
            $task = json_encode([
                'public_key'  => $publicKey,
                'server_url'  => $serverUrl,
                'file_hash'   => $fileHash,
                'filename'    => $filename,
                'enqueued_at' => time(),
            ]);
            // Score = timestamp when this task should next run
            $score = time() + REDIS_REVERIF_INTERVAL;
            $this->r->zAdd($this->k('reverif_queue'), $score, $task);
        } catch (\Throwable $e) {
            error_log('[MeentoRedis] reverifEnqueue error: ' . $e->getMessage());
        }
    }

    /**
     * Dequeue up to $limit tasks that are due (score <= now).
     * Called by the worker process.
     */
    public function reverifDequeueDue(int $limit = 20): array
    {
        if (!$this->available) return [];
        try {
            $key  = $this->k('reverif_queue');
            $now  = time();
            $items = $this->r->zRangeByScore($key, '-inf', (string)$now, ['limit' => [0, $limit]]);
            if (empty($items)) return [];
            // Remove dequeued items atomically
            $this->r->zRem($key, ...$items);
            return array_map(fn($v) => json_decode($v, true), $items);
        } catch (\Throwable $e) {
            error_log('[MeentoRedis] reverifDequeueDue error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Re-enqueue a task for the next interval (call after a successful re-verify).
     */
    public function reverifReschedule(string $publicKey, string $serverUrl, string $fileHash, string $filename): void
    {
        $this->reverifEnqueue($publicKey, $serverUrl, $fileHash, $filename);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  7. IP-hash / DNS cache
    // ══════════════════════════════════════════════════════════════════════════

    public function ipHashGet(string $host): ?string
    {
        if (!$this->available) return null;
        try {
            $v = $this->r->get($this->k('iphash', $host));
            return ($v !== false && $v !== null) ? (string)$v : null;
        } catch (\Throwable $e) { return null; }
    }

    public function ipHashSet(string $host, string $ipHash): void
    {
        if (!$this->available) return;
        try {
            $this->r->setex($this->k('iphash', $host), 3600, $ipHash); // cache 1 hour
        } catch (\Throwable $e) {}
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  8. Node heartbeat / peer liveness
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Record that this node is alive. Call once per request (or on a timer).
     */
    public function heartbeatPing(string $nodeUrl): void
    {
        if (!$this->available) return;
        try {
            $key = $this->k('heartbeat', hash('sha256', $nodeUrl));
            $this->r->setex($key, 120, json_encode([
                'url'  => $nodeUrl,
                'ts'   => time(),
                'host' => gethostname(),
            ]));
            // Add to the known-nodes set (no TTL on the set itself)
            $this->r->sAdd($this->k('known_nodes'), $nodeUrl);
        } catch (\Throwable $e) {}
    }

    /**
     * Return list of nodes that have sent a heartbeat in the last 2 minutes.
     */
    public function heartbeatLiveNodes(): array
    {
        if (!$this->available) return [];
        try {
            $nodes = $this->r->sMembers($this->k('known_nodes')) ?: [];
            $live  = [];
            foreach ($nodes as $url) {
                $key  = $this->k('heartbeat', hash('sha256', $url));
                $data = $this->r->get($key);
                if ($data !== false && $data !== null) {
                    $live[] = json_decode($data, true);
                }
            }
            return $live;
        } catch (\Throwable $e) { return []; }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  Diagnostics
    // ══════════════════════════════════════════════════════════════════════════

    public function ping(): bool
    {
        if (!$this->available) return false;
        try { return $this->r->ping() === true || $this->r->ping() === '+PONG'; }
        catch (\Throwable $e) { return false; }
    }

    public function info(): array
    {
        if (!$this->available) return ['available' => false];
        try {
            $info = $this->r->info();
            return [
                'available'       => true,
                'redis_version'   => $info['redis_version'] ?? '?',
                'used_memory_human' => $info['used_memory_human'] ?? '?',
                'connected_clients' => $info['connected_clients'] ?? '?',
                'keyspace'        => $info['db' . REDIS_DB] ?? 'empty',
            ];
        } catch (\Throwable $e) {
            return ['available' => false, 'error' => $e->getMessage()];
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
//  Transparent overrides — these functions wrap the originals defined later
//  in index_full.php.  They are registered as class method hooks via the
//  pattern below, using PHP's class_alias / function wrapping trick:
//  we redefine the functions that index_full.php WOULD define, before it does.
//
//  Because PHP does not allow redeclaring a function, we use a different
//  approach: we intercept at the class level by swapping UserStore with
//  RedisAwareUserStore before index_full.php defines anything.
//
//  The trick: class_alias creates an alias so that when index_full.php does
//  `new UserStore()` it actually instantiates RedisAwareUserStore.
// ══════════════════════════════════════════════════════════════════════════════

class RedisAwareUserStore
{
    private int $maxFieldLen = 512;

    // ── Register (passthrough + cache invalidation) ────────────────────────
    public function register(
        string $username,
        string $password,
        string $publicKey,
        string $mail,
        string $aboutMe,
        string $userServer = ''
    ): array {
        $required = [
            'username'   => $username,
            'password'   => $password,
            'public_key' => $publicKey,
            'mail'       => $mail,
            'about_me'   => $aboutMe,
        ];
        foreach ($required as $field => $value) {
            if ($value === '') return ['ok' => false, 'message' => "Field '$field' must not be empty."];
            if (strlen($value) > $this->maxFieldLen) return ['ok' => false, 'message' => "Field '$field' exceeds 512 characters."];
        }
        if (strlen($userServer) > $this->maxFieldLen) return ['ok' => false, 'message' => "Field 'user_server' exceeds 512 characters."];

        $path = accountPath($publicKey);
        if (file_exists($path)) return ['ok' => false, 'message' => 'A account with this public key already exists.'];

        $data = [
            'username'           => $username,
            'password'           => hash('sha512', $password),
            'public_key'         => $publicKey,
            'mail'               => $mail,
            'about_me'           => $aboutMe,
            'user_server'        => $userServer,
            'balance'            => 0,
            'files'              => [],
            'servers'            => [],
            'dates'              => [],
            'server_ip_hashes'   => [],
            'created_at'         => nowIso(),
            'updated_at'         => nowIso(),
        ];

        $ok = $this->safeWrite($publicKey, $data);
        if ($ok) {
            MeentoRedis::get()->eventPublish('register', ['public_key' => $publicKey, 'username' => $username]);
        }
        return $ok
            ? ['ok' => true,  'message' => 'Account created successfully.']
            : ['ok' => false, 'message' => 'Failed to write account file.'];
    }

    // ── Login with rate limiting + session token ───────────────────────────
    public function login(string $publicKey, string $password): array
    {
        $redis = MeentoRedis::get();
        $ip    = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

        // Rate limiting on both public key and IP
        $byKey = $redis->rateCheck('login_key:' . $publicKey);
        $byIp  = $redis->rateCheck('login_ip:' . $ip);

        if (!$byKey['allowed']) {
            return ['ok' => false, 'message' => 'Too many login attempts. Try again in ' . $byKey['reset_in'] . 's.', 'rate_limited' => true];
        }
        if (!$byIp['allowed']) {
            return ['ok' => false, 'message' => 'Too many login attempts from this IP. Try again in ' . $byIp['reset_in'] . 's.', 'rate_limited' => true];
        }

        $data = $this->loadByKey($publicKey);
        if ($data === null) {
            // Count failed attempt even when account doesn't exist (anti-enumeration)
            $redis->rateCheck('login_key:' . $publicKey);
            return ['ok' => false, 'message' => 'Account not found.'];
        }
        if (!hash_equals($data['password'], hash('sha512', $password))) {
            $redis->eventPublish('login_fail', ['public_key' => $publicKey, 'ip' => $ip]);
            return ['ok' => false, 'message' => 'Invalid password.'];
        }

        // Successful login — clear rate counters, create session token
        $redis->rateReset('login_key:' . $publicKey);
        $redis->rateReset('login_ip:' . $ip);
        $token = $redis->sessionCreate($publicKey);

        $safe = $data;
        unset($safe['password']);
        $redis->eventPublish('login', ['public_key' => $publicKey, 'ip' => $ip]);

        return [
            'ok'            => true,
            'message'       => 'Login successful.',
            'data'          => $safe,
            'session_token' => $token,   // NEW: proper session token
            // Legacy nonce still returned so existing clients keep working
            'session_nonce' => expectedNonce($publicKey),
        ];
    }

    // ── addFileRecord (cache-aware) ────────────────────────────────────────
    public function addFileRecord(string $publicKey, array $fileRecord): array
    {
        $redis = MeentoRedis::get();
        $lockToken = $redis->acquireLockWait('account:' . $publicKey);
        if ($lockToken === null) return ['ok' => false, 'message' => 'Could not acquire account lock.'];
        try {
            $data = $this->loadByKey($publicKey);
            if ($data === null) return ['ok' => false, 'message' => 'Account not found.'];
            if (!isset($data['files'])) $data['files'] = [];

            foreach ($data['files'] as &$f) {
                if (is_array($f) && ($f['hash'] ?? '') === $fileRecord['hash']) {
                    $knownUrlKeys  = [];
                    $knownIpHashes = [];
                    foreach ($f['servers'] ?? [] as $s) {
                        $knownUrlKeys[]  = serverUrlKey($s);
                        $ih = $this->cachedIpHash($s, $redis);
                        if ($ih !== null) $knownIpHashes[] = $ih;
                    }
                    foreach ($fileRecord['servers'] ?? [] as $s) {
                        $uk    = serverUrlKey($s);
                        $ih    = $this->cachedIpHash($s, $redis);
                        $dupUrl = in_array($uk, $knownUrlKeys, true);
                        $dupIp  = ($ih !== null) && in_array($ih, $knownIpHashes, true);
                        if (!$dupUrl && !$dupIp) {
                            $f['servers'][]  = $s;
                            $knownUrlKeys[]  = $uk;
                            if ($ih !== null) $knownIpHashes[] = $ih;
                        }
                    }
                    $existingDates = $f['dates'] ?? [];
                    foreach ($fileRecord['dates'] ?? [] as $srv => $dt) {
                        if (!isset($existingDates[$srv])) $existingDates[$srv] = $dt;
                    }
                    $f['dates']         = $existingDates;
                    $f['last_verified'] = nowIso();
                    unset($f);
                    $data['updated_at'] = nowIso();
                    $ok = $this->safeWrite($publicKey, $data);
                    if ($ok) {
                        $redis->eventPublish('file_record_updated', [
                            'public_key' => $publicKey,
                            'hash'       => $fileRecord['hash'],
                        ]);
                        // Enqueue re-verification for new servers
                        foreach ($fileRecord['servers'] ?? [] as $srv) {
                            $redis->reverifEnqueue($publicKey, $srv, $fileRecord['hash'], $fileRecord['filename'] ?? '');
                        }
                    }
                    return $ok
                        ? ['ok' => true, 'message' => 'File record updated (servers merged).']
                        : ['ok' => false, 'message' => 'Failed to save account.'];
                }
            }
            unset($f);

            $data['files'][]    = $fileRecord;
            $data['updated_at'] = nowIso();
            $ok = $this->safeWrite($publicKey, $data);
            if ($ok) {
                $redis->eventPublish('file_added', [
                    'public_key' => $publicKey,
                    'hash'       => $fileRecord['hash'],
                    'filename'   => $fileRecord['filename'] ?? '',
                ]);
                foreach ($fileRecord['servers'] ?? [] as $srv) {
                    $redis->reverifEnqueue($publicKey, $srv, $fileRecord['hash'], $fileRecord['filename'] ?? '');
                }
            }
            return $ok
                ? ['ok' => true, 'message' => 'File record added.']
                : ['ok' => false, 'message' => 'Failed to save account.'];
        } finally {
            $redis->releaseLock('account:' . $publicKey, $lockToken);
        }
    }

    // ── reportServer (IP hash cached, lock-protected) ─────────────────────
    public function reportServer(string $publicKey, string $serverAddress): array
    {
        $redis = MeentoRedis::get();
        $lockToken = $redis->acquireLockWait('account:' . $publicKey);
        if ($lockToken === null) return ['ok' => false, 'message' => 'Could not acquire account lock.', 'awarded' => false];
        try {
            $data = $this->loadByKey($publicKey);
            if ($data === null) return ['ok' => false, 'message' => 'Account not found.', 'awarded' => false];

            if (!isset($data['server_ip_hashes'])) $data['server_ip_hashes'] = [];

            $urlKey = serverUrlKey($serverAddress);
            $ipHash = $this->cachedIpHash($serverAddress, $redis);
            $awarded = false;

            if ($ipHash !== null && in_array($ipHash, $data['server_ip_hashes'], true)) {
                return ['ok' => true, 'message' => 'Duplicate IP rejected.', 'awarded' => false, 'new_balance' => $data['balance']];
            }

            if (!isset($data['servers'][$urlKey])) {
                $data['servers'][$urlKey]  = $serverAddress;
                $data['dates'][$urlKey]    = nowIso();
                if ($ipHash !== null) $data['server_ip_hashes'][] = $ipHash;
                $data['balance']++;
                $data['updated_at'] = nowIso();
                $awarded = true;
            } else {
                $data['dates'][$urlKey] = nowIso();
            }

            if (!$this->safeWrite($publicKey, $data)) return ['ok' => false, 'message' => 'Failed to save account.', 'awarded' => false];
            if ($awarded) {
                $this->logTransaction($publicKey, $serverAddress, $urlKey, $data['balance']);
                $redis->eventPublish('server_confirmed', [
                    'public_key'     => $publicKey,
                    'server'         => $serverAddress,
                    'new_balance'    => $data['balance'],
                ]);
            }

            return ['ok' => true, 'message' => $awarded ? '+1 balance.' : 'Date updated.', 'awarded' => $awarded, 'new_balance' => $data['balance']];
        } finally {
            $redis->releaseLock('account:' . $publicKey, $lockToken);
        }
    }

    // ── getProfile ─────────────────────────────────────────────────────────
    public function getProfile(string $publicKey): ?array
    {
        $data = $this->loadByKey($publicKey);
        if ($data === null) return null;
        unset($data['password']);
        return $data;
    }

    // ── Internal helpers ───────────────────────────────────────────────────
    public function loadByKey(string $publicKey): ?array
    {
        $redis = MeentoRedis::get();
        // Cache hit
        $cached = $redis->accountGet($publicKey);
        if ($cached !== null) return $cached;
        // Cache miss — read from disk
        $path = accountPath($publicKey);
        if (!file_exists($path)) return null;
        $raw  = file_get_contents($path);
        if ($raw === false) return null;
        $data = json_decode($raw, true);
        if (!is_array($data)) return null;
        // Populate cache
        $redis->accountSet($publicKey, $data);
        return $data;
    }

    private function safeWrite(string $publicKey, array $data): bool
    {
        $real = accountPath($publicKey);
        $tmp  = $real . '.tmp';
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) return false;
        if (file_put_contents($tmp, $json, LOCK_EX) === false) return false;
        if (json_decode(file_get_contents($tmp), true) === null) return false;
        if (PHP_OS_FAMILY === 'Windows' && file_exists($real)) unlink($real);
        if (!rename($tmp, $real)) return false;
        file_put_contents($tmp, $json, LOCK_EX); // keep .tmp backup
        // Update cache with freshly written data
        MeentoRedis::get()->accountSet($publicKey, $data);
        return true;
    }

    private function logTransaction(string $publicKey, string $server, string $serverKey, int $balance): void
    {
        $line = sprintf("[%s] +1 point | server: %s (key: %s) | balance: %d\n", nowIso(), $server, $serverKey, $balance);
        file_put_contents(transactionPath($publicKey), $line, FILE_APPEND | LOCK_EX);
    }

    /** IP hash with Redis DNS cache to avoid repeated gethostbyname() calls */
    private function cachedIpHash(string $serverUrl, MeentoRedis $redis): ?string
    {
        $host = parse_url(rtrim($serverUrl, '/'), PHP_URL_HOST);
        if (!$host) return null;
        $cached = $redis->ipHashGet($host);
        if ($cached !== null) return $cached;
        $ip = @gethostbyname($host);
        if ($ip === $host && !filter_var($ip, FILTER_VALIDATE_IP)) return null;
        $hash = hash('sha256', $ip);
        $redis->ipHashSet($host, $hash);
        return $hash;
    }
}

// ── Swap UserStore → RedisAwareUserStore transparently ───────────────────────
// Any `new UserStore()` in index_full.php will instantiate RedisAwareUserStore.
class_alias('RedisAwareUserStore', 'UserStore');

// ── Intercept session_nonce validation to also accept Redis session tokens ────
// We wrap expectedNonce() BEFORE index_full.php defines it, using a
// register_shutdown_function trick is not needed — instead we override the
// upload handler's nonce check via an output buffer + string replacement.
// The cleanest zero-edit approach: register an early request filter.

function meentoRedisBootstrap(): void
{
    $redis = MeentoRedis::get();

    // Heartbeat for this node
    $nodeUrl = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . $_SERVER['REQUEST_URI'];
    $redis->heartbeatPing(rtrim(dirname($nodeUrl), '/'));

    // Validate Redis session token if present in the upload request.
    // This runs before the upload handler checks the nonce, so we inject
    // the correct nonce into $_POST if the token is valid.
    if (!empty($_POST['session_token'])) {
        $pk = $redis->sessionValidate($_POST['session_token']);
        if ($pk !== null) {
            // Inject the expected nonce so the existing nonce check passes
            $_POST['session_nonce'] = hash('sha256', pubkeyToFilename($pk) . date('Y-m-d'));
            $_POST['public_key']    = $pk;
            $redis->sessionTouch($_POST['session_token']);
        }
    }

    // Intercept logout action (JSON POST action=logout)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && strpos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== false) {
        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        if (($body['action'] ?? '') === 'logout' && !empty($body['session_token'])) {
            $redis->sessionDestroy($body['session_token']);
            header('Content-Type: application/json');
            echo json_encode(['ok' => true, 'message' => 'Logged out.']);
            exit;
        }
        // Re-wind the input stream is not possible, but we can buffer it
        // index_full.php reads php://input fresh, so this is fine.
    }

    // ?redis_status endpoint — diagnostics
    if (isset($_GET['redis_status'])) {
        header('Content-Type: application/json');
        echo json_encode([
            'redis'      => $redis->info(),
            'live_nodes' => $redis->heartbeatLiveNodes(),
            'event_log'  => $redis->eventLog(20),
        ], JSON_PRETTY_PRINT);
        exit;
    }
}

// Run bootstrap immediately on include
meentoRedisBootstrap();
