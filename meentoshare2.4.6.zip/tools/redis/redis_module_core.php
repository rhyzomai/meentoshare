<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  redis_module_core.php — MeentoRedis class only, no web hooks
//  Used by redis_worker.php and any other CLI tool that needs Redis access
//  without the UserStore swap or the HTTP bootstrap logic.
// ═══════════════════════════════════════════════════════════════════════════════

if (!defined('REDIS_HOST'))            define('REDIS_HOST',            '127.0.0.1');
if (!defined('REDIS_PORT'))            define('REDIS_PORT',            6379);
if (!defined('REDIS_PASSWORD'))        define('REDIS_PASSWORD',        '');
if (!defined('REDIS_DB'))              define('REDIS_DB',              0);
if (!defined('REDIS_PREFIX'))          define('REDIS_PREFIX',          'meento:');
if (!defined('REDIS_ACCOUNT_TTL'))     define('REDIS_ACCOUNT_TTL',     300);
if (!defined('REDIS_SESSION_TTL'))     define('REDIS_SESSION_TTL',     86400);
if (!defined('REDIS_LOCK_TTL'))        define('REDIS_LOCK_TTL',        5);
if (!defined('REDIS_RATE_WINDOW'))     define('REDIS_RATE_WINDOW',     300);
if (!defined('REDIS_RATE_LIMIT'))      define('REDIS_RATE_LIMIT',      10);
if (!defined('REDIS_REVERIF_INTERVAL'))define('REDIS_REVERIF_INTERVAL',604800);
if (!defined('REDIS_ENABLED'))         define('REDIS_ENABLED',         true);

class MeentoRedis
{
    private static ?MeentoRedis $instance = null;
    private ?\Redis $r = null;
    private bool $available = false;

    private function __construct()
    {
        if (!REDIS_ENABLED) return;
        if (!extension_loaded('redis')) {
            error_log('[MeentoRedis] php-redis extension not loaded.');
            return;
        }
        try {
            $this->r = new \Redis();
            if (!$this->r->connect(REDIS_HOST, REDIS_PORT, 2.0))
                throw new \RuntimeException('connect() returned false');
            if (REDIS_PASSWORD !== '') $this->r->auth(REDIS_PASSWORD);
            $this->r->select(REDIS_DB);
            $this->r->setOption(\Redis::OPT_PREFIX, REDIS_PREFIX);
            $this->available = true;
        } catch (\Throwable $e) {
            error_log('[MeentoRedis] ' . $e->getMessage());
            $this->r = null;
        }
    }

    public static function get(): self { if (!self::$instance) self::$instance = new self(); return self::$instance; }
    public function available(): bool  { return $this->available; }
    public function raw(): ?\Redis     { return $this->r; }

    private function k(string ...$parts): string { return implode(':', $parts); }

    // Account cache
    public function accountGet(string $pk): ?array {
        if (!$this->available) return null;
        try { $v = $this->r->get($this->k('account', $pk)); return ($v !== false && $v !== null) ? json_decode($v, true) : null; }
        catch (\Throwable $e) { return null; }
    }
    public function accountSet(string $pk, array $data): void {
        if (!$this->available) return;
        try { $this->r->setex($this->k('account', $pk), REDIS_ACCOUNT_TTL, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); }
        catch (\Throwable $e) {}
    }
    public function accountInvalidate(string $pk): void {
        if (!$this->available) return;
        try { $this->r->del($this->k('account', $pk)); } catch (\Throwable $e) {}
    }

    // Locks
    public function acquireLock(string $res, int $ttl = REDIS_LOCK_TTL): ?string {
        if (!$this->available) return 'no-redis';
        try { $t = bin2hex(random_bytes(16)); return $this->r->set($this->k('lock', $res), $t, ['NX', 'EX' => $ttl]) ? $t : null; }
        catch (\Throwable $e) { return 'no-redis'; }
    }
    public function acquireLockWait(string $res, int $waitMs = 2000, int $ttl = REDIS_LOCK_TTL): ?string {
        $dl = microtime(true) * 1000 + $waitMs;
        do { $t = $this->acquireLock($res, $ttl); if ($t !== null) return $t; usleep(50_000); } while (microtime(true) * 1000 < $dl);
        return null;
    }
    public function releaseLock(string $res, string $token): void {
        if (!$this->available || $token === 'no-redis') return;
        try { $this->r->eval("if redis.call('get',KEYS[1])==ARGV[1] then return redis.call('del',KEYS[1]) else return 0 end", [$this->k('lock', $res)], 1); }
        catch (\Throwable $e) {}
    }

    // Sessions
    public function sessionCreate(string $pk): string {
        $t = bin2hex(random_bytes(32));
        if ($this->available) try { $this->r->setex($this->k('session', hash('sha256', $t)), REDIS_SESSION_TTL, $pk); } catch (\Throwable $e) {}
        return $t;
    }
    public function sessionValidate(string $token): ?string {
        if (!$this->available || $token === '') return null;
        try { $v = $this->r->get($this->k('session', hash('sha256', $token))); return ($v !== false && $v !== null) ? (string)$v : null; }
        catch (\Throwable $e) { return null; }
    }
    public function sessionTouch(string $token): void {
        if (!$this->available) return;
        try { $this->r->expire($this->k('session', hash('sha256', $token)), REDIS_SESSION_TTL); } catch (\Throwable $e) {}
    }
    public function sessionDestroy(string $token): void {
        if (!$this->available || $token === '') return;
        try { $this->r->del($this->k('session', hash('sha256', $token))); } catch (\Throwable $e) {}
    }

    // Rate limiting
    public function rateCheck(string $id, int $limit = REDIS_RATE_LIMIT, int $window = REDIS_RATE_WINDOW): array {
        if (!$this->available) return ['allowed' => true, 'attempts' => 0, 'reset_in' => 0];
        try {
            $key = $this->k('rate', $id); $n = (int)$this->r->incr($key);
            if ($n === 1) $this->r->expire($key, $window);
            return ['allowed' => $n <= $limit, 'attempts' => $n, 'reset_in' => max(0, (int)$this->r->ttl($key))];
        } catch (\Throwable $e) { return ['allowed' => true, 'attempts' => 0, 'reset_in' => 0]; }
    }
    public function rateReset(string $id): void {
        if (!$this->available) return;
        try { $this->r->del($this->k('rate', $id)); } catch (\Throwable $e) {}
    }

    // Events
    public function eventPublish(string $type, array $payload): void {
        if (!$this->available) return;
        try {
            $msg = json_encode(['type' => $type, 'ts' => time(), 'node' => gethostname(), 'payload' => $payload], JSON_UNESCAPED_SLASHES);
            $this->r->publish($this->k('events'), $msg);
            $this->r->lPush($this->k('event_log'), $msg);
            $this->r->lTrim($this->k('event_log'), 0, 499);
        } catch (\Throwable $e) {}
    }
    public function eventLog(int $n = 50): array {
        if (!$this->available) return [];
        try { return array_map(fn($v) => json_decode($v, true), $this->r->lRange($this->k('event_log'), 0, $n - 1) ?: []); }
        catch (\Throwable $e) { return []; }
    }

    // Re-verification queue
    public function reverifEnqueue(string $pk, string $srv, string $hash, string $fn): void {
        if (!$this->available) return;
        try { $this->r->zAdd($this->k('reverif_queue'), time() + REDIS_REVERIF_INTERVAL, json_encode(['public_key' => $pk, 'server_url' => $srv, 'file_hash' => $hash, 'filename' => $fn, 'enqueued_at' => time()])); }
        catch (\Throwable $e) {}
    }
    public function reverifDequeueDue(int $limit = 20): array {
        if (!$this->available) return [];
        try {
            $key = $this->k('reverif_queue');
            $items = $this->r->zRangeByScore($key, '-inf', (string)time(), ['limit' => [0, $limit]]);
            if (empty($items)) return [];
            $this->r->zRem($key, ...$items);
            return array_map(fn($v) => json_decode($v, true), $items);
        } catch (\Throwable $e) { return []; }
    }
    public function reverifReschedule(string $pk, string $srv, string $hash, string $fn): void { $this->reverifEnqueue($pk, $srv, $hash, $fn); }

    // IP hash cache
    public function ipHashGet(string $host): ?string {
        if (!$this->available) return null;
        try { $v = $this->r->get($this->k('iphash', $host)); return ($v !== false && $v !== null) ? (string)$v : null; } catch (\Throwable $e) { return null; }
    }
    public function ipHashSet(string $host, string $h): void {
        if (!$this->available) return;
        try { $this->r->setex($this->k('iphash', $host), 3600, $h); } catch (\Throwable $e) {}
    }

    // Heartbeat
    public function heartbeatPing(string $url): void {
        if (!$this->available) return;
        try {
            $this->r->setex($this->k('heartbeat', hash('sha256', $url)), 120, json_encode(['url' => $url, 'ts' => time(), 'host' => gethostname()]));
            $this->r->sAdd($this->k('known_nodes'), $url);
        } catch (\Throwable $e) {}
    }
    public function heartbeatLiveNodes(): array {
        if (!$this->available) return [];
        try {
            $nodes = $this->r->sMembers($this->k('known_nodes')) ?: [];
            $live = [];
            foreach ($nodes as $url) { $d = $this->r->get($this->k('heartbeat', hash('sha256', $url))); if ($d) $live[] = json_decode($d, true); }
            return $live;
        } catch (\Throwable $e) { return []; }
    }

    // Diagnostics
    public function ping(): bool {
        if (!$this->available) return false;
        try { $p = $this->r->ping(); return $p === true || $p === '+PONG'; } catch (\Throwable $e) { return false; }
    }
    public function info(): array {
        if (!$this->available) return ['available' => false];
        try {
            $i = $this->r->info();
            return ['available' => true, 'redis_version' => $i['redis_version'] ?? '?', 'used_memory_human' => $i['used_memory_human'] ?? '?', 'connected_clients' => $i['connected_clients'] ?? '?'];
        } catch (\Throwable $e) { return ['available' => false, 'error' => $e->getMessage()]; }
    }
}
