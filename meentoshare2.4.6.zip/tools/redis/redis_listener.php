#!/usr/bin/env php
<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  redis_listener.php — Meento Share event listener
//
//  Subscribes to the meento:events pub/sub channel and logs or reacts to events
//  in real time.  Run as a long-lived process or daemon.
//
//  Usage:
//    php redis_listener.php                   — log to stdout
//    php redis_listener.php --log file.log    — append to file
//    php redis_listener.php --json            — JSON output (one object per line)
//
//  Extend the handleEvent() function below to add your own reactions:
//    - Send a webhook on 'upload'
//    - Alert on repeated 'login_fail' from the same IP
//    - Trigger a backup on 'server_confirmed'
// ═══════════════════════════════════════════════════════════════════════════════

define('REDIS_HOST',    getenv('REDIS_HOST')   ?: '127.0.0.1');
define('REDIS_PORT',    (int)(getenv('REDIS_PORT')  ?: 6379));
define('REDIS_PASSWORD',getenv('REDIS_PASS')   ?: '');
define('REDIS_DB',      (int)(getenv('REDIS_DB')    ?: 0));
define('REDIS_PREFIX',  getenv('REDIS_PREFIX') ?: 'meento:');
define('REDIS_ENABLED', true);
define('REDIS_ACCOUNT_TTL', 300);
define('REDIS_SESSION_TTL', 86400);
define('REDIS_LOCK_TTL', 5);
define('REDIS_RATE_WINDOW', 300);
define('REDIS_RATE_LIMIT', 10);
define('REDIS_REVERIF_INTERVAL', 604800);

require_once __DIR__ . '/redis_module_core.php';

// ── CLI args ──────────────────────────────────────────────────────────────────
$args    = $argv ?? [];
$logFile = null;
$jsonOut = in_array('--json', $args);
if (($li = array_search('--log', $args)) !== false && isset($args[$li + 1])) {
    $logFile = $args[$li + 1];
}

// ── Event handler — extend this ───────────────────────────────────────────────
function handleEvent(string $channel, array $event): void
{
    global $logFile, $jsonOut;
    $type    = $event['type']    ?? 'unknown';
    $ts      = date('c', $event['ts'] ?? time());
    $node    = $event['node']    ?? '?';
    $payload = $event['payload'] ?? [];

    if ($jsonOut) {
        $line = json_encode(['ts' => $ts, 'type' => $type, 'node' => $node, 'payload' => $payload]) . "\n";
    } else {
        $detail = '';
        switch ($type) {
            case 'upload':
            case 'file_added':
                $detail = "hash={$payload['hash']} file={$payload['filename']}";
                break;
            case 'server_confirmed':
                $detail = "server={$payload['server']} balance={$payload['new_balance']}";
                break;
            case 'login':
            case 'login_fail':
                $detail = "key={$payload['public_key']} ip={$payload['ip']}";
                break;
            case 'register':
                $detail = "user={$payload['username']}";
                break;
            case 'reverif_done':
                $ok     = ($payload['ok'] ?? false) ? 'OK' : 'FAIL';
                $detail = "[$ok] hash={$payload['hash']} server={$payload['server']}";
                break;
            default:
                $detail = json_encode($payload);
        }
        $line = "[$ts] [$node] $type  $detail\n";
    }

    // Write
    if ($logFile) {
        file_put_contents($logFile, $line, FILE_APPEND | LOCK_EX);
    } else {
        echo $line;
        flush();
    }
}

// ── Subscribe ─────────────────────────────────────────────────────────────────
if (!extension_loaded('redis')) {
    fwrite(STDERR, "ERROR: php-redis extension not loaded.\n");
    exit(1);
}

$r = new Redis();
try {
    $r->connect(REDIS_HOST, REDIS_PORT, 5.0);
    if (REDIS_PASSWORD !== '') $r->auth(REDIS_PASSWORD);
    $r->select(REDIS_DB);
} catch (Throwable $e) {
    fwrite(STDERR, "ERROR: Redis connection failed: " . $e->getMessage() . "\n");
    exit(1);
}

$channel = REDIS_PREFIX . 'events';
echo "[" . date('c') . "] Listening on $channel ...\n";

$r->subscribe([$channel], function (Redis $redis, string $chan, string $msg) {
    $event = json_decode($msg, true);
    if (!is_array($event)) return;
    handleEvent($chan, $event);
});
