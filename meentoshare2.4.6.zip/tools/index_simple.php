﻿<?php
// ============================================================
//  Seastar — File Chunker, Seeder & P2P Distributor
//  Sends each chunk to all servers listed in servers.txt
//  Receives and stores chunks sent by remote nodes
//
//  TRANSPORT MODES
//  ─────────────────────────────────────────────────────────
//  GET  (default) — sends chunk data as query-string params.
//                   The "Max GET Chunk Size" slider caps how
//                   many bytes of raw file data go into a
//                   single GET request (100 B – 8 KB).
//                   Larger files are split into more chunks
//                   automatically so each URL stays safe.
//
//  POST           — sends chunk data in the request body.
//                   Supports the full Chunk Size slider
//                   (64 KB – 4 MB) without URL-length issues.
// ============================================================

define('BASE64_HASH_DIR',    __DIR__ . '/base64_hash');
define('CHUNKS_DIR',         __DIR__ . '/chunks');
define('SEEDER_TMPDIR',      __DIR__ . '/seeder_tmp');
define('FILES_DIR',          __DIR__ . '/files');
define('SERVERS_FILE',       __DIR__ . '/servers.txt');
define('PUBLIC_KEY_FILE',    __DIR__ . '/public_key.txt');
define('NODE_INFO_FILE',     __DIR__ . '/node_info.txt');
define('DEFAULT_CHUNK_SIZE', 512 * 1024);
define('MAX_UPLOAD_MB',      200);

// GET mode limits (bytes of raw binary data per chunk before base64)
define('GET_CHUNK_MIN_BYTES', 100);
define('GET_CHUNK_MAX_BYTES', 8192);   // 8 KB → ~10.9 KB base64 → well under URL limits

foreach ([BASE64_HASH_DIR, CHUNKS_DIR, SEEDER_TMPDIR, FILES_DIR] as $d) {
    if (!is_dir($d)) mkdir($d, 0755, true);
}

// ============================================================
//  Identity helpers
// ============================================================

function loadPublicKey(): string {
    if (!file_exists(PUBLIC_KEY_FILE)) return '';
    $fh = fopen(PUBLIC_KEY_FILE, 'r');
    if (!$fh) return '';
    $out = '';
    while (!feof($fh)) $out .= fread($fh, 4096);
    fclose($fh);
    return trim($out);
}

function loadNodeInfo(): string {
    if (!file_exists(NODE_INFO_FILE)) return '';
    $fh = fopen(NODE_INFO_FILE, 'r');
    if (!$fh) return '';
    $out = '';
    while (!feof($fh)) $out .= fread($fh, 4096);
    fclose($fh);
    return trim($out);
}

// ============================================================
//  Server list helpers
// ============================================================

function loadServers(): array {
    if (!file_exists(SERVERS_FILE)) return [];
    $lines = file(SERVERS_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    return array_values(array_unique(array_map('trim', $lines ?: [])));
}

function addServer(string $url): string {
    $url = trim($url);
    if ($url === '') return 'empty';
    $servers = loadServers();
    if (in_array($url, $servers, true)) return 'duplicate';
    $servers[] = $url;
    $fh = fopen(SERVERS_FILE, 'w');
    if (!$fh) return 'write_error';
    foreach ($servers as $s) fwrite($fh, $s . "\n");
    fclose($fh);
    return 'ok';
}

// ============================================================
//  Receive chunk  (API endpoint: ?action=receive_chunk)
//
//  Accepts both GET and POST transparently.
//  Required fields (any of $_GET / $_POST):
//    filename, file_hash, chunk_num, chunk_hash,
//    contents, public_key, node_info, total_chunks
//  Optional:
//    chunk_list  — comma-separated list of all chunk names
// ============================================================

function receiveParam(string $key): string {
    // Prefer POST body; fall back to query-string
    if (isset($_POST[$key]) && $_POST[$key] !== '') return $_POST[$key];
    if (isset($_GET[$key])  && $_GET[$key]  !== '') return $_GET[$key];
    return '';
}

function handleReceiveChunk(): void {
    $required = ['filename','file_hash','chunk_num','chunk_hash',
                 'contents','total_chunks'];

    foreach ($required as $k) {
        if (receiveParam($k) === '') {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => "Missing parameter: {$k}"]);
            exit;
        }
    }

    $filename    = basename(receiveParam('filename'));
    $fileHash    = strtolower(preg_replace('/[^a-f0-9]/i', '', receiveParam('file_hash')));
    $chunkNum    = (int)receiveParam('chunk_num');
    $sentHash    = strtolower(trim(receiveParam('chunk_hash')));
    $contents    = receiveParam('contents');
    $publicKey   = receiveParam('public_key');
    $nodeInfo    = receiveParam('node_info');
    $totalChunks = (int)receiveParam('total_chunks');

    // Validate file_hash (32 hex chars)
    if (!preg_match('/^[a-f0-9]{32}$/', $fileHash)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Invalid file_hash']);
        exit;
    }

    // Validate chunk_num
    if ($chunkNum < 1 || $chunkNum > $totalChunks) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Invalid chunk_num']);
        exit;
    }

    // Integrity check: md5(base64-contents) must match sent chunk_hash
    $actualHash = md5($contents);
    if ($actualHash !== $sentHash) {
        http_response_code(400);
        echo json_encode([
            'ok'       => false,
            'error'    => 'Chunk integrity check failed',
            'expected' => $sentHash,
            'got'      => $actualHash,
        ]);
        exit;
    }

    // Chunk filename: <file_hash>.<chunk_num>.<chunk_hash>.json
    $chunkName     = $fileHash . '.' . $chunkNum . '.' . $sentHash;
    $chunkJsonPath = BASE64_HASH_DIR . '/' . $chunkName . '.json';

    $isNew = !file_exists($chunkJsonPath);

    if ($isNew) {
        $data = [
            'filename'    => $filename,
            'file_hash'   => $fileHash,
            'chunk_num'   => $chunkNum,
            'chunk_name'  => $chunkName,
            'content'     => $contents,
            'public_key'  => $publicKey,
            'node_info'   => $nodeInfo,
            'received_at' => date('c'),
        ];
        $fh = fopen($chunkJsonPath, 'w');
        if ($fh) {
            fwrite($fh, json_encode($data, JSON_PRETTY_PRINT));
            fclose($fh);
        } else {
            http_response_code(500);
            echo json_encode(['ok' => false, 'error' => 'Failed to write chunk file']);
            exit;
        }
    }

    // Chunks index: chunks/<file_hash>.txt — written ONCE via fopen('x')
    $chunksIndexPath = CHUNKS_DIR . '/' . $fileHash . '.txt';
    $chunkListRaw    = receiveParam('chunk_list');
    if (!file_exists($chunksIndexPath) && $chunkListRaw !== '') {
        $chunkList = array_filter(array_map('trim', explode(',', $chunkListRaw)));
        $fh = fopen($chunksIndexPath, 'x');
        if ($fh) {
            foreach ($chunkList as $cn) fwrite($fh, $cn . "\n");
            fclose($fh);
        }
    }

    echo json_encode([
        'ok'     => true,
        'chunk'  => $chunkName,
        'stored' => $isNew ? 'new' : 'exists',
    ]);
    exit;
}

// ============================================================
//  Receive full file via POST  (API endpoint: ?action=receive_file)
//
//  Accepts a multipart/form-data POST with:
//    $_FILES['file']         — the raw file upload
//    $_POST['public_key']    — sender's public key (optional)
//    $_POST['node_info']     — sender's node info (optional)
//
//  Stores as files/<md5_of_file>.<ext>
//  Never overwrites an existing file.
// ============================================================

function handleReceiveFile(): void {
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        $code = $_FILES['file']['error'] ?? -1;
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => "File upload error code: {$code}"]);
        exit;
    }

    $f        = $_FILES['file'];
    $origName = basename($f['name']);
    $ext      = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
    $fileHash = md5_file($f['tmp_name']);

    if (!$fileHash) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'Could not compute file hash']);
        exit;
    }

    $destName = $ext !== '' ? "{$fileHash}.{$ext}" : $fileHash;
    $destPath = FILES_DIR . '/' . $destName;

    if (file_exists($destPath)) {
        echo json_encode([
            'ok'       => true,
            'file'     => $destName,
            'stored'   => 'exists',
            'hash'     => $fileHash,
        ]);
        exit;
    }

    if (!move_uploaded_file($f['tmp_name'], $destPath)) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'Failed to move uploaded file']);
        exit;
    }

    echo json_encode([
        'ok'     => true,
        'file'   => $destName,
        'stored' => 'new',
        'hash'   => $fileHash,
    ]);
    exit;
}

// ============================================================
//  Send full file via POST to all servers
// ============================================================

function sendFileToServers(string $tmpPath, string $originalName): array {
    $servers   = loadServers();
    $publicKey = loadPublicKey();
    $nodeInfo  = loadNodeInfo();
    $fileHash  = md5_file($tmpPath);
    $fileSize  = filesize($tmpPath);
    $ext       = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    $destName  = $ext !== '' ? "{$fileHash}.{$ext}" : $fileHash;
    $log       = [];

    $log[] = ['type' => 'info', 'msg' => "File: {$originalName}"];
    $log[] = ['type' => 'info', 'msg' => "MD5: {$fileHash}"];
    $log[] = ['type' => 'info', 'msg' => "Size: " . formatBytes($fileSize)];
    $log[] = ['type' => 'info', 'msg' => "Transport: POST (direct file)"];
    $log[] = ['type' => 'info', 'msg' => "Destination filename: {$destName}"];
    $log[] = ['type' => 'info', 'msg' => "Servers: " . count($servers)];

    if (empty($servers)) {
        $log[] = ['type' => 'error', 'msg' => 'No servers in servers.txt — add servers in the Servers tab.'];
        return ['success' => false, 'log' => $log, 'file_hash' => $fileHash,
                'total_chunks' => 1, 'new_chunks' => 0, 'skipped' => 0,
                'original_name' => $originalName, 'file_size' => $fileSize];
    }

    $newCount = 0;
    $skipped  = 0;

    foreach ($servers as $server) {
        $server = rtrim($server, '/');
        $url    = $server . '/index.php?action=receive_file';

        // Build multipart body using curl if available, else stream_context
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_POST           => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 120,
                CURLOPT_POSTFIELDS     => [
                    'file'       => new CURLFile($tmpPath, mime_content_type($tmpPath) ?: 'application/octet-stream', $originalName),
                    'public_key' => $publicKey,
                    'node_info'  => $nodeInfo,
                ],
            ]);
            $resp  = curl_exec($ch);
            $errno = curl_errno($ch);
            curl_close($ch);
            if ($errno || $resp === false) {
                $log[] = ['type' => 'error', 'msg' => "→ {$server} FAILED (curl error {$errno})"];
                continue;
            }
        } else {
            // Fallback: build multipart manually
            $boundary = '----SeastarBoundary' . bin2hex(random_bytes(8));
            $body  = "--{$boundary}\r\n";
            $body .= "Content-Disposition: form-data; name=\"public_key\"\r\n\r\n{$publicKey}\r\n";
            $body .= "--{$boundary}\r\n";
            $body .= "Content-Disposition: form-data; name=\"node_info\"\r\n\r\n{$nodeInfo}\r\n";
            $body .= "--{$boundary}\r\n";
            $mime  = mime_content_type($tmpPath) ?: 'application/octet-stream';
            $body .= "Content-Disposition: form-data; name=\"file\"; filename=\"" . addslashes($originalName) . "\"\r\n";
            $body .= "Content-Type: {$mime}\r\n\r\n";
            $fh    = fopen($tmpPath, 'rb');
            $body .= fread($fh, filesize($tmpPath));
            fclose($fh);
            $body .= "\r\n--{$boundary}--\r\n";

            $ctx  = stream_context_create(['http' => [
                'method'        => 'POST',
                'header'        => "Content-Type: multipart/form-data; boundary={$boundary}\r\n"
                                 . "Content-Length: " . strlen($body) . "\r\n",
                'content'       => $body,
                'timeout'       => 120,
                'ignore_errors' => true,
            ]]);
            $resp = @file_get_contents($url, false, $ctx);
            if ($resp === false) {
                $log[] = ['type' => 'error', 'msg' => "→ {$server} FAILED (no response)"];
                continue;
            }
        }

        $decoded = json_decode($resp, true);
        if (!empty($decoded['ok'])) {
            if (($decoded['stored'] ?? '') === 'exists') {
                $skipped++;
                $log[] = ['type' => 'skip', 'msg' => "→ {$server} file already existed ({$destName})"];
            } else {
                $newCount++;
                $log[] = ['type' => 'ok', 'msg' => "→ {$server} ✓ stored as {$destName}"];
            }
        } else {
            $err   = is_array($decoded) ? ($decoded['error'] ?? $resp) : $resp;
            $log[] = ['type' => 'error', 'msg' => "→ {$server} error: {$err}"];
        }
    }

    $log[] = ['type' => 'ok',
              'msg'  => "Done. {$newCount} stored, {$skipped} already existed across "
                        . count($servers) . " server(s)."];

    return [
        'success'       => true,
        'log'           => $log,
        'file_hash'     => $fileHash,
        'total_chunks'  => 1,
        'new_chunks'    => $newCount,
        'skipped'       => $skipped,
        'original_name' => $originalName,
        'file_size'     => $fileSize,
    ];
}

// ============================================================
//  Send chunks to all servers
//
//  $transport  : 'get' | 'post'
//  $getChunkBytes: only used when $transport === 'get'.
//                  Raw bytes per chunk (100–8192). Each chunk
//                  is base64-encoded before sending, so the
//                  actual query-string value is ~33% larger.
//  $chunkSize  : only used when $transport === 'post' (bytes).
// ============================================================

function sendChunksToServers(
    string $tmpPath,
    string $originalName,
    int    $chunkSize,       // POST chunk size (bytes)
    string $transport,       // 'get' or 'post'
    int    $getChunkBytes    // GET raw bytes per chunk (100-8192)
): array {
    $servers     = loadServers();
    $publicKey   = loadPublicKey();
    $nodeInfo    = loadNodeInfo();
    $fileHash    = md5_file($tmpPath);
    $fileSize    = filesize($tmpPath);
    $log         = [];

    // Choose effective chunk size based on transport
    $effectiveChunkSize = ($transport === 'get') ? $getChunkBytes : $chunkSize;
    $totalChunks = (int)ceil($fileSize / $effectiveChunkSize);

    $log[] = ['type' => 'info', 'msg' => "File: {$originalName}"];
    $log[] = ['type' => 'info', 'msg' => "MD5: {$fileHash}"];
    $log[] = ['type' => 'info', 'msg' => "Size: " . formatBytes($fileSize)];
    $log[] = ['type' => 'info', 'msg' => "Transport: " . strtoupper($transport)];
    $log[] = ['type' => 'info', 'msg' => "Chunk size: " . formatBytes($effectiveChunkSize)
              . ($transport === 'get' ? ' (raw bytes before base64)' : '')];
    $log[] = ['type' => 'info', 'msg' => "Total chunks: {$totalChunks}"];
    $log[] = ['type' => 'info', 'msg' => "Servers: " . count($servers)];

    if (empty($servers)) {
        $log[] = ['type' => 'error', 'msg' => 'No servers in servers.txt — add servers in the Servers tab.'];
        return ['success' => false, 'log' => $log, 'file_hash' => $fileHash,
                'total_chunks' => $totalChunks, 'new_chunks' => 0, 'skipped' => 0,
                'original_name' => $originalName, 'file_size' => $fileSize];
    }

    // Read all chunks into memory to compute chunk_list upfront
    $fh = fopen($tmpPath, 'rb');
    if (!$fh) {
        $log[] = ['type' => 'error', 'msg' => 'Could not open file.'];
        return ['success' => false, 'log' => $log, 'file_hash' => $fileHash,
                'total_chunks' => $totalChunks, 'new_chunks' => 0, 'skipped' => 0,
                'original_name' => $originalName, 'file_size' => $fileSize];
    }

    $chunks = [];
    for ($i = 1; $i <= $totalChunks; $i++) {
        $raw       = fread($fh, $effectiveChunkSize);
        $encoded   = base64_encode($raw);
        $chunkHash = md5($encoded);
        $chunks[]  = ['num' => $i, 'hash' => $chunkHash, 'encoded' => $encoded];
    }
    fclose($fh);

    // Build chunk_list param: file_hash.chunk_num.chunk_hash per entry
    $chunkNames     = [];
    foreach ($chunks as $c) {
        $chunkNames[] = $fileHash . '.' . $c['num'] . '.' . $c['hash'];
    }
    $chunkListParam = implode(',', $chunkNames);

    $newChunks = 0;
    $skipped   = 0;

    foreach ($chunks as $c) {
        $chunkName = $fileHash . '.' . $c['num'] . '.' . $c['hash'];

        foreach ($servers as $server) {
            $server = rtrim($server, '/');

            $payload = [
                'action'       => 'receive_chunk',
                'filename'     => $originalName,
                'file_hash'    => $fileHash,
                'chunk_num'    => $c['num'],
                'chunk_hash'   => $c['hash'],
                'contents'     => $c['encoded'],
                'public_key'   => $publicKey,
                'node_info'    => $nodeInfo,
                'total_chunks' => $totalChunks,
                'chunk_list'   => $chunkListParam,
            ];

            if ($transport === 'post') {
                // ── POST: all data goes in the request body ──────────
                $url = $server . '/index.php';
                $ctx = stream_context_create(['http' => [
                    'method'        => 'POST',
                    'header'        => "Content-Type: application/x-www-form-urlencoded\r\n",
                    'content'       => http_build_query($payload),
                    'timeout'       => 30,
                    'ignore_errors' => true,
                ]]);
            } else {
                // ── GET: all data goes in the query string ───────────
                // Safe because getChunkBytes is capped at 8 KB (raw),
                // which becomes ~10.9 KB base64 — well within server limits.
                $url = $server . '/index.php?' . http_build_query($payload);
                $ctx = stream_context_create(['http' => [
                    'method'        => 'GET',
                    'timeout'       => 15,
                    'ignore_errors' => true,
                ]]);
            }

            $resp = @file_get_contents($url, false, $ctx);

            if ($resp === false) {
                $log[] = ['type' => 'error',
                          'msg'  => "Chunk {$c['num']}/{$totalChunks} → {$server} FAILED (no response)"];
            } else {
                $decoded = json_decode($resp, true);
                if (!empty($decoded['ok'])) {
                    if (($decoded['stored'] ?? '') === 'exists') {
                        $skipped++;
                        $log[] = ['type' => 'skip',
                                  'msg'  => "Chunk {$c['num']}/{$totalChunks} → {$server} already existed ({$c['hash']})"];
                    } else {
                        $newChunks++;
                        $log[] = ['type' => 'ok',
                                  'msg'  => "Chunk {$c['num']}/{$totalChunks} → {$server} ✓ stored ({$c['hash']})"];
                    }
                } else {
                    $err   = is_array($decoded) ? ($decoded['error'] ?? $resp) : $resp;
                    $log[] = ['type' => 'error',
                              'msg'  => "Chunk {$c['num']}/{$totalChunks} → {$server} error: {$err}"];
                }
            }
        }
    }

    $log[] = ['type' => 'ok',
              'msg'  => "Done. {$newChunks} stored, {$skipped} already existed across "
                        . count($servers) . " server(s)."];

    return [
        'success'       => true,
        'log'           => $log,
        'file_hash'     => $fileHash,
        'total_chunks'  => $totalChunks,
        'new_chunks'    => $newChunks,
        'skipped'       => $skipped,
        'original_name' => $originalName,
        'file_size'     => $fileSize,
    ];
}

// ============================================================
//  Local chunk + seed (stores locally, same format as received)
// ============================================================

function chunkAndSeed(string $tmpPath, string $originalName, int $chunkSize): array {
    $publicKey   = loadPublicKey();
    $nodeInfo    = loadNodeInfo();
    $fileHash    = md5_file($tmpPath);
    $fileSize    = filesize($tmpPath);
    $totalChunks = (int)ceil($fileSize / $chunkSize);
    $log         = [];
    $existingChunks = 0;
    $newChunks   = 0;

    $log[] = ['type' => 'info', 'msg' => "File: {$originalName}"];
    $log[] = ['type' => 'info', 'msg' => "MD5: {$fileHash}"];
    $log[] = ['type' => 'info', 'msg' => "Size: " . formatBytes($fileSize)];
    $log[] = ['type' => 'info', 'msg' => "Chunk size: " . formatBytes($chunkSize)];
    $log[] = ['type' => 'info', 'msg' => "Total chunks: {$totalChunks}"];

    $fh = fopen($tmpPath, 'rb');
    if (!$fh) {
        $log[] = ['type' => 'error', 'msg' => 'Could not open uploaded file.'];
        return ['success' => false, 'log' => $log, 'file_hash' => $fileHash, 'total_chunks' => 0];
    }

    $allChunkNames = [];
    for ($i = 1; $i <= $totalChunks; $i++) {
        $raw       = fread($fh, $chunkSize);
        $encoded   = base64_encode($raw);
        $chunkHash = md5($encoded);
        $chunkName = $fileHash . '.' . $i . '.' . $chunkHash;
        $allChunkNames[] = $chunkName;
        $destPath  = BASE64_HASH_DIR . '/' . $chunkName . '.json';

        if (file_exists($destPath)) {
            $existingChunks++;
            $log[] = ['type' => 'skip',
                      'msg'  => "Chunk {$i}/{$totalChunks} already exists — skipped ({$chunkHash})"];
        } else {
            $data = [
                'filename'    => $originalName,
                'file_hash'   => $fileHash,
                'chunk_num'   => $i,
                'chunk_name'  => $chunkName,
                'content'     => $encoded,
                'public_key'  => $publicKey,
                'node_info'   => $nodeInfo,
                'received_at' => date('c'),
            ];
            $wh = fopen($destPath, 'w');
            if ($wh) {
                fwrite($wh, json_encode($data, JSON_PRETTY_PRINT));
                fclose($wh);
                $newChunks++;
                $log[] = ['type' => 'ok',
                          'msg'  => "Chunk {$i}/{$totalChunks} seeded ({$chunkHash})"];
            } else {
                $log[] = ['type' => 'error',
                          'msg'  => "Chunk {$i}/{$totalChunks} FAILED to write"];
            }
        }
    }
    fclose($fh);

    // Write chunks index — once only, via fopen 'x'
    $chunksIndexPath = CHUNKS_DIR . '/' . $fileHash . '.txt';
    if (!file_exists($chunksIndexPath)) {
        $ih = fopen($chunksIndexPath, 'x');
        if ($ih) {
            foreach ($allChunkNames as $cn) fwrite($ih, $cn . "\n");
            fclose($ih);
            $log[] = ['type' => 'ok', 'msg' => "Chunks index created: chunks/{$fileHash}.txt"];
        } else {
            $log[] = ['type' => 'error', 'msg' => "Failed to create chunks index"];
        }
    } else {
        $log[] = ['type' => 'skip', 'msg' => "Chunks index already exists — not modified"];
    }

    $log[] = ['type' => 'ok',
              'msg'  => "Done. {$newChunks} new chunk(s), {$existingChunks} skipped."];

    return [
        'success'       => true,
        'log'           => $log,
        'file_hash'     => $fileHash,
        'total_chunks'  => $totalChunks,
        'new_chunks'    => $newChunks,
        'skipped'       => $existingChunks,
        'original_name' => $originalName,
        'file_size'     => $fileSize,
    ];
}

// ============================================================
//  Manage local stored chunks
// ============================================================

function readJsonFile(string $path): ?array {
    $fh = fopen($path, 'r');
    if (!$fh) return null;
    $raw = '';
    while (!feof($fh)) $raw .= fread($fh, 8192);
    fclose($fh);
    $d = json_decode($raw, true);
    return is_array($d) ? $d : null;
}

function listSeededFiles(): array {
    $files  = glob(BASE64_HASH_DIR . '/*.*.*.json') ?: [];
    $byFile = [];
    foreach ($files as $f) {
        $d = readJsonFile($f);
        if (!$d || !isset($d['file_hash'])) continue;
        $hash = $d['file_hash'];
        $byFile[$hash]['chunks'][]  = $d['chunk_name'] ?? basename($f, '.json');
        $byFile[$hash]['filename']  = $d['filename']   ?? '—';
        $byFile[$hash]['size']      = ($byFile[$hash]['size'] ?? 0) + strlen($d['content'] ?? '');
    }
    foreach ($byFile as $hash => &$data) {
        $idx = CHUNKS_DIR . '/' . $hash . '.txt';
        if (file_exists($idx)) {
            $ifh   = fopen($idx, 'r');
            $lines = [];
            if ($ifh) {
                while (!feof($ifh)) {
                    $line = trim(fgets($ifh));
                    if ($line !== '') $lines[] = $line;
                }
                fclose($ifh);
            }
            $data['total'] = count($lines);
        } else {
            $data['total'] = '?';
        }
        $data['count']    = count($data['chunks']);
        $data['complete'] = is_int($data['total']) && $data['count'] === $data['total'];
    }
    unset($data);
    arsort($byFile);
    return $byFile;
}

function deleteFileChunks(string $fileHash): int {
    if (!preg_match('/^[a-f0-9]{32}$/i', $fileHash)) return 0;
    $files = glob(BASE64_HASH_DIR . '/' . $fileHash . '.*.*.json') ?: [];
    foreach ($files as $f) unlink($f);
    $idx = CHUNKS_DIR . '/' . $fileHash . '.txt';
    if (file_exists($idx)) unlink($idx);
    return count($files);
}

function formatBytes(int $bytes): string {
    if ($bytes >= 1048576) return round($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024)    return round($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}

// ============================================================
//  Route: receive_chunk API endpoint  (GET or POST)
// ============================================================

$actionParam = receiveParam('action');
if ($actionParam === 'receive_chunk') {
    header('Content-Type: application/json');
    handleReceiveChunk();
    exit;
}
if ($actionParam === 'receive_file') {
    header('Content-Type: application/json');
    handleReceiveFile();
    exit;
}

// ============================================================
//  Handle form actions
// ============================================================

$result  = null;
$message = '';
$msgType = '';
$tab     = $_POST['tab'] ?? $_GET['tab'] ?? 'seed';

// ── Upload & seed locally ────────────────────────────────────
if (isset($_POST['do_seed']) && isset($_FILES['upload_file'])) {
    $tab  = 'seed';
    $file = $_FILES['upload_file'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $message = 'Upload error code: ' . $file['error'];
        $msgType = 'error';
    } elseif ($file['size'] > MAX_UPLOAD_MB * 1024 * 1024) {
        $message = 'File exceeds ' . MAX_UPLOAD_MB . ' MB limit.';
        $msgType = 'error';
    } else {
        $chunkKb   = max(64, min(4096, (int)($_POST['chunk_kb'] ?? 512)));
        $chunkSize = $chunkKb * 1024;
        $tmpDest   = SEEDER_TMPDIR . '/' . basename($file['tmp_name']);
        move_uploaded_file($file['tmp_name'], $tmpDest);
        $result  = chunkAndSeed($tmpDest, $file['name'], $chunkSize);
        unlink($tmpDest);
        $message = $result['success'] ? "File seeded locally! Hash below." : 'Seeding failed — see log.';
        $msgType = $result['success'] ? 'ok' : 'error';
    }
}

// ── Upload & distribute to servers ──────────────────────────
if (isset($_POST['do_distribute']) && isset($_FILES['upload_file'])) {
    $tab  = 'seed';
    $file = $_FILES['upload_file'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $message = 'Upload error code: ' . $file['error'];
        $msgType = 'error';
    } elseif ($file['size'] > MAX_UPLOAD_MB * 1024 * 1024) {
        $message = 'File exceeds ' . MAX_UPLOAD_MB . ' MB limit.';
        $msgType = 'error';
    } else {
        $transport = (($_POST['transport'] ?? 'get') === 'post') ? 'post' : 'get';
        $tmpDest   = SEEDER_TMPDIR . '/' . basename($file['tmp_name']);
        move_uploaded_file($file['tmp_name'], $tmpDest);

        if ($transport === 'post') {
            // POST mode: send the raw file directly — no chunking, no base64
            $result  = sendFileToServers($tmpDest, $file['name']);
        } else {
            // GET mode: chunk + base64 as before
            $getChunkBytes = max(GET_CHUNK_MIN_BYTES,
                             min(GET_CHUNK_MAX_BYTES, (int)($_POST['get_chunk_bytes'] ?? 4096)));
            $result  = sendChunksToServers($tmpDest, $file['name'], DEFAULT_CHUNK_SIZE, 'get', $getChunkBytes);
        }

        unlink($tmpDest);
        $message = $result['success'] ? "Distribution complete! See log." : 'Distribution failed — see log.';
        $msgType = $result['success'] ? 'ok' : 'error';
    }
}

// ── Delete local file chunks ─────────────────────────────────
if (isset($_POST['do_delete'])) {
    $tab     = 'manage';
    $delHash = strtolower(trim($_POST['del_hash'] ?? ''));
    if (preg_match('/^[a-f0-9]{32}$/i', $delHash)) {
        $count   = deleteFileChunks($delHash);
        $message = "Removed {$count} chunk(s) for {$delHash}.";
        $msgType = 'ok';
    } else {
        $message = 'Invalid hash.';
        $msgType = 'error';
    }
}

// ── Add server ───────────────────────────────────────────────
if (isset($_POST['do_add_server'])) {
    $tab    = 'servers';
    $newUrl = trim($_POST['server_url'] ?? '');
    $res    = addServer($newUrl);
    if ($res === 'ok')           { $message = "Server added: {$newUrl}";             $msgType = 'ok'; }
    elseif ($res === 'duplicate'){ $message = "Server already in list: {$newUrl}";   $msgType = 'info'; }
    elseif ($res === 'empty')    { $message = 'Please enter a server URL.';           $msgType = 'error'; }
    else                          { $message = 'Could not write servers.txt.';        $msgType = 'error'; }
}

// ── Remove server ────────────────────────────────────────────
if (isset($_POST['do_remove_server'])) {
    $tab       = 'servers';
    $removeUrl = trim($_POST['remove_url'] ?? '');
    $servers   = loadServers();
    $servers   = array_values(array_filter($servers, fn($s) => $s !== $removeUrl));
    $fh = fopen(SERVERS_FILE, 'w');
    if ($fh) { foreach ($servers as $s) fwrite($fh, $s . "\n"); fclose($fh); }
    $message = "Removed server: {$removeUrl}";
    $msgType = 'ok';
}

$seededFiles = listSeededFiles();
$servers     = loadServers();

// Restore previous transport/slider values across page reload
$prevTransport     = $_POST['transport']       ?? 'get';
$prevChunkKb       = (int)($_POST['chunk_kb']       ?? 512);
$prevGetChunkBytes = (int)($_POST['get_chunk_bytes'] ?? 4096);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Seastar</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=Space+Grotesk:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
  :root {
    --bg:      #0d0f14;
    --surface: #13161e;
    --border:  #1e2330;
    --accent:  #00e5a0;
    --accent2: #0077ff;
    --yellow:  #f5c400;
    --red:     #ff3f5b;
    --text:    #d4dae8;
    --muted:   #5a6380;
    --mono:    'IBM Plex Mono', monospace;
    --sans:    'Space Grotesk', sans-serif;
    --radius:  6px;
  }
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    background: var(--bg);
    color: var(--text);
    font-family: var(--sans);
    font-size: 14px;
    min-height: 100vh;
    padding: 0 0 60px;
  }

  /* ── Header ─────────────────────────────────────────────── */
  .header {
    border-bottom: 1px solid var(--border);
    padding: 18px 32px;
    display: flex; align-items: center; gap: 16px;
    background: var(--surface);
  }
  .header-logo {
    width: 36px; height: 36px;
    background: var(--accent);
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
  }
  .header-logo svg { width: 22px; height: 22px; fill: none; stroke: #0d0f14;
                     stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }
  .header-title { font-size: 17px; font-weight: 600; letter-spacing: -.3px; }
  .header-sub   { font-size: 12px; color: var(--muted); font-family: var(--mono); margin-top: 1px; }
  .server-count {
    margin-left: auto;
    font-family: var(--mono); font-size: 12px; color: var(--muted);
    border: 1px solid var(--border); padding: 4px 10px; border-radius: var(--radius);
  }
  .server-count span { color: var(--accent); }

  /* ── Layout ──────────────────────────────────────────────── */
  .container { max-width: 900px; margin: 0 auto; padding: 32px 24px 0; }

  /* ── Tabs ────────────────────────────────────────────────── */
  nav {
    display: flex; gap: 4px;
    margin-bottom: 24px;
    border-bottom: 1px solid var(--border);
  }
  nav button {
    background: none; border: none;
    border-bottom: 2px solid transparent;
    color: var(--muted);
    font-family: var(--sans); font-size: 13px; font-weight: 500;
    padding: 8px 16px; cursor: pointer;
    margin-bottom: -1px;
    transition: color .15s, border-color .15s;
  }
  nav button.active { color: var(--accent); border-bottom-color: var(--accent); }
  nav button:hover:not(.active) { color: var(--text); }
  .tab { display: none; }
  .tab.active { display: block; }

  /* ── Cards ───────────────────────────────────────────────── */
  .card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 22px 24px;
    margin-bottom: 16px;
  }
  .card-title {
    font-size: 11px; font-weight: 600;
    text-transform: uppercase; letter-spacing: .1em;
    color: var(--muted); margin-bottom: 18px;
  }

  /* ── Drop zone ───────────────────────────────────────────── */
  .drop-zone {
    border: 2px dashed var(--border);
    border-radius: var(--radius);
    padding: 40px 24px; text-align: center;
    cursor: pointer; position: relative;
    transition: border-color .2s, background .2s;
    margin-bottom: 20px;
  }
  .drop-zone:hover, .drop-zone.dragover { border-color: var(--accent); background: rgba(0,229,160,.04); }
  .drop-zone input[type=file] { position: absolute; inset: 0; opacity: 0; cursor: pointer; width: 100%; height: 100%; }
  .drop-icon  { font-size: 32px; margin-bottom: 10px; }
  .drop-label { color: var(--text); font-size: 14px; font-weight: 500; }
  .drop-hint  { color: var(--muted); font-size: 12px; margin-top: 4px; font-family: var(--mono); }
  .drop-chosen { color: var(--accent); font-size: 13px; margin-top: 8px; font-family: var(--mono); display: none; }

  /* ── Form ────────────────────────────────────────────────── */
  .field { margin-bottom: 16px; }
  label { display: block; font-size: 12px; color: var(--muted); margin-bottom: 6px; font-family: var(--mono); }

  input[type=text], input[type=url] {
    width: 100%;
    background: #080a10; border: 1px solid var(--border);
    color: var(--text); font-family: var(--mono); font-size: 13px;
    padding: 9px 12px; border-radius: var(--radius); outline: none;
    transition: border-color .15s;
  }
  input[type=text]:focus, input[type=url]:focus { border-color: var(--accent); }

  .range-row { display: flex; align-items: center; gap: 12px; }
  input[type=range] { width: 100%; accent-color: var(--accent); height: 4px; cursor: pointer; }
  .range-val { font-family: var(--mono); font-size: 13px; color: var(--accent); min-width: 70px; text-align: right; }

  /* ── Transport toggle ────────────────────────────────────── */
  .transport-row {
    display: flex; gap: 8px; margin-bottom: 18px;
  }
  .transport-btn {
    flex: 1;
    padding: 10px 0;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    background: #080a10;
    color: var(--muted);
    font-family: var(--mono); font-size: 13px; font-weight: 500;
    cursor: pointer;
    text-align: center;
    transition: border-color .15s, color .15s, background .15s;
    user-select: none;
  }
  .transport-btn.selected-get  { border-color: var(--accent);  color: var(--accent);  background: rgba(0,229,160,.07); }
  .transport-btn.selected-post { border-color: var(--accent2); color: var(--accent2); background: rgba(0,119,255,.07); }
  .transport-badge {
    display: inline-block;
    font-size: 9px; font-weight: 700;
    padding: 2px 5px; border-radius: 3px;
    text-transform: uppercase; letter-spacing: .08em;
    vertical-align: middle; margin-left: 6px;
  }
  .badge-default { background: rgba(0,229,160,.2); color: var(--accent); }

  /* GET chunk size panel */
  #get-chunk-panel { margin-top: 4px; }
  .info-note {
    font-family: var(--mono); font-size: 11px;
    color: var(--muted); margin-top: 6px;
    line-height: 1.6;
  }
  .info-note strong { color: var(--yellow); }

  .btn-row { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; margin-top: 4px; }

  /* ── Buttons ─────────────────────────────────────────────── */
  button[type=submit], .btn {
    background: var(--accent); color: #0d0f14;
    border: none; border-radius: var(--radius);
    font-family: var(--sans); font-weight: 600; font-size: 13px;
    padding: 9px 20px; cursor: pointer;
    transition: opacity .15s, transform .1s;
    white-space: nowrap;
  }
  button[type=submit]:hover, .btn:hover { opacity: .88; }
  button[type=submit]:active { transform: scale(.97); }
  .btn-secondary { background: var(--accent2); color: #fff; }
  .btn-danger    { background: var(--red);     color: #fff; }
  .btn-muted     { background: var(--border);  color: var(--text); }
  .btn-sm        { padding: 5px 12px; font-size: 12px; }

  /* ── Banner ──────────────────────────────────────────────── */
  .banner {
    padding: 12px 18px; border-radius: var(--radius);
    margin-bottom: 20px; font-size: 13px; font-family: var(--mono);
    border-left: 3px solid;
  }
  .banner.ok    { background: rgba(0,229,160,.08);  border-color: var(--accent);  color: var(--accent); }
  .banner.error { background: rgba(255,63,91,.08);   border-color: var(--red);     color: var(--red); }
  .banner.info  { background: rgba(0,119,255,.08);   border-color: var(--accent2); color: var(--accent2); }

  /* ── Hash box ────────────────────────────────────────────── */
  .hash-box {
    background: #080a10; border: 1px solid var(--accent);
    border-radius: var(--radius); padding: 18px 20px; margin-top: 16px;
  }
  .hash-label { font-size: 11px; color: var(--muted); font-family: var(--mono); margin-bottom: 6px; }
  .hash-val   { font-family: var(--mono); font-size: 20px; color: var(--accent);
                letter-spacing: .04em; word-break: break-all; }
  .hash-meta  { font-family: var(--mono); font-size: 11px; color: var(--muted); margin-top: 8px; }
  .copy-btn {
    background: rgba(0,229,160,.12); color: var(--accent);
    border: 1px solid var(--accent); border-radius: var(--radius);
    font-family: var(--mono); font-size: 11px; padding: 4px 10px;
    cursor: pointer; margin-top: 10px; transition: background .15s;
  }
  .copy-btn:hover { background: rgba(0,229,160,.22); }

  /* ── Log box ─────────────────────────────────────────────── */
  .log-box {
    background: #080a10; border: 1px solid var(--border);
    border-radius: var(--radius); padding: 14px 16px;
    max-height: 280px; overflow-y: auto;
    font-family: var(--mono); font-size: 12px; line-height: 1.7;
  }
  .log-line       { padding: 1px 0; }
  .log-line.ok    { color: var(--accent); }
  .log-line.skip  { color: var(--muted); }
  .log-line.error { color: var(--red); }
  .log-line.info  { color: var(--accent2); }

  /* ── Stats ───────────────────────────────────────────────── */
  .stat-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 12px; margin-bottom: 20px;
  }
  .stat-card {
    background: var(--surface); border: 1px solid var(--border);
    border-radius: var(--radius); padding: 16px; text-align: center;
  }
  .stat-val   { font-size: 26px; font-weight: 600; font-family: var(--mono); color: var(--accent); }
  .stat-label { font-size: 11px; color: var(--muted); margin-top: 4px;
                text-transform: uppercase; letter-spacing: .08em; }

  /* ── Table ───────────────────────────────────────────────── */
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th {
    text-align: left; font-size: 11px; font-weight: 600;
    color: var(--muted); text-transform: uppercase; letter-spacing: .08em;
    padding: 0 12px 10px; border-bottom: 1px solid var(--border);
  }
  td { padding: 10px 12px; border-bottom: 1px solid var(--border); vertical-align: middle; }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: rgba(255,255,255,.02); }

  .mono { font-family: var(--mono); font-size: 12px; color: var(--text); }
  .tag  { display: inline-block; font-family: var(--mono); font-size: 10px; font-weight: 600;
          padding: 2px 7px; border-radius: 3px; text-transform: uppercase; letter-spacing: .06em; }
  .tag.green { background: rgba(0,229,160,.15); color: var(--accent);  border: 1px solid rgba(0,229,160,.3); }
  .tag.red   { background: rgba(255,63,91,.12);  color: var(--red);    border: 1px solid rgba(255,63,91,.3); }
  .tag.blue  { background: rgba(0,119,255,.12);  color: var(--accent2);border: 1px solid rgba(0,119,255,.3); }

  .del-form { display: inline; }
  .del-btn  {
    background: none; border: 1px solid var(--border);
    color: var(--muted); font-size: 11px; font-family: var(--mono);
    padding: 3px 8px; border-radius: var(--radius); cursor: pointer;
    transition: border-color .15s, color .15s;
  }
  .del-btn:hover { border-color: var(--red); color: var(--red); }

  /* ── Server list ─────────────────────────────────────────── */
  .server-item {
    display: flex; align-items: center; gap: 10px;
    padding: 10px 0; border-bottom: 1px solid var(--border);
    font-family: var(--mono); font-size: 12px; color: var(--text);
  }
  .server-item:last-child { border-bottom: none; }
  .server-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--accent); flex-shrink: 0; }
  .server-url { flex: 1; word-break: break-all; }

  ::-webkit-scrollbar { width: 6px; height: 6px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }
</style>
</head>
<body>

<div class="header">
  <div class="header-logo">
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 2 L13.5 8.5 L20 7 L15.5 12 L20 17 L13.5 15.5 L12 22 L10.5 15.5 L4 17 L8.5 12 L4 7 L10.5 8.5 Z" stroke-width="1.5"/>
    </svg>
  </div>
  <div>
    <div class="header-title">Meento Seastar</div>
    <div class="header-sub">chunk · distribute · receive</div>
  </div>
  <div class="server-count">
    <span><?= count($servers) ?></span> server<?= count($servers) !== 1 ? 's' : '' ?> configured
  </div>
</div>

<div class="container">

  <?php if ($message): ?>
  <div class="banner <?= htmlspecialchars($msgType) ?>"><?= htmlspecialchars($message) ?></div>
  <?php endif; ?>

  <nav>
    <button onclick="switchTab('seed',    this)" class="<?= $tab==='seed'    ? 'active' : '' ?>">Seed &amp; Send</button>
    <button onclick="switchTab('manage',  this)" class="<?= $tab==='manage'  ? 'active' : '' ?>">
      Stored (<?= count($seededFiles) ?>)
    </button>
    <button onclick="switchTab('servers', this)" class="<?= $tab==='servers' ? 'active' : '' ?>">
      Servers (<?= count($servers) ?>)
    </button>
    <button onclick="switchTab('help',    this)" class="<?= $tab==='help'    ? 'active' : '' ?>">How It Works</button>
  </nav>

  <!-- ══════════════════════════════════════════════════════
       SEED & SEND TAB
  ══════════════════════════════════════════════════════ -->
  <div id="tab-seed" class="tab <?= $tab==='seed' ? 'active' : '' ?>">

    <div class="card">
      <div class="card-title">Upload &amp; Process File</div>

      <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="tab" value="seed">

        <!-- Hidden transport state field, kept in sync by JS -->
        <input type="hidden" name="transport" id="transportInput" value="<?= htmlspecialchars($prevTransport) ?>">

        <div class="drop-zone" id="dropZone">
          <input type="file" name="upload_file" id="fileInput" required>
          <div class="drop-icon">⭐</div>
          <div class="drop-label">Drop file here or click to browse</div>
          <div class="drop-hint">Max <?= MAX_UPLOAD_MB ?> MB · Any file type</div>
          <div class="drop-chosen" id="chosenName"></div>
        </div>

        <!-- ── Chunk size (GET mode only) ───────────────────── -->
        <div class="field" id="post-chunk-panel" style="display:none">
          <!-- Hidden in POST mode: no chunking, file sent directly -->
        </div>

        <!-- ── GET chunk size panel ─────────────────────────── -->
        <div class="field" id="get-chunk-panel">
          <label>Max GET Chunk Size <span style="color:var(--muted)">(raw bytes per request)</span></label>
          <div class="range-row">
            <input type="range" name="get_chunk_bytes" id="getChunkRange"
                   min="100" max="8192" step="100"
                   value="<?= max(100, min(8192, $prevGetChunkBytes)) ?>">
            <span class="range-val" id="getChunkLabel">4.0 KB</span>
          </div>
          <div class="info-note">
            Raw bytes before base64 encoding. Base64 adds ~33% overhead, so <strong>8 KB raw → ~10.9 KB in URL</strong>.
            Smaller values = more requests but safer for strict servers.
          </div>
        </div>

        <!-- ── Transport selector ────────────────────────── -->
        <div class="field">
          <label>Transport Method</label>
          <div class="transport-row">
            <div class="transport-btn <?= $prevTransport === 'get' ? 'selected-get' : '' ?>"
                 id="btnGet" onclick="setTransport('get')">
              GET
              <span class="transport-badge badge-default">default</span>
            </div>
            <div class="transport-btn <?= $prevTransport === 'post' ? 'selected-post' : '' ?>"
                 id="btnPost" onclick="setTransport('post')">
              POST
            </div>
          </div>
          <div class="info-note" id="transport-note-get"  style="<?= $prevTransport !== 'get'  ? 'display:none' : '' ?>">
            Chunks are sent as query-string parameters. Safe because the <strong>Max GET Chunk Size</strong>
            slider caps each request at ≤ 8 KB of raw data (~10.9 KB base64).
          </div>
          <div class="info-note" id="transport-note-post" style="<?= $prevTransport !== 'post' ? 'display:none' : '' ?>">
            The file is sent as a single <strong>multipart/form-data</strong> POST — no chunking, no base64.
            Stored on each server as <code>files/&lt;md5&gt;.&lt;ext&gt;</code>. Existing files are never overwritten.
          </div>
        </div>

        <div class="btn-row">
          <button type="submit" name="do_seed">💾 Seed Locally</button>
          <button type="submit" name="do_distribute" class="btn btn-secondary">
            📡 Distribute to <?= count($servers) ?> Server<?= count($servers) !== 1 ? 's' : '' ?>
          </button>
        </div>
      </form>
    </div>

    <?php if ($result && $result['success']): ?>
    <div class="card">
      <div class="card-title">Result</div>
      <div class="hash-box">
        <div class="hash-label">File Hash (MD5)</div>
        <div class="hash-val" id="resultHash"><?= htmlspecialchars($result['file_hash']) ?></div>
        <div class="hash-meta">
          <?= htmlspecialchars($result['original_name']) ?>
          &nbsp;·&nbsp; <?= formatBytes($result['file_size']) ?>
          &nbsp;·&nbsp; <?= $result['total_chunks'] ?> chunks
          &nbsp;·&nbsp; <?= $result['new_chunks'] ?> new, <?= $result['skipped'] ?> skipped
        </div>
        <button class="copy-btn" onclick="copyHash()">Copy Hash</button>
      </div>
    </div>
    <div class="card">
      <div class="card-title">Log</div>
      <div class="log-box">
        <?php foreach ($result['log'] as $entry): ?>
        <div class="log-line <?= htmlspecialchars($entry['type']) ?>"><?= htmlspecialchars($entry['msg']) ?></div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

    <?php if ($result && !$result['success']): ?>
    <div class="card">
      <div class="card-title">Error Log</div>
      <div class="log-box">
        <?php foreach ($result['log'] as $entry): ?>
        <div class="log-line <?= htmlspecialchars($entry['type']) ?>"><?= htmlspecialchars($entry['msg']) ?></div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <!-- ══════════════════════════════════════════════════════
       MANAGE TAB
  ══════════════════════════════════════════════════════ -->
  <div id="tab-manage" class="tab <?= $tab==='manage' ? 'active' : '' ?>">

    <?php
    $totalChunkCount = array_sum(array_column($seededFiles, 'count'));
    $totalSize       = array_sum(array_column($seededFiles, 'size'));
    $completeCount   = count(array_filter($seededFiles, fn($f) => $f['complete']));
    ?>

    <div class="stat-grid">
      <div class="stat-card"><div class="stat-val"><?= count($seededFiles) ?></div><div class="stat-label">Files</div></div>
      <div class="stat-card"><div class="stat-val"><?= $totalChunkCount ?></div><div class="stat-label">Chunks</div></div>
      <div class="stat-card"><div class="stat-val"><?= $completeCount ?></div><div class="stat-label">Complete</div></div>
      <div class="stat-card"><div class="stat-val"><?= formatBytes($totalSize) ?></div><div class="stat-label">Disk (b64)</div></div>
    </div>

    <?php if (empty($seededFiles)): ?>
    <div class="card">
      <p style="color:var(--muted); font-family:var(--mono); font-size:13px;">
        No chunks stored yet. Use "Seed &amp; Send" to add files.
      </p>
    </div>
    <?php else: ?>
    <div class="card">
      <div class="card-title">Stored Files</div>
      <table>
        <tr>
          <th>File Hash</th>
          <th>Filename</th>
          <th>Chunks</th>
          <th>Size (b64)</th>
          <th>Status</th>
          <th></th>
        </tr>
        <?php foreach ($seededFiles as $hash => $data): ?>
        <tr>
          <td class="mono"><?= htmlspecialchars($hash) ?></td>
          <td class="mono"><?= htmlspecialchars($data['filename']) ?></td>
          <td><?= $data['count'] ?> / <?= $data['total'] ?></td>
          <td class="mono"><?= formatBytes($data['size']) ?></td>
          <td>
            <?php if ($data['complete']): ?>
              <span class="tag green">complete</span>
            <?php else: ?>
              <span class="tag red">partial</span>
            <?php endif; ?>
          </td>
          <td>
            <form method="POST" class="del-form" onsubmit="return confirm('Remove all chunks for this file?')">
              <input type="hidden" name="tab"      value="manage">
              <input type="hidden" name="del_hash" value="<?= htmlspecialchars($hash) ?>">
              <button type="submit" name="do_delete" class="del-btn">✕ Remove</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </table>
    </div>
    <?php endif; ?>
  </div>

  <!-- ══════════════════════════════════════════════════════
       SERVERS TAB
  ══════════════════════════════════════════════════════ -->
  <div id="tab-servers" class="tab <?= $tab==='servers' ? 'active' : '' ?>">

    <div class="card">
      <div class="card-title">Add Server</div>
      <form method="POST">
        <input type="hidden" name="tab" value="servers">
        <div class="field">
          <label>Server URL (base URL of the remote Seastar node)</label>
          <input type="url" name="server_url" placeholder="https://example.com/node" required>
        </div>
        <button type="submit" name="do_add_server">+ Add Server</button>
      </form>
    </div>

    <div class="card">
      <div class="card-title">Configured Servers (<?= count($servers) ?>)</div>

      <?php if (empty($servers)): ?>
      <p style="color:var(--muted); font-family:var(--mono); font-size:13px;">
        No servers configured yet. Add a server above to enable distribution.
      </p>
      <?php else: ?>
      <div>
        <?php foreach ($servers as $srv): ?>
        <div class="server-item">
          <div class="server-dot"></div>
          <div class="server-url"><?= htmlspecialchars($srv) ?></div>
          <form method="POST" class="del-form" onsubmit="return confirm('Remove this server?')">
            <input type="hidden" name="tab"        value="servers">
            <input type="hidden" name="remove_url" value="<?= htmlspecialchars($srv) ?>">
            <button type="submit" name="do_remove_server" class="del-btn">✕</button>
          </form>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>

    <div class="card">
      <div class="card-title">Node Identity</div>
      <div class="log-box" style="max-height: none;">
        <div class="log-line info">public_key.txt → <?= file_exists(PUBLIC_KEY_FILE) ? '<span style="color:var(--accent)">found</span>' : '<span style="color:var(--red)">missing</span>' ?></div>
        <div class="log-line info">node_info.txt  → <?= file_exists(NODE_INFO_FILE)  ? '<span style="color:var(--accent)">found</span>' : '<span style="color:var(--red)">missing</span>' ?></div>
        <?php if (file_exists(PUBLIC_KEY_FILE)): ?>
        <div class="log-line skip">public key: <?= htmlspecialchars(substr(loadPublicKey(), 0, 64)) ?>…</div>
        <?php endif; ?>
        <?php if (file_exists(NODE_INFO_FILE)): ?>
        <div class="log-line skip">node info: <?= htmlspecialchars(substr(loadNodeInfo(), 0, 80)) ?>…</div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- ══════════════════════════════════════════════════════
       HELP TAB
  ══════════════════════════════════════════════════════ -->
  <div id="tab-help" class="tab <?= $tab==='help' ? 'active' : '' ?>">

    <div class="card">
      <div class="card-title">Transport Modes</div>
      <div style="line-height:1.8; color:var(--text); font-size:13px;">
        <p style="margin-bottom:12px;">
          <strong style="color:var(--accent)">GET (default)</strong> — All chunk parameters,
          including the base64-encoded content, are sent in the URL query string.
          This works reliably because the <em>Max GET Chunk Size</em> slider caps each
          chunk at 100 B – 8 KB of raw data (~133 B – 10.9 KB after base64), staying
          well within the ~8 KB URL limit enforced by most web servers.
          The file is split into as many chunks as needed automatically.
        </p>
        <p>
          <strong style="color:var(--accent2)">POST</strong> — The file is sent <em>whole</em> as a single
          <code>multipart/form-data</code> request directly to <code>index.php?action=receive_file</code>.
          No chunking or base64 encoding occurs. The file is stored in <code>files/&lt;md5&gt;.&lt;ext&gt;</code>.
          Existing files are never overwritten. The Chunk Size slider is hidden in this mode.
        </p>
      </div>
    </div>

    <div class="card">
      <div class="card-title">How Seastar Works</div>
      <div style="line-height:1.8; color:var(--text); font-size:13px;">
        <p style="margin-bottom:12px;">
          <strong style="color:var(--accent)">1. Upload</strong> — Pick any file (up to <?= MAX_UPLOAD_MB ?> MB).
          Its MD5 becomes the permanent file identifier shared across all nodes.
        </p>
        <p style="margin-bottom:12px;">
          <strong style="color:var(--accent)">2. Chunk (GET mode)</strong> — The file is split into fixed-size pieces.
          Each piece is Base64-encoded and its MD5 is computed for integrity.
        </p>
        <p style="margin-bottom:12px;">
          <strong style="color:var(--accent2)">2. Direct (POST mode)</strong> — No chunking or encoding at all.
          The raw file is posted in one multipart/form-data request and stored as
          <code>files/&lt;md5&gt;.&lt;ext&gt;</code>. Existing files are never overwritten.
        </p>
        <p style="margin-bottom:12px;">
          <strong style="color:var(--accent)">3. Seed Locally</strong> — Stores each chunk as a JSON file in
          <code>base64_hash/&lt;file_hash&gt;.&lt;chunk_num&gt;.&lt;chunk_hash&gt;.json</code>.
          A chunk index is created once in <code>chunks/&lt;file_hash&gt;.txt</code>.
        </p>
        <p style="margin-bottom:12px;">
          <strong style="color:var(--accent)">4. Distribute</strong> — Sends every chunk to every server in
          <code>servers.txt</code> via the chosen transport (GET or POST) to
          <code>index.php?action=receive_chunk&amp;…</code>.
        </p>
        <p style="margin-bottom:12px;">
          <strong style="color:var(--accent)">5. Receive</strong> — Verifies <code>md5(contents) === chunk_hash</code>
          before writing. The endpoint accepts both GET and POST transparently.
          Existing chunks are never overwritten.
        </p>
        <p>
          <strong style="color:var(--accent)">6. Integrity</strong> — The chunks index
          (<code>chunks/&lt;file_hash&gt;.txt</code>) is written once using
          <code>fopen('x')</code> and can never be edited after creation.
        </p>
      </div>
    </div>

    <div class="card">
      <div class="card-title">Directory Layout</div>
      <div class="log-box" style="max-height:none;">
        <div class="log-line info">base64_hash/                              ← received/seeded chunk JSON files</div>
        <div class="log-line info">  &lt;file_hash&gt;.&lt;chunk_num&gt;.&lt;chunk_hash&gt;.json  ← one JSON per chunk</div>
        <div class="log-line info">chunks/                                   ← chunk index files (write-once)</div>
        <div class="log-line info">  &lt;file_hash&gt;.txt                        ← one chunk name per line</div>
        <div class="log-line ok">files/                                    ← POST-mode direct file store</div>
        <div class="log-line ok">  &lt;md5&gt;.&lt;ext&gt;                            ← raw file, named by hash+ext</div>
        <div class="log-line skip">seeder_tmp/                               ← upload staging, auto-cleaned</div>
        <div class="log-line skip">servers.txt                               ← one server URL per line</div>
        <div class="log-line skip">public_key.txt                            ← this node's public key</div>
        <div class="log-line skip">node_info.txt                             ← this node's info/metadata</div>
      </div>
    </div>

    <div class="card">
      <div class="card-title">Receive Endpoint (GET/POST chunks)</div>
      <div class="log-box" style="max-height:none;">
        <div class="log-line info">GET or POST  index.php?action=receive_chunk</div>
        <div class="log-line ok">&amp;filename=&lt;original filename&gt;</div>
        <div class="log-line ok">&amp;file_hash=&lt;md5 of full file&gt;</div>
        <div class="log-line ok">&amp;chunk_num=&lt;1-based chunk number&gt;</div>
        <div class="log-line ok">&amp;chunk_hash=&lt;md5(base64 contents)&gt;</div>
        <div class="log-line ok">&amp;contents=&lt;base64 encoded chunk data&gt;</div>
        <div class="log-line ok">&amp;public_key=&lt;sender public key&gt;</div>
        <div class="log-line ok">&amp;node_info=&lt;sender node info&gt;</div>
        <div class="log-line ok">&amp;total_chunks=&lt;total number of chunks&gt;</div>
        <div class="log-line ok">&amp;chunk_list=&lt;comma-separated list of all chunk names&gt;</div>
        <div class="log-line skip">→ returns JSON: {"ok":true,"chunk":"...","stored":"new|exists"}</div>
      </div>
    </div>

    <div class="card">
      <div class="card-title">Receive Endpoint (POST direct file)</div>
      <div class="log-box" style="max-height:none;">
        <div class="log-line info">POST  index.php?action=receive_file</div>
        <div class="log-line ok">multipart/form-data body:</div>
        <div class="log-line ok">  file=&lt;raw file binary&gt;</div>
        <div class="log-line ok">  public_key=&lt;sender public key&gt;  (optional)</div>
        <div class="log-line ok">  node_info=&lt;sender node info&gt;    (optional)</div>
        <div class="log-line skip">Stored as: files/&lt;md5_of_file&gt;.&lt;ext&gt;</div>
        <div class="log-line skip">→ returns JSON: {"ok":true,"file":"...","stored":"new|exists","hash":"..."}</div>
        <div class="log-line skip">→ existing files are NEVER overwritten</div>
      </div>
    </div>

    <div class="card">
      <div class="card-title">GET Chunk Size Guide</div>
      <table>
        <tr><th>Raw Bytes</th><th>Base64 in URL</th><th>Best For</th></tr>
        <tr><td class="mono">100 – 500 B</td><td class="mono">~133 – 666 B</td><td>Extremely strict servers / tiny files</td></tr>
        <tr><td class="mono">1 – 2 KB</td>  <td class="mono">~1.3 – 2.7 KB</td><td>Conservative / shared hosting</td></tr>
        <tr><td class="mono">4 KB</td>       <td class="mono">~5.3 KB</td>      <td>General use (recommended default)</td></tr>
        <tr><td class="mono">8 KB</td>       <td class="mono">~10.9 KB</td>     <td>Maximum safe GET size</td></tr>
      </table>
    </div>

    <div class="card">
      <div class="card-title">POST Chunk Size Guide</div>
      <table>
        <tr><th>Size</th><th>Best For</th></tr>
        <tr><td class="mono">64 – 128 KB</td><td>Small files, slow connections, many peers</td></tr>
        <tr><td class="mono">256 – 512 KB</td><td>General use (default)</td></tr>
        <tr><td class="mono">1 – 2 MB</td>   <td>Large files, fast connections, few peers</td></tr>
        <tr><td class="mono">4 MB</td>        <td>Very large files, LAN / local network only</td></tr>
      </table>
    </div>
  </div>

</div><!-- /container -->

<script>
// ── Tab switching ─────────────────────────────────────────────
function switchTab(name, btn) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('nav button').forEach(b => b.classList.remove('active'));
  document.getElementById('tab-' + name).classList.add('active');
  btn.classList.add('active');
}

// ── Transport toggle ──────────────────────────────────────────
function setTransport(mode) {
  document.getElementById('transportInput').value = mode;

  const btnGet  = document.getElementById('btnGet');
  const btnPost = document.getElementById('btnPost');
  btnGet.className  = 'transport-btn' + (mode === 'get'  ? ' selected-get'  : '');
  btnPost.className = 'transport-btn' + (mode === 'post' ? ' selected-post' : '');

  // POST mode sends the file whole — no chunking, no slider needed
  const getPanel = document.getElementById('get-chunk-panel');
  getPanel.style.display = (mode === 'get') ? '' : 'none';

  document.getElementById('transport-note-get').style.display  = (mode === 'get')  ? '' : 'none';
  document.getElementById('transport-note-post').style.display = (mode === 'post') ? '' : 'none';
}

// Initialise visibility from current state
(function() {
  const current = document.getElementById('transportInput').value || 'get';
  setTransport(current);
})();

// ── POST chunk-size slider (removed for POST mode — kept as no-op) ────────

// ── GET chunk-size slider ─────────────────────────────────────
const getRange = document.getElementById('getChunkRange');
const getLabel = document.getElementById('getChunkLabel');
function updateGetLabel() {
  const b = parseInt(getRange.value);
  if (b >= 1024) {
    getLabel.textContent = (b / 1024).toFixed(1) + ' KB';
  } else {
    getLabel.textContent = b + ' B';
  }
}
getRange.addEventListener('input', updateGetLabel);
updateGetLabel();

// ── File input / drop zone ────────────────────────────────────
const fileInput  = document.getElementById('fileInput');
const chosenName = document.getElementById('chosenName');
const dropZone   = document.getElementById('dropZone');

fileInput.addEventListener('change', () => {
  if (fileInput.files.length > 0) {
    chosenName.style.display = 'block';
    chosenName.textContent   = '✓ ' + fileInput.files[0].name;
  }
});
dropZone.addEventListener('dragover',  e => { e.preventDefault(); dropZone.classList.add('dragover'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
dropZone.addEventListener('drop', e => {
  e.preventDefault();
  dropZone.classList.remove('dragover');
  if (e.dataTransfer.files.length > 0) {
    fileInput.files = e.dataTransfer.files;
    chosenName.style.display = 'block';
    chosenName.textContent   = '✓ ' + e.dataTransfer.files[0].name;
  }
});

// ── Copy hash ─────────────────────────────────────────────────
function copyHash() {
  const hash = document.getElementById('resultHash');
  if (!hash) return;
  navigator.clipboard.writeText(hash.textContent.trim()).then(() => {
    const btn = document.querySelector('.copy-btn');
    btn.textContent = '✓ Copied!';
    setTimeout(() => btn.textContent = 'Copy Hash', 1800);
  });
}
</script>
</body>
</html>