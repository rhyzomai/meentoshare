import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
import java.util.regex.*;
import java.util.stream.*;

/**
 * -------------------------------------------------------------------------------
 *  MeshBlockchain Auditor � Java CLI tool
 *
 *  Reads the JSON block files produced by the PHP MeshBlockchain library and
 *  performs read-only integrity and validity checks.  Nothing is ever written.
 *
 *  Compile:
 *    javac MeshBlockchainAuditor.java
 *
 *  Run (interactive menu):
 *    java MeshBlockchainAuditor
 *    java MeshBlockchainAuditor /path/to/json_blocks
 *
 *  Operations
 *  ----------
 *  1. Full Chain Validation       � prev_hash linkage + SHA-256 re-computation
 *  2. Genesis Block Check         � verifies block_0 structure and sentinel prev_hash
 *  3. Inspect a Single Block      � pretty-print any block (by index or hash)
 *  4. List All Blocks (summary)   � table view of every block
 *  5. Transfer Payload Audit      � check required fields inside transfer objects
 *  6. Orphan / Gap Detection      � finds missing or out-of-order block files
 *  7. Duplicate Hash Detection    � flags any repeated block_hash values
 *  8. Chain Statistics            � size totals, peer counts, timestamps
 *  9. Export Audit Report (txt)   � writes a full report to disk
 *  0. Quit
 * -------------------------------------------------------------------------------
 */
public class MeshBlockchainAuditor {

    // -- Constants mirrored from PHP --------------------------------------------
    static final String GENESIS_PREV =
        "0000000000000000000000000000000000000000000000000000000000000000";
    static final String ALGO = "SHA-256";
    static final String BLOCK_PREFIX = "block_";
    static final String INDEX_FILE   = "chain_index.json";

    // -- ANSI colours (disabled on Windows CMD) ---------------------------------
    static final boolean USE_COLOR = !System.getProperty("os.name","").toLowerCase().contains("win");
    static final String RESET  = USE_COLOR ? "\u001B[0m"  : "";
    static final String GREEN  = USE_COLOR ? "\u001B[32m" : "";
    static final String RED    = USE_COLOR ? "\u001B[31m" : "";
    static final String YELLOW = USE_COLOR ? "\u001B[33m" : "";
    static final String CYAN   = USE_COLOR ? "\u001B[36m" : "";
    static final String BOLD   = USE_COLOR ? "\u001B[1m"  : "";

    // -- State ------------------------------------------------------------------
    private final Path blocksDir;
    private final Scanner scanner = new Scanner(System.in);

    // --------------------------------------------------------------------------
    //  ENTRY POINT
    // --------------------------------------------------------------------------

    public static void main(String[] args) throws Exception {
        String dir = args.length > 0 ? args[0] : resolveDefaultDir();
        MeshBlockchainAuditor app = new MeshBlockchainAuditor(dir);
        app.run();
    }

    /** Tries to find ./json_blocks next to the JAR / working directory. */
    private static String resolveDefaultDir() {
        Path candidate = Paths.get("json_blocks");
        if (Files.isDirectory(candidate)) return candidate.toAbsolutePath().toString();
        return ".";
    }

    public MeshBlockchainAuditor(String dir) {
        this.blocksDir = Paths.get(dir).toAbsolutePath().normalize();
    }

    // --------------------------------------------------------------------------
    //  MAIN MENU LOOP
    // --------------------------------------------------------------------------

    private void run() {
        header("MeshBlockchain Auditor  v1.0");
        System.out.println("  Blocks directory : " + CYAN + blocksDir + RESET);
        System.out.println("  Directory exists : " + (Files.isDirectory(blocksDir)
                ? GREEN + "YES" : RED + "NO") + RESET);
        System.out.println();

        while (true) {
            printMenu();
            String choice = prompt("Choice").trim();
            System.out.println();
            switch (choice) {
                case "1": opFullValidation();  break;
                case "2": opGenesisCheck();    break;
                case "3": opInspectBlock();    break;
                case "4": opListBlocks();      break;
                case "5": opTransferAudit();   break;
                case "6": opGapDetection();    break;
                case "7": opDuplicateHashes(); break;
                case "8": opStatistics();      break;
                case "9": opExportReport();    break;
                case "0": System.out.println("Goodbye."); return;
                default:  warn("Unknown option \u2014 try again."); break;
            }
            System.out.println();
        }
    }

    private void printMenu() {
        System.out.println(BOLD + "------------ Operations ------------" + RESET);
        System.out.println("  1  Full Chain Validation");
        System.out.println("  2  Genesis Block Check");
        System.out.println("  3  Inspect a Single Block");
        System.out.println("  4  List All Blocks (summary)");
        System.out.println("  5  Transfer Payload Audit");
        System.out.println("  6  Orphan / Gap Detection");
        System.out.println("  7  Duplicate Hash Detection");
        System.out.println("  8  Chain Statistics");
        System.out.println("  9  Export Audit Report (.txt)");
        System.out.println("  0  Quit");
        System.out.println(BOLD + "------------------------------------" + RESET);
    }

    // --------------------------------------------------------------------------
    //  OPERATION 1 � Full Chain Validation
    // --------------------------------------------------------------------------

    private void opFullValidation() {
        header("Full Chain Validation");
        List<Map<String, Object>> blocks = loadAllBlocks();
        if (blocks.isEmpty()) { warn("No blocks found."); return; }

        List<String> errors = new ArrayList<>();
        String expectedPrev = GENESIS_PREV;
        int brokenAt = -1;

        for (int i = 0; i < blocks.size(); i++) {
            Map<String, Object> block = blocks.get(i);
            String label = "Block " + i;

            // 1. Index field matches position
            int storedIdx = asInt(block.get("index"));
            if (storedIdx != i) {
                errors.add(label + ": index field is " + storedIdx + ", expected " + i);
                brokenAt = i; break;
            }

            // 2. prev_hash linkage
            String prevHash = str(block.get("prev_hash"));
            if (!prevHash.equals(expectedPrev)) {
                errors.add(label + ": prev_hash mismatch");
                brokenAt = i; break;
            }

            // 3. Hash recomputation
            String storedHash  = str(block.get("block_hash"));
            String computedHash = computeBlockHash(block);
            if (!computedHash.equals(storedHash)) {
                errors.add(label + ": block_hash tampered! stored=" + storedHash
                         + " computed=" + computedHash);
                brokenAt = i; break;
            }

            // 4. next_hash forward pointer (if present and not null)
            Object nextHashObj = block.get("next_hash");
            if (nextHashObj != null && i + 1 < blocks.size()) {
                String nextHash = str(nextHashObj);
                String actualNext = str(blocks.get(i + 1).get("block_hash"));
                if (!nextHash.isEmpty() && !nextHash.equals(actualNext)) {
                    errors.add(label + ": next_hash does not match block " + (i+1) + " hash");
                }
            }

            expectedPrev = storedHash;
            System.out.println("  " + GREEN + "?" + RESET + "  Block " + i
                             + "  " + storedHash.substring(0, 12) + "�");
        }

        System.out.println();
        if (errors.isEmpty()) {
            ok("Chain is VALID. " + blocks.size() + " blocks checked.");
        } else {
            fail("Chain INVALID � broken at block " + brokenAt);
            for (String e : errors) System.out.println("     " + RED + e + RESET);
        }
    }

    // --------------------------------------------------------------------------
    //  OPERATION 2 � Genesis Block Check
    // --------------------------------------------------------------------------

    private void opGenesisCheck() {
        header("Genesis Block Check");
        Map<String, Object> genesis = loadBlock(0);
        if (genesis == null) { fail("Genesis block (block_0000000000.json) not found."); return; }

        List<String> issues = new ArrayList<>();

        check(issues, asInt(genesis.get("index")) == 0,        "index == 0");
        check(issues, GENESIS_PREV.equals(genesis.get("prev_hash")),
                      "prev_hash == 64 zeros sentinel");
        check(issues, Boolean.TRUE.equals(genesis.get("genesis")),
                      "genesis flag == true");
        check(issues, genesis.get("transfer") == null || "null".equals(String.valueOf(genesis.get("transfer"))),
                      "transfer == null (genesis carries no payload)");

        String stored   = str(genesis.get("block_hash"));
        String computed = computeBlockHash(genesis);
        check(issues, stored.equals(computed), "block_hash integrity  [" + stored.substring(0,12) + "�]");

        System.out.println();
        if (issues.stream().noneMatch(s -> s.startsWith("FAIL"))) {
            ok("Genesis block is valid.");
        } else {
            fail("Genesis block has problems:");
            issues.stream().filter(s -> s.startsWith("FAIL"))
                  .forEach(s -> System.out.println("  " + RED + s + RESET));
        }
    }

    // --------------------------------------------------------------------------
    //  OPERATION 3 � Inspect a Single Block
    // --------------------------------------------------------------------------

    private void opInspectBlock() {
        header("Inspect a Single Block");
        String input = prompt("Enter block index (number) or block_hash").trim();

        Map<String, Object> block;
        if (input.matches("\\d+")) {
            block = loadBlock(Integer.parseInt(input));
        } else {
            block = loadBlockByHash(input);
        }

        if (block == null) { fail("Block not found."); return; }

        System.out.println();
        prettyPrint(block, 0);

        // Quick integrity summary
        System.out.println();
        String stored   = str(block.get("block_hash"));
        String computed = computeBlockHash(block);
        if (stored.equals(computed)) {
            ok("Hash integrity OK");
        } else {
            fail("Hash mismatch! Stored:   " + stored);
            System.out.println("           Computed: " + RED + computed + RESET);
        }
    }

    // --------------------------------------------------------------------------
    //  OPERATION 4 � List All Blocks
    // --------------------------------------------------------------------------

    private void opListBlocks() {
        header("All Blocks � Summary Table");
        List<Map<String, Object>> blocks = loadAllBlocks();
        if (blocks.isEmpty()) { warn("No blocks found."); return; }

        String fmt = "  %-6s  %-14s  %-20s  %-14s  %s%n";
        System.out.printf(BOLD + fmt + RESET,
            "INDEX", "HASH (prefix)", "DATETIME", "FILE SIZE", "TRANSFER");

        long totalSize = 0;
        for (Map<String, Object> b : blocks) {
            int idx = asInt(b.get("index"));
            String hash = str(b.get("block_hash"));
            String dt   = str(b.get("datetime"));
            String file = blockFilename(idx);
            long fsize  = fileSize(blocksDir.resolve(file));
            totalSize  += fsize;

            // Short transfer label
            Object tfr = b.get("transfer");
            String tfrLabel = "�";
            if (tfr instanceof Map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> t = (Map<String, Object>) tfr;
                tfrLabel = str(t.getOrDefault("filename", "")).replaceAll("^$", "(no name)");
            }

            System.out.printf(fmt,
                idx,
                (hash.length() >= 12 ? hash.substring(0,12) + "�" : hash),
                (dt.length() > 20 ? dt.substring(0,19) : dt),
                formatSize(fsize),
                tfrLabel);
        }

        System.out.println();
        System.out.println("  Blocks total : " + BOLD + blocks.size() + RESET);
        System.out.println("  Storage used : " + BOLD + formatSize(totalSize) + RESET);
    }

    // --------------------------------------------------------------------------
    //  OPERATION 5 � Transfer Payload Audit
    // --------------------------------------------------------------------------

    private void opTransferAudit() {
        header("Transfer Payload Audit");
        List<Map<String, Object>> blocks = loadAllBlocks();
        List<String> warnings = new ArrayList<>();

        String[] required = {"filename", "hash", "size"};

        int nonGenesis = 0;
        for (Map<String, Object> b : blocks) {
            if (Boolean.TRUE.equals(b.get("genesis"))) continue;
            nonGenesis++;
            int idx = asInt(b.get("index"));

            Object tfrObj = b.get("transfer");
            if (!(tfrObj instanceof Map)) {
                warnings.add("Block " + idx + ": 'transfer' is missing or not an object");
                continue;
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> t = (Map<String, Object>) tfrObj;

            for (String key : required) {
                if (!t.containsKey(key) || t.get(key) == null || t.get(key).toString().isEmpty()) {
                    warnings.add("Block " + idx + ": transfer." + key + " is empty/missing");
                }
            }

            // Size must be positive
            int size = asInt(t.get("size"));
            if (size < 0) warnings.add("Block " + idx + ": transfer.size is negative (" + size + ")");

            // hash should look like a hex digest
            String hash = str(t.getOrDefault("hash", ""));
            if (!hash.matches("[0-9a-fA-F]{32,}")) {
                warnings.add("Block " + idx + ": transfer.hash does not look like a hex digest");
            }

            System.out.println("  " + GREEN + "?" + RESET + "  Block " + idx
                             + "  " + str(t.getOrDefault("filename","?"))
                             + "  (" + formatSize(size) + ")");
        }

        System.out.println();
        System.out.println("  Non-genesis blocks checked : " + nonGenesis);
        if (warnings.isEmpty()) {
            ok("All transfer payloads look valid.");
        } else {
            warn(warnings.size() + " issue(s) found:");
            warnings.forEach(w -> System.out.println("  " + YELLOW + "?  " + w + RESET));
        }
    }

    // --------------------------------------------------------------------------
    //  OPERATION 6 � Orphan / Gap Detection
    // --------------------------------------------------------------------------

    private void opGapDetection() {
        header("Orphan / Gap Detection");

        // Collect all block_XXXXXXXXXX.json files in directory
        List<Integer> foundIndices = new ArrayList<>();
        try (DirectoryStream<Path> ds =
             Files.newDirectoryStream(blocksDir, BLOCK_PREFIX + "*.json")) {
            for (Path p : ds) {
                String name = p.getFileName().toString();
                Matcher m = Pattern.compile("block_(\\d+)\\.json").matcher(name);
                if (m.matches()) foundIndices.add(Integer.parseInt(m.group(1)));
            }
        } catch (IOException e) {
            fail("Cannot read directory: " + e.getMessage()); return;
        }

        Collections.sort(foundIndices);

        // Load index file
        List<String> idxEntries = loadIndexFile();

        System.out.println("  Files on disk  : " + foundIndices.size());
        System.out.println("  Entries in index: " + idxEntries.size());
        System.out.println();

        List<String> issues = new ArrayList<>();

        // Check for gaps in on-disk sequence
        for (int i = 0; i < foundIndices.size() - 1; i++) {
            int curr = foundIndices.get(i);
            int next = foundIndices.get(i + 1);
            if (next != curr + 1) {
                issues.add("Gap detected: block " + curr + " ? " + next
                         + "  (missing indices " + (curr+1) + ".." + (next-1) + ")");
            }
        }

        // Check index file vs disk
        for (int i = 0; i < idxEntries.size(); i++) {
            String fname = idxEntries.get(i);
            Path fp = blocksDir.resolve(fname);
            if (!Files.exists(fp)) {
                issues.add("Index entry [" + i + "] points to missing file: " + fname);
            }
        }

        // Files on disk not in index
        Set<String> indexedFiles = new HashSet<>(idxEntries);
        for (int idx : foundIndices) {
            String fname = blockFilename(idx);
            if (!indexedFiles.contains(fname)) {
                issues.add("Orphan file on disk not in index: " + fname);
            }
        }

        if (issues.isEmpty()) {
            ok("No gaps or orphans found.");
        } else {
            fail(issues.size() + " issue(s):");
            issues.forEach(s -> System.out.println("  " + RED + "?  " + s + RESET));
        }
    }

    // --------------------------------------------------------------------------
    //  OPERATION 7 � Duplicate Hash Detection
    // --------------------------------------------------------------------------

    private void opDuplicateHashes() {
        header("Duplicate Hash Detection");
        List<Map<String, Object>> blocks = loadAllBlocks();

        Map<String, List<Integer>> hashMap = new LinkedHashMap<>();
        for (Map<String, Object> b : blocks) {
            String h = str(b.get("block_hash"));
            hashMap.computeIfAbsent(h, k -> new ArrayList<>()).add(asInt(b.get("index")));
        }

        List<Map.Entry<String, List<Integer>>> dups = hashMap.entrySet().stream()
            .filter(e -> e.getValue().size() > 1)
            .collect(Collectors.toList());

        if (dups.isEmpty()) {
            ok("No duplicate block_hash values found in " + blocks.size() + " blocks.");
        } else {
            fail(dups.size() + " duplicate hash(es) detected:");
            for (var e : dups) {
                System.out.println("  " + RED + e.getKey().substring(0,16) + "�"
                    + "  appears at blocks " + e.getValue() + RESET);
            }
        }
    }

    // --------------------------------------------------------------------------
    //  OPERATION 8 � Chain Statistics
    // --------------------------------------------------------------------------

    private void opStatistics() {
        header("Chain Statistics");
        List<Map<String, Object>> blocks = loadAllBlocks();
        if (blocks.isEmpty()) { warn("No blocks."); return; }

        long totalFileSize   = 0;
        long totalTransferSize = 0;
        int  totalPeersReached = 0;
        int  totalPeersFailed  = 0;
        Set<String> uniquePeers = new HashSet<>();
        Set<String> uniqueIPs   = new HashSet<>();
        double earliest = Double.MAX_VALUE, latest = 0;

        int nonGenesis = 0;
        for (Map<String, Object> b : blocks) {
            int idx = asInt(b.get("index"));
            totalFileSize += fileSize(blocksDir.resolve(blockFilename(idx)));

            double ts = asDouble(b.get("timestamp"));
            if (ts < earliest) earliest = ts;
            if (ts > latest)   latest   = ts;

            if (Boolean.TRUE.equals(b.get("genesis"))) continue;
            nonGenesis++;

            Object tfrObj = b.get("transfer");
            if (!(tfrObj instanceof Map)) continue;
            @SuppressWarnings("unchecked")
            Map<String, Object> t = (Map<String, Object>) tfrObj;

            totalTransferSize += asLong(t.get("size"));

            Object pr = t.get("peers_reached");
            if (pr instanceof List) {
                @SuppressWarnings("unchecked")
                List<Object> prList = (List<Object>) pr;
                totalPeersReached += prList.size();
                prList.forEach(p -> uniquePeers.add(p.toString()));
            }
            Object pf = t.get("peers_failed");
            if (pf instanceof List) {
                @SuppressWarnings("unchecked")
                List<Object> pfList = (List<Object>) pf;
                totalPeersFailed += pfList.size();
            }

            String ip = str(t.getOrDefault("sender_ip",""));
            if (!ip.isEmpty()) uniqueIPs.add(ip);
        }

        String fmtS = "  %-30s : %s%n";
        System.out.printf(fmtS, "Total blocks",        blocks.size() + " (genesis + " + nonGenesis + " transfers)");
        System.out.printf(fmtS, "Chain file storage",  formatSize(totalFileSize));
        System.out.printf(fmtS, "Total transferred",   formatSize(totalTransferSize));
        System.out.printf(fmtS, "First block (UTC)",   earliest == Double.MAX_VALUE ? "�"
                                                         : Instant.ofEpochSecond((long)earliest).toString());
        System.out.printf(fmtS, "Last  block (UTC)",   latest == 0 ? "�"
                                                         : Instant.ofEpochSecond((long)latest).toString());
        System.out.printf(fmtS, "Peers reached (sum)", totalPeersReached);
        System.out.printf(fmtS, "Peers failed  (sum)", totalPeersFailed);
        System.out.printf(fmtS, "Unique peers seen",   uniquePeers.size());
        System.out.printf(fmtS, "Unique sender IPs",   uniqueIPs.size());
    }

    // --------------------------------------------------------------------------
    //  OPERATION 9 � Export Audit Report
    // --------------------------------------------------------------------------

    private void opExportReport() {
        header("Export Audit Report");
        String outPath = prompt("Output file path [audit_report.txt]").trim();
        if (outPath.isEmpty()) outPath = "audit_report.txt";

        StringBuilder sb = new StringBuilder();
        sb.append("MeshBlockchain Audit Report\n");
        sb.append("Generated : ").append(new Date()).append("\n");
        sb.append("Directory : ").append(blocksDir).append("\n");
        sb.append("=".repeat(72)).append("\n\n");

        List<Map<String, Object>> blocks = loadAllBlocks();

        // --- Validation ---
        sb.append("SECTION 1: Full Chain Validation\n").append("-".repeat(40)).append("\n");
        String expectedPrev = GENESIS_PREV;
        boolean chainOk = true;
        for (int i = 0; i < blocks.size(); i++) {
            Map<String, Object> b = blocks.get(i);
            String storedHash  = str(b.get("block_hash"));
            String computedHash = computeBlockHash(b);
            String prevHash    = str(b.get("prev_hash"));

            boolean ok = storedHash.equals(computedHash) && prevHash.equals(expectedPrev)
                      && asInt(b.get("index")) == i;
            sb.append("  Block ").append(String.format("%4d", i))
              .append("  ").append(storedHash, 0, Math.min(20, storedHash.length()))
              .append("�  ").append(ok ? "OK" : "*** FAIL ***").append("\n");
            if (!ok) chainOk = false;
            expectedPrev = storedHash;
        }
        sb.append("\nChain valid: ").append(chainOk ? "YES" : "NO").append("\n\n");

        // --- Transfer audit ---
        sb.append("SECTION 2: Transfer Payload Summary\n").append("-".repeat(40)).append("\n");
        for (Map<String, Object> b : blocks) {
            if (Boolean.TRUE.equals(b.get("genesis"))) continue;
            int idx = asInt(b.get("index"));
            Object tfrObj = b.get("transfer");
            if (!(tfrObj instanceof Map)) {
                sb.append("  Block ").append(idx).append(": NO transfer object\n"); continue;
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> t = (Map<String, Object>) tfrObj;
            sb.append("  Block ").append(String.format("%4d", idx))
              .append("  file=").append(t.getOrDefault("filename","?"))
              .append("  size=").append(formatSize(asLong(t.get("size"))))
              .append("  ip=").append(t.getOrDefault("sender_ip","?"))
              .append("\n");
        }

        // --- Statistics ---
        sb.append("\nSECTION 3: Statistics\n").append("-".repeat(40)).append("\n");
        sb.append("  Total blocks: ").append(blocks.size()).append("\n");

        try {
            Files.writeString(Paths.get(outPath), sb.toString(), StandardCharsets.UTF_8);
            ok("Report saved to: " + outPath);
        } catch (IOException e) {
            fail("Could not write report: " + e.getMessage());
        }
    }

    // --------------------------------------------------------------------------
    //  HASH COMPUTATION  (mirrors PHP computeBlockHash)
    //
    //  The PHP code does:
    //    unset($copy['block_hash'], $copy['next_hash']);
    //    json_encode($copy, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
    //    hash('sha256', $canonical)
    //
    //  We reproduce the same canonical JSON string in Java.
    // --------------------------------------------------------------------------

    String computeBlockHash(Map<String, Object> block) {
        // Build a copy without block_hash and next_hash
        Map<String, Object> copy = new LinkedHashMap<>(block);
        copy.remove("block_hash");
        copy.remove("next_hash");

        String canonical = toCanonicalJson(copy);
        try {
            MessageDigest md = MessageDigest.getInstance(ALGO);
            byte[] digest = md.digest(canonical.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (byte b : digest) hex.append(String.format("%02x", b));
            return hex.toString();
        } catch (Exception e) {
            throw new RuntimeException("SHA-256 unavailable", e);
        }
    }

    /**
     * Produces JSON equivalent to PHP's JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES.
     * Key ordering must match the order stored in the LinkedHashMap loaded from the file,
     * which in turn mirrors the order PHP's json_encode uses (insertion order).
     */
    private String toCanonicalJson(Object value) {
        if (value == null)               return "null";
        if (value instanceof Boolean)    return value.toString();
        if (value instanceof Number)     return numberToJson((Number) value);
        if (value instanceof String)     return stringToJson((String) value);
        if (value instanceof List) {
            @SuppressWarnings("unchecked")
            List<Object> list = (List<Object>) value;
            StringJoiner sj = new StringJoiner(",", "[", "]");
            for (Object item : list) sj.add(toCanonicalJson(item));
            return sj.toString();
        }
        if (value instanceof Map) {
            @SuppressWarnings("unchecked")
            Map<String, Object> map = (Map<String, Object>) value;
            StringJoiner sj = new StringJoiner(",", "{", "}");
            for (Map.Entry<String, Object> e : map.entrySet()) {
                sj.add(stringToJson(e.getKey()) + ":" + toCanonicalJson(e.getValue()));
            }
            return sj.toString();
        }
        return "\"" + value + "\"";
    }

    private String numberToJson(Number n) {
        if (n instanceof Double || n instanceof Float) {
            double d = n.doubleValue();
            // PHP prints floats with up to 14 significant digits
            // For timestamps like 1712345678.123456 we need full precision
            String s = String.valueOf(d);
            // Remove trailing ".0" only if no fractional part
            if (s.endsWith(".0")) return String.valueOf(n.longValue());
            return s;
        }
        return String.valueOf(n.longValue());
    }

    private String stringToJson(String s) {
        // Mirrors JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES:
        // Do NOT escape / (solidus) or non-ASCII; DO escape control chars and "
        StringBuilder sb = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"':  sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\b': sb.append("\\b");  break;
                case '\f': sb.append("\\f");  break;
                case '\n': sb.append("\\n");  break;
                case '\r': sb.append("\\r");  break;
                case '\t': sb.append("\\t");  break;
                default:
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c); // non-ASCII kept as-is (UNESCAPED_UNICODE)
                    }
                    break;
            }
        }
        sb.append("\"");
        return sb.toString();
    }

    // --------------------------------------------------------------------------
    //  JSON LOADING  (minimal hand-rolled parser � no external deps)
    // --------------------------------------------------------------------------

    List<Map<String, Object>> loadAllBlocks() {
        List<String> index = loadIndexFile();
        List<Map<String, Object>> blocks = new ArrayList<>();
        for (String fname : index) {
            Map<String, Object> b = loadBlockFile(fname);
            if (b != null) blocks.add(b);
        }
        if (blocks.isEmpty()) {
            // Fallback: scan directory
            try (DirectoryStream<Path> ds =
                 Files.newDirectoryStream(blocksDir, BLOCK_PREFIX + "*.json")) {
                List<Path> paths = new ArrayList<>();
                for (Path p : ds) paths.add(p);
                paths.sort(Comparator.comparing(p -> p.getFileName().toString()));
                for (Path p : paths) {
                    Map<String, Object> b = parseJsonObject(
                        Files.readString(p, StandardCharsets.UTF_8));
                    if (b != null) blocks.add(b);
                }
            } catch (IOException ignored) {}
        }
        return blocks;
    }

    Map<String, Object> loadBlock(int index) {
        return loadBlockFile(blockFilename(index));
    }

    Map<String, Object> loadBlockByHash(String hash) {
        for (Map<String, Object> b : loadAllBlocks()) {
            if (hash.equals(b.get("block_hash"))) return b;
        }
        return null;
    }

    Map<String, Object> loadBlockFile(String filename) {
        Path p = blocksDir.resolve(filename);
        if (!Files.exists(p)) return null;
        try {
            return parseJsonObject(Files.readString(p, StandardCharsets.UTF_8));
        } catch (IOException e) {
            return null;
        }
    }

    List<String> loadIndexFile() {
        Path p = blocksDir.resolve(INDEX_FILE);
        if (!Files.exists(p)) return Collections.emptyList();
        try {
            String raw = Files.readString(p, StandardCharsets.UTF_8);
            return parseJsonStringArray(raw);
        } catch (IOException e) {
            return Collections.emptyList();
        }
    }

    // -- Tiny JSON parser (LinkedHashMap to preserve key order) ----------------

    @SuppressWarnings("unchecked")
    Map<String, Object> parseJsonObject(String json) {
        if (json == null || json.isBlank()) return null;
        try {
            JsonParser p = new JsonParser(json.trim());
            Object val = p.parseValue();
            return (val instanceof Map) ? (Map<String, Object>) val : null;
        } catch (Exception e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    List<String> parseJsonStringArray(String json) {
        try {
            JsonParser p = new JsonParser(json.trim());
            Object val = p.parseValue();
            if (val instanceof List) {
                return ((List<?>) val).stream()
                    .map(Object::toString).collect(Collectors.toList());
            }
        } catch (Exception ignored) {}
        return Collections.emptyList();
    }

    // --------------------------------------------------------------------------
    //  MINIMAL JSON PARSER (no external libraries)
    // --------------------------------------------------------------------------

    static class JsonParser {
        private final String src;
        private int pos;

        JsonParser(String src) { this.src = src; }

        Object parseValue() {
            skipWs();
            if (pos >= src.length()) return null;
            char c = src.charAt(pos);
            if (c == '{') return parseObject();
            if (c == '[') return parseArray();
            if (c == '"') return parseString();
            if (c == 't') { pos += 4; return Boolean.TRUE; }
            if (c == 'f') { pos += 5; return Boolean.FALSE; }
            if (c == 'n') { pos += 4; return null; }
            return parseNumber();
        }

        Map<String, Object> parseObject() {
            Map<String, Object> map = new LinkedHashMap<>();
            pos++; // {
            skipWs();
            if (pos < src.length() && src.charAt(pos) == '}') { pos++; return map; }
            while (pos < src.length()) {
                skipWs();
                String key = parseString();
                skipWs();
                pos++; // :
                skipWs();
                Object val = parseValue();
                map.put(key, val);
                skipWs();
                if (pos < src.length() && src.charAt(pos) == ',') { pos++; } else break;
            }
            if (pos < src.length() && src.charAt(pos) == '}') pos++;
            return map;
        }

        List<Object> parseArray() {
            List<Object> list = new ArrayList<>();
            pos++; // [
            skipWs();
            if (pos < src.length() && src.charAt(pos) == ']') { pos++; return list; }
            while (pos < src.length()) {
                skipWs();
                list.add(parseValue());
                skipWs();
                if (pos < src.length() && src.charAt(pos) == ',') { pos++; } else break;
            }
            if (pos < src.length() && src.charAt(pos) == ']') pos++;
            return list;
        }

        String parseString() {
            pos++; // opening "
            StringBuilder sb = new StringBuilder();
            while (pos < src.length()) {
                char c = src.charAt(pos++);
                if (c == '"') break;
                if (c == '\\') {
                    char esc = src.charAt(pos++);
                    switch (esc) {
                        case '"':  sb.append('"');  break;
                        case '\\': sb.append('\\'); break;
                        case '/':  sb.append('/');  break;
                        case 'n':  sb.append('\n'); break;
                        case 'r':  sb.append('\r'); break;
                        case 't':  sb.append('\t'); break;
                        case 'b':  sb.append('\b'); break;
                        case 'f':  sb.append('\f'); break;
                        case 'u':
                            int cp = Integer.parseInt(src.substring(pos, pos + 4), 16);
                            sb.append((char) cp); pos += 4;
                            break;
                        default:   sb.append(esc); break;
                    }
                } else {
                    sb.append(c);
                }
            }
            return sb.toString();
        }

        Number parseNumber() {
            int start = pos;
            boolean isFloat = false;
            if (pos < src.length() && src.charAt(pos) == '-') pos++;
            while (pos < src.length() && (Character.isDigit(src.charAt(pos))
                    || src.charAt(pos) == '.' || src.charAt(pos) == 'e'
                    || src.charAt(pos) == 'E' || src.charAt(pos) == '+'
                    || src.charAt(pos) == '-')) {
                char c = src.charAt(pos);
                if (c == '.' || c == 'e' || c == 'E') isFloat = true;
                pos++;
            }
            String num = src.substring(start, pos);
            if (isFloat) return Double.parseDouble(num);
            try { return Long.parseLong(num); } catch (NumberFormatException e) {
                return Double.parseDouble(num);
            }
        }

        void skipWs() {
            while (pos < src.length() && Character.isWhitespace(src.charAt(pos))) pos++;
        }
    }

    // --------------------------------------------------------------------------
    //  PRETTY PRINTER
    // --------------------------------------------------------------------------

    @SuppressWarnings("unchecked")
    private void prettyPrint(Object value, int indent) {
        String pad  = "  ".repeat(indent);
        String pad2 = "  ".repeat(indent + 1);
        if (value instanceof Map) {
            Map<String, Object> map = (Map<String, Object>) value;
            System.out.println(pad + "{");
            int i = 0;
            for (Map.Entry<String, Object> e : map.entrySet()) {
                boolean last = (++i == map.size());
                System.out.print(pad2 + CYAN + "\"" + e.getKey() + "\"" + RESET + ": ");
                printValue(e.getValue(), indent + 1, last);
            }
            System.out.println(pad + "}");
        } else {
            printValue(value, indent, true);
        }
    }

    @SuppressWarnings("unchecked")
    private void printValue(Object v, int indent, boolean last) {
        String pad2 = "  ".repeat(indent + 1);
        String comma = last ? "" : ",";
        if (v instanceof Map) {
            System.out.println();
            prettyPrint(v, indent);
        } else if (v instanceof List) {
            List<Object> list = (List<Object>) v;
            if (list.isEmpty()) {
                System.out.println("[]" + comma);
            } else {
                System.out.println("[");
                for (int i = 0; i < list.size(); i++) {
                    System.out.print(pad2);
                    printValue(list.get(i), indent, i == list.size() - 1);
                }
                System.out.println("  ".repeat(indent) + "]" + comma);
            }
        } else if (v instanceof String) {
            System.out.println(GREEN + "\"" + v + "\"" + RESET + comma);
        } else if (v instanceof Boolean) {
            System.out.println(YELLOW + v + RESET + comma);
        } else if (v == null) {
            System.out.println(YELLOW + "null" + RESET + comma);
        } else {
            System.out.println(YELLOW + v + RESET + comma);
        }
    }

    // --------------------------------------------------------------------------
    //  HELPERS
    // --------------------------------------------------------------------------

    private static String blockFilename(int index) {
        return BLOCK_PREFIX + String.format("%010d", index) + ".json";
    }

    private static int asInt(Object o) {
        if (o instanceof Number) return ((Number) o).intValue();
        if (o instanceof String) { try { return Integer.parseInt((String) o); } catch (Exception e) { return 0; } }
        return 0;
    }

    private static long asLong(Object o) {
        if (o instanceof Number) return ((Number) o).longValue();
        return 0L;
    }

    private static double asDouble(Object o) {
        if (o instanceof Number) return ((Number) o).doubleValue();
        return 0.0;
    }

    private static String str(Object o) {
        return o == null ? "" : o.toString();
    }

    private static long fileSize(Path p) {
        try { return Files.size(p); } catch (IOException e) { return 0; }
    }

    private static String formatSize(long bytes) {
        if (bytes < 1024)       return bytes + " B";
        if (bytes < 1024*1024)  return String.format("%.1f KB", bytes / 1024.0);
        return                         String.format("%.2f MB", bytes / (1024.0 * 1024));
    }

    private void check(List<String> issues, boolean cond, String label) {
        if (cond) {
            System.out.println("  " + GREEN + "?" + RESET + "  " + label);
            issues.add("OK: " + label);
        } else {
            System.out.println("  " + RED + "?" + RESET + "  " + label);
            issues.add("FAIL: " + label);
        }
    }

    private String prompt(String msg) {
        System.out.print(BOLD + msg + " > " + RESET);
        return scanner.hasNextLine() ? scanner.nextLine() : "";
    }

    private void header(String title) {
        System.out.println(BOLD + CYAN + "\n-- " + title + " --" + RESET);
    }

    private void ok(String msg) {
        System.out.println(GREEN + BOLD + "?  " + msg + RESET);
    }

    private void fail(String msg) {
        System.out.println(RED + BOLD + "?  " + msg + RESET);
    }

    private void warn(String msg) {
        System.out.println(YELLOW + BOLD + "?  " + msg + RESET);
    }
}