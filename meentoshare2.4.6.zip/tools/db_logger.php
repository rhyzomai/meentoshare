﻿<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  DB LOGGER  —  optional MySQL module for index.php (Mesh Node)
//
//  Usage (add to index.php after the require/define block):
//      require __DIR__ . '/db_logger.php';
//
//  Then, at each upload success point where a NEW file was stored locally,
//  add the following call right after appendFilesAndDataJson():
//
//      // Upload endpoint (browser POST, !peer_push):
//      appendFilesAndDataJson($local['hash']);
//      dbLogFile($local['hash']);              // ← add this
//
//      // Receive endpoint (peer_push = 1):
//      appendFilesAndDataJson($result['hash']);
//      dbLogFile($result['hash']);             // ← add this
//
//  Only files uploaded directly to THIS node are logged (existed === false).
//  Peer-pushed files are intentionally excluded; add the call inside the
//  peer_push block too if you want those logged as well.
//
//  Configuration:
//      Edit the DB_* constants below to match your MySQL credentials.
//      The table is created automatically on first use.
//
//  Behaviour:
//      · Reads the hash's info JSON from INFO_DIR and inserts one row.
//      · If a row with the same hash already exists the INSERT is silently
//        skipped (INSERT IGNORE).
//      · Entirely silent — no output, no exceptions, never affects the
//        HTTP response.
// ═══════════════════════════════════════════════════════════════════════════════

// ── database credentials ──────────────────────────────────────────────────────
define('DB_HOST',    'localhost');
define('DB_PORT',    3306);
define('DB_NAME',    'mesh_node');
define('DB_USER',    'mesh_user');
define('DB_PASS',    'change_me');
define('DB_CHARSET', 'utf8mb4');

// ── table name ────────────────────────────────────────────────────────────────
define('DB_TABLE', 'uploaded_files');

// ─────────────────────────────────────────────────────────────────────────────

/**
 * Return a persistent PDO connection, creating the table on first use.
 * Returns null silently on any failure.
 */
function _dbConnection(): ?PDO
{
    static $pdo = null;
    static $tried = false;

    if ($tried) return $pdo;
    $tried = true;

    try {
        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=%s',
            DB_HOST, DB_PORT, DB_NAME, DB_CHARSET
        );

        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);

        // Create the table if it does not exist yet.
        // hash is the PRIMARY KEY — duplicate inserts are silently ignored.
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS `" . DB_TABLE . "` (
                `id`                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `hash`              CHAR(64)        NOT NULL,
                `filename`          VARCHAR(320)    NOT NULL DEFAULT '',
                `original_filename` VARCHAR(512)    NOT NULL DEFAULT '',
                `extension`         VARCHAR(32)     NOT NULL DEFAULT '',
                `size`              BIGINT UNSIGNED NOT NULL DEFAULT 0,
                `public_key`        TEXT            NOT NULL,
                `node_info`         TEXT            NOT NULL,
                `description`       TEXT            NOT NULL,
                `uploaded_at`       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uq_hash` (`hash`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");

    } catch (\Throwable $e) {
        $pdo = null;
    }

    return $pdo;
}

/**
 * Insert the file record identified by $hash into MySQL.
 * Reads the info JSON written by storeLocally() from INFO_DIR.
 * Silently skips if the hash already exists (INSERT IGNORE).
 * Entirely silent — no output, no exceptions.
 */
function dbLogFile(string $hash): void
{
    ob_start();
    $prev = error_reporting(0);
    try {
        // Read the info JSON that storeLocally() already wrote
        $infoPath = INFO_DIR . '/' . $hash . '.json';
        $raw      = @file_get_contents($infoPath);
        if ($raw === false) return;

        $info = json_decode($raw, true);
        if (!is_array($info)) return;

        $pdo = _dbConnection();
        if ($pdo === null) return;

        $ext      = $info['extension'] ?? '';
        $baseName = $ext !== '' ? "{$hash}.{$ext}" : $hash;

        $stmt = $pdo->prepare("
            INSERT IGNORE INTO `" . DB_TABLE . "`
                (hash, filename, original_filename, extension, size,
                 public_key, node_info, description)
            VALUES
                (:hash, :filename, :original_filename, :extension, :size,
                 :public_key, :node_info, :description)
        ");

        $stmt->execute([
            ':hash'              => $hash,
            ':filename'          => $baseName,
            ':original_filename' => $info['original_filename'] ?? '',
            ':extension'         => $ext,
            ':size'              => (int) ($info['size'] ?? 0),
            ':public_key'        => $info['public_key']  ?? '',
            ':node_info'         => $info['node_info']   ?? '',
            ':description'       => $info['description'] ?? '',
        ]);

    } catch (\Throwable $e) {
        // silently discard
    } finally {
        error_reporting($prev);
        ob_end_clean();
    }
}