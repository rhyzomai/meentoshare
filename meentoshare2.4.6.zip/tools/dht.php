﻿<?php
// -------------------------------------------------------------------------------
//  DHT Crawler — discovers peers via UDP DHT (BEP 5)
//  PHP 7 compatible | single file | fopen-based I/O | file-lock race-condition safe
// -------------------------------------------------------------------------------

// ── constants ──────────────────────────────────────────────────────────────────
define('SERVERS_SRC',  __DIR__ . '/servers.txt');
define('SERVERS_DHT',  __DIR__ . '/servers_dht.txt');
define('SOCKET_TIMEOUT', 3);       // seconds per UDP probe
define('MAX_NODES_PER_ROUND', 50); // cap discovered nodes per run
define('MAX_COMMENT_LEN', 280);

// ── action dispatch ────────────────────────────────────────────────────────────
$action = $_POST['action'] ?? '';

if ($action === 'crawl') {
    header('Content-Type: application/json');
    echo json_encode(dht_crawl_action());
    exit;
}
if ($action === 'list') {
    header('Content-Type: application/json');
    echo json_encode(['servers' => read_all_servers()]);
    exit;
}
if ($action === 'add') {
    header('Content-Type: application/json');
    $raw = trim($_POST['server'] ?? '');
    echo json_encode(manual_add_server($raw));
    exit;
}

// ── helpers ────────────────────────────────────────────────────────────────────

/**
 * Read servers from both files, return unique list.
 */
function read_all_servers(): array {
    $out = [];
    foreach ([SERVERS_SRC, SERVERS_DHT] as $path) {
        if (!file_exists($path)) continue;
        $fh = fopen($path, 'r');
        if (!$fh) continue;
        while (($line = fgets($fh)) !== false) {
            $s = trim($line);
            if ($s !== '' && $s[0] !== '#') $out[$s] = true;
        }
        fclose($fh);
    }
    return array_keys($out);
}

/**
 * Append new unique servers to servers_dht.txt using exclusive lock.
 * Returns count of actually written lines.
 */
function append_new_servers(array $new_hosts): int {
    $existing = array_fill_keys(read_all_servers(), true);
    $to_write = [];
    foreach ($new_hosts as $h) {
        $h = trim($h);
        if ($h !== '' && !isset($existing[$h])) {
            $to_write[] = $h;
            $existing[$h] = true;
        }
    }
    if (empty($to_write)) return 0;

    // Open for append + exclusive lock to avoid race conditions
    $fh = fopen(SERVERS_DHT, 'a');
    if (!$fh) return 0;
    if (!flock($fh, LOCK_EX)) { fclose($fh); return 0; }

    // Re-read inside the lock to catch concurrent writers
    $confirmed = array_fill_keys(read_all_servers(), true);
    $written = 0;
    foreach ($to_write as $h) {
        if (!isset($confirmed[$h])) {
            fwrite($fh, $h . "\n");
            $confirmed[$h] = true;
            $written++;
        }
    }
    flock($fh, LOCK_UN);
    fclose($fh);
    return $written;
}

/**
 * Parse "host:port" string into [host, port] or false.
 */
function parse_host_port(string $s) {
    $s = trim($s);
    // IPv6 [::1]:6881
    if (preg_match('/^\[([^\]]+)\]:(\d+)$/', $s, $m)) return [$m[1], (int)$m[2]];
    // host:port
    if (preg_match('/^([^:]+):(\d+)$/', $s, $m)) return [$m[1], (int)$m[2]];
    return false;
}

/**
 * BEP 5 — send find_node to a DHT node, return list of "host:port" strings.
 */
function dht_find_node(string $host, int $port): array {
    $node_id  = random_bytes(20);
    $target   = random_bytes(20);
    $tid      = random_bytes(2);

    // Bencode the find_node query
    $msg = 'd'
        . '1:ad'
        . '2:id20:' . $node_id
        . '6:target20:' . $target
        . 'e'
        . '1:q9:find_node'
        . '1:t2:' . $tid
        . '1:y1:q'
        . 'e';

    $sock = @fsockopen('udp://' . $host, $port, $errno, $errstr, SOCKET_TIMEOUT);
    if (!$sock) return [];

    stream_set_timeout($sock, SOCKET_TIMEOUT);
    fwrite($sock, $msg);

    $resp = '';
    $deadline = microtime(true) + SOCKET_TIMEOUT;
    while (microtime(true) < $deadline) {
        $chunk = fread($sock, 4096);
        if ($chunk === false || $chunk === '') break;
        $resp .= $chunk;
        if (strlen($resp) > 200) break; // enough for compact nodes
    }
    fclose($sock);

    if ($resp === '') return [];
    return parse_compact_nodes($resp);
}

/**
 * Extract compact node info (26 bytes each) from a raw DHT response.
 * Returns array of "ip:port" strings.
 */
function parse_compact_nodes(string $data): array {
    // Find "nodes" value in bencoded response
    $pos = strpos($data, '5:nodes');
    if ($pos === false) $pos = strpos($data, '6:nodes6');
    if ($pos === false) return [];

    // After "5:nodes" or "6:nodes6" comes the bencoded string: <len>:<bytes>
    $colon = strpos($data, ':', $pos + 5);
    if ($colon === false) return [];
    $len = (int)substr($data, $pos + 6, $colon - $pos - 6);
    if ($len <= 0 || $len % 26 !== 0) return [];

    $nodes_raw = substr($data, $colon + 1, $len);
    $results = [];
    for ($i = 0; $i + 26 <= strlen($nodes_raw); $i += 26) {
        // 20 bytes node_id + 4 bytes IP + 2 bytes port
        $ip_raw   = substr($nodes_raw, $i + 20, 4);
        $port_raw = substr($nodes_raw, $i + 24, 2);
        $ip   = implode('.', array_values(unpack('C4', $ip_raw)));
        $port = unpack('n', $port_raw)[1];
        if ($port > 0 && $port < 65536 && $ip !== '0.0.0.0') {
            $results[] = $ip . ':' . $port;
        }
    }
    return array_unique($results);
}

/**
 * Main crawl action — probe known servers, collect new nodes, save.
 */
function dht_crawl_action(): array {
    $seeds    = read_all_servers();
    if (empty($seeds)) return ['ok' => false, 'msg' => 'No seed servers found.', 'new' => 0, 'probed' => 0];

    $discovered = [];
    $probed     = 0;
    $errors     = 0;

    shuffle($seeds);
    $limit = min(count($seeds), 20); // probe up to 20 seeds per run

    for ($i = 0; $i < $limit; $i++) {
        $parsed = parse_host_port($seeds[$i]);
        if (!$parsed) { $errors++; continue; }
        [$host, $port] = $parsed;
        $found = dht_find_node($host, $port);
        $probed++;
        foreach ($found as $n) $discovered[$n] = true;
        if (count($discovered) >= MAX_NODES_PER_ROUND) break;
    }

    $new_hosts = array_keys($discovered);
    $written   = append_new_servers($new_hosts);

    return [
        'ok'       => true,
        'probed'   => $probed,
        'found'    => count($new_hosts),
        'new'      => $written,
        'errors'   => $errors,
        'msg'      => "Probed $probed nodes, found " . count($new_hosts) . " peers, saved $written new.",
    ];
}

/**
 * Manually add a single server.
 */
function manual_add_server(string $raw): array {
    if ($raw === '') return ['ok' => false, 'msg' => 'Empty input.'];
    if (!parse_host_port($raw)) return ['ok' => false, 'msg' => 'Invalid format. Use host:port.'];
    $written = append_new_servers([$raw]);
    return [
        'ok'  => $written > 0,
        'msg' => $written > 0 ? "Added $raw to servers_dht.txt." : "Already exists.",
    ];
}

// ── HTML output ────────────────────────────────────────────────────────────────
$initial_servers = read_all_servers();
$server_count    = count($initial_servers);
$dht_count       = 0;
if (file_exists(SERVERS_DHT)) {
    $fh = fopen(SERVERS_DHT, 'r');
    if ($fh) { while (fgets($fh) !== false) $dht_count++; fclose($fh); }
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DHT Crawler</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{min-height:100%;background:#fff;color:#111;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
body{display:flex;flex-direction:column;align-items:center;padding:2rem 1.5rem}

.page{max-width:36rem;width:100%}

header{margin-bottom:2rem;display:flex;align-items:baseline;justify-content:space-between;flex-wrap:wrap;gap:0.8rem}
h1{font-size:1.4rem;font-weight:700;letter-spacing:-0.02em}
h1 em{font-weight:400;color:#555;font-style:normal}
.sub{font-size:0.8rem;color:#777;margin-top:0.2rem}

#node-bar{display:flex;gap:0.75rem;flex-wrap:wrap;margin-bottom:1.75rem;font-size:0.8rem;color:#555}
.nb-pill{display:flex;align-items:center;gap:0.35rem;padding:0.25rem 0.6rem;background:#f5f5f5;border-radius:4px;border:1px solid #e0e0e0}
.nb-dot{width:7px;height:7px;border-radius:50%;background:#aaa}
.nb-dot.ok{background:#1a8e3f}
.nb-dot.blue{background:#0044cc}
.nb-val{font-weight:500}

/* ── crawl card ── */
.card{border:1px solid #ddd;border-radius:6px;overflow:hidden;margin-bottom:1.25rem}
.card-head{display:flex;align-items:center;gap:0.8rem;padding:0.8rem 1rem;border-bottom:1px solid #eee;background:#fafafa}
.c-icon{width:2rem;height:2rem;background:#f0f4ff;border-radius:4px;display:grid;place-items:center;flex-shrink:0;font-size:1rem;color:#0044cc}
.c-title{font-size:0.9rem;font-weight:600;flex:1}
.c-sub{font-size:0.75rem;color:#777}

.card-body{padding:1rem}
.fl{display:block;font-size:0.75rem;color:#777;margin-bottom:0.4rem}

/* add-server row */
.add-row{display:flex;gap:0.5rem;margin-bottom:0.75rem}
.add-row input{flex:1;padding:0.5rem 0.7rem;border:1px solid #ccc;border-radius:4px;font-family:inherit;font-size:0.85rem;outline:none;transition:border-color 0.2s}
.add-row input:focus{border-color:#0044cc}
.btn-add{padding:0.5rem 1rem;background:#fff;color:#0044cc;border:1px solid #0044cc;border-radius:4px;font-weight:600;font-size:0.82rem;cursor:pointer;white-space:nowrap;transition:background 0.15s}
.btn-add:hover{background:#f0f4ff}

/* textarea */
textarea#comment-box{width:100%;min-height:4rem;padding:0.6rem 0.8rem;border:1px solid #ccc;border-radius:4px;font-family:inherit;font-size:0.85rem;resize:vertical;outline:none;transition:border-color 0.2s;margin-bottom:0.4rem}
textarea#comment-box:focus{border-color:#0044cc}
.cmeta{display:flex;justify-content:space-between;font-size:0.75rem;color:#999}
.ccount.over{color:#d00}

.card-bot{padding:0.8rem 1rem;border-top:1px solid #eee;display:flex;align-items:center;justify-content:space-between;gap:0.8rem}
.peer-info{font-size:0.8rem;color:#555}
.peer-info b{font-weight:600}
.btn-crawl{padding:0.5rem 1.2rem;background:#0044cc;color:#fff;border:none;border-radius:4px;font-weight:600;font-size:0.85rem;cursor:pointer;transition:opacity 0.2s;display:flex;align-items:center;gap:0.4rem}
.btn-crawl:hover{opacity:0.9}
.btn-crawl.busy{opacity:0.5;pointer-events:none}
.btn-crawl svg{width:1rem;height:1rem;stroke:#fff;stroke-width:2.2;fill:none;stroke-linecap:round;stroke-linejoin:round}

#prog-wrap{height:3px;background:#eee;border-radius:3px;overflow:hidden;display:none;margin-top:0.75rem}
#prog-bar{height:100%;width:0%;background:#0044cc;transition:width 0.12s linear}

#status{display:none;margin-top:1rem;padding:0.8rem 1rem;border-radius:4px;font-size:0.88rem;line-height:1.5;animation:fadeUp 0.25s ease}
#status.ok{background:#f0fff0;border:1px solid #c0e0c0;color:#1a8e3f}
#status.fail{background:#fff0f0;border:1px solid #e0c0c0;color:#d00}
#status.info{background:#f0f4ff;border:1px solid #c0d0f0;color:#0044cc}

/* server list */
.json-preview{margin-top:1.5rem;border:1px solid #ddd;border-radius:4px;overflow:hidden}
.json-preview-head{padding:0.5rem 1rem;border-bottom:1px solid #eee;font-size:0.75rem;color:#777;background:#fafafa;display:flex;align-items:center;justify-content:space-between;gap:0.4rem}
.json-preview-head svg{width:0.9rem;height:0.9rem;stroke:#777;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
#server-list{padding:0.75rem 1rem;font-family:"SF Mono","Fira Code","Fira Mono","Roboto Mono",monospace;font-size:0.78rem;line-height:1.7;color:#333;overflow-x:auto;max-height:18rem;overflow-y:auto;margin:0}
.sline{display:flex;align-items:center;gap:0.5rem;padding:0.1rem 0}
.sline .sdot{width:6px;height:6px;border-radius:50%;background:#ccc;flex-shrink:0}
.sline .sdot.src{background:#0044cc}
.sline .sdot.dht{background:#1a8e3f}
.sline .sval{color:#0044cc}
.sline .stag{font-size:0.68rem;color:#aaa;margin-left:auto}

footer{border-top:1px solid #eee;padding-top:1.2rem;margin-top:2rem;display:flex;justify-content:space-between;flex-wrap:wrap;gap:0.5rem;font-size:0.75rem;color:#aaa}

@keyframes fadeUp{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
</style>
</head>
<body>
<div class="page">

  <header>
    <div>
      <h1>DHT <em>Crawler</em></h1>
      <div class="sub">BEP&thinsp;5 node discovery · single-file · PHP 7+</div>
    </div>
  </header>

  <div id="node-bar">
    <div class="nb-pill">
      <span class="nb-dot ok"></span>
      <span>Total servers</span>
      <span class="nb-val" id="cnt-total"><?= $server_count ?></span>
    </div>
    <div class="nb-pill">
      <span class="nb-dot blue"></span>
      <span>servers_dht.txt</span>
      <span class="nb-val" id="cnt-dht"><?= $dht_count ?></span>
    </div>
    <div class="nb-pill">
      <span class="nb-dot" id="status-dot"></span>
      <span id="status-label">idle</span>
    </div>
  </div>

  <!-- Manual add -->
  <div class="card">
    <div class="card-head">
      <div class="c-icon">＋</div>
      <div>
        <div class="c-title">Add server manually</div>
        <div class="c-sub">Format: <code>host:port</code> or <code>[ipv6]:port</code></div>
      </div>
    </div>
    <div class="card-body">
      <label class="fl" for="manual-input">Server address</label>
      <div class="add-row">
        <input type="text" id="manual-input" placeholder="test.com:12345" autocomplete="off" spellcheck="false">
        <button class="btn-add" id="btn-add" onclick="addServer()">Add</button>
      </div>
    </div>
  </div>

  <!-- Crawl card -->
  <div class="card">
    <div class="card-head">
      <div class="c-icon">⛓</div>
      <div>
        <div class="c-title">DHT crawl round</div>
        <div class="c-sub">Probes up to 20 seeds · saves new peers to <code>servers_dht.txt</code></div>
      </div>
    </div>
    <div class="card-body">
      <label class="fl" for="comment-box">Notes (optional)</label>
      <textarea id="comment-box" placeholder="e.g. scheduled crawl, testing new seed list…" oninput="updateCount(this)" maxlength="<?= MAX_COMMENT_LEN ?>"></textarea>
      <div class="cmeta">
        <span></span>
        <span><span class="ccount" id="ccount">0</span> / <?= MAX_COMMENT_LEN ?></span>
      </div>
      <div id="prog-wrap"><div id="prog-bar"></div></div>
    </div>
    <div class="card-bot">
      <div class="peer-info">Seeds loaded: <b id="seed-count"><?= $server_count ?></b></div>
      <button class="btn-crawl" id="btn-crawl" onclick="startCrawl()">
        <svg viewBox="0 0 24 24"><polyline points="5 12 12 5 19 12"/><polyline points="5 19 12 12 19 19"/></svg>
        Start crawl
      </button>
    </div>
  </div>

  <div id="status"></div>

  <!-- Server list -->
  <div class="json-preview">
    <div class="json-preview-head">
      <svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>
      <span>Known servers</span>
      <span style="margin-left:auto;cursor:pointer;color:#0044cc;font-size:0.75rem" onclick="refreshList()">↻ refresh</span>
    </div>
    <div id="server-list">
<?php foreach ($initial_servers as $s): ?>
      <div class="sline">
        <span class="sdot src"></span>
        <span class="sval"><?= htmlspecialchars($s) ?></span>
      </div>
<?php endforeach; ?>
<?php if (empty($initial_servers)): ?>
      <div style="color:#aaa;font-size:0.8rem">No servers loaded yet.</div>
<?php endif; ?>
    </div>
  </div>

  <footer>
    <span>servers.txt + servers_dht.txt · flock() safe · PHP <?= PHP_VERSION ?></span>
    <span>BEP&thinsp;5 DHT — UDP find_node</span>
  </footer>
</div>

<script>
const MAX_COMMENT = <?= MAX_COMMENT_LEN ?>;

function updateCount(el) {
  const n = el.value.length;
  const el2 = document.getElementById('ccount');
  el2.textContent = n;
  el2.classList.toggle('over', n >= MAX_COMMENT);
}

function setStatus(msg, type) {
  const el = document.getElementById('status');
  el.textContent = msg;
  el.className = type;
  el.style.display = 'block';
}

function setDot(state) {
  const d = document.getElementById('status-dot');
  const l = document.getElementById('status-label');
  d.className = 'nb-dot' + (state === 'ok' ? ' ok' : state === 'busy' ? ' blue' : '');
  l.textContent = state;
}

function animateBar(done) {
  const wrap = document.getElementById('prog-wrap');
  const bar  = document.getElementById('prog-bar');
  if (done) { bar.style.width = '100%'; setTimeout(() => { wrap.style.display = 'none'; bar.style.width = '0%'; }, 400); return; }
  wrap.style.display = 'block';
  let w = 0;
  const iv = setInterval(() => {
    w = Math.min(w + Math.random() * 8, 85);
    bar.style.width = w + '%';
    if (w >= 85) clearInterval(iv);
  }, 200);
  return iv;
}

async function post(action, extra) {
  const body = new FormData();
  body.append('action', action);
  Object.entries(extra || {}).forEach(([k, v]) => body.append(k, v));
  const r = await fetch(location.href, { method: 'POST', body });
  return r.json();
}

async function startCrawl() {
  const btn = document.getElementById('btn-crawl');
  btn.classList.add('busy');
  setDot('busy');
  const iv = animateBar(false);
  try {
    const d = await post('crawl');
    animateBar(true);
    if (d.ok) {
      setStatus(`✓ ${d.msg}`, 'ok');
      setDot('ok');
      refreshList();
      refreshCounts(d);
    } else {
      setStatus('✗ ' + d.msg, 'fail');
      setDot('idle');
    }
  } catch(e) {
    animateBar(true);
    setStatus('✗ Network error: ' + e.message, 'fail');
    setDot('idle');
  } finally {
    btn.classList.remove('busy');
  }
}

async function addServer() {
  const inp = document.getElementById('manual-input');
  const val = inp.value.trim();
  if (!val) return;
  const d = await post('add', { server: val });
  setStatus((d.ok ? '✓ ' : '✗ ') + d.msg, d.ok ? 'ok' : 'fail');
  if (d.ok) { inp.value = ''; refreshList(); }
}

async function refreshList() {
  const d = await post('list');
  const el = document.getElementById('server-list');
  if (!d.servers || !d.servers.length) { el.innerHTML = '<div style="color:#aaa;font-size:0.8rem">No servers loaded yet.</div>'; return; }
  el.innerHTML = d.servers.map(s =>
    `<div class="sline"><span class="sdot src"></span><span class="sval">${escHtml(s)}</span></div>`
  ).join('');
  document.getElementById('cnt-total').textContent = d.servers.length;
  document.getElementById('seed-count').textContent = d.servers.length;
}

function refreshCounts(d) {
  if (d.new !== undefined) {
    const cur = parseInt(document.getElementById('cnt-dht').textContent, 10) || 0;
    document.getElementById('cnt-dht').textContent = cur + d.new;
  }
}

function escHtml(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

document.getElementById('manual-input').addEventListener('keydown', e => {
  if (e.key === 'Enter') addServer();
});
</script>
</body>
</html>