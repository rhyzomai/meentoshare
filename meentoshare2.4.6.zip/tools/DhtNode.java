import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.*;
import javax.net.ssl.*;

/**
 * DHT (Distributed Hash Table) Node � Java 8, single file, no external deps.
 *
 * Features:
 *  - Kademlia-inspired XOR-metric routing with k-buckets
 *  - Dual transport: HTTP/HTTPS REST-like API + raw TCP socket
 *  - servers.txt   : persisted known peers (never shrinks automatically)
 *  - active_servers.txt : current online peers (rewritten on every ping cycle)
 *
 * Usage:
 *   java DhtNode [port] [--https] [--bootstrap host:port] [--socket-port port]
 *
 * Interactive commands (stdin):
 *   put <key> <value>
 *   get <key>
 *   peers
 *   active
 *   ping <host:port>
 *   quit
 */
public class DhtNode {

    // ------------------------------------------------------- constants ------
    private static final int    K           = 8;          // k-bucket size
    private static final int    ALPHA       = 3;          // concurrency factor
    private static final int    ID_BITS     = 160;        // SHA-1
    private static final int    PING_PERIOD = 30;         // seconds
    private static final String SERVERS_FILE        = "servers.txt";
    private static final String ACTIVE_SERVERS_FILE = "active_servers.txt";

    // ------------------------------------------------------- node state -----
    private final byte[]   nodeId;
    private final String   nodeIdHex;
    private final int      httpPort;
    private final boolean  useHttps;
    private final int      socketPort;
    private final String   selfAddress;       // "host:httpPort"

    // routing table: bucket[i] holds peers whose XOR distance has MSB at bit i
    private final List<List<PeerInfo>> kBuckets = new ArrayList<>();
    private final Object               bucketsLock = new Object();

    // local storage
    private final ConcurrentHashMap<String, String> store = new ConcurrentHashMap<>();

    // thread pool
    private final ExecutorService pool = Executors.newCachedThreadPool();

    // ------------------------------------------------------------------------
    //  Entry point
    // ------------------------------------------------------------------------
    public static void main(String[] args) throws Exception {
        int     httpPort   = 8080;
        boolean useHttps   = false;
        int     socketPort = 9090;
        String  bootstrap  = null;

        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "--https":       useHttps = true; break;
                case "--bootstrap":   bootstrap = args[++i]; break;
                case "--socket-port": socketPort = Integer.parseInt(args[++i]); break;
                default:
                    try { httpPort = Integer.parseInt(args[i]); }
                    catch (NumberFormatException ignored) {}
            }
        }

        DhtNode node = new DhtNode(httpPort, useHttps, socketPort);
        node.start(bootstrap);
    }

    // ------------------------------------------------------------------------
    //  Constructor
    // ------------------------------------------------------------------------
    public DhtNode(int httpPort, boolean useHttps, int socketPort) throws Exception {
        this.httpPort   = httpPort;
        this.useHttps   = useHttps;
        this.socketPort = socketPort;

        // stable node-id: SHA-1 of "host:port"
        String host = InetAddress.getLocalHost().getHostAddress();
        this.selfAddress = host + ":" + httpPort;
        this.nodeId      = sha1((selfAddress + System.currentTimeMillis()).getBytes());
        this.nodeIdHex   = hex(nodeId);

        for (int i = 0; i < ID_BITS; i++) kBuckets.add(new ArrayList<>());

        log("Node ID : " + nodeIdHex);
        log("Address : " + selfAddress + " (" + (useHttps ? "HTTPS" : "HTTP") + ")");
        log("Socket  : " + host + ":" + socketPort);
    }

    // ------------------------------------------------------------------------
    //  Start
    // ------------------------------------------------------------------------
    private void start(String bootstrap) throws Exception {
        // load previously known servers
        loadKnownServers();

        // start HTTP(S) server
        pool.submit(this::runHttpServer);

        // start raw socket server
        pool.submit(this::runSocketServer);

        // periodic ping / active list refresh
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(this::pingAllAndRefreshActive,
                5, PING_PERIOD, TimeUnit.SECONDS);

        // bootstrap: contact a known peer
        if (bootstrap != null) {
            PeerInfo seed = parsePeer(bootstrap);
            if (seed != null) {
                addPeer(seed);
                saveKnownServers();
                nodeLookup(nodeId); // populate routing table
            }
        } else if (!getAllPeers().isEmpty()) {
            pool.submit(() -> nodeLookup(nodeId));
        }

        // interactive REPL
        runRepl();

        scheduler.shutdown();
        pool.shutdown();
    }

    // ------------------------------------------------------------------------
    //  HTTP / HTTPS server  (tiny hand-rolled HTTP/1.1)
    // ------------------------------------------------------------------------
    private void runHttpServer() {
        try {
            ServerSocket ss = useHttps ? makeHttpsServerSocket(httpPort)
                                       : new ServerSocket(httpPort);
            log("HTTP" + (useHttps ? "S" : "") + " server listening on port " + httpPort);
            while (!Thread.currentThread().isInterrupted()) {
                Socket client = ss.accept();
                pool.submit(() -> handleHttpClient(client));
            }
        } catch (Exception e) {
            log("HTTP server error: " + e.getMessage());
        }
    }

    private void handleHttpClient(Socket socket) {
        try (socket;
             BufferedReader in  = new BufferedReader(
                     new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
             OutputStream   out = socket.getOutputStream()) {

            // parse request line
            String requestLine = in.readLine();
            if (requestLine == null || requestLine.isEmpty()) return;

            String[] parts = requestLine.split(" ");
            if (parts.length < 2) return;
            String method = parts[0];
            String path   = parts[1];

            // read headers
            Map<String, String> headers = new LinkedHashMap<>();
            String line;
            while ((line = in.readLine()) != null && !line.isEmpty()) {
                int colon = line.indexOf(':');
                if (colon > 0)
                    headers.put(line.substring(0, colon).trim().toLowerCase(),
                                line.substring(colon + 1).trim());
            }

            // read body if present
            String body = "";
            if (headers.containsKey("content-length")) {
                int len = Integer.parseInt(headers.get("content-length"));
                char[] buf = new char[len];
                in.read(buf, 0, len);
                body = new String(buf);
            }

            // route
            String response = route(method, path, body, socket.getInetAddress().getHostAddress());
            sendHttpResponse(out, 200, "OK", response);

        } catch (Exception e) {
            // silently close
        }
    }

    private String route(String method, String path, String body, String remoteHost) {
        // GET /ping  ? returns node info
        if ("GET".equals(method) && "/ping".equals(path)) {
            return json("id", nodeIdHex, "address", selfAddress,
                        "peers", String.valueOf(getAllPeers().size()));
        }

        // GET /peers ? returns known peers
        if ("GET".equals(method) && "/peers".equals(path)) {
            List<PeerInfo> all = getAllPeers();
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < all.size(); i++) {
                if (i > 0) sb.append(",");
                PeerInfo p = all.get(i);
                sb.append("{\"id\":\"").append(p.idHex)
                  .append("\",\"address\":\"").append(p.address).append("\"}");
            }
            sb.append("]");
            return sb.toString();
        }

        // GET /get?key=<k>
        if ("GET".equals(method) && path.startsWith("/get")) {
            String key = queryParam(path, "key");
            if (key == null) return json("error", "missing key");
            String val = store.get(key);
            if (val != null) return json("key", key, "value", val, "found", "true");
            // try remote lookup
            String found = remoteLookupValue(key);
            if (found != null) return json("key", key, "value", found, "found", "true");
            return json("key", key, "found", "false");
        }

        // POST /put  body: key=<k>&value=<v>  OR JSON {"key":"..","value":".."}
        if ("POST".equals(method) && "/put".equals(path)) {
            String key = null, value = null;
            if (body.startsWith("{")) {
                key   = jsonField(body, "key");
                value = jsonField(body, "value");
            } else {
                Map<String, String> kv = parseFormBody(body);
                key   = kv.get("key");
                value = kv.get("value");
            }
            if (key == null || value == null) return json("error", "missing key or value");
            store.put(key, value);
            distributeStore(key, value);
            return json("status", "ok", "key", key);
        }

        // POST /store  ? remote store request
        if ("POST".equals(method) && "/store".equals(path)) {
            String key = null, value = null;
            if (body.startsWith("{")) {
                key   = jsonField(body, "key");
                value = jsonField(body, "value");
            } else {
                Map<String, String> kv = parseFormBody(body);
                key   = kv.get("key");
                value = kv.get("value");
            }
            if (key != null && value != null) store.put(key, value);
            return json("status", "ok");
        }

        // POST /findnode  body: {"targetId":"<hex>"}
        if ("POST".equals(method) && "/findnode".equals(path)) {
            String targetHex = jsonField(body, "targetId");
            if (targetHex == null) return json("error", "missing targetId");
            byte[] target = fromHex(targetHex);
            List<PeerInfo> closest = closestPeers(target, K);
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < closest.size(); i++) {
                if (i > 0) sb.append(",");
                PeerInfo p = closest.get(i);
                sb.append("{\"id\":\"").append(p.idHex)
                  .append("\",\"address\":\"").append(p.address).append("\"}");
            }
            sb.append("]");
            return sb.toString();
        }

        // POST /findvalue  body: {"key":"<k>"}
        if ("POST".equals(method) && "/findvalue".equals(path)) {
            String key = jsonField(body, "key");
            if (key == null) return json("error", "missing key");
            String val = store.get(key);
            if (val != null) return json("found", "true", "value", val);
            // return closest peers instead
            byte[] target = sha1(key.getBytes(StandardCharsets.UTF_8));
            List<PeerInfo> closest = closestPeers(target, K);
            StringBuilder sb = new StringBuilder("{\"found\":false,\"peers\":[");
            for (int i = 0; i < closest.size(); i++) {
                if (i > 0) sb.append(",");
                PeerInfo p = closest.get(i);
                sb.append("{\"id\":\"").append(p.idHex)
                  .append("\",\"address\":\"").append(p.address).append("\"}");
            }
            sb.append("]}");
            return sb.toString();
        }

        // POST /announce  body: {"id":"<hex>","address":"<host:port>"}
        if ("POST".equals(method) && "/announce".equals(path)) {
            String id   = jsonField(body, "id");
            String addr = jsonField(body, "address");
            if (id != null && addr != null) {
                PeerInfo p = new PeerInfo(id, addr);
                addPeer(p);
                pool.submit(() -> { saveKnownServers(); });
            }
            return json("status", "ok");
        }

        return json("error", "unknown endpoint");
    }

    private void sendHttpResponse(OutputStream out, int status, String statusText,
                                  String body) throws IOException {
        byte[] bodyBytes = body.getBytes(StandardCharsets.UTF_8);
        String header = "HTTP/1.1 " + status + " " + statusText + "\r\n"
                + "Content-Type: application/json; charset=utf-8\r\n"
                + "Content-Length: " + bodyBytes.length + "\r\n"
                + "Connection: close\r\n\r\n";
        out.write(header.getBytes(StandardCharsets.UTF_8));
        out.write(bodyBytes);
        out.flush();
    }

    // ------------------------------------------------------------------------
    //  Raw TCP socket server
    // ------------------------------------------------------------------------
    private void runSocketServer() {
        try (ServerSocket ss = new ServerSocket(socketPort)) {
            log("Socket server listening on port " + socketPort);
            while (!Thread.currentThread().isInterrupted()) {
                Socket client = ss.accept();
                pool.submit(() -> handleSocketClient(client));
            }
        } catch (Exception e) {
            log("Socket server error: " + e.getMessage());
        }
    }

    /**
     * Simple text protocol over socket:
     *   Request line: COMMAND [args...]\n
     *   Response: JSON\n
     *
     * Commands: PING, PEERS, FINDNODE <id>, FINDVALUE <key>, STORE <key> <value>, ANNOUNCE <id> <addr>
     */
    private void handleSocketClient(Socket socket) {
        try (socket;
             BufferedReader in  = new BufferedReader(
                     new InputStreamReader(socket.getInputStream(),  StandardCharsets.UTF_8));
             PrintWriter    out = new PrintWriter(
                     new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true)) {

            String line = in.readLine();
            if (line == null || line.isEmpty()) return;

            String[] tokens = line.trim().split(" ", 3);
            String cmd = tokens[0].toUpperCase();
            String response;

            switch (cmd) {
                case "PING":
                    response = json("id", nodeIdHex, "address", selfAddress);
                    break;
                case "PEERS":
                    List<PeerInfo> peers = getAllPeers();
                    StringBuilder sb = new StringBuilder("[");
                    for (int i = 0; i < peers.size(); i++) {
                        if (i > 0) sb.append(",");
                        sb.append("{\"id\":\"").append(peers.get(i).idHex)
                          .append("\",\"address\":\"").append(peers.get(i).address).append("\"}");
                    }
                    sb.append("]");
                    response = sb.toString();
                    break;
                case "FINDNODE":
                    if (tokens.length < 2) { response = json("error", "missing id"); break; }
                    byte[] target = fromHex(tokens[1]);
                    List<PeerInfo> closest = closestPeers(target, K);
                    StringBuilder sb2 = new StringBuilder("[");
                    for (int i = 0; i < closest.size(); i++) {
                        if (i > 0) sb2.append(",");
                        sb2.append("{\"id\":\"").append(closest.get(i).idHex)
                           .append("\",\"address\":\"").append(closest.get(i).address).append("\"}");
                    }
                    sb2.append("]");
                    response = sb2.toString();
                    break;
                case "FINDVALUE":
                    if (tokens.length < 2) { response = json("error", "missing key"); break; }
                    String val = store.get(tokens[1]);
                    response = val != null
                            ? json("found", "true", "value", val)
                            : json("found", "false");
                    break;
                case "STORE":
                    if (tokens.length < 3) { response = json("error", "missing key/value"); break; }
                    store.put(tokens[1], tokens[2]);
                    response = json("status", "ok");
                    break;
                case "ANNOUNCE":
                    if (tokens.length < 3) { response = json("error", "missing id/addr"); break; }
                    addPeer(new PeerInfo(tokens[1], tokens[2]));
                    pool.submit(() -> saveKnownServers());
                    response = json("status", "ok");
                    break;
                default:
                    response = json("error", "unknown command: " + cmd);
            }

            out.println(response);

        } catch (Exception e) {
            // silently close
        }
    }

    // ------------------------------------------------------------------------
    //  REPL
    // ------------------------------------------------------------------------
    private void runRepl() {
        Scanner scanner = new Scanner(System.in, "UTF-8");
        System.out.println("\n+--------------------------------------+");
        System.out.println("�         DHT Node Interactive CLI      �");
        System.out.println("+--------------------------------------+");
        System.out.println("Commands: put <key> <value> | get <key> | peers | active | ping <host:port> | quit\n");

        while (scanner.hasNextLine()) {
            System.out.print("dht> ");
            System.out.flush();
            String input = scanner.nextLine().trim();
            if (input.isEmpty()) continue;

            String[] parts = input.split(" ", 3);
            String cmd = parts[0].toLowerCase();

            switch (cmd) {
                case "put":
                    if (parts.length < 3) { System.out.println("Usage: put <key> <value>"); break; }
                    store.put(parts[1], parts[2]);
                    distributeStore(parts[1], parts[2]);
                    System.out.println("Stored: " + parts[1] + " = " + parts[2]);
                    break;

                case "get":
                    if (parts.length < 2) { System.out.println("Usage: get <key>"); break; }
                    String val = store.get(parts[1]);
                    if (val != null) {
                        System.out.println("Local  ? " + parts[1] + " = " + val);
                    } else {
                        System.out.println("Searching network...");
                        String found = remoteLookupValue(parts[1]);
                        System.out.println(found != null
                                ? "Remote ? " + parts[1] + " = " + found
                                : "Not found: " + parts[1]);
                    }
                    break;

                case "peers":
                    List<PeerInfo> all = getAllPeers();
                    System.out.println("Known peers (" + all.size() + "):");
                    all.forEach(p -> System.out.println("  " + p.address + " [" + p.idHex.substring(0, 8) + "...]"));
                    break;

                case "active":
                    List<String> active = readActiveServers();
                    System.out.println("Active servers (" + active.size() + "):");
                    active.forEach(a -> System.out.println("  " + a));
                    break;

                case "ping":
                    if (parts.length < 2) { System.out.println("Usage: ping <host:port>"); break; }
                    PeerInfo p = parsePeer(parts[1]);
                    if (p == null) { System.out.println("Could not resolve: " + parts[1]); break; }
                    boolean alive = pingPeer(p);
                    System.out.println(parts[1] + " is " + (alive ? "ONLINE" : "OFFLINE"));
                    if (alive) {
                        addPeer(p);
                        saveKnownServers();
                    }
                    break;

                case "quit":
                case "exit":
                    System.out.println("Goodbye.");
                    return;

                default:
                    System.out.println("Unknown command: " + cmd);
            }
        }
    }

    // ------------------------------------------------------------------------
    //  DHT routing
    // ------------------------------------------------------------------------
    private void addPeer(PeerInfo peer) {
        if (peer.address.equals(selfAddress)) return;
        byte[] dist = xor(nodeId, peer.id);
        int bucket = bucketIndex(dist);
        synchronized (bucketsLock) {
            List<PeerInfo> b = kBuckets.get(bucket);
            // remove if already present (refresh)
            b.removeIf(pp -> pp.address.equals(peer.address));
            if (b.size() < K) {
                b.add(peer);
            } else {
                // evict least-recently-seen (head) � simplified
                b.remove(0);
                b.add(peer);
            }
        }
    }

    private List<PeerInfo> getAllPeers() {
        synchronized (bucketsLock) {
            return kBuckets.stream()
                    .flatMap(Collection::stream)
                    .collect(Collectors.toList());
        }
    }

    private List<PeerInfo> closestPeers(byte[] target, int count) {
        List<PeerInfo> all = getAllPeers();
        all.sort(Comparator.comparing(p -> new BigInt(xor(p.id, target))));
        return all.subList(0, Math.min(count, all.size()));
    }

    /** Kademlia node lookup � iterative */
    private List<PeerInfo> nodeLookup(byte[] target) {
        Set<String> queried  = new HashSet<>();
        List<PeerInfo> closest = closestPeers(target, ALPHA);
        if (closest.isEmpty()) return closest;

        boolean changed = true;
        while (changed) {
            changed = false;
            List<PeerInfo> toQuery = new ArrayList<>();
            for (PeerInfo p : closest) {
                if (!queried.contains(p.address)) {
                    toQuery.add(p);
                    if (toQuery.size() >= ALPHA) break;
                }
            }
            if (toQuery.isEmpty()) break;

            for (PeerInfo p : toQuery) {
                queried.add(p.address);
                List<PeerInfo> returned = remoteFind(p, target);
                for (PeerInfo rp : returned) {
                    addPeer(rp);
                }
                pool.submit(this::saveKnownServers);
            }

            List<PeerInfo> newClosest = closestPeers(target, K);
            if (!newClosest.equals(closest)) { closest = newClosest; changed = true; }
        }
        return closest;
    }

    // ------------------------------------------------------------------------
    //  Remote calls (HTTP)
    // ------------------------------------------------------------------------
    private boolean pingPeer(PeerInfo peer) {
        try {
            String resp = httpGet(peer.address, "/ping");
            return resp != null && resp.contains("id");
        } catch (Exception e) {
            return false;
        }
    }

    private List<PeerInfo> remoteFind(PeerInfo peer, byte[] target) {
        try {
            String body = "{\"targetId\":\"" + hex(target) + "\"}";
            String resp = httpPost(peer.address, "/findnode", body);
            return parsePeerArray(resp);
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

    private String remoteLookupValue(String key) {
        byte[] target = sha1(key.getBytes(StandardCharsets.UTF_8));
        List<PeerInfo> candidates = closestPeers(target, K);
        Set<String> queried = new HashSet<>();
        for (PeerInfo p : candidates) {
            if (queried.contains(p.address)) continue;
            queried.add(p.address);
            try {
                String body = "{\"key\":\"" + escJson(key) + "\"}";
                String resp = httpPost(p.address, "/findvalue", body);
                if (resp != null && resp.contains("\"found\":true")) {
                    String val = jsonField(resp, "value");
                    if (val != null) { store.put(key, val); return val; }
                }
            } catch (Exception ignored) {}
        }
        return null;
    }

    private void distributeStore(String key, String value) {
        byte[] target = sha1(key.getBytes(StandardCharsets.UTF_8));
        List<PeerInfo> targets = closestPeers(target, K);
        String body = "{\"key\":\"" + escJson(key) + "\",\"value\":\"" + escJson(value) + "\"}";
        for (PeerInfo p : targets) {
            final String b = body;
            pool.submit(() -> {
                try { httpPost(p.address, "/store", b); } catch (Exception ignored) {}
            });
        }
    }

    // ------------------------------------------------------------------------
    //  Periodic ping & active_servers.txt refresh
    // ------------------------------------------------------------------------
    private void pingAllAndRefreshActive() {
        List<PeerInfo> all = getAllPeers();
        List<String> online = new CopyOnWriteArrayList<>();

        List<Future<?>> futures = new ArrayList<>();
        for (PeerInfo peer : all) {
            futures.add(pool.submit(() -> {
                if (pingPeer(peer)) online.add(peer.address);
            }));
        }
        for (Future<?> f : futures) {
            try { f.get(5, TimeUnit.SECONDS); } catch (Exception ignored) {}
        }

        // also announce ourselves to online peers
        for (PeerInfo peer : all) {
            pool.submit(() -> {
                try {
                    String body = "{\"id\":\"" + nodeIdHex + "\",\"address\":\"" + selfAddress + "\"}";
                    httpPost(peer.address, "/announce", body);
                } catch (Exception ignored) {}
            });
        }

        writeActiveServers(online);
        log("Ping cycle complete. Active: " + online.size() + "/" + all.size());
    }

    // ------------------------------------------------------------------------
    //  File I/O
    // ------------------------------------------------------------------------
    private synchronized void saveKnownServers() {
        try {
            Set<String> existing = new LinkedHashSet<>();
            Path p = Paths.get(SERVERS_FILE);
            if (Files.exists(p)) {
                Files.readAllLines(p, StandardCharsets.UTF_8)
                     .stream()
                     .map(String::trim)
                     .filter(s -> !s.isEmpty())
                     .forEach(existing::add);
            }
            for (PeerInfo peer : getAllPeers()) existing.add(peer.address);

            Files.write(p, new ArrayList<>(existing), StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (Exception e) {
            log("Error saving servers.txt: " + e.getMessage());
        }
    }

    private void loadKnownServers() {
        Path p = Paths.get(SERVERS_FILE);
        if (!Files.exists(p)) return;
        try {
            List<String> lines = Files.readAllLines(p, StandardCharsets.UTF_8);
            for (String line : lines) {
                String addr = line.trim();
                if (addr.isEmpty() || addr.equals(selfAddress)) continue;
                PeerInfo peer = parsePeer(addr);
                if (peer != null) addPeer(peer);
            }
            log("Loaded " + getAllPeers().size() + " peers from " + SERVERS_FILE);
        } catch (Exception e) {
            log("Error loading servers.txt: " + e.getMessage());
        }
    }

    /** Overwrites active_servers.txt with the current online list (no duplicates). */
    private synchronized void writeActiveServers(List<String> online) {
        try {
            List<String> unique = online.stream()
                    .distinct()
                    .sorted()
                    .collect(Collectors.toList());
            Files.write(Paths.get(ACTIVE_SERVERS_FILE), unique, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (Exception e) {
            log("Error writing active_servers.txt: " + e.getMessage());
        }
    }

    private List<String> readActiveServers() {
        Path p = Paths.get(ACTIVE_SERVERS_FILE);
        if (!Files.exists(p)) return Collections.emptyList();
        try {
            return Files.readAllLines(p, StandardCharsets.UTF_8).stream()
                    .map(String::trim).filter(s -> !s.isEmpty())
                    .collect(Collectors.toList());
        } catch (Exception e) { return Collections.emptyList(); }
    }

    // ------------------------------------------------------------------------
    //  HTTP client (supports http:// and https://)
    // ------------------------------------------------------------------------
    private String httpGet(String address, String path) throws Exception {
        URL url = new URL((useHttps ? "https" : "http") + "://" + address + path);
        HttpURLConnection conn = openConnection(url);
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(3000);
        conn.setReadTimeout(3000);
        return readResponse(conn);
    }

    private String httpPost(String address, String path, String body) throws Exception {
        URL url = new URL((useHttps ? "https" : "http") + "://" + address + path);
        HttpURLConnection conn = openConnection(url);
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        conn.setConnectTimeout(3000);
        conn.setReadTimeout(3000);
        byte[] out = body.getBytes(StandardCharsets.UTF_8);
        conn.setRequestProperty("Content-Length", String.valueOf(out.length));
        conn.getOutputStream().write(out);
        return readResponse(conn);
    }

    private HttpURLConnection openConnection(URL url) throws Exception {
        if (useHttps) {
            HttpsURLConnection c = (HttpsURLConnection) url.openConnection();
            c.setSSLSocketFactory(trustAllSslContext().getSocketFactory());
            c.setHostnameVerifier((h, s) -> true);
            return c;
        }
        return (HttpURLConnection) url.openConnection();
    }

    private String readResponse(HttpURLConnection conn) throws Exception {
        InputStream is = conn.getResponseCode() >= 400
                ? conn.getErrorStream() : conn.getInputStream();
        if (is == null) return "";
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(is, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            return sb.toString();
        }
    }

    // ------------------------------------------------------------------------
    //  SSL helpers  (self-signed / trust-all for demo)
    // ------------------------------------------------------------------------
    private ServerSocket makeHttpsServerSocket(int port) throws Exception {
        // generate ephemeral self-signed key in memory via JSSE
        SSLContext ctx = trustAllSslContext();
        SSLServerSocketFactory ssf = ctx.getServerSocketFactory();
        return ssf.createServerSocket(port);
    }

    private SSLContext trustAllSslContext() throws Exception {
        TrustManager[] tm = new TrustManager[]{
            new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers() { return new java.security.cert.X509Certificate[0]; }
                public void checkClientTrusted(java.security.cert.X509Certificate[] c, String a) {}
                public void checkServerTrusted(java.security.cert.X509Certificate[] c, String a) {}
            }
        };
        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(null, tm, new SecureRandom());
        return ctx;
    }

    // ------------------------------------------------------------------------
    //  Peer info
    // ------------------------------------------------------------------------
    static class PeerInfo {
        final String idHex;
        final byte[] id;
        final String address;

        PeerInfo(String idHex, String address) {
            this.idHex   = idHex;
            this.id      = fromHex(idHex);
            this.address = address;
        }

        static PeerInfo fromAddress(String address) {
            byte[] id = sha1(address.getBytes(StandardCharsets.UTF_8));
            return new PeerInfo(hex(id), address);
        }
    }

    private PeerInfo parsePeer(String address) {
        try {
            // try HTTP ping first
            URL url = new URL((useHttps ? "https" : "http") + "://" + address + "/ping");
            HttpURLConnection conn = openConnection(url);
            conn.setConnectTimeout(3000);
            conn.setReadTimeout(3000);
            String resp = readResponse(conn);
            String id = jsonField(resp, "id");
            if (id != null) return new PeerInfo(id, address);
        } catch (Exception ignored) {}
        // fallback: derive id from address
        return PeerInfo.fromAddress(address);
    }

    private List<PeerInfo> parsePeerArray(String json) {
        List<PeerInfo> result = new ArrayList<>();
        if (json == null || json.isEmpty()) return result;
        // naive JSON array parser � no external deps
        int i = 0;
        while (i < json.length()) {
            int idStart = json.indexOf("\"id\":\"", i);
            if (idStart < 0) break;
            idStart += 6;
            int idEnd = json.indexOf("\"", idStart);
            int addrStart = json.indexOf("\"address\":\"", i);
            if (addrStart < 0) break;
            addrStart += 11;
            int addrEnd = json.indexOf("\"", addrStart);
            if (idEnd < 0 || addrEnd < 0) break;
            String id   = json.substring(idStart, idEnd);
            String addr = json.substring(addrStart, addrEnd);
            if (!addr.equals(selfAddress)) result.add(new PeerInfo(id, addr));
            i = addrEnd + 1;
        }
        return result;
    }

    // ------------------------------------------------------------------------
    //  Crypto & XOR utilities
    // ------------------------------------------------------------------------
    private static byte[] sha1(byte[] data) {
        try {
            return MessageDigest.getInstance("SHA-1").digest(data);
        } catch (NoSuchAlgorithmException e) { throw new RuntimeException(e); }
    }

    private static byte[] xor(byte[] a, byte[] b) {
        int len = Math.min(a.length, b.length);
        byte[] r = new byte[len];
        for (int i = 0; i < len; i++) r[i] = (byte) (a[i] ^ b[i]);
        return r;
    }

    private static int bucketIndex(byte[] dist) {
        for (int i = 0; i < dist.length; i++)
            for (int bit = 7; bit >= 0; bit--)
                if (((dist[i] >> bit) & 1) == 1)
                    return i * 8 + (7 - bit);
        return ID_BITS - 1;
    }

    private static String hex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    private static byte[] fromHex(String hex) {
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2)
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                                 + Character.digit(hex.charAt(i + 1), 16));
        return data;
    }

    /** Comparable wrapper for byte[] XOR distance */
    private static class BigInt implements Comparable<BigInt> {
        final byte[] val;
        BigInt(byte[] val) { this.val = val; }
        public int compareTo(BigInt o) {
            for (int i = 0; i < Math.min(val.length, o.val.length); i++) {
                int a = val[i] & 0xFF, b = o.val[i] & 0xFF;
                if (a != b) return Integer.compare(a, b);
            }
            return Integer.compare(val.length, o.val.length);
        }
    }

    // ------------------------------------------------------------------------
    //  Tiny JSON / HTTP utilities
    // ------------------------------------------------------------------------
    private static String json(String... kv) {
        StringBuilder sb = new StringBuilder("{");
        for (int i = 0; i < kv.length; i += 2) {
            if (i > 0) sb.append(",");
            sb.append("\"").append(kv[i]).append("\":\"").append(escJson(kv[i + 1])).append("\"");
        }
        sb.append("}");
        return sb.toString();
    }

    private static String escJson(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r");
    }

    /** Very minimal field extractor � handles "key":"value" (no nesting needed) */
    private static String jsonField(String json, String field) {
        if (json == null) return null;
        String marker = "\"" + field + "\":\"";
        int start = json.indexOf(marker);
        if (start < 0) return null;
        start += marker.length();
        int end = start;
        while (end < json.length()) {
            if (json.charAt(end) == '"' && json.charAt(end - 1) != '\\') break;
            end++;
        }
        return json.substring(start, end).replace("\\\"", "\"").replace("\\n", "\n");
    }

    private static String queryParam(String path, String name) {
        int q = path.indexOf('?');
        if (q < 0) return null;
        String query = path.substring(q + 1);
        for (String pair : query.split("&")) {
            String[] kv = pair.split("=", 2);
            if (kv.length == 2 && kv[0].equals(name)) {
                try { return URLDecoder.decode(kv[1], "UTF-8"); }
                catch (UnsupportedEncodingException e) { return kv[1]; }
            }
        }
        return null;
    }

    private static Map<String, String> parseFormBody(String body) {
        Map<String, String> map = new LinkedHashMap<>();
        if (body == null || body.isEmpty()) return map;
        for (String pair : body.split("&")) {
            String[] kv = pair.split("=", 2);
            if (kv.length == 2) {
                try {
                    map.put(URLDecoder.decode(kv[0], "UTF-8"),
                            URLDecoder.decode(kv[1], "UTF-8"));
                } catch (UnsupportedEncodingException e) {
                    map.put(kv[0], kv[1]);
                }
            }
        }
        return map;
    }

    // ------------------------------------------------------------------------
    //  Logging
    // ------------------------------------------------------------------------
    private static final SimpleDateFormat SDF = new SimpleDateFormat("HH:mm:ss");
    private static synchronized void log(String msg) {
        System.out.println("[" + SDF.format(new Date()) + "] " + msg);
    }
}