﻿<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  BOARD — Social messaging board over MySQL
//  Entry point. Include or require the modules you need:
//
//    require_once 'config.php';     // DB credentials (REQUIRED first)
//    require_once 'auth.php';       // Register / login / logout
//    require_once 'messages.php';   // Post messages, file uploads, groups
//    require_once 'comments.php';   // Threaded comments with rate-limit
//    require_once 'likes.php';      // SHA-256 like system
//    require_once 'board.php';      // HTML front-end (requires all above)
//
//  You may also use each file standalone for API/CLI work.
// ═══════════════════════════════════════════════════════════════════════════════

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/messages.php';
require_once __DIR__ . '/comments.php';
require_once __DIR__ . '/likes.php';
require_once __DIR__ . '/board.php';