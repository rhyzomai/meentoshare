﻿<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  board.php — HTML front-end
//  Requires: config.php, auth.php, messages.php, comments.php, likes.php
// ═══════════════════════════════════════════════════════════════════════════════

if (!defined('DB_HOST')) {
    require_once __DIR__ . '/config.php';
    require_once __DIR__ . '/auth.php';
    require_once __DIR__ . '/messages.php';
    require_once __DIR__ . '/comments.php';
    require_once __DIR__ . '/likes.php';
}

// ── Dispatch POST actions before any output ───────────────────────────────────
handleAuthPost();
handleMessagePost();
handleCommentPost();
handleLikePost();   // exits with JSON if triggered

// ── Routing ───────────────────────────────────────────────────────────────────
$view  = $_GET['view'] ?? 'board';
$user  = currentUser();
$flash = flashGet();

// ── Helpers for the view layer ────────────────────────────────────────────────

function renderFlash(?array $flash): void {
    if (!$flash) return;
    $cls = $flash['type'] === 'ok' ? 'flash-ok' : 'flash-err';
    echo '<div class="flash ' . $cls . '">' . h($flash['msg']) . '</div>';
}

function renderPager(int $pages, int $current, array $extraParams = []): void {
    if ($pages <= 1) return;
    echo '<nav class="pager">';
    for ($p = 1; $p <= $pages; $p++) {
        $url = selfUrl(array_merge($extraParams, ['page' => $p]));
        $cls = $p === $current ? ' class="active"' : '';
        echo '<a href="' . h($url) . '"' . $cls . '>' . $p . '</a>';
    }
    echo '</nav>';
}

function renderMessage(array $msg, bool $linked = true, bool $currentUserLiked = false): void {
    $author = $msg['is_anonymous'] ? '<em>Anonymous</em>' : h($msg['username'] ?? '—');
    $date   = date('d M Y H:i', strtotime($msg['created_at']));
    $likes  = (int) ($msg['like_count'] ?? 0);
    $cmts   = (int) ($msg['comment_count'] ?? 0);

    $msgUrl = selfUrl(['view' => 'message', 'mid' => $msg['id'],
                       'gid'  => $_GET['gid'] ?? 0]);
    echo '<article class="msg" id="msg-' . $msg['id'] . '">';
    echo '<header class="msg-head"><span class="msg-author">' . $author . '</span>'
       . '<span class="msg-date">' . h($date) . '</span></header>';

    // File attachment
    if ($msg['file_path']) {
        $webPath = h(UPLOAD_WEB_PATH . $msg['file_path']);
        if (isImageMime($msg['file_mime'] ?? '')) {
            echo '<div class="msg-img"><img src="' . $webPath . '" alt="' . h($msg['file_name']) . '" loading="lazy"></div>';
        } else {
            echo '<div class="msg-file"><a href="' . $webPath . '" target="_blank" rel="noopener">📎 '
               . h($msg['file_name']) . '</a></div>';
        }
    }

    if ($msg['body'] !== '') {
        echo '<div class="msg-body">' . nl2br(h($msg['body'])) . '</div>';
    }

    echo '<footer class="msg-foot">';

    // Like button (AJAX)
    $likedCls = $currentUserLiked ? ' liked' : '';
    echo '<button class="btn-like' . $likedCls . '" data-mid="' . $msg['id'] . '" title="Like">'
       . '♥ <span class="like-count">' . $likes . '</span></button>';

    if ($linked) {
        echo '<a class="btn-cmt" href="' . h($msgUrl) . '#comments">💬 ' . $cmts . ' comment' . ($cmts !== 1 ? 's' : '') . '</a>';
    }

    echo '</footer></article>';
}

function renderCommentNode(array $c, int $messageId, int $groupId, int $depth = 0): void {
    $indent = min($depth, 3) * 1.5;
    echo '<div class="comment" id="comment-' . $c['id'] . '" style="margin-left:' . $indent . 'rem">';
    echo '<div class="cmt-head"><b>' . h($c['username']) . '</b> '
       . '<span class="cmt-date">' . date('d M Y H:i', strtotime($c['created_at'])) . '</span></div>';
    echo '<div class="cmt-body">' . nl2br(h($c['body'])) . '</div>';

    if (currentUser()) {
        echo '<a class="reply-link" href="#" data-parent="' . $c['id']
           . '" data-mid="' . $messageId . '" data-gid="' . $groupId . '">↩ Reply</a>';
    }

    foreach ($c['replies'] as $reply) {
        renderCommentNode($reply, $messageId, $groupId, $depth + 1);
    }

    echo '</div>';
}

// ─────────────────────────────────────────────────────────────────────────────
//  HTML OUTPUT
// ─────────────────────────────────────────────────────────────────────────────
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Board</title>
<style>
/* ── Reset & base ─────────────────────────────────────────────── */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{font-size:16px}
body{font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;background:#f4f6f9;color:#1a1a2e;min-height:100vh;display:flex;flex-direction:column}

/* ── Layout ───────────────────────────────────────────────────── */
.wrap{max-width:860px;margin:0 auto;width:100%;padding:0 1rem}
.layout{display:flex;gap:1.5rem;padding:1.5rem 0;align-items:flex-start}
.sidebar{width:220px;flex-shrink:0}
.main{flex:1;min-width:0}

/* ── Topbar ───────────────────────────────────────────────────── */
.topbar{background:#1a1a2e;color:#fff;padding:.75rem 0}
.topbar .wrap{display:flex;align-items:center;justify-content:space-between;gap:1rem;flex-wrap:wrap}
.topbar h1{font-size:1.25rem;font-weight:700;letter-spacing:-.02em}
.topbar h1 span{color:#7c83ff}
.topbar-right{display:flex;align-items:center;gap:.75rem;flex-wrap:wrap}
.topbar-user{font-size:.85rem;opacity:.8}
.btn,.btn-sm{display:inline-flex;align-items:center;gap:.3rem;padding:.45rem 1rem;border-radius:6px;font-size:.85rem;font-weight:600;cursor:pointer;border:none;text-decoration:none;transition:opacity .15s}
.btn-sm{padding:.3rem .7rem;font-size:.8rem}
.btn-pri{background:#7c83ff;color:#fff}
.btn-pri:hover{opacity:.88}
.btn-sec{background:#e9ecef;color:#333}
.btn-sec:hover{background:#dee2e6}
.btn-ghost{background:transparent;border:1px solid rgba(255,255,255,.35);color:#fff}
.btn-ghost:hover{background:rgba(255,255,255,.1)}

/* ── Flash ─────────────────────────────────────────────────────── */
.flash{padding:.7rem 1rem;border-radius:6px;margin-bottom:1rem;font-size:.9rem}
.flash-ok{background:#d1fae5;color:#065f46;border:1px solid #6ee7b7}
.flash-err{background:#fee2e2;color:#991b1b;border:1px solid #fca5a5}

/* ── Cards / panels ───────────────────────────────────────────── */
.card{background:#fff;border-radius:10px;box-shadow:0 1px 4px rgba(0,0,0,.07);padding:1.25rem;margin-bottom:1rem}
.card h2{font-size:1rem;font-weight:700;margin-bottom:1rem;color:#1a1a2e}
.card h3{font-size:.9rem;font-weight:600;margin-bottom:.75rem}

/* ── Forms ─────────────────────────────────────────────────────── */
.form-group{margin-bottom:.9rem}
label{display:block;font-size:.8rem;font-weight:600;color:#555;margin-bottom:.3rem}
input[type=text],input[type=password],textarea,select{width:100%;padding:.5rem .75rem;border:1px solid #ced4da;border-radius:6px;font-size:.9rem;font-family:inherit;transition:border-color .2s;background:#fff}
input:focus,textarea:focus,select:focus{outline:none;border-color:#7c83ff;box-shadow:0 0 0 3px rgba(124,131,255,.15)}
textarea{min-height:4rem;resize:vertical}
.form-hint{font-size:.75rem;color:#888;margin-top:.25rem}
.form-row{display:flex;gap:.75rem;flex-wrap:wrap}
.form-row>*{flex:1;min-width:140px}
.check-row{display:flex;align-items:center;gap:.5rem;font-size:.875rem}
.check-row input{width:auto}
.form-file label{display:flex;align-items:center;gap:.4rem;cursor:pointer;padding:.45rem .85rem;border:1px dashed #adb5bd;border-radius:6px;font-size:.8rem;color:#666;background:#fafafa;transition:border-color .2s}
.form-file label:hover{border-color:#7c83ff;color:#7c83ff}
.form-file input{display:none}

/* ── Groups sidebar ────────────────────────────────────────────── */
.group-list{list-style:none}
.group-list li{margin-bottom:.2rem}
.group-list a{display:flex;justify-content:space-between;align-items:center;padding:.45rem .75rem;border-radius:6px;font-size:.875rem;text-decoration:none;color:#333;transition:background .15s}
.group-list a:hover,.group-list a.active{background:#ede9fe;color:#5b21b6}
.group-list .gc{font-size:.75rem;color:#999;background:#f3f4f6;padding:.1rem .4rem;border-radius:10px}

/* ── Message cards ─────────────────────────────────────────────── */
.msg{background:#fff;border-radius:10px;box-shadow:0 1px 4px rgba(0,0,0,.06);padding:1rem 1.25rem;margin-bottom:.85rem;transition:box-shadow .15s}
.msg:hover{box-shadow:0 3px 10px rgba(0,0,0,.1)}
.msg-head{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:.5rem;gap:.5rem;flex-wrap:wrap}
.msg-author{font-weight:700;font-size:.9rem}
.msg-author em{font-style:italic;color:#888}
.msg-date{font-size:.75rem;color:#aaa}
.msg-body{font-size:.9rem;line-height:1.55;color:#333;white-space:pre-wrap;word-break:break-word}
.msg-img{margin:.75rem 0}
.msg-img img{max-width:100%;max-height:400px;border-radius:6px;display:block;object-fit:contain}
.msg-file{margin:.5rem 0;font-size:.875rem}
.msg-file a{color:#7c83ff;text-decoration:none}
.msg-file a:hover{text-decoration:underline}
.msg-foot{display:flex;align-items:center;gap:.75rem;margin-top:.75rem;padding-top:.6rem;border-top:1px solid #f0f0f0}
.btn-like{background:none;border:1px solid #e0e0e0;border-radius:20px;padding:.25rem .7rem;font-size:.8rem;cursor:pointer;color:#888;transition:all .2s;display:inline-flex;align-items:center;gap:.25rem}
.btn-like:hover{border-color:#f87171;color:#f87171}
.btn-like.liked{border-color:#f87171;color:#f87171;background:#fff5f5}
.btn-cmt{font-size:.8rem;color:#888;text-decoration:none;padding:.25rem .5rem;border-radius:4px}
.btn-cmt:hover{background:#f3f4f6;color:#555}

/* ── Pager ─────────────────────────────────────────────────────── */
.pager{display:flex;gap:.4rem;flex-wrap:wrap;margin-top:1rem}
.pager a{padding:.35rem .7rem;background:#fff;border:1px solid #dee2e6;border-radius:5px;font-size:.825rem;text-decoration:none;color:#555;transition:all .15s}
.pager a:hover{background:#ede9fe;border-color:#7c83ff;color:#5b21b6}
.pager a.active{background:#7c83ff;border-color:#7c83ff;color:#fff}

/* ── Comments ──────────────────────────────────────────────────── */
.comment{background:#fafafa;border-left:3px solid #e9ecef;padding:.75rem 1rem;margin:.5rem 0;border-radius:0 6px 6px 0}
.cmt-head{font-size:.8rem;color:#888;margin-bottom:.3rem}
.cmt-head b{color:#1a1a2e}
.cmt-date{margin-left:.4rem}
.cmt-body{font-size:.875rem;line-height:1.5;white-space:pre-wrap;word-break:break-word}
.reply-link{font-size:.75rem;color:#7c83ff;cursor:pointer;text-decoration:none;display:inline-block;margin-top:.3rem}
.reply-link:hover{text-decoration:underline}
.reply-form{margin-top:.6rem;padding:.75rem;background:#fff;border:1px solid #e0e0e0;border-radius:6px}
.reply-form textarea{min-height:2.5rem;font-size:.85rem}

/* ── Auth panel ─────────────────────────────────────────────────── */
.auth-tabs{display:flex;gap:0;margin-bottom:1rem;border-bottom:2px solid #e9ecef}
.auth-tab{padding:.5rem 1rem;font-size:.875rem;font-weight:600;cursor:pointer;color:#888;background:none;border:none;border-bottom:2px solid transparent;margin-bottom:-2px;transition:color .15s}
.auth-tab.active{color:#7c83ff;border-bottom-color:#7c83ff}
.auth-panel{display:none}
.auth-panel.active{display:block}

/* ── Empty state ────────────────────────────────────────────────── */
.empty{text-align:center;padding:2.5rem 1rem;color:#aaa;font-size:.9rem}
.empty span{display:block;font-size:2rem;margin-bottom:.5rem}

/* ── Breadcrumb ─────────────────────────────────────────────────── */
.breadcrumb{font-size:.8rem;color:#888;margin-bottom:.75rem}
.breadcrumb a{color:#7c83ff;text-decoration:none}
.breadcrumb a:hover{text-decoration:underline}
.breadcrumb span{margin:0 .3rem}

/* ── Section header ─────────────────────────────────────────────── */
.section-hd{display:flex;align-items:center;justify-content:space-between;margin-bottom:.85rem;flex-wrap:wrap;gap:.5rem}
.section-hd h2{font-size:1.05rem;font-weight:700}
.group-badge{font-size:.75rem;background:#ede9fe;color:#5b21b6;padding:.15rem .55rem;border-radius:10px;font-weight:600}

@media(max-width:640px){
  .layout{flex-direction:column}
  .sidebar{width:100%}
  .form-row{flex-direction:column}
}
</style>
</head>
<body>

<!-- ── Topbar ── -->
<div class="topbar">
  <div class="wrap">
    <h1>📋 <span>Board</span></h1>
    <div class="topbar-right">
      <?php if ($user): ?>
        <span class="topbar-user">👤 <?= h($user['username']) ?></span>
        <form method="post" style="margin:0">
          <input type="hidden" name="auth_action" value="logout">
          <button class="btn btn-ghost btn-sm">Log out</button>
        </form>
      <?php else: ?>
        <a class="btn btn-ghost btn-sm" href="<?= h(selfUrl(['view'=>'auth'])) ?>">Log in / Register</a>
      <?php endif ?>
    </div>
  </div>
</div>

<div class="wrap">
  <div class="layout">

    <!-- ── Sidebar ── -->
    <aside class="sidebar">
      <div class="card">
        <h2>Groups</h2>
        <?php
          $groups  = groupList();
          $activeGid = (int) ($_GET['gid'] ?? 0);
        ?>
        <?php if ($groups): ?>
          <ul class="group-list">
            <?php foreach ($groups as $g): ?>
              <li>
                <a href="<?= h(selfUrl(['view'=>'group','gid'=>$g['id'],'page'=>1])) ?>"
                   <?= $activeGid === (int)$g['id'] ? 'class="active"' : '' ?>>
                  # <?= h($g['name']) ?>
                  <span class="gc"><?= (int)$g['msg_count'] ?></span>
                </a>
              </li>
            <?php endforeach ?>
          </ul>
        <?php else: ?>
          <p style="font-size:.8rem;color:#aaa">No groups yet. Post a message to create one.</p>
        <?php endif ?>
      </div>

      <!-- Post message form (sidebar) -->
      <div class="card">
        <h2>New message</h2>
        <form method="post" enctype="multipart/form-data">
          <input type="hidden" name="msg_action" value="post">
          <div class="form-group">
            <label>Group</label>
            <input type="text" name="group_name"
                   value="<?= h(isset($groups[$activeGid]) ? $groups[$activeGid]['name'] : '') ?>"
                   placeholder="general" maxlength="100">
            <p class="form-hint">Type any name — created if it doesn't exist</p>
          </div>
          <div class="form-group">
            <label>Message</label>
            <textarea name="body" placeholder="What's on your mind?" maxlength="20000"></textarea>
          </div>
          <div class="form-group form-file">
            <label>📎 <span>Attach a file</span>
              <input type="file" name="attachment">
            </label>
          </div>
          <div class="form-group check-row">
            <input type="checkbox" name="is_anonymous" id="anon" value="1"
                   <?= !$user ? 'checked disabled' : '' ?>>
            <label for="anon" style="display:inline;font-weight:normal">
              Post anonymously <?= !$user ? '<em style="color:#aaa">(no account)</em>' : '' ?>
            </label>
          </div>
          <button class="btn btn-pri" style="width:100%">Send →</button>
        </form>
      </div>
    </aside>

    <!-- ── Main content ── -->
    <main class="main">
      <?php renderFlash($flash); ?>

      <?php
      // ── VIEW: auth ──────────────────────────────────────────────────────────
      if ($view === 'auth' && !$user):
      ?>
      <div class="card" style="max-width:420px">
        <div class="auth-tabs">
          <button class="auth-tab active" onclick="switchTab('login', this)">Log in</button>
          <button class="auth-tab" onclick="switchTab('register', this)">Register</button>
        </div>

        <div id="tab-login" class="auth-panel active">
          <form method="post">
            <input type="hidden" name="auth_action" value="login">
            <div class="form-group">
              <label>Username</label>
              <input type="text" name="username" autocomplete="username" required>
            </div>
            <div class="form-group">
              <label>Password</label>
              <input type="password" name="password" autocomplete="current-password" required>
            </div>
            <button class="btn btn-pri" style="width:100%">Log in</button>
          </form>
        </div>

        <div id="tab-register" class="auth-panel">
          <form method="post">
            <input type="hidden" name="auth_action" value="register">
            <div class="form-group">
              <label>Username <span class="form-hint" style="display:inline">(letters, digits, _ - .)</span></label>
              <input type="text" name="username" autocomplete="username" required minlength="3" maxlength="60">
            </div>
            <div class="form-group">
              <label>Password <span class="form-hint" style="display:inline">(min 6 chars)</span></label>
              <input type="password" name="password" autocomplete="new-password" required minlength="6">
            </div>
            <button class="btn btn-pri" style="width:100%">Create account</button>
          </form>
        </div>
      </div>

      <?php
      // ── VIEW: group ─────────────────────────────────────────────────────────
      elseif ($view === 'group' && $activeGid > 0):
        // Look up group name
        $stG = db()->prepare('SELECT name FROM `groups` WHERE id = ? LIMIT 1');
        $stG->execute([$activeGid]);
        $gRow = $stG->fetch();
        if (!$gRow) {
            echo '<div class="empty"><span>🤷</span>Group not found.</div>';
        } else {
          $page   = max(1, (int) ($_GET['page'] ?? 1));
          $result = messageList($activeGid, $page);
          $msgs   = $result['messages'];

          // Bulk like status for logged-in user
          $likedMap = [];
          if ($user && $msgs) {
              $likedMap = likeBulkStatus($user['id'], array_column($msgs, 'id'));
          }
      ?>
        <div class="section-hd">
          <h2># <?= h($gRow['name']) ?> <span class="group-badge"><?= $result['total'] ?> msg<?= $result['total'] !== 1 ? 's' : '' ?></span></h2>
        </div>

        <?php if ($msgs): ?>
          <?php foreach ($msgs as $m): ?>
            <?php renderMessage($m, true, $likedMap[(int)$m['id']] ?? false); ?>
          <?php endforeach ?>
          <?php renderPager($result['pages'], $result['page'], ['view'=>'group','gid'=>$activeGid]); ?>
        <?php else: ?>
          <div class="empty"><span>💬</span>No messages yet. Be the first!</div>
        <?php endif ?>

      <?php } ?>

      <?php
      // ── VIEW: single message + comments ────────────────────────────────────
      elseif ($view === 'message'):
        $mid  = (int) ($_GET['mid'] ?? 0);
        $gid  = (int) ($_GET['gid'] ?? 0);
        $msg  = $mid > 0 ? messageFetch($mid) : null;

        if (!$msg) { ?>
          <div class="empty"><span>🤷</span>Message not found.</div>
        <?php } else {
          $isLiked = $user ? likeStatus($user['id'], $mid) : false;

          // Breadcrumb group name
          $stG2 = db()->prepare('SELECT name FROM `groups` WHERE id = ? LIMIT 1');
          $stG2->execute([$gid ?: $msg['group_id']]);
          $gRow2 = $stG2->fetch();
        ?>
        <div class="breadcrumb">
          <a href="<?= h(selfUrl(['view'=>'board'])) ?>">Board</a>
          <span>›</span>
          <?php if ($gRow2): ?>
            <a href="<?= h(selfUrl(['view'=>'group','gid'=>$gid])) ?>"># <?= h($gRow2['name']) ?></a>
            <span>›</span>
          <?php endif ?>
          Message #<?= $mid ?>
        </div>

        <?php renderMessage($msg, false, $isLiked); ?>

        <!-- ── Comments section ── -->
        <div class="card" id="comments">
          <h2>Comments</h2>

          <?php if ($user): ?>
            <form method="post" class="form-group" id="comment-form-top">
              <input type="hidden" name="comment_action" value="post">
              <input type="hidden" name="message_id" value="<?= $mid ?>">
              <input type="hidden" name="group_id" value="<?= $gid ?>">
              <input type="hidden" name="parent_id" value="">
              <textarea name="comment_body" placeholder="Write a comment…" maxlength="4000"></textarea>
              <button class="btn btn-pri btn-sm" style="margin-top:.5rem">Post comment</button>
            </form>
          <?php else: ?>
            <p style="font-size:.875rem;color:#888;margin-bottom:1rem">
              <a href="<?= h(selfUrl(['view'=>'auth'])) ?>">Log in</a> to comment.
            </p>
          <?php endif ?>

          <?php
            $tree = commentTree($mid);
            if ($tree):
              foreach ($tree as $c) renderCommentNode($c, $mid, $gid);
            else: ?>
              <div class="empty" style="padding:1.5rem"><span>💬</span>No comments yet.</div>
          <?php endif ?>
        </div>

        <?php } ?>

      <?php
      // ── VIEW: board (default landing) ──────────────────────────────────────
      else:
        // Show latest messages across all groups
        $latestMsgs = db()->query("
            SELECT m.id, m.body, m.file_path, m.file_name, m.file_mime, m.is_anonymous,
                   m.created_at, u.username, g.name AS group_name, g.id AS group_id,
                   (SELECT COUNT(*) FROM likes  l WHERE l.message_id = m.id) AS like_count,
                   (SELECT COUNT(*) FROM comments c WHERE c.message_id = m.id) AS comment_count
            FROM messages m
            LEFT JOIN users u ON u.id = m.user_id
            JOIN `groups` g ON g.id = m.group_id
            ORDER BY m.created_at DESC
            LIMIT 20
        ")->fetchAll();

        $likedMap2 = [];
        if ($user && $latestMsgs) {
            $likedMap2 = likeBulkStatus($user['id'], array_column($latestMsgs, 'id'));
        }
      ?>
      <div class="section-hd">
        <h2>Latest messages</h2>
      </div>

      <?php if ($latestMsgs): ?>
        <?php foreach ($latestMsgs as $m):
          // Override comment link to include group context
          $_GET['gid'] = $m['group_id'];
          renderMessage($m, true, $likedMap2[(int)$m['id']] ?? false);
        endforeach ?>
      <?php else: ?>
        <div class="empty"><span>📋</span>No messages yet. Post something in any group!</div>
      <?php endif ?>

      <?php endif; ?>
    </main>

  </div>
</div>

<script>
// ── Auth tab switcher ─────────────────────────────────────────────────────────
function switchTab(name, btn) {
  document.querySelectorAll('.auth-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.auth-tab').forEach(b => b.classList.remove('active'));
  document.getElementById('tab-' + name).classList.add('active');
  btn.classList.add('active');
}

// ── Like button (AJAX, no page reload) ───────────────────────────────────────
document.addEventListener('click', function(e) {
  const btn = e.target.closest('.btn-like');
  if (!btn) return;
  e.preventDefault();
  const mid = btn.dataset.mid;
  const fd  = new FormData();
  fd.append('like_action', 'toggle');
  fd.append('message_id', mid);
  fetch(window.location.href, { method: 'POST', body: fd })
    .then(r => r.json())
    .then(d => {
      if (!d.ok) { alert(d.error); return; }
      btn.querySelector('.like-count').textContent = d.count;
      btn.classList.toggle('liked', d.liked);
    })
    .catch(() => alert('Network error.'));
});

// ── Reply-to-comment inline form ──────────────────────────────────────────────
document.addEventListener('click', function(e) {
  const link = e.target.closest('.reply-link');
  if (!link) return;
  e.preventDefault();

  const parentId = link.dataset.parent;
  const mid      = link.dataset.mid;
  const gid      = link.dataset.gid;

  // Remove any existing reply form
  document.querySelectorAll('.reply-form').forEach(f => f.remove());

  const form = document.createElement('form');
  form.method = 'post';
  form.className = 'reply-form';
  form.innerHTML =
    '<input type="hidden" name="comment_action" value="post">' +
    '<input type="hidden" name="message_id" value="' + mid + '">' +
    '<input type="hidden" name="group_id" value="' + gid + '">' +
    '<input type="hidden" name="parent_id" value="' + parentId + '">' +
    '<textarea name="comment_body" placeholder="Write a reply…" maxlength="4000" rows="2"></textarea>' +
    '<div style="display:flex;gap:.5rem;margin-top:.4rem">' +
      '<button type="submit" class="btn btn-pri btn-sm">Reply</button>' +
      '<button type="button" class="btn btn-sec btn-sm" onclick="this.closest(\'.reply-form\').remove()">Cancel</button>' +
    '</div>';

  link.after(form);
  form.querySelector('textarea').focus();
});
</script>

</body>
</html>
<?php
// End of board.php