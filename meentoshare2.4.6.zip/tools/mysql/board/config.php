﻿<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  config.php — DB credentials, constants, PDO bootstrap, schema installer
//  Include this file FIRST before any other module.
// ═══════════════════════════════════════════════════════════════════════════════

// ── Credentials ───────────────────────────────────────────────────────────────
define('DB_HOST',     'localhost');
define('DB_PORT',     '3306');
define('DB_NAME',     'board');
define('DB_USER',     'root');
define('DB_PASS',     '');
define('DB_CHARSET',  'utf8mb4');

// ── Application constants ─────────────────────────────────────────────────────
define('UPLOAD_DIR',         __DIR__ . '/uploads');
define('UPLOAD_WEB_PATH',    'uploads/');
define('MAX_FILE_BYTES',     10 * 1024 * 1024);   // 10 MB
define('BLOCKED_EXT',        ['php','php3','php4','php5','php7','phtml','phar','exe','sh','bat']);
define('LIKE_SALT',          'ch4ng3_th1s_s4lt_!');  // change in production
define('COMMENTS_PER_MIN',   5);   // rate-limit: max comments per user per minute
define('MESSAGES_PER_PAGE',  10);
define('COMMENTS_PER_PAGE',  20);
define('SESSION_LIFETIME',   86400); // 1 day

// ── Session ───────────────────────────────────────────────────────────────────
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_strict_mode', '1');
    session_set_cookie_params(['lifetime' => SESSION_LIFETIME, 'samesite' => 'Lax']);
    session_start();
}

// ── PDO singleton ─────────────────────────────────────────────────────────────
function db(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    $dsn = sprintf(
        'mysql:host=%s;port=%s;dbname=%s;charset=%s',
        DB_HOST, DB_PORT, DB_NAME, DB_CHARSET
    );
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
    return $pdo;
}

// ── Schema installer (run once on first boot) ─────────────────────────────────
function installSchema(): void {
    $pdo = db();
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            username    VARCHAR(60)  NOT NULL UNIQUE,
            pass_hash   VARCHAR(255) NOT NULL,
            created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `groups` (
            id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name        VARCHAR(100) NOT NULL UNIQUE,
            created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS messages (
            id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id      INT UNSIGNED NULL COMMENT 'NULL = anonymous',
            group_id     INT UNSIGNED NOT NULL,
            body         TEXT         NOT NULL,
            file_path    VARCHAR(512) NULL COMMENT 'relative path inside uploads/',
            file_name    VARCHAR(255) NULL,
            file_mime    VARCHAR(120) NULL,
            is_anonymous TINYINT(1)   NOT NULL DEFAULT 0,
            created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id)  REFERENCES users(`id`)  ON DELETE SET NULL,
            FOREIGN KEY (group_id) REFERENCES `groups`(`id`) ON DELETE CASCADE,
            INDEX idx_group_date (group_id, created_at DESC)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS comments (
            id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            message_id  INT UNSIGNED NOT NULL,
            parent_id   INT UNSIGNED NULL COMMENT 'NULL = top-level; set = reply to comment',
            user_id     INT UNSIGNED NOT NULL,
            body        TEXT         NOT NULL,
            created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (message_id) REFERENCES messages(`id`) ON DELETE CASCADE,
            FOREIGN KEY (parent_id)  REFERENCES comments(`id`) ON DELETE CASCADE,
            FOREIGN KEY (user_id)    REFERENCES users(`id`)    ON DELETE CASCADE,
            INDEX idx_msg (message_id, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS likes (
            id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            message_id  INT UNSIGNED NOT NULL,
            like_hash   CHAR(64)     NOT NULL,
            created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_like (message_id, like_hash),
            FOREIGN KEY (message_id) REFERENCES messages(`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS rate_limit_comments (
            user_id    INT UNSIGNED NOT NULL,
            ts         DATETIME     NOT NULL,
            INDEX idx_user_ts (user_id, ts)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
}

// Auto-install on first load (safe — uses IF NOT EXISTS)
try {
    installSchema();
} catch (PDOException $e) {
    // Surface DB connection errors clearly
    http_response_code(503);
    echo '<pre style="color:red">DB Error: ' . htmlspecialchars($e->getMessage()) . '</pre>';
    exit;
}

// ── Utility helpers ───────────────────────────────────────────────────────────

/** Escape output safely. */
function h(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Current logged-in user array or null. */
function currentUser(): ?array {
    return $_SESSION['user'] ?? null;
}

/** Redirect to a URL and exit. */
function redirect(string $url): void {
    header('Location: ' . $url);
    exit;
}

/** Return a URL to the current script with query params merged. */
function selfUrl(array $params = []): string {
    $base = strtok($_SERVER['REQUEST_URI'], '?');
    $qs   = array_merge($_GET, $params);
    return $base . ($qs ? '?' . http_build_query($qs) : '');
}

/** Flash message helpers. */
function flashSet(string $type, string $msg): void {
    $_SESSION['flash'] = ['type' => $type, 'msg' => $msg];
}
function flashGet(): ?array {
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}

/** Detect image MIME. */
function isImageMime(string $mime): bool {
    return in_array($mime, ['image/jpeg','image/png','image/gif','image/webp','image/svg+xml'], true);
}

/** Ensure upload directory exists. */
if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}