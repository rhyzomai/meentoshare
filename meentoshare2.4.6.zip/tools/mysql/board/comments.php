﻿<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  comments.php — Threaded comments (reply to comments), rate-limit per minute
//  Requires: config.php
//  Only logged-in users may comment.
// ═══════════════════════════════════════════════════════════════════════════════

if (!defined('DB_HOST')) {
    require_once __DIR__ . '/config.php';
}

// ── Rate limiter ──────────────────────────────────────────────────────────────

/**
 * Check and record a comment attempt.
 * Returns true if allowed, false if rate-limited.
 */
function commentRateCheck(int $userId): bool {
    $pdo     = db();
    $window  = date('Y-m-d H:i:s', time() - 60);   // last 60 seconds

    // Purge old entries older than 2 minutes (housekeeping)
    $pdo->prepare('DELETE FROM rate_limit_comments WHERE ts < ?')
        ->execute([date('Y-m-d H:i:s', time() - 120)]);

    $st = $pdo->prepare('SELECT COUNT(*) FROM rate_limit_comments WHERE user_id = ? AND ts >= ?');
    $st->execute([$userId, $window]);
    $count = (int) $st->fetchColumn();

    if ($count >= COMMENTS_PER_MIN) {
        return false;
    }

    $pdo->prepare('INSERT INTO rate_limit_comments (user_id, ts) VALUES (?, NOW())')
        ->execute([$userId]);
    return true;
}

// ── Comment CRUD ──────────────────────────────────────────────────────────────

/**
 * Post a comment.
 * $parentId = null  → top-level comment on the message
 * $parentId = int   → reply to another comment (one level deeper is fine)
 */
function commentPost(int $userId, int $messageId, ?int $parentId, string $body): array {
    $body = trim($body);
    if ($body === '') {
        return ['ok' => false, 'error' => 'Comment cannot be empty.'];
    }
    if (strlen($body) > 4000) {
        return ['ok' => false, 'error' => 'Comment too long (max 4 000 chars).'];
    }

    // Validate parent belongs to same message
    if ($parentId !== null) {
        $st = db()->prepare('SELECT message_id FROM comments WHERE id = ? LIMIT 1');
        $st->execute([$parentId]);
        $row = $st->fetch();
        if (!$row || (int) $row['message_id'] !== $messageId) {
            return ['ok' => false, 'error' => 'Invalid parent comment.'];
        }
    }

    if (!commentRateCheck($userId)) {
        return ['ok' => false, 'error' => 'Rate limit: max ' . COMMENTS_PER_MIN . ' comments per minute.'];
    }

    $st = db()->prepare("
        INSERT INTO comments (message_id, parent_id, user_id, body)
        VALUES (?, ?, ?, ?)
    ");
    $st->execute([$messageId, $parentId, $userId, $body]);

    return ['ok' => true, 'id' => (int) db()->lastInsertId()];
}

/**
 * Fetch all comments for a message, threaded (top-level + their replies).
 * Returns a nested array: each top-level comment has 'replies' => [...].
 * Ordered by created_at ASC within each level.
 */
function commentTree(int $messageId): array {
    $st = db()->prepare("
        SELECT c.id, c.parent_id, c.body, c.created_at, u.username
        FROM comments c
        JOIN users u ON u.id = c.user_id
        WHERE c.message_id = ?
        ORDER BY c.parent_id IS NOT NULL, c.parent_id, c.created_at ASC
    ");
    $st->execute([$messageId]);
    $rows = $st->fetchAll();

    // Index by id
    $byId = [];
    foreach ($rows as $r) {
        $r['replies'] = [];
        $byId[$r['id']] = $r;
    }

    // Build tree
    $roots = [];
    foreach ($byId as $id => &$row) {
        if ($row['parent_id'] === null) {
            $roots[] = &$row;
        } else {
            $pid = (int) $row['parent_id'];
            if (isset($byId[$pid])) {
                $byId[$pid]['replies'][] = &$row;
            } else {
                // Orphaned reply (parent deleted?) — show as root
                $roots[] = &$row;
            }
        }
    }
    unset($row);

    return $roots;
}

// ── Request handler ───────────────────────────────────────────────────────────

function handleCommentPost(): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['comment_action'])) return;

    $user = currentUser();
    if (!$user) {
        flashSet('error', 'You must be logged in to comment.');
        redirect(selfUrl());
    }

    if ($_POST['comment_action'] === 'post') {
        $msgId    = (int) ($_POST['message_id'] ?? 0);
        $parentId = isset($_POST['parent_id']) && $_POST['parent_id'] !== ''
            ? (int) $_POST['parent_id']
            : null;
        $body = $_POST['comment_body'] ?? '';

        $r = commentPost($user['id'], $msgId, $parentId, $body);

        if ($r['ok']) {
            flashSet('ok', 'Comment posted.');
        } else {
            flashSet('error', $r['error']);
        }

        // Return to same message view
        $gid = (int) ($_POST['group_id'] ?? 0);
        redirect(selfUrl(['view' => 'message', 'mid' => $msgId, 'gid' => $gid])
            . '#comment-' . ($r['id'] ?? 'form'));
    }
}