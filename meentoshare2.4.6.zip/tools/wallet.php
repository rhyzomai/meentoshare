﻿<?php
// ================================================================
//  Seastar Wallet  —  wallet.php
//  Key management UI for the Seastar Blockchain.
//
//  FEATURES
//  ----------------------------------------------------------------
//  • Generate RSA-4096 key pairs (PEM format)
//  • Store private keys AES-256-CBC encrypted with a user passphrase
//    in the  wallet/  folder (one JSON file per key)
//  • List all wallet keys (shows public key + fingerprint)
//  • Sign & submit transfers via SeastarBlockchain::buildTransfer()
//  • Export public key (copy/paste for sharing)
//  • Delete a wallet key
//
//  FILE LAYOUT
//  ----------------------------------------------------------------
//  wallet/<fingerprint>.json   — encrypted key record
//    {
//      "fingerprint": "sha256:abcd…",   // first 16 hex of SHA-256(pubkey)
//      "label":       "My main wallet",
//      "public_key":  "<base64 – no PEM headers>",
//      "created_at":  1234567890,
//      "iv":          "<hex>",           // AES IV
//      "encrypted_private_key": "<hex>" // AES-256-CBC ciphertext
//    }
//
//  SECURITY NOTES
//  ----------------------------------------------------------------
//  • The passphrase is NEVER stored. Lose it → lose the key.
//  • Private key bytes never touch disk unencrypted.
//  • The wallet/ folder should be outside your web root or protected
//    via .htaccess — see the note at the bottom of this file.
// ================================================================

define('WALLET_DIR', __DIR__ . '/wallet');

if (!is_dir(WALLET_DIR)) {
    mkdir(WALLET_DIR, 0700, true);
}

// ================================================================
//  Wallet helpers
// ================================================================

class SeastarWallet
{
    // ── Key generation ──────────────────────────────────────────

    /**
     * Generate a new RSA-4096 key pair.
     * Returns ['private_pem' => '…', 'public_pem' => '…'].
     */
    public static function generateKeyPair(): array
    {
        $config = [
            'private_key_bits' => 4096,
            'private_key_type' => OPENSSL_KEYTYPE_RSA,
        ];
        $res = openssl_pkey_new($config);
        if ($res === false) {
            throw new RuntimeException('openssl_pkey_new failed: ' . openssl_error_string());
        }
        openssl_pkey_export($res, $privatePem);
        $details   = openssl_pkey_get_details($res);
        $publicPem = $details['key'];
        return ['private_pem' => $privatePem, 'public_pem' => $publicPem];
    }

    // ── Encryption helpers ──────────────────────────────────────

    /**
     * Encrypt a string with AES-256-CBC using a passphrase.
     * The passphrase is stretched via SHA-256 (simple; add PBKDF2 for production).
     */
    public static function encrypt(string $plaintext, string $passphrase): array
    {
        $key = hash('sha256', $passphrase, true);   // 32 bytes
        $iv  = random_bytes(16);
        $ct  = openssl_encrypt($plaintext, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
        if ($ct === false) {
            throw new RuntimeException('Encryption failed: ' . openssl_error_string());
        }
        return [
            'iv'         => bin2hex($iv),
            'ciphertext' => bin2hex($ct),
        ];
    }

    /**
     * Decrypt a string encrypted by self::encrypt().
     * Returns null on failure (wrong passphrase or corrupt data).
     */
    public static function decrypt(string $ciphertextHex, string $ivHex, string $passphrase): ?string
    {
        $key = hash('sha256', $passphrase, true);
        $iv  = hex2bin($ivHex);
        $ct  = hex2bin($ciphertextHex);
        $pt  = @openssl_decrypt($ct, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
        return $pt !== false ? $pt : null;
    }

    // ── Fingerprint ─────────────────────────────────────────────

    /**
     * Derive a short fingerprint from a PEM public key.
     * Format: "sha256:<first 16 hex chars>"
     */
    public static function fingerprint(string $publicPem): string
    {
        // Strip headers, decode base64 → hash raw DER bytes
        $b64 = preg_replace('/-----[^-]+-----|\s/', '', $publicPem);
        return 'sha256:' . substr(hash('sha256', base64_decode($b64)), 0, 16);
    }

    /**
     * Return the safe filename component (hex only, no colons).
     */
    public static function fingerprintSlug(string $fingerprint): string
    {
        return str_replace(':', '_', $fingerprint);
    }

    // ── Storage ─────────────────────────────────────────────────

    /**
     * Save an encrypted key record to wallet/.
     */
    public static function save(
        string $label,
        string $publicPem,
        string $privatePem,
        string $passphrase
    ): array {
        $fp      = self::fingerprint($publicPem);
        $slug    = self::fingerprintSlug($fp);
        $path    = WALLET_DIR . '/' . $slug . '.json';
        $pubB64  = self::normalisePem($publicPem);
        $enc     = self::encrypt($privatePem, $passphrase);

        $record = [
            'fingerprint'           => $fp,
            'label'                 => substr(htmlspecialchars($label, ENT_QUOTES), 0, 80),
            'public_key'            => $pubB64,
            'created_at'            => time(),
            'iv'                    => $enc['iv'],
            'encrypted_private_key' => $enc['ciphertext'],
        ];

        file_put_contents($path, json_encode($record, JSON_PRETTY_PRINT));
        return $record;
    }

    /**
     * Load all wallet key records from wallet/.
     */
    public static function loadAll(): array
    {
        $files = glob(WALLET_DIR . '/*.json') ?: [];
        $keys  = [];
        foreach ($files as $f) {
            $d = @json_decode(file_get_contents($f), true);
            if (is_array($d) && isset($d['fingerprint'])) {
                $keys[] = $d;
            }
        }
        usort($keys, fn($a, $b) => $b['created_at'] <=> $a['created_at']);
        return $keys;
    }

    /**
     * Load a single record by fingerprint slug.
     */
    public static function load(string $slug): ?array
    {
        $slug = preg_replace('/[^a-z0-9_]/', '', strtolower($slug));
        $path = WALLET_DIR . '/' . $slug . '.json';
        if (!file_exists($path)) return null;
        $d = @json_decode(file_get_contents($path), true);
        return is_array($d) ? $d : null;
    }

    /**
     * Delete a key record by slug. Returns true on success.
     */
    public static function delete(string $slug): bool
    {
        $slug = preg_replace('/[^a-z0-9_]/', '', strtolower($slug));
        $path = WALLET_DIR . '/' . $slug . '.json';
        if (file_exists($path)) {
            unlink($path);
            return true;
        }
        return false;
    }

    // ── PEM helper (mirrors SeastarBlockchain) ───────────────────

    public static function normalisePem(string $pem): string
    {
        $lines = explode("\n", $pem);
        $b64   = '';
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '-----') === 0) continue;
            $b64 .= $line;
        }
        return $b64;
    }

    public static function base64ToPem(string $b64, string $type = 'PUBLIC KEY'): string
    {
        return "-----BEGIN {$type}-----\n"
             . chunk_split($b64, 64, "\n")
             . "-----END {$type}-----\n";
    }
}

// ================================================================
//  Action handlers
// ================================================================

$message = '';      // feedback string to display
$msgType = 'ok';    // 'ok' | 'error'
$action  = trim($_POST['action'] ?? $_GET['action'] ?? '');

// ── Generate key pair ────────────────────────────────────────────
if ($action === 'generate') {
    $label      = trim($_POST['label'] ?? 'My Wallet Key');
    $passphrase = $_POST['passphrase'] ?? '';
    $confirm    = $_POST['passphrase_confirm'] ?? '';

    if (strlen($passphrase) < 8) {
        $message = 'Passphrase must be at least 8 characters.';
        $msgType = 'error';
    } elseif ($passphrase !== $confirm) {
        $message = 'Passphrases do not match.';
        $msgType = 'error';
    } else {
        try {
            $pair   = SeastarWallet::generateKeyPair();
            $record = SeastarWallet::save($label, $pair['public_pem'], $pair['private_pem'], $passphrase);
            $message = "Key pair generated and saved. Fingerprint: <code>{$record['fingerprint']}</code>";
        } catch (RuntimeException $e) {
            $message = 'Key generation failed: ' . htmlspecialchars($e->getMessage());
            $msgType = 'error';
        }
    }
}

// ── Delete key ───────────────────────────────────────────────────
if ($action === 'delete') {
    $slug = trim($_POST['slug'] ?? '');
    if ($slug && SeastarWallet::delete($slug)) {
        $message = 'Key deleted successfully.';
    } else {
        $message = 'Key not found or could not be deleted.';
        $msgType = 'error';
    }
}

// ── Sign & submit transfer ───────────────────────────────────────
$transferResult = null;
if ($action === 'transfer') {
    $slug        = trim($_POST['slug'] ?? '');
    $passphrase  = $_POST['passphrase'] ?? '';
    $receiverPem = trim($_POST['receiver_public_key'] ?? '');
    $amount      = trim($_POST['amount'] ?? '');
    $asset       = trim($_POST['asset'] ?? '');
    $memo        = trim($_POST['memo'] ?? '');

    $record = $slug ? SeastarWallet::load($slug) : null;

    if (!$record) {
        $message = 'Wallet key not found.';
        $msgType = 'error';
    } elseif ($passphrase === '') {
        $message = 'Passphrase is required to sign.';
        $msgType = 'error';
    } elseif (!is_numeric($amount) || (float)$amount <= 0) {
        $message = 'Amount must be a positive number.';
        $msgType = 'error';
    } elseif ($asset === '') {
        $message = 'Asset identifier is required.';
        $msgType = 'error';
    } elseif ($receiverPem === '') {
        $message = 'Receiver public key is required.';
        $msgType = 'error';
    } else {
        // Decrypt private key
        $privPem = SeastarWallet::decrypt(
            $record['encrypted_private_key'],
            $record['iv'],
            $passphrase
        );

        if ($privPem === null || openssl_pkey_get_private($privPem) === false) {
            $message = 'Wrong passphrase — could not decrypt the private key.';
            $msgType = 'error';
        } else {
            // Normalise receiver key: accept raw base64 or full PEM
            if (strpos($receiverPem, '-----BEGIN') === false) {
                $receiverPem = SeastarWallet::base64ToPem($receiverPem, 'PUBLIC KEY');
            }

            $senderPem = SeastarWallet::base64ToPem($record['public_key'], 'PUBLIC KEY');

            // Require blockchain.php
            $bcPath = __DIR__ . '/blockchain.php';
            if (!file_exists($bcPath)) {
                $message = '<code>blockchain.php</code> not found in the same directory. Cannot submit transfer.';
                $msgType = 'error';
            } else {
                require_once $bcPath;
                try {
                    $tx  = SeastarBlockchain::buildTransfer(
                        $senderPem,
                        $receiverPem,
                        $amount,
                        $asset,
                        $memo,
                        $privPem
                    );
                    $log = SeastarBlockchain::submitTransferToServers($tx);
                    $transferResult = ['tx' => $tx, 'log' => $log];
                    $message = "Transfer signed and submitted! TXID: <code>{$tx['txid']}</code>";
                } catch (RuntimeException $e) {
                    $message = 'Transfer failed: ' . htmlspecialchars($e->getMessage());
                    $msgType = 'error';
                }
            }
        }
    }
}

// ── Load current wallet keys for display ─────────────────────────
$walletKeys = SeastarWallet::loadAll();

// ── Key to show public PEM for (export) ──────────────────────────
$exportSlug   = trim($_GET['export'] ?? '');
$exportRecord = $exportSlug ? SeastarWallet::load($exportSlug) : null;

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Seastar Wallet</title>
<style>
/* ── Reset & base ──────────────────────────────────────────── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
:root {
    --bg:        #0f1117;
    --surface:   #1a1d27;
    --surface2:  #22263a;
    --border:    #2e3450;
    --accent:    #4f7df3;
    --accent2:   #7c5cf6;
    --ok:        #22c55e;
    --err:       #ef4444;
    --warn:      #f59e0b;
    --text:      #e2e8f0;
    --muted:     #64748b;
    --code-bg:   #0d1020;
    --radius:    10px;
    --radius-sm: 6px;
}
body {
    background: var(--bg);
    color: var(--text);
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    font-size: 15px;
    line-height: 1.6;
    min-height: 100vh;
}

/* ── Layout ─────────────────────────────────────────────────── */
.shell {
    display: flex;
    min-height: 100vh;
}
.sidebar {
    width: 240px;
    flex-shrink: 0;
    background: var(--surface);
    border-right: 1px solid var(--border);
    padding: 24px 0;
    display: flex;
    flex-direction: column;
}
.main {
    flex: 1;
    padding: 32px 40px;
    max-width: 860px;
}

/* ── Sidebar ────────────────────────────────────────────────── */
.brand {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 0 20px 24px;
    border-bottom: 1px solid var(--border);
    margin-bottom: 16px;
}
.brand-icon {
    width: 32px;
    height: 32px;
    background: linear-gradient(135deg, var(--accent), var(--accent2));
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    flex-shrink: 0;
}
.brand-name {
    font-weight: 700;
    font-size: 15px;
    letter-spacing: 0.02em;
    color: var(--text);
}
.brand-sub {
    font-size: 11px;
    color: var(--muted);
    margin-top: 1px;
}
.nav-label {
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    color: var(--muted);
    padding: 8px 20px 4px;
}
.nav-link {
    display: block;
    padding: 9px 20px;
    color: var(--text);
    text-decoration: none;
    font-size: 14px;
    border-left: 3px solid transparent;
    transition: background .15s, border-color .15s;
}
.nav-link:hover { background: var(--surface2); border-left-color: var(--border); }
.nav-link.active { background: rgba(79,125,243,.12); border-left-color: var(--accent); color: var(--accent); }

/* ── Section headings ───────────────────────────────────────── */
.section-title {
    font-size: 20px;
    font-weight: 700;
    color: var(--text);
    margin-bottom: 4px;
}
.section-sub {
    font-size: 13px;
    color: var(--muted);
    margin-bottom: 24px;
}
.divider {
    border: none;
    border-top: 1px solid var(--border);
    margin: 32px 0;
}

/* ── Alert / message ────────────────────────────────────────── */
.alert {
    padding: 12px 16px;
    border-radius: var(--radius-sm);
    border: 1px solid;
    font-size: 14px;
    margin-bottom: 24px;
    line-height: 1.5;
}
.alert code {
    background: rgba(0,0,0,.3);
    padding: 1px 5px;
    border-radius: 3px;
    font-size: 12px;
}
.alert.ok    { background: rgba(34,197,94,.08); border-color: rgba(34,197,94,.3); color: #86efac; }
.alert.error { background: rgba(239,68,68,.08); border-color: rgba(239,68,68,.3); color: #fca5a5; }
.alert.warn  { background: rgba(245,158,11,.08); border-color: rgba(245,158,11,.3); color: #fcd34d; }

/* ── Card ───────────────────────────────────────────────────── */
.card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 24px;
    margin-bottom: 20px;
}
.card-title {
    font-size: 14px;
    font-weight: 600;
    color: var(--text);
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    gap: 8px;
}

/* ── Key list ───────────────────────────────────────────────── */
.key-list { display: flex; flex-direction: column; gap: 12px; }
.key-card {
    background: var(--surface2);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    padding: 16px 18px;
}
.key-card-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 12px;
    margin-bottom: 10px;
}
.key-label { font-weight: 600; font-size: 14px; }
.key-fp    { font-size: 11px; color: var(--muted); font-family: monospace; margin-top: 2px; }
.key-date  { font-size: 11px; color: var(--muted); }
.key-actions { display: flex; gap: 8px; flex-shrink: 0; }
.key-pubkey {
    font-family: monospace;
    font-size: 11px;
    color: var(--muted);
    word-break: break-all;
    background: var(--code-bg);
    padding: 8px 10px;
    border-radius: var(--radius-sm);
    border: 1px solid var(--border);
    max-height: 60px;
    overflow: hidden;
    position: relative;
}
.key-pubkey::after {
    content: '';
    position: absolute;
    bottom: 0; left: 0; right: 0;
    height: 24px;
    background: linear-gradient(transparent, var(--code-bg));
}

/* ── Forms ──────────────────────────────────────────────────── */
.form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.form-grid.single { grid-template-columns: 1fr; }
.field { display: flex; flex-direction: column; gap: 6px; }
.field label { font-size: 13px; font-weight: 500; color: var(--muted); }
.field input,
.field select,
.field textarea {
    background: var(--surface2);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    color: var(--text);
    font-size: 14px;
    padding: 9px 12px;
    transition: border-color .15s;
    width: 100%;
    font-family: inherit;
}
.field input:focus,
.field select:focus,
.field textarea:focus {
    outline: none;
    border-color: var(--accent);
}
.field textarea { resize: vertical; min-height: 80px; }
.field .hint { font-size: 11px; color: var(--muted); margin-top: 2px; }

/* ── Buttons ────────────────────────────────────────────────── */
.btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 9px 18px;
    border-radius: var(--radius-sm);
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    border: 1px solid transparent;
    transition: opacity .15s, background .15s;
    text-decoration: none;
    background: none;
    color: var(--text);
    white-space: nowrap;
}
.btn:hover { opacity: .85; }
.btn-primary { background: var(--accent); color: #fff; border-color: var(--accent); }
.btn-secondary { background: var(--surface2); border-color: var(--border); }
.btn-danger { background: rgba(239,68,68,.15); border-color: rgba(239,68,68,.4); color: #fca5a5; }
.btn-sm { padding: 5px 11px; font-size: 12px; }
.btn-full { width: 100%; justify-content: center; margin-top: 16px; }

/* ── Transfer result log ────────────────────────────────────── */
.log-list { list-style: none; display: flex; flex-direction: column; gap: 4px; }
.log-item {
    font-family: monospace;
    font-size: 12px;
    padding: 5px 10px;
    border-radius: 4px;
    border-left: 3px solid;
}
.log-item.ok    { background: rgba(34,197,94,.07); border-color: var(--ok); color: #86efac; }
.log-item.error { background: rgba(239,68,68,.07); border-color: var(--err); color: #fca5a5; }
.log-item.info  { background: rgba(100,116,139,.07); border-color: var(--muted); color: var(--muted); }

/* ── Export modal ───────────────────────────────────────────── */
.modal-bg {
    position: fixed; inset: 0;
    background: rgba(0,0,0,.6);
    z-index: 100;
    display: flex; align-items: center; justify-content: center;
    padding: 20px;
}
.modal {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 28px;
    max-width: 600px;
    width: 100%;
}
.modal-title { font-weight: 700; font-size: 16px; margin-bottom: 12px; }
.modal-pem {
    font-family: monospace;
    font-size: 12px;
    background: var(--code-bg);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    padding: 14px;
    word-break: break-all;
    white-space: pre-wrap;
    color: #94a3b8;
    max-height: 280px;
    overflow-y: auto;
    margin-bottom: 14px;
}
.modal-actions { display: flex; gap: 10px; justify-content: flex-end; }

/* ── Security notice ────────────────────────────────────────── */
.notice {
    background: rgba(245,158,11,.06);
    border: 1px solid rgba(245,158,11,.2);
    border-radius: var(--radius-sm);
    padding: 12px 16px;
    font-size: 12px;
    color: #fcd34d;
    margin-top: 24px;
}
.notice strong { display: block; margin-bottom: 4px; }

/* ── Responsive ─────────────────────────────────────────────── */
@media (max-width: 700px) {
    .shell { flex-direction: column; }
    .sidebar { width: 100%; border-right: none; border-bottom: 1px solid var(--border); padding: 16px 0; }
    .main { padding: 20px 16px; }
    .form-grid { grid-template-columns: 1fr; }
}

/* ── Tab sections ───────────────────────────────────────────── */
.tab-sections section { display: none; }
.tab-sections section.active { display: block; }
</style>
</head>
<body>

<div class="shell">

    <!-- ── Sidebar ────────────────────────────────────────────── -->
    <aside class="sidebar">
        <div class="brand">
            <div class="brand-icon">⭐</div>
            <div>
                <div class="brand-name">Seastar</div>
                <div class="brand-sub">Wallet</div>
            </div>
        </div>

        <span class="nav-label">Manage</span>
        <a href="?tab=keys"     class="nav-link <?= (!isset($_GET['tab']) || $_GET['tab']==='keys')     ? 'active' : '' ?>">🔑 My Keys</a>
        <a href="?tab=generate" class="nav-link <?= (isset($_GET['tab']) && $_GET['tab']==='generate')  ? 'active' : '' ?>">✨ Generate Key</a>

        <span class="nav-label" style="margin-top:12px;">Transact</span>
        <a href="?tab=transfer" class="nav-link <?= (isset($_GET['tab']) && $_GET['tab']==='transfer')  ? 'active' : '' ?>">🚀 Send Transfer</a>

        <span class="nav-label" style="margin-top:12px;">Network</span>
        <a href="blockchain.php?bc_action=tip"      class="nav-link" target="_blank">📡 Chain Tip ↗</a>
        <a href="blockchain.php?bc_action=pending"  class="nav-link" target="_blank">⏳ Pending Pool ↗</a>
        <a href="blockchain.php?bc_action=validate" class="nav-link" target="_blank">✅ Validate Chain ↗</a>
    </aside>

    <!-- ── Main content ───────────────────────────────────────── -->
    <main class="main">

        <?php if ($message): ?>
        <div class="alert <?= htmlspecialchars($msgType) ?>">
            <?= $message /* already safe — built from trusted strings or htmlspecialchars'd */ ?>
        </div>
        <?php endif; ?>

        <?php
        $tab = isset($_GET['tab']) ? $_GET['tab'] : 'keys';
        // Force to transfer tab if the POST was a transfer action
        if ($action === 'transfer') $tab = 'transfer';
        if ($action === 'generate') $tab = 'keys';
        ?>

        <!-- ════════════════════════════════════════════════════
             TAB: My Keys
        ═════════════════════════════════════════════════════ -->
        <?php if ($tab === 'keys'): ?>

        <div class="section-title">🔑 My Keys</div>
        <p class="section-sub">Your locally stored RSA key pairs. Private keys are encrypted with your passphrase and never leave this server unencrypted.</p>

        <?php if (empty($walletKeys)): ?>
        <div class="card" style="text-align:center; color:var(--muted); padding: 40px;">
            No keys yet. <a href="?tab=generate" style="color:var(--accent);">Generate your first key pair →</a>
        </div>
        <?php else: ?>
        <div class="key-list">
        <?php foreach ($walletKeys as $k):
            $slug     = SeastarWallet::fingerprintSlug($k['fingerprint']);
            $pubShort = substr($k['public_key'], 0, 64) . '…';
            $date     = date('Y-m-d H:i', $k['created_at']);
        ?>
        <div class="key-card">
            <div class="key-card-header">
                <div>
                    <div class="key-label"><?= htmlspecialchars($k['label']) ?></div>
                    <div class="key-fp"><?= htmlspecialchars($k['fingerprint']) ?></div>
                    <div class="key-date">Created <?= $date ?></div>
                </div>
                <div class="key-actions">
                    <a href="?tab=keys&export=<?= urlencode($slug) ?>" class="btn btn-sm btn-secondary">📋 Export</a>
                    <a href="?tab=transfer&slug=<?= urlencode($slug) ?>" class="btn btn-sm btn-primary">🚀 Send</a>
                    <form method="post" style="display:inline" onsubmit="return confirm('Delete this key? This cannot be undone.');">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="slug" value="<?= htmlspecialchars($slug) ?>">
                        <button type="submit" class="btn btn-sm btn-danger">🗑</button>
                    </form>
                </div>
            </div>
            <div class="key-pubkey"><?= htmlspecialchars($pubShort) ?></div>
        </div>
        <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- ── Export modal ─────────────────────────────────── -->
        <?php if ($exportRecord): ?>
        <?php
            $expPem = SeastarWallet::base64ToPem($exportRecord['public_key'], 'PUBLIC KEY');
        ?>
        <div class="modal-bg" onclick="if(event.target===this)location='?tab=keys'">
            <div class="modal">
                <div class="modal-title">📋 Public Key — <?= htmlspecialchars($exportRecord['label']) ?></div>
                <p style="font-size:13px;color:var(--muted);margin-bottom:12px;">
                    Share this public key with others so they can send you transfers.
                    Fingerprint: <code style="font-size:12px;"><?= htmlspecialchars($exportRecord['fingerprint']) ?></code>
                </p>
                <div class="modal-pem" id="pubkey-pem"><?= htmlspecialchars($expPem) ?></div>
                <div class="modal-actions">
                    <button class="btn btn-secondary btn-sm" onclick="
                        navigator.clipboard.writeText(document.getElementById('pubkey-pem').innerText);
                        this.textContent='✅ Copied!';
                        setTimeout(()=>this.textContent='📋 Copy',2000);
                    ">📋 Copy</button>
                    <a href="?tab=keys" class="btn btn-primary btn-sm">Close</a>
                </div>
            </div>
        </div>
        <?php endif; ?>


        <!-- ════════════════════════════════════════════════════
             TAB: Generate Key
        ═════════════════════════════════════════════════════ -->
        <?php elseif ($tab === 'generate'): ?>

        <div class="section-title">✨ Generate Key Pair</div>
        <p class="section-sub">Creates a new RSA-4096 key pair. The private key is encrypted with your passphrase before being saved to disk.</p>

        <div class="card">
            <form method="post" id="gen-form">
                <input type="hidden" name="action" value="generate">
                <div class="form-grid">
                    <div class="field" style="grid-column:1/-1">
                        <label for="label">Key label</label>
                        <input type="text" id="label" name="label" placeholder="e.g. Main wallet, Trading key…"
                               value="<?= htmlspecialchars($_POST['label'] ?? 'My Wallet Key') ?>" required>
                    </div>
                    <div class="field">
                        <label for="passphrase">Passphrase</label>
                        <input type="password" id="passphrase" name="passphrase" required
                               placeholder="Min 8 characters" autocomplete="new-password">
                        <span class="hint">Used to encrypt your private key. Store it safely — it cannot be recovered.</span>
                    </div>
                    <div class="field">
                        <label for="passphrase_confirm">Confirm passphrase</label>
                        <input type="password" id="passphrase_confirm" name="passphrase_confirm" required
                               placeholder="Repeat passphrase" autocomplete="new-password">
                    </div>
                </div>

                <div class="notice">
                    <strong>⚠️ Security reminder</strong>
                    RSA-4096 generation may take a few seconds. Your passphrase is never stored — if you forget it, the key is permanently inaccessible.
                </div>

                <button type="submit" class="btn btn-primary btn-full" onclick="this.textContent='⏳ Generating…';this.disabled=true;this.form.submit();">
                    ✨ Generate Key Pair
                </button>
            </form>
        </div>


        <!-- ════════════════════════════════════════════════════
             TAB: Send Transfer
        ═════════════════════════════════════════════════════ -->
        <?php elseif ($tab === 'transfer'): ?>

        <div class="section-title">🚀 Send Transfer</div>
        <p class="section-sub">Sign and broadcast a transfer to the blockchain network. Your private key is decrypted in memory only and discarded after signing.</p>

        <?php if ($transferResult): ?>
        <div class="card">
            <div class="card-title">📡 Submission result</div>
            <ul class="log-list">
            <?php foreach ($transferResult['log'] as $entry): ?>
                <li class="log-item <?= htmlspecialchars($entry['type']) ?>">
                    <?= htmlspecialchars($entry['msg']) ?>
                </li>
            <?php endforeach; ?>
            </ul>
            <div style="margin-top:14px; font-size:13px; color:var(--muted);">
                TXID: <code style="font-size:11px;"><?= htmlspecialchars($transferResult['tx']['txid']) ?></code>
            </div>
        </div>
        <?php endif; ?>

        <div class="card">
            <form method="post">
                <input type="hidden" name="action" value="transfer">

                <!-- Sender key selection -->
                <div class="field" style="margin-bottom:16px;">
                    <label for="slug">From (your key)</label>
                    <?php if (empty($walletKeys)): ?>
                        <p style="color:var(--err);font-size:13px;">No keys in wallet. <a href="?tab=generate" style="color:var(--accent);">Generate one first →</a></p>
                    <?php else: ?>
                    <select id="slug" name="slug" required>
                        <?php
                        $preselect = trim($_GET['slug'] ?? $_POST['slug'] ?? '');
                        foreach ($walletKeys as $k):
                            $s   = SeastarWallet::fingerprintSlug($k['fingerprint']);
                            $sel = ($preselect === $s) ? 'selected' : '';
                        ?>
                        <option value="<?= htmlspecialchars($s) ?>" <?= $sel ?>>
                            <?= htmlspecialchars($k['label']) ?> (<?= htmlspecialchars($k['fingerprint']) ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <?php endif; ?>
                </div>

                <div class="form-grid">
                    <div class="field">
                        <label for="amount">Amount</label>
                        <input type="text" id="amount" name="amount"
                               placeholder="e.g. 10.5"
                               value="<?= htmlspecialchars($_POST['amount'] ?? '') ?>" required>
                    </div>
                    <div class="field">
                        <label for="asset">Asset</label>
                        <input type="text" id="asset" name="asset"
                               placeholder="e.g. SST"
                               maxlength="32"
                               value="<?= htmlspecialchars($_POST['asset'] ?? 'SST') ?>" required>
                    </div>
                </div>

                <div class="field" style="margin-top:16px;">
                    <label for="receiver_public_key">Receiver public key</label>
                    <textarea id="receiver_public_key" name="receiver_public_key"
                              placeholder="Paste full PEM (-----BEGIN PUBLIC KEY-----…) or raw base64 key"
                              style="min-height:120px;font-family:monospace;font-size:12px;"
                              required><?= htmlspecialchars($_POST['receiver_public_key'] ?? '') ?></textarea>
                    <span class="hint">The recipient shares their public key with you (use the Export button on their wallet).</span>
                </div>

                <div class="field" style="margin-top:16px;">
                    <label for="memo">Memo <span style="color:var(--muted);font-weight:400;">(optional, max 256 chars)</span></label>
                    <input type="text" id="memo" name="memo"
                           maxlength="256"
                           placeholder="Payment for services…"
                           value="<?= htmlspecialchars($_POST['memo'] ?? '') ?>">
                </div>

                <hr class="divider" style="margin:20px 0;">

                <div class="field">
                    <label for="passphrase_tx">Your passphrase</label>
                    <input type="password" id="passphrase_tx" name="passphrase"
                           placeholder="Decrypt your private key to sign"
                           autocomplete="current-password" required>
                    <span class="hint">Used only in memory to sign the transaction. Never stored or logged.</span>
                </div>

                <?php if (!empty($walletKeys)): ?>
                <button type="submit" class="btn btn-primary btn-full">
                    🚀 Sign &amp; Submit Transfer
                </button>
                <?php endif; ?>
            </form>
        </div>

        <?php endif; ?>

        <!-- ── Footer notice ─────────────────────────────────────── -->
        <div class="notice">
            <strong>🔒 Protect your wallet/ directory</strong>
            Add the following to <code>wallet/.htaccess</code> to block direct web access to the encrypted key files:
            <br><br>
            <code>Deny from all</code>
            <br><br>
            Or place the <code>wallet/</code> folder outside your document root and update <code>WALLET_DIR</code> accordingly.
        </div>

    </main><!-- /main -->
</div><!-- /shell -->

<script>
// Auto-select the key matching the ?slug= query param when navigating via Send button
(function () {
    const params = new URLSearchParams(location.search);
    const slug   = params.get('slug');
    if (!slug) return;
    const sel = document.getElementById('slug');
    if (!sel) return;
    for (const opt of sel.options) {
        if (opt.value === slug) { opt.selected = true; break; }
    }
})();
</script>

</body>
</html>