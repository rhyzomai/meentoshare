﻿<?php
// ============================================================
//  View Meento — PHP 7+
//  Searches across data.json, data_2.json, data_3.json …
// ============================================================

$dataDir = __DIR__ . '/';

function dataFilePath(int $n): string {
    global $dataDir;
    return $dataDir . ($n === 1 ? 'data.json' : "data_{$n}.json");
}

function maxDataIndex(): int {
    $n = 1;
    while (file_exists(dataFilePath($n))) $n++;
    return $n - 1;
}

function loadDataFile(int $n): array {
    $path = dataFilePath($n);
    if (!file_exists($path)) return [];
    $decoded = json_decode(file_get_contents($path), true);
    return is_array($decoded) ? $decoded : [];
}

// ── JSON search endpoint ──────────────────────────────────────────────────────
if (isset($_GET['q'])) {
    header('Content-Type: application/json; charset=utf-8');
    $q    = strtolower(trim($_GET['q']));
    $page = max(1, (int) ($_GET['p'] ?? 1));
    $max  = maxDataIndex();
    if ($page < 1 || $page > max(1, $max)) {
        echo json_encode(['results' => [], 'max' => $max, 'page' => $page]);
        exit;
    }
    $data    = loadDataFile($page);
    $results = [];
    if ($q !== '') {
        foreach ($data as $item) {
            if (strpos(strtolower(json_encode($item)), $q) !== false)
                $results[] = $item;
        }
    } else {
        $results = $data;
    }
    echo json_encode(['results' => $results, 'max' => $max, 'page' => $page]);
    exit;
}

// ── page-count endpoint ───────────────────────────────────────────────────────
if (isset($_GET['maxpage'])) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['max' => maxDataIndex()]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Meento</title>
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --ink:    #111;
  --bg:     #fff;
  --muted:  #888;
  --border: #ddd;
  --hover:  #f5f5f5;
  --mono:   'Courier New', monospace;
  --sans:   Arial, Helvetica, sans-serif;
}

html, body {
  min-height: 100vh;
  background: var(--bg);
  color: var(--ink);
  font-family: var(--sans);
  font-size: 13px;
  line-height: 1.5;
}

/* ── Header ──────────────────────────────────────────────────────────────────── */
header {
  position: sticky;
  top: 0;
  z-index: 100;
  background: var(--bg);
  border-bottom: 1px solid var(--border);
  height: 44px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 1.5rem;
}

.logo {
  font-size: .95rem;
  font-weight: bold;
  color: var(--ink);
  text-decoration: none;
  letter-spacing: -.01em;
}

nav a {
  color: var(--muted);
  text-decoration: none;
  font-size: .78rem;
  border: 1px solid var(--border);
  padding: .25rem .7rem;
  border-radius: 3px;
  transition: color .15s, border-color .15s;
}
nav a:hover { color: var(--ink); border-color: #aaa; }

/* ── Layout ───────────────────────────────────────────────────────────────────── */
main {
  max-width: 860px;
  margin: 0 auto;
  padding: 2.5rem 1.5rem 5rem;
}

/* ── Hero ─────────────────────────────────────────────────────────────────────── */
.hero {
  margin-bottom: 1.8rem;
}
.hero h1 {
  font-size: 1.4rem;
  font-weight: bold;
  letter-spacing: -.02em;
  margin-bottom: .2rem;
}
.hero p {
  color: var(--muted);
  font-size: .8rem;
}

/* ── Search ───────────────────────────────────────────────────────────────────── */
.search-wrap {
  position: relative;
  max-width: 520px;
  margin-bottom: 1.5rem;
}
.search-wrap .icon {
  position: absolute;
  left: .7rem;
  top: 50%;
  transform: translateY(-50%);
  color: var(--muted);
  pointer-events: none;
  display: flex;
}
#searchInput {
  width: 100%;
  padding: .6rem .8rem .6rem 2.2rem;
  border: 1px solid var(--border);
  border-radius: 3px;
  background: var(--bg);
  font-family: var(--sans);
  font-size: .85rem;
  color: var(--ink);
  outline: none;
  transition: border-color .15s;
}
#searchInput:focus { border-color: #999; }
#searchInput::placeholder { color: #bbb; }

/* ── Pagination ───────────────────────────────────────────────────────────────── */
.pagination {
  display: flex;
  align-items: center;
  gap: .6rem;
  margin-bottom: 1.2rem;
}
.page-btn {
  display: inline-flex;
  align-items: center;
  gap: .3rem;
  padding: .28rem .7rem;
  border: 1px solid var(--border);
  border-radius: 3px;
  background: var(--bg);
  font-family: var(--sans);
  font-size: .75rem;
  color: var(--ink);
  cursor: pointer;
  transition: background .15s, border-color .15s;
}
.page-btn:hover:not(:disabled) { background: var(--hover); border-color: #aaa; }
.page-btn:disabled { opacity: .35; cursor: not-allowed; }
.page-info {
  font-size: .75rem;
  color: var(--muted);
  min-width: 80px;
}
.pagination.hidden { display: none; }

/* ── Results ──────────────────────────────────────────────────────────────────── */
#resultsList {
  display: flex;
  flex-direction: column;
  gap: 1px;
  border: 1px solid var(--border);
  border-radius: 3px;
  overflow: hidden;
}

/* ── Card ─────────────────────────────────────────────────────────────────────── */
.card {
  display: flex;
  flex-direction: row;
  text-decoration: none;
  color: var(--ink);
  background: var(--bg);
  border-top: 1px solid var(--border);
  transition: background .12s;
}
.card:first-child { border-top: none; }
.card:hover { background: var(--hover); }

/* left column */
.card-left {
  width: 200px;
  flex-shrink: 0;
  border-right: 1px solid var(--border);
  display: flex;
  flex-direction: column;
}
.thumb-wrap {
  width: 100%;
  aspect-ratio: 16 / 9;
  background: #f8f8f8;
  overflow: hidden;
  flex-shrink: 0;
}
.thumb-wrap img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
  transition: transform .25s;
}
.card:hover .thumb-wrap img { transform: scale(1.03); }
.thumb-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ccc;
}
.card-primary {
  padding: .55rem .75rem .65rem;
  border-top: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  gap: .2rem;
}
.card-title {
  font-size: .82rem;
  font-weight: bold;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.card-size { font-size: .72rem; color: var(--muted); }

/* right column */
.card-right {
  flex: 1;
  padding: .75rem 1rem;
  display: flex;
  flex-direction: column;
  gap: .45rem;
  overflow: hidden;
}
.field-row { display: flex; flex-direction: column; gap: .05rem; overflow: hidden; }
.field-label {
  font-size: .6rem;
  font-weight: bold;
  text-transform: uppercase;
  letter-spacing: .1em;
  color: var(--muted);
}
.field-value {
  font-size: .78rem;
  color: var(--ink);
  word-break: break-all;
  line-height: 1.45;
}
.field-value.hash {
  font-family: var(--mono);
  font-size: .7rem;
  color: var(--muted);
}
.field-value.empty { color: #ccc; }

/* ext badge */
.ext-badge {
  display: inline-block;
  padding: .1rem .4rem;
  border: 1px solid var(--border);
  border-radius: 2px;
  font-size: .65rem;
  font-weight: bold;
  letter-spacing: .06em;
  text-transform: uppercase;
  color: var(--muted);
  width: fit-content;
}

/* ── State messages ───────────────────────────────────────────────────────────── */
.state-msg {
  text-align: center;
  color: var(--muted);
  font-size: .82rem;
  padding: 3rem 0;
}
.state-msg svg {
  display: block;
  margin: 0 auto .5rem;
  opacity: .25;
}

/* ── Animations ───────────────────────────────────────────────────────────────── */
@keyframes fadeUp {
  from { opacity: 0; transform: translateY(6px); }
  to   { opacity: 1; transform: translateY(0); }
}
.card { animation: fadeUp .18s ease both; }

/* ── Footer ───────────────────────────────────────────────────────────────────── */
footer {
  border-top: 1px solid var(--border);
  color: var(--muted);
  text-align: center;
  font-size: .72rem;
  padding: 1rem;
  margin-top: 3rem;
}

/* ── Responsive ───────────────────────────────────────────────────────────────── */
@media (max-width: 580px) {
  header { padding: 0 1rem; }
  main   { padding: 1.5rem 1rem 4rem; }
  .card  { flex-direction: column; }
  .card-left { width: 100%; border-right: none; border-bottom: 1px solid var(--border); }
  .card-primary { border-top: none; }
}
</style>
</head>
<body>

<header>
  <a class="logo" href="?">View Meento</a>
  <nav>
    <a href="index.php">↑ Upload</a>
  </nav>
</header>

<main>
  <div class="hero">
    <h1>Meento</h1>
    <p>Search your media catalogue — type to explore.</p>
  </div>

  <div class="search-wrap">
    <span class="icon">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
      </svg>
    </span>
    <input id="searchInput" type="text" placeholder="Search by name, description, hash…" autocomplete="off" autofocus>
  </div>

  <div class="pagination hidden" id="pagination">
    <button class="page-btn" id="prevBtn" disabled>
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
      Prev
    </button>
    <span class="page-info" id="pageInfo"></span>
    <button class="page-btn" id="nextBtn" disabled>
      Next
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
    </button>
  </div>

  <div id="resultsList">
    <div class="state-msg">
      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4">
        <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
      </svg>
      Start typing to search the catalogue.
    </div>
  </div>
</main>

<footer>&copy; <?= date('Y') ?> View Meento &middot; All rights reserved.</footer>

<script>
(function () {
'use strict';

const list      = document.getElementById('resultsList');
const input     = document.getElementById('searchInput');
const pagination= document.getElementById('pagination');
const prevBtn   = document.getElementById('prevBtn');
const nextBtn   = document.getElementById('nextBtn');
const pageInfo  = document.getElementById('pageInfo');

let currentPage = 1;
let maxPage     = 1;
let currentQ    = '';
let searchTimer = null;

function esc(s) {
  return String(s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function fmtSize(bytes) {
  if (!bytes) return '';
  if (bytes < 1024)        return bytes + ' B';
  if (bytes < 1048576)     return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1048576).toFixed(2) + ' MB';
}

function buildCard(item) {
  const hash  = item.hash || item._file || '';
  const ext   = (item.extension || 'bin').toLowerCase();
  const href  = 'files/' + encodeURIComponent(hash) + '.' + ext;

  const imgExts = ['jpg','jpeg','png','gif','webp','bmp','svg','avif'];
  const thumb   = imgExts.includes(ext)
    ? 'files/' + encodeURIComponent(hash) + '.' + ext
    : 'thumbs/' + encodeURIComponent(hash) + '.jpg';

  const title    = item.original_filename || hash || 'Untitled';
  const sizeStr  = fmtSize(item.size);
  const desc     = item.description || '';
  const pubKey   = item.public_key   || '';
  const nodeInfo = item.node_info    || '';

  const field = (label, value, cls = '') => `
    <div class="field-row">
      <div class="field-label">${label}</div>
      ${value
        ? `<div class="field-value ${cls}">${esc(value)}</div>`
        : `<div class="field-value empty">—</div>`}
    </div>`;

  return `
<a class="card" href="${esc(href)}" target="_blank" rel="noopener">
  <div class="card-left">
    <div class="thumb-wrap">
      <img src="${esc(thumb)}" alt="${esc(title)}" loading="lazy"
           onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
      <div class="thumb-placeholder" style="display:none">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4">
          <rect x="3" y="3" width="18" height="18" rx="2"/>
          <circle cx="8.5" cy="8.5" r="1.5"/>
          <polyline points="21 15 16 10 5 21"/>
        </svg>
      </div>
    </div>
    <div class="card-primary">
      <div class="card-title" title="${esc(title)}">${esc(title)}</div>
      ${sizeStr ? `<div class="card-size">${esc(sizeStr)}</div>` : ''}
      ${ext ? `<span class="ext-badge">${esc(ext)}</span>` : ''}
    </div>
  </div>
  <div class="card-right">
    ${field('Hash', hash, 'hash')}
    ${desc     ? field('Description', desc)           : ''}
    ${pubKey   ? field('Public Key',  pubKey,  'hash') : field('Public Key', '')}
    ${nodeInfo ? field('Node Info',   nodeInfo)        : field('Node Info', '')}
  </div>
</a>`;
}

function renderEmpty(q) {
  list.innerHTML = `<div class="state-msg">
    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4">
      <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
    </svg>
    ${q ? 'No results for <strong>' + esc(q) + '</strong> on this page.' : 'No entries in this file.'}
  </div>`;
}

function renderHint() {
  list.innerHTML = `<div class="state-msg">
    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4">
      <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
    </svg>
    Start typing to search the catalogue.
  </div>`;
}

function updateNav() {
  if (maxPage <= 1) { pagination.classList.add('hidden'); return; }
  pagination.classList.remove('hidden');
  pageInfo.textContent = 'File ' + currentPage + ' / ' + maxPage;
  prevBtn.disabled = (currentPage <= 1);
  nextBtn.disabled = (currentPage >= maxPage);
}

function search(q, page) {
  fetch('?q=' + encodeURIComponent(q) + '&p=' + page)
    .then(r => r.json())
    .then(data => {
      maxPage     = data.max  || 1;
      currentPage = data.page || page;
      updateNav();
      const items = data.results || [];
      if (!items.length) { renderEmpty(q); return; }
      list.innerHTML = items.map((item, i) =>
        buildCard(item).replace('class="card"', `class="card" style="animation-delay:${i * 0.04}s"`)
      ).join('');
    })
    .catch(() => {
      list.innerHTML = '<div class="state-msg">Search error — please try again.</div>';
    });
}

// init: discover how many data files exist
fetch('?maxpage=1')
  .then(r => r.json())
  .then(d => { maxPage = d.max || 1; updateNav(); })
  .catch(() => {});

// events
input.addEventListener('input', function () {
  clearTimeout(searchTimer);
  currentQ = this.value.trim();
  currentPage = 1;
  if (!currentQ) { renderHint(); updateNav(); return; }
  searchTimer = setTimeout(() => search(currentQ, currentPage), 220);
});

prevBtn.addEventListener('click', () => {
  if (currentPage <= 1) return;
  search(currentQ, --currentPage);
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

nextBtn.addEventListener('click', () => {
  if (currentPage >= maxPage) return;
  search(currentQ, ++currentPage);
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

})();
</script>
</body>
</html>