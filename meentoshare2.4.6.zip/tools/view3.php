﻿<?php
// ============================================================
//  View Meento — PHP 7+
//  Searches across data.json, data_2.json, data_3.json …
// ============================================================

$infoDir  = __DIR__ . '/info/';
$dataDir  = __DIR__ . '/';          // data*.json lives next to this file
$thumbDir = __DIR__ . '/thumbs/';
$filesDir = __DIR__ . '/files/';

// ── helpers ──────────────────────────────────────────────────────────────────

/**
 * Resolve the path for log-file index $n.
 *   1 → data.json
 *   2 → data_2.json  …
 */
function dataFilePath(int $n): string {
    global $dataDir;
    return $dataDir . ($n === 1 ? 'data.json' : "data_{$n}.json");
}

/** Return the highest $n for which data(_n).json exists (0 = none). */
function maxDataIndex(): int {
    $n = 1;
    while (file_exists(dataFilePath($n))) $n++;
    return $n - 1;          // last existing index (0 if none)
}

/** Load and decode a data file; returns [] on failure. */
function loadDataFile(int $n): array {
    $path = dataFilePath($n);
    if (!file_exists($path)) return [];
    $decoded = json_decode(file_get_contents($path), true);
    return is_array($decoded) ? $decoded : [];
}

// ── JSON search endpoint ──────────────────────────────────────────────────────
if (isset($_GET['q'])) {
    header('Content-Type: application/json; charset=utf-8');

    $q    = strtolower(trim($_GET['q']));
    $page = max(1, (int) ($_GET['p'] ?? 1));
    $max  = maxDataIndex();

    if ($page < 1 || $page > max(1, $max)) {
        echo json_encode(['results' => [], 'max' => $max, 'page' => $page]);
        exit;
    }

    $data    = loadDataFile($page);
    $results = [];

    if ($q !== '') {
        foreach ($data as $item) {
            if (strpos(strtolower(json_encode($item)), $q) !== false) {
                $results[] = $item;
            }
        }
    } else {
        $results = $data;       // empty query → return everything on this page
    }

    echo json_encode(['results' => $results, 'max' => $max, 'page' => $page]);
    exit;
}

// ── page-count endpoint (for the nav buttons on first load) ──────────────────
if (isset($_GET['maxpage'])) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['max' => maxDataIndex()]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Meento</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Syne:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
/* ── Reset ─────────────────────────────────────────────────────────────────── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --ink:     #0e0e0e;
  --paper:   #f5f3ef;
  --card:    #ffffff;
  --bar:     #0e0e0e;
  --bar-tx:  #e8e4da;
  --accent:  #b8945a;
  --accent2: #d4a96a;
  --muted:   #8a8780;
  --border:  #dedad2;
  --tag-bg:  #f0ede6;
  --r:       8px;
  --font-d:  'Instrument Serif', Georgia, serif;
  --font-b:  'Syne', system-ui, sans-serif;
  --trans:   .18s ease;
}

html, body {
  min-height: 100vh;
  background: var(--paper);
  color: var(--ink);
  font-family: var(--font-b);
  font-size: 14px;
  line-height: 1.6;
}

/* ── Top bar ────────────────────────────────────────────────────────────────── */
header {
  position: sticky;
  top: 0;
  z-index: 200;
  background: var(--bar);
  height: 54px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 2rem;
  box-shadow: 0 1px 0 rgba(255,255,255,.07);
}

.logo {
  font-family: var(--font-d);
  font-size: 1.3rem;
  color: var(--bar-tx);
  text-decoration: none;
  letter-spacing: .01em;
}
.logo em { color: var(--accent2); font-style: italic; }

nav a {
  color: var(--bar-tx);
  text-decoration: none;
  font-size: .72rem;
  font-weight: 600;
  letter-spacing: .12em;
  text-transform: uppercase;
  padding: .3rem .8rem;
  border: 1px solid rgba(255,255,255,.2);
  border-radius: 3px;
  transition: background var(--trans), color var(--trans), border-color var(--trans);
}
nav a:hover {
  background: var(--accent);
  border-color: var(--accent);
  color: #fff;
}

/* ── Layout ─────────────────────────────────────────────────────────────────── */
main {
  max-width: 960px;
  margin: 0 auto;
  padding: 3rem 1.5rem 5rem;
}

/* ── Hero ───────────────────────────────────────────────────────────────────── */
.hero {
  text-align: center;
  margin-bottom: 2.2rem;
}
.hero h1 {
  font-family: var(--font-d);
  font-size: clamp(2.2rem, 6vw, 3.2rem);
  font-weight: 400;
  line-height: 1.1;
  margin-bottom: .4rem;
}
.hero h1 em { font-style: italic; color: var(--accent); }
.hero p {
  color: var(--muted);
  font-size: .85rem;
  letter-spacing: .04em;
}

/* ── Search bar ─────────────────────────────────────────────────────────────── */
.search-wrap {
  position: relative;
  max-width: 580px;
  margin: 0 auto 2rem;
}
.search-wrap .icon {
  position: absolute;
  left: 1rem;
  top: 50%;
  transform: translateY(-50%);
  color: var(--muted);
  pointer-events: none;
  display: flex;
}
#searchInput {
  width: 100%;
  padding: .8rem 1rem .8rem 2.8rem;
  border: 1.5px solid var(--border);
  border-radius: var(--r);
  background: #fff;
  font-family: var(--font-b);
  font-size: .9rem;
  color: var(--ink);
  outline: none;
  transition: border-color var(--trans), box-shadow var(--trans);
}
#searchInput:focus {
  border-color: var(--accent);
  box-shadow: 0 0 0 3px rgba(184,148,90,.14);
}
#searchInput::placeholder { color: #c0bdb6; }

/* ── Pagination nav ─────────────────────────────────────────────────────────── */
.pagination {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: .8rem;
  margin-bottom: 1.8rem;
}
.page-btn {
  display: inline-flex;
  align-items: center;
  gap: .4rem;
  padding: .38rem .9rem;
  border: 1.5px solid var(--border);
  border-radius: 4px;
  background: #fff;
  font-family: var(--font-b);
  font-size: .75rem;
  font-weight: 600;
  letter-spacing: .08em;
  text-transform: uppercase;
  color: var(--ink);
  cursor: pointer;
  transition: background var(--trans), border-color var(--trans), color var(--trans);
}
.page-btn:hover:not(:disabled) {
  background: var(--accent);
  border-color: var(--accent);
  color: #fff;
}
.page-btn:disabled {
  opacity: .32;
  cursor: not-allowed;
}
.page-info {
  font-size: .78rem;
  color: var(--muted);
  letter-spacing: .05em;
  min-width: 90px;
  text-align: center;
}
/* hide nav when only one file exists */
.pagination.hidden { display: none; }

/* ── Results list ───────────────────────────────────────────────────────────── */
#resultsList {
  display: flex;
  flex-direction: column;
  gap: .9rem;
}

/* ── Card (two-column on wide screens) ──────────────────────────────────────── */
.card {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: var(--r);
  overflow: hidden;
  display: flex;
  flex-direction: row;        /* side-by-side on wide */
  text-decoration: none;
  color: var(--ink);
  transition: transform var(--trans), box-shadow var(--trans);
  position: relative;
}
.card::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: var(--r);
  box-shadow: 0 0 0 0 rgba(184,148,90,.3);
  transition: box-shadow var(--trans);
  pointer-events: none;
}
.card:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 22px rgba(0,0,0,.08);
}
.card:hover::before { box-shadow: 0 0 0 2px var(--accent); }

/* left column — thumbnail + primary info */
.card-left {
  display: flex;
  flex-direction: column;
  width: 260px;
  flex-shrink: 0;
  border-right: 1px solid var(--border);
}

.thumb-wrap {
  width: 100%;
  aspect-ratio: 16 / 9;
  background: var(--tag-bg);
  overflow: hidden;
  flex-shrink: 0;
  position: relative;
}
.thumb-wrap img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
  transition: transform .3s ease;
}
.card:hover .thumb-wrap img { transform: scale(1.04); }

.thumb-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #d0ccc4;
}

.card-primary {
  padding: .75rem 1rem .9rem;
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: .28rem;
  border-top: 1px solid var(--border);
}
.card-title {
  font-size: .88rem;
  font-weight: 600;
  color: var(--ink);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.card-size {
  font-size: .74rem;
  color: var(--muted);
}

/* right column — all metadata */
.card-right {
  flex: 1;
  padding: 1.1rem 1.2rem;
  display: flex;
  flex-direction: column;
  gap: .55rem;
  overflow: hidden;
}

.field-row {
  display: flex;
  flex-direction: column;
  gap: .1rem;
  overflow: hidden;
}
.field-label {
  font-size: .62rem;
  font-weight: 700;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: var(--muted);
}
.field-value {
  font-size: .8rem;
  color: var(--ink);
  word-break: break-all;
  line-height: 1.5;
}
.field-value.hash {
  font-family: 'Courier New', monospace;
  font-size: .7rem;
  color: var(--muted);
  word-break: break-all;
}
.field-value.empty { color: var(--border); font-style: italic; }

/* ext badge */
.ext-badge {
  display: inline-block;
  padding: .15rem .5rem;
  background: var(--tag-bg);
  border: 1px solid var(--border);
  border-radius: 3px;
  font-size: .68rem;
  font-weight: 700;
  letter-spacing: .08em;
  text-transform: uppercase;
  color: var(--accent);
}

/* ── Empty / hint state ─────────────────────────────────────────────────────── */
.state-msg {
  text-align: center;
  color: var(--muted);
  font-size: .88rem;
  padding: 3.5rem 0;
}
.state-msg svg { margin-bottom: .6rem; opacity: .35; display: block; margin-left: auto; margin-right: auto; }

/* ── Responsive: small screens → stack columns ──────────────────────────────── */
@media (max-width: 640px) {
  header { padding: 0 1rem; }
  main   { padding: 2rem 1rem 4rem; }

  .card {
    flex-direction: column;
  }
  .card-left {
    width: 100%;
    border-right: none;
    border-bottom: 1px solid var(--border);
  }
  .card-primary {
    border-top: none;
    padding: .6rem .85rem .75rem;
  }
  .card-right {
    padding: .75rem .85rem 1rem;
  }
}

/* ── Animations ─────────────────────────────────────────────────────────────── */
@keyframes fadeUp {
  from { opacity: 0; transform: translateY(10px); }
  to   { opacity: 1; transform: translateY(0); }
}
.card { animation: fadeUp .22s ease both; }

/* ── Footer ─────────────────────────────────────────────────────────────────── */
footer {
  background: var(--bar);
  color: #444;
  text-align: center;
  font-size: .7rem;
  letter-spacing: .06em;
  padding: 1rem;
}
footer span { color: var(--accent); }
</style>
</head>
<body>

<header>
  <a class="logo" href="?">View <em>Meento</em></a>
  <nav>
    <a href="index.php">&#8593; Upload</a>
  </nav>
</header>

<main>
  <div class="hero">
    <h1><em>Meento</em></h1>
    <p>Search your media catalogue — type to explore.</p>
  </div>

  <!-- Search -->
  <div class="search-wrap">
    <span class="icon">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
      </svg>
    </span>
    <input id="searchInput" type="text" placeholder="Search by name, description, hash…" autocomplete="off" autofocus>
  </div>

  <!-- Pagination -->
  <div class="pagination hidden" id="pagination">
    <button class="page-btn" id="prevBtn" disabled>
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
      Prev
    </button>
    <span class="page-info" id="pageInfo">— / —</span>
    <button class="page-btn" id="nextBtn" disabled>
      Next
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
    </button>
  </div>

  <!-- Results -->
  <div id="resultsList">
    <div class="state-msg">
      <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4">
        <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
      </svg>
      Start typing to search the catalogue.
    </div>
  </div>
</main>

<footer>
  &copy; <?= date('Y') ?> &nbsp;<span>View Meento</span> &nbsp;·&nbsp; All rights reserved.
</footer>

<script>
(function () {
'use strict';

const list      = document.getElementById('resultsList');
const input     = document.getElementById('searchInput');
const pagination= document.getElementById('pagination');
const prevBtn   = document.getElementById('prevBtn');
const nextBtn   = document.getElementById('nextBtn');
const pageInfo  = document.getElementById('pageInfo');

let currentPage = 1;
let maxPage     = 1;
let currentQ    = '';
let searchTimer = null;

// ── utilities ──────────────────────────────────────────────────────────────

function esc(s) {
  return String(s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function fmtSize(bytes) {
  if (!bytes) return '';
  if (bytes < 1024)        return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

// ── card builder ───────────────────────────────────────────────────────────

function buildCard(item) {
  const hash = item.hash || item._file || '';
  const ext  = (item.extension || 'bin').toLowerCase();
  const href = 'files/' + encodeURIComponent(hash) + '.' + ext;

  const imgExts = ['jpg','jpeg','png','gif','webp','bmp','svg','avif'];
  const thumb   = imgExts.includes(ext)
    ? 'files/' + encodeURIComponent(hash) + '.' + ext
    : 'thumbs/' + encodeURIComponent(hash) + '.jpg';

  const title    = item.original_filename || hash || 'Untitled';
  const sizeStr  = fmtSize(item.size);
  const desc     = item.description || '';
  const pubKey   = item.public_key  || '';
  const nodeInfo = item.node_info   || '';

  const fieldHtml = (label, value, cls = '') => {
    const display = value
      ? `<div class="field-value ${cls}">${esc(value)}</div>`
      : `<div class="field-value empty">—</div>`;
    return `<div class="field-row">
      <div class="field-label">${label}</div>
      ${display}
    </div>`;
  };

  return `
<a class="card" href="${esc(href)}" target="_blank" rel="noopener">

  <!-- LEFT: thumbnail + primary info -->
  <div class="card-left">
    <div class="thumb-wrap">
      <img src="${esc(thumb)}" alt="${esc(title)}"
           loading="lazy"
           onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
      <div class="thumb-placeholder" style="display:none">
        <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4">
          <rect x="3" y="3" width="18" height="18" rx="2"/>
          <circle cx="8.5" cy="8.5" r="1.5"/>
          <polyline points="21 15 16 10 5 21"/>
        </svg>
      </div>
    </div>
    <div class="card-primary">
      <div class="card-title" title="${esc(title)}">${esc(title)}</div>
      ${sizeStr ? `<div class="card-size">${esc(sizeStr)}</div>` : ''}
      ${ext ? `<span class="ext-badge">${esc(ext)}</span>` : ''}
    </div>
  </div>

  <!-- RIGHT: all other fields -->
  <div class="card-right">
    ${fieldHtml('Hash', hash, 'hash')}
    ${desc     ? fieldHtml('Description', desc)          : ''}
    ${pubKey   ? fieldHtml('Public Key',  pubKey,  'hash') : fieldHtml('Public Key', '')}
    ${nodeInfo ? fieldHtml('Node Info',   nodeInfo)       : fieldHtml('Node Info', '')}
  </div>

</a>`;
}

// ── render helpers ─────────────────────────────────────────────────────────

function renderEmpty(q) {
  const msg = q
    ? `No results for <strong>${esc(q)}</strong> on this page.`
    : 'No entries in this file.';
  list.innerHTML = `<div class="state-msg">
    <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4">
      <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
    </svg>
    ${msg}
  </div>`;
}

function renderHint() {
  list.innerHTML = `<div class="state-msg">
    <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4">
      <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
    </svg>
    Start typing to search the catalogue.
  </div>`;
}

function updateNav() {
  if (maxPage <= 1) {
    pagination.classList.add('hidden');
    return;
  }
  pagination.classList.remove('hidden');
  pageInfo.textContent = 'File ' + currentPage + ' / ' + maxPage;
  prevBtn.disabled = (currentPage <= 1);
  nextBtn.disabled = (currentPage >= maxPage);
}

// ── fetch & display ────────────────────────────────────────────────────────

function search(q, page) {
  const url = '?q=' + encodeURIComponent(q) + '&p=' + page;
  fetch(url)
    .then(r => r.json())
    .then(data => {
      maxPage     = data.max  || 1;
      currentPage = data.page || page;
      updateNav();

      const items = data.results || [];
      if (!items.length) { renderEmpty(q); return; }

      // stagger card animations
      list.innerHTML = items.map((item, i) => {
        const card = buildCard(item);
        // inject animation-delay via a wrapper trick
        return card.replace('class="card"', `class="card" style="animation-delay:${i * 0.04}s"`);
      }).join('');
    })
    .catch(() => {
      list.innerHTML = '<div class="state-msg">Search error — please try again.</div>';
    });
}

// ── init: discover how many data files exist ───────────────────────────────

fetch('?maxpage=1')
  .then(r => r.json())
  .then(d => {
    maxPage = d.max || 1;
    updateNav();
  })
  .catch(() => {});

// ── events ─────────────────────────────────────────────────────────────────

input.addEventListener('input', function () {
  clearTimeout(searchTimer);
  currentQ = this.value.trim();
  currentPage = 1;

  if (!currentQ) { renderHint(); updateNav(); return; }

  searchTimer = setTimeout(() => search(currentQ, currentPage), 220);
});

prevBtn.addEventListener('click', () => {
  if (currentPage <= 1) return;
  currentPage--;
  search(currentQ, currentPage);
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

nextBtn.addEventListener('click', () => {
  if (currentPage >= maxPage) return;
  currentPage++;
  search(currentQ, currentPage);
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

})();
</script>
</body>
</html>