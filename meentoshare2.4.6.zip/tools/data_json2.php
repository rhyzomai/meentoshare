﻿<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  DATA LOG  —  optional rolling JSON append logger
//  Compatible with: Mesh Node (index.php) · PHP 7+
//
//  HOW TO USE
//  ──────────
//  Drop this file next to index.php, then add ONE line anywhere after a
//  successful storeLocally() call (the $local array must be in scope):
//
//      require_once __DIR__ . '/data_log.php';
//      DataLog::append($local['hash']);   // writes the info JSON to the log
//
//  Or call it right after the storeLocally() block inside index.php:
//
//      $local = storeLocally(...);
//      if ($local['ok']) {
//          require_once __DIR__ . '/data_log.php';
//          DataLog::append($local['hash']);
//      }
//
//  BEHAVIOUR
//  ─────────
//  • Reads  info/<hash>.json  (written by storeLocally) and appends its
//    decoded contents as a new JSON object into the rolling log.
//
//  • Log files are kept inside  ./data_log/  (created automatically).
//    Sequence:  data.json → data_2.json → data_3.json → …
//
//  • A file is considered "full" once it reaches or exceeds MAX_BYTES.
//    The next write always goes to the first file that is still below the
//    limit.  If all existing files are full a new numbered file is created.
//
//  • Each log file is a JSON array.  New entries are appended to the array
//    without rewriting the whole file (only the closing bracket is patched),
//    so the operation is fast regardless of how large the file has grown.
//
//  • Concurrent writes are serialised with an exclusive flock() so entries
//    are never corrupted under parallel requests.
//
//  CONFIGURATION  (optional — edit the constants below)
//  ─────────────
//  DATA_LOG_DIR      directory that holds the log files  (default: ./data_log)
//  DATA_LOG_MAX_BYTES  per-file size cap in bytes         (default: 100 KB)
// ═══════════════════════════════════════════════════════════════════════════════

if (!defined('DATA_LOG_DIR')) {
    define('DATA_LOG_DIR', __DIR__ . '/');
}

if (!defined('DATA_LOG_MAX_BYTES')) {
    define('DATA_LOG_MAX_BYTES', 100 * 1024);   // 100 KB
}

class DataLog
{
    // ── public API ────────────────────────────────────────────────────────────

    /**
     * Append the info record for $hash to the current rolling log file.
     *
     * @param  string $hash   SHA-256 hash returned by storeLocally()
     * @return array{ok:bool, file:string, error?:string}
     */
    public static function append(string $hash): void
    {
        // Capture any accidental output (notices, warnings) so nothing
        // leaks into index.php's JSON response.
        ob_start();
        $prev = error_reporting(0);

        try {
            // 1. Resolve the source info JSON written by storeLocally()
            $infoPath = INFO_DIR . '/' . $hash . '.json';
            if (!file_exists($infoPath)) return;

            $raw = @file_get_contents($infoPath);
            if ($raw === false) return;

            $info = json_decode($raw, true);
            if (!is_array($info)) return;

            // 2. Attach the hash itself so each log entry is self-contained
            $entry = array_merge(['hash' => $hash], $info);

            // 3. Ensure the log directory exists
            if (!is_dir(DATA_LOG_DIR)) {
                @mkdir(DATA_LOG_DIR, 0755, true);
                if (!is_dir(DATA_LOG_DIR)) return;
            }

            // 4. Pick the target log file
            $targetFile = self::resolveTargetFile();

            // 5. Write (with exclusive lock to handle concurrency)
            self::writeEntry($targetFile, $entry);

        } catch (\Throwable $e) {
            // Silently discard — must never affect index.php's output
        } finally {
            error_reporting($prev);
            ob_end_clean(); // discard any captured output, never echo it
        }
    }

    // ── internals ─────────────────────────────────────────────────────────────

    /**
     * Return the path of the log file that should receive the next entry.
     * Walks data.json, data_2.json, data_3.json … and stops at the first
     * file whose size is below the cap.  If none qualifies a new file is
     * created with the next sequence number.
     */
    private static function resolveTargetFile(): string
    {
        $n = 1;
        while (true) {
            $path = self::logPath($n);

            if (!file_exists($path)) {
                // New file — initialise it with an empty JSON array
                file_put_contents($path, "[\n]", LOCK_EX);
                return $path;
            }

            if (filesize($path) < DATA_LOG_MAX_BYTES) {
                return $path;   // still has room
            }

            $n++;   // this file is full — try the next one
        }
    }

    /**
     * Translate a sequence number to a file path.
     *   1  →  data_log/data.json
     *   2  →  data_log/data_2.json
     *   3  →  data_log/data_3.json  …
     */
    private static function logPath(int $n): string
    {
        $name = ($n === 1) ? 'data.json' : "data_{$n}.json";
        return DATA_LOG_DIR . '/' . $name;
    }

    /**
     * Append $entry to the JSON array stored in $filePath.
     *
     * Strategy (no full-file rewrite):
     *   • The file is a JSON array: [  {…}, {…}  ]
     *   • We open it, seek to just before the closing ']', inject a comma
     *     (if the array is not empty) + the new JSON object, then write ']'.
     *
     * Returns true on success, false on failure.
     */
    private static function writeEntry(string $filePath, array $entry): bool
    {
        $fp = fopen($filePath, 'c+');   // open for read+write, no truncate
        if ($fp === false) {
            return false;
        }

        if (!flock($fp, LOCK_EX)) {
            fclose($fp);
            return false;
        }

        // Read current content (needed to detect empty array and find the ']')
        $content = stream_get_contents($fp);
        if ($content === false) {
            flock($fp, LOCK_UN);
            fclose($fp);
            return false;
        }

        $content = rtrim($content);

        // Find the position of the last ']' — that is where we inject
        $closingPos = strrpos($content, ']');
        if ($closingPos === false) {
            // Malformed file — overwrite with a fresh single-element array
            $newContent = "[\n"
                . '    ' . json_encode($entry, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
                . "\n]";
            rewind($fp);
            ftruncate($fp, 0);
            fwrite($fp, $newContent);
            flock($fp, LOCK_UN);
            fclose($fp);
            return true;
        }

        // Everything before the ']'
        $before = rtrim(substr($content, 0, $closingPos));

        // Is the array currently empty?  ("[\n]" or "[]")
        $isEmpty = (trim(substr($content, 1, $closingPos - 1)) === '');

        $encodedEntry = json_encode($entry, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

        // Indent each line of the pretty-printed object by 4 spaces
        $indented = implode("\n", array_map(
            static fn(string $line) => '    ' . $line,
            explode("\n", $encodedEntry)
        ));

        if ($isEmpty) {
            $newContent = "[\n" . $indented . "\n]";
        } else {
            $newContent = $before . ",\n" . $indented . "\n]";
        }

        // Overwrite the file with the updated content
        rewind($fp);
        ftruncate($fp, 0);
        $written = fwrite($fp, $newContent);

        flock($fp, LOCK_UN);
        fclose($fp);

        return $written !== false;
    }
}