Quick guide
===========

1) Upload your files using "index.php" or "index_full.php" (account creation required).
2) Open "indexer.php" and click in "Run Sync Engine". So the JSON files will be migrated to MySQL.
3) Open "feed.php" or "feed_full.php" for a modern view and navigation of content uploaded in your server and in the others.

