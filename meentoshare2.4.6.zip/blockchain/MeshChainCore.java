import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * MeshChainCore � Minimal Blockchain Micro Core
 * -------------------------------------------------------------------------------
 *
 * PURPOSE
 *   Provide the smallest possible, secure, self-contained blockchain kernel
 *   whose ONLY responsibilities are:
 *     1. Manage RSA-2048 key pairs (miner identity).
 *     2. Build, sign, hash, store, and verify blocks.
 *     3. Elect the "server public key" by majority vote across mesh servers
 *        (reads /info/<hash>.json from each server in servers.txt).
 *     4. Expose clean extension points (interfaces + static hooks) so that
 *        consensus rules, storage, networking, REST APIs, etc. can be plugged
 *        in as separate modules / Spring Boot beans without touching this file.
 *
 * WHAT THIS FILE DELIBERATELY OMITS (add as modules):
 *   - Proof-of-work / proof-of-storage difficulty loop
 *   - File downloading / caching pipeline
 *   - Coin reward accounting / balance queries
 *   - P2P block propagation
 *   - HTTP server / REST endpoints
 *   - Persistence backends (DB, IPFS, etc.)
 *   - Admin UI / CLI menus
 *
 * MODULARISATION CONTRACT
 *   Every extension point is a Java interface declared in the "Extension Points"
 *   section below. Replace the default no-op or in-process implementations with
 *   your own beans/services. The core never calls anything outside those
 *   interfaces (except java.* and javax.crypto.*).
 *
 * BLOCK JSON SCHEMA (canonical � do NOT add fields; extend via metadata map)
 *   {
 *     "v"                 : 1,               // schema version
 *     "index"             : <long>,
 *     "timestamp"         : <long ms>,
 *     "file_ref"          : "<sha256>.<ext>", // mesh filename that anchors this block
 *     "file_hash"         : "<sha256>",       // bare hash (strip extension)
 *     "previous_hash"     : "<hex64>",
 *     "miner_key"         : "<base64 RSA pub>",
 *     "server_key"        : "<base64 RSA pub | empty>",
 *     "metadata"          : {},              // free JSON object � modules write here
 *     "block_hash"        : "<sha256 of above canonical string>",
 *     "signature"         : "<base64 RSA-SHA256 over canonical string>"
 *   }
 *
 * SECURITY PROPERTIES
 *   - RSA-2048 / SHA-256withRSA for all signing.
 *   - Block hash covers every field; prev-hash links the chain.
 *   - Majority vote (strict > 50 %) for server public key election.
 *   - HTTPS preferred; HTTP allowed for local/dev networks.
 *   - No eval / reflection / serialisation of untrusted data.
 *   - All I/O within the BLOCKS_DIR sandbox; no path traversal possible.
 *
 * COMPATIBILITY: Java 8+, zero external libraries.
 *
 * TYPICAL INTEGRATION (Spring Boot example):
 *   @Bean MeshChainCore core() {
 *       MeshChainCore c = new MeshChainCore();
 *       c.setBlockStore(new JpaBlockStore(...));      // swap storage
 *       c.setConsensusMechanism(new PoWConsensus()); // swap consensus
 *       c.setEventBus(applicationEventPublisher::publishEvent);
 *       return c;
 *   }
 */
public class MeshChainCore {

    // -- tunables (override via setters before first use) ------------------------
    private String  blocksDir       = "json_blocks";
    private String  keysDir         = "keys";
    private String  serversFile     = "servers.txt";
    private int     connectMs       = 8_000;
    private int     readMs          = 30_000;
    private int     threadPool      = 16;
    private int     schemaVersion   = 1;

    // -- extension-point implementations (swappable) -----------------------------
    private BlockStore          blockStore          = new DefaultFileBlockStore();
    private ConsensusMechanism  consensusMechanism  = new NoOpConsensusMechanism();
    private EventSink           eventSink           = msg -> {};   // no-op by default

    // -- cached key pair (lazy-loaded) --------------------------------------------
    private KeyPair keyPair;

    // ----------------------------------------------------------------------------
    // EXTENSION POINTS � implement these in your modules
    // ----------------------------------------------------------------------------

    /**
     * Where blocks are persisted.
     * Default: one JSON file per block under blocksDir/.
     * Replace with a JPA, MongoDB, or IPFS implementation.
     */
    public interface BlockStore {
        /** Persist a block. Throw if already exists or integrity fails. */
        void save(Block block) throws Exception;
        /** Return all blocks ordered by index ascending. */
        List<Block> loadAll() throws Exception;
        /** Return the block with the highest index, or null if empty. */
        Block loadLatest() throws Exception;
        /** Return block count. */
        long count() throws Exception;
    }

    /**
     * Pluggable consensus gate.
     * The core calls {@code check()} before building any block. Return false
     * to abort. Default: always returns true (no gate � add PoW / PoStorage etc.).
     */
    public interface ConsensusMechanism {
        /**
         * @param fileRef   mesh filename that will anchor the new block
         * @param servers   reachable server base-URLs from servers.txt
         * @return true if the caller has earned the right to add a block
         */
        boolean check(String fileRef, List<String> servers) throws Exception;
    }

    /**
     * Minimal event bus interface.
     * Fire domain events so external modules (wallets, explorers, P2P sync)
     * can react without being coupled to this class.
     */
    public interface EventSink {
        void emit(String eventJson);
    }

    // ----------------------------------------------------------------------------
    // BLOCK VALUE OBJECT
    // ----------------------------------------------------------------------------

    /** Immutable block. Build via {@link BlockBuilder}. */
    public static final class Block {
        public final int    version;
        public final long   index;
        public final long   timestamp;
        public final String fileRef;        // e.g. "abc123.jpg"
        public final String fileHash;       // bare sha256 hex
        public final String previousHash;
        public final String minerKey;       // base64 RSA public key
        public final String serverKey;      // majority-voted server public key (may be "")
        public final String metadata;       // raw JSON object string "{...}"
        public final String blockHash;      // sha256 of canonical string
        public final String signature;      // base64 RSA-SHA256

        private Block(int version, long index, long timestamp,
                      String fileRef, String fileHash,
                      String previousHash, String minerKey, String serverKey,
                      String metadata, String blockHash, String signature) {
            this.version      = version;
            this.index        = index;
            this.timestamp    = timestamp;
            this.fileRef      = fileRef;
            this.fileHash     = fileHash;
            this.previousHash = previousHash;
            this.minerKey     = minerKey;
            this.serverKey    = serverKey;
            this.metadata     = metadata;
            this.blockHash    = blockHash;
            this.signature    = signature;
        }

        /** Serialise to canonical JSON (preserves field order for hashing). */
        public String toJson() {
            return "{\n" +
                "  \"v\":"            + version                     + ",\n" +
                "  \"index\":"        + index                       + ",\n" +
                "  \"timestamp\":"    + timestamp                   + ",\n" +
                "  \"file_ref\":\""   + esc(fileRef)    + "\",\n"  +
                "  \"file_hash\":\""  + esc(fileHash)   + "\",\n"  +
                "  \"previous_hash\":\"" + esc(previousHash) + "\",\n" +
                "  \"miner_key\":\""  + esc(minerKey)   + "\",\n"  +
                "  \"server_key\":\"" + esc(serverKey)  + "\",\n"  +
                "  \"metadata\":"     + (metadata == null || metadata.isEmpty() ? "{}" : metadata) + ",\n" +
                "  \"block_hash\":\"" + esc(blockHash)  + "\",\n"  +
                "  \"signature\":\""  + esc(signature)  + "\"\n"   +
                "}";
        }

        /** Human-readable summary (not canonical). */
        @Override public String toString() {
            return "Block{index=" + index +
                   ", fileRef=" + fileRef +
                   ", hash=" + blockHash.substring(0, 12) + "..." +
                   ", miner=" + minerKey.substring(0, 20) + "...}";
        }
    }

    // ----------------------------------------------------------------------------
    // BLOCK BUILDER � fluent, used internally and by extension modules
    // ----------------------------------------------------------------------------

    public static final class BlockBuilder {
        private int    version      = 1;
        private long   index;
        private long   timestamp    = System.currentTimeMillis();
        private String fileRef      = "";
        private String fileHash     = "";
        private String previousHash = "0000000000000000000000000000000000000000000000000000000000000000";
        private String minerKey     = "";
        private String serverKey    = "";
        private String metadata     = "{}";

        public BlockBuilder version(int v)       { this.version      = v;  return this; }
        public BlockBuilder index(long v)        { this.index        = v;  return this; }
        public BlockBuilder timestamp(long v)    { this.timestamp    = v;  return this; }
        public BlockBuilder fileRef(String v)    { this.fileRef      = v;  return this; }
        public BlockBuilder fileHash(String v)   { this.fileHash     = v;  return this; }
        public BlockBuilder previousHash(String v){ this.previousHash = v;  return this; }
        public BlockBuilder minerKey(String v)   { this.minerKey     = v;  return this; }
        public BlockBuilder serverKey(String v)  { this.serverKey    = v;  return this; }
        public BlockBuilder metadata(String v)   { this.metadata     = v;  return this; }

        /**
         * Compute hash and sign, then return the immutable Block.
         * @param privateKey RSA private key used to sign
         */
        public Block build(PrivateKey privateKey) throws Exception {
            // canonical string = everything except blockHash and signature
            String canonical = canonicalString(version, index, timestamp,
                    fileRef, fileHash, previousHash, minerKey, serverKey, metadata);
            String hash = sha256Hex(canonical.getBytes(StandardCharsets.UTF_8));
            String sig  = signBase64(canonical.getBytes(StandardCharsets.UTF_8), privateKey);
            return new Block(version, index, timestamp,
                    fileRef, fileHash, previousHash, minerKey, serverKey,
                    metadata, hash, sig);
        }
    }

    // ----------------------------------------------------------------------------
    // CORE PUBLIC API
    // ----------------------------------------------------------------------------

    /**
     * Initialise directories and load (or generate) the local RSA key pair.
     * Call once at application startup.
     */
    public synchronized void init() throws Exception {
        new File(blocksDir).mkdirs();
        new File(keysDir).mkdirs();
        keyPair = loadOrGenerateKeys();
        eventSink.emit("{\"event\":\"CORE_INIT\",\"key\":\"" +
                esc(myPublicKeyBase64().substring(0, 40)) + "...\"}");
    }

    /**
     * Return the local node's public key as Base64.
     * Requires {@link #init()} to have been called.
     */
    public String myPublicKeyBase64() throws Exception {
        if (keyPair == null) throw new IllegalStateException("Call init() first.");
        return encodeBase64(keyPair.getPublic().getEncoded());
    }

    /**
     * Main block-minting entry point.
     *
     * <pre>
     * Flow:
     *   1. Load servers.txt ? list of mesh server base-URLs.
     *   2. Poll each server's /info/<fileHash>.json ? collect "public_key" votes.
     *   3. Elect server public key by strict majority (> 50 %).
     *   4. Ask ConsensusMechanism.check() � abort if it returns false.
     *   5. Build, sign, hash, and persist the block via BlockStore.
     *   6. Emit BLOCK_ADDED event.
     * </pre>
     *
     * @param fileRef  Mesh filename (e.g. "abc123def...789.jpg") that anchors this block.
     *                 Must be a name appearing in at least one server's files.txt.
     *                 Uniqueness enforcement is the BlockStore's responsibility.
     * @param metadata Optional extra JSON object string "{...}" (modules write their data here).
     *                 Pass null or "{}" for none.
     * @return The newly created and persisted Block.
     * @throws Exception if consensus fails, signing fails, or BlockStore rejects the block.
     */
    public Block mintBlock(String fileRef, String metadata) throws Exception {
        if (keyPair == null) throw new IllegalStateException("Call init() first.");

        // 1. Load servers
        List<String> servers = loadServers();

        // 2. Elect server public key via majority vote over /info/ JSON files
        String fileHash    = stripExtension(fileRef).toLowerCase();
        String serverKey   = electServerPublicKey(fileHash, servers);

        // 3. Consensus gate � throws or returns false to abort
        if (!consensusMechanism.check(fileRef, servers)) {
            throw new IllegalStateException(
                "Consensus mechanism rejected block for: " + fileRef);
        }

        // 4. Chain state
        Block  latest      = blockStore.loadLatest();
        long   prevIdx     = (latest == null) ? 0L   : latest.index;
        String prevHash    = (latest == null) ? "0000000000000000000000000000000000000000000000000000000000000000"
                                              : latest.blockHash;
        String myKey       = encodeBase64(keyPair.getPublic().getEncoded());
        String meta        = (metadata == null || metadata.trim().isEmpty()) ? "{}" : metadata.trim();

        // 5. Build and sign
        Block block = new BlockBuilder()
                .version(schemaVersion)
                .index(prevIdx + 1)
                .timestamp(System.currentTimeMillis())
                .fileRef(fileRef)
                .fileHash(fileHash)
                .previousHash(prevHash)
                .minerKey(myKey)
                .serverKey(serverKey == null ? "" : serverKey)
                .metadata(meta)
                .build(keyPair.getPrivate());

        // 6. Persist
        blockStore.save(block);

        // 7. Emit
        eventSink.emit("{\"event\":\"BLOCK_ADDED\",\"index\":" + block.index +
                ",\"hash\":\"" + block.blockHash + "\"}");

        return block;
    }

    /**
     * Verify the entire chain: hash integrity, prev-hash linkage, RSA signatures.
     *
     * @return list of error strings (empty = chain is valid)
     */
    public List<String> verifyChain() throws Exception {
        List<Block>  chain  = blockStore.loadAll();
        List<String> errors = new ArrayList<>();
        String prevHash = "0000000000000000000000000000000000000000000000000000000000000000";

        for (Block b : chain) {
            // a) re-compute hash
            String canonical = canonicalString(b.version, b.index, b.timestamp,
                    b.fileRef, b.fileHash, b.previousHash, b.minerKey, b.serverKey, b.metadata);
            String reHash = sha256Hex(canonical.getBytes(StandardCharsets.UTF_8));
            if (!reHash.equals(b.blockHash)) {
                errors.add("Block " + b.index + ": hash mismatch");
            }

            // b) chain linkage
            if (!b.previousHash.equals(prevHash)) {
                errors.add("Block " + b.index + ": previous_hash break");
            }

            // c) RSA signature
            try {
                byte[] pubBytes = decodeBase64(b.minerKey);
                PublicKey pub   = KeyFactory.getInstance("RSA")
                        .generatePublic(new X509EncodedKeySpec(pubBytes));
                Signature sig   = Signature.getInstance("SHA256withRSA");
                sig.initVerify(pub);
                sig.update(canonical.getBytes(StandardCharsets.UTF_8));
                if (!sig.verify(decodeBase64(b.signature))) {
                    errors.add("Block " + b.index + ": signature invalid");
                }
            } catch (Exception e) {
                errors.add("Block " + b.index + ": signature error (" + e.getMessage() + ")");
            }

            prevHash = b.blockHash;
        }
        return errors;
    }

    /**
     * Parse a block from its canonical JSON string.
     * Used by import / P2P sync modules.
     */
    public static Block parseBlock(String json) {
        return new Block(
            (int) parseLong(extractField(json, "v")),
            parseLong(extractField(json, "index")),
            parseLong(extractField(json, "timestamp")),
            extractField(json, "file_ref"),
            extractField(json, "file_hash"),
            extractField(json, "previous_hash"),
            extractField(json, "miner_key"),
            extractField(json, "server_key"),
            extractObjectField(json, "metadata"),
            extractField(json, "block_hash"),
            extractField(json, "signature")
        );
    }

    // ----------------------------------------------------------------------------
    // SERVER PUBLIC KEY ELECTION (mesh-majority vote)
    // ----------------------------------------------------------------------------

    /**
     * For each server in servers.txt, fetch /info/<fileHash>.json and read
     * the "public_key" field. Returns the key that appears in a strict majority
     * (> 50 %) of responding servers, or null if no majority exists.
     *
     * This method is intentionally public so that extension modules (e.g. a
     * scheduled task that pre-caches election results) can call it directly.
     */
    public String electServerPublicKey(String fileHash, List<String> servers) {
        if (servers == null || servers.isEmpty()) return null;

        ExecutorService pool = Executors.newFixedThreadPool(
                Math.min(threadPool, servers.size()));
        List<Future<String>> futures = new ArrayList<>();

        for (final String base : servers) {
            futures.add(pool.submit(new Callable<String>() {
                public String call() {
                    String url  = base + "/info/" + fileHash + ".json";
                    String json = fetchText(url);
                    if (json == null) return "";
                    return extractField(json, "public_key");
                }
            }));
        }
        pool.shutdown();
        try { pool.awaitTermination(readMs, TimeUnit.MILLISECONDS); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }

        List<String> votes = new ArrayList<>();
        for (Future<String> f : futures) {
            try { String v = f.get(); if (v != null) votes.add(v); }
            catch (Exception ignored) {}
        }
        return majorityVote(votes);
    }

    // ----------------------------------------------------------------------------
    // DEFAULT BLOCK STORE (files under blocksDir/)
    // ----------------------------------------------------------------------------

    private class DefaultFileBlockStore implements BlockStore {

        @Override
        public void save(Block block) throws Exception {
            File dir  = new File(blocksDir);
            dir.mkdirs();
            // file name = <index>_<fileHash>.json � collision-safe and sortable
            String name = String.format("%020d_%s.json", block.index, block.fileHash);
            File   dest = new File(dir, name);
            if (dest.exists()) {
                throw new IOException("Block file already exists: " + dest.getPath());
            }
            // Atomic write: write to tmp then rename
            File tmp = new File(dir, name + ".tmp");
            try (FileOutputStream fos = new FileOutputStream(tmp)) {
                fos.write(block.toJson().getBytes(StandardCharsets.UTF_8));
            }
            if (!tmp.renameTo(dest)) {
                tmp.delete();
                throw new IOException("Could not atomically save block: " + dest.getPath());
            }
        }

        @Override
        public List<Block> loadAll() throws Exception {
            File dir = new File(blocksDir);
            if (!dir.exists()) return Collections.emptyList();
            File[] files = dir.listFiles(f -> f.getName().endsWith(".json"));
            if (files == null || files.length == 0) return Collections.emptyList();
            Arrays.sort(files, Comparator.comparing(File::getName));
            List<Block> out = new ArrayList<>();
            for (File f : files) {
                String json = readUtf8(f);
                out.add(parseBlock(json));
            }
            return out;
        }

        @Override
        public Block loadLatest() throws Exception {
            List<Block> all = loadAll();
            return all.isEmpty() ? null : all.get(all.size() - 1);
        }

        @Override
        public long count() throws Exception {
            File dir = new File(blocksDir);
            if (!dir.exists()) return 0L;
            File[] files = dir.listFiles(f -> f.getName().endsWith(".json"));
            return (files == null) ? 0L : files.length;
        }
    }

    // ----------------------------------------------------------------------------
    // DEFAULT CONSENSUS � no gate (modules replace this)
    // ----------------------------------------------------------------------------

    private static final class NoOpConsensusMechanism implements ConsensusMechanism {
        @Override
        public boolean check(String fileRef, List<String> servers) { return true; }
    }

    // ----------------------------------------------------------------------------
    // KEY MANAGEMENT (RSA-2048)
    // ----------------------------------------------------------------------------

    private KeyPair loadOrGenerateKeys() throws Exception {
        File privFile = new File(keysDir + "/private.key");
        File pubFile  = new File(keysDir + "/public.key");
        if (privFile.exists() && pubFile.exists()) {
            byte[] privBytes = readBytes(privFile);
            byte[] pubBytes  = readBytes(pubFile);
            KeyFactory kf = KeyFactory.getInstance("RSA");
            PrivateKey priv = kf.generatePrivate(new PKCS8EncodedKeySpec(decodeBase64(new String(privBytes, StandardCharsets.UTF_8).trim())));
            PublicKey  pub  = kf.generatePublic (new X509EncodedKeySpec  (decodeBase64(new String(pubBytes,  StandardCharsets.UTF_8).trim())));
            return new KeyPair(pub, priv);
        }
        // Generate new pair
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        kpg.initialize(2048, new SecureRandom());
        KeyPair kp = kpg.generateKeyPair();
        writeUtf8(privFile, encodeBase64(kp.getPrivate().getEncoded()));
        writeUtf8(pubFile,  encodeBase64(kp.getPublic() .getEncoded()));
        return kp;
    }

    // ----------------------------------------------------------------------------
    // CANONICAL STRING  (what gets hashed and signed)
    // ----------------------------------------------------------------------------

    static String canonicalString(int version, long index, long timestamp,
                                  String fileRef, String fileHash,
                                  String previousHash, String minerKey, String serverKey,
                                  String metadata) {
        // Strict order, no whitespace variation, no nulls
        return "v="        + version      + "\n" +
               "index="    + index        + "\n" +
               "ts="        + timestamp   + "\n" +
               "file_ref=" + safe(fileRef)      + "\n" +
               "file_hash=" + safe(fileHash)    + "\n" +
               "prev="     + safe(previousHash) + "\n" +
               "miner="    + safe(minerKey)     + "\n" +
               "server="   + safe(serverKey)    + "\n" +
               "meta="     + safe(metadata == null ? "{}" : metadata);
    }

    // ----------------------------------------------------------------------------
    // CRYPTO HELPERS
    // ----------------------------------------------------------------------------

    static String sha256Hex(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest    = md.digest(data);
            StringBuilder sb = new StringBuilder(64);
            for (byte b : digest) sb.append(String.format("%02x", b & 0xff));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) { throw new RuntimeException(e); }
    }

    static String signBase64(byte[] data, PrivateKey key) throws Exception {
        Signature sig = Signature.getInstance("SHA256withRSA");
        sig.initSign(key);
        sig.update(data);
        return encodeBase64(sig.sign());
    }

    static String encodeBase64(byte[] data) {
        return Base64.getEncoder().encodeToString(data);
    }

    static byte[] decodeBase64(String s) {
        return Base64.getDecoder().decode(s.trim());
    }

    // ----------------------------------------------------------------------------
    // NETWORK HELPERS
    // ----------------------------------------------------------------------------

    private String fetchText(String rawUrl) {
        try {
            // Validate URL to prevent SSRF to unexpected schemes
            URL u = new URL(rawUrl);
            String proto = u.getProtocol();
            if (!"http".equals(proto) && !"https".equals(proto)) return null;
            HttpURLConnection conn = (HttpURLConnection) u.openConnection();
            conn.setConnectTimeout(connectMs);
            conn.setReadTimeout(readMs);
            conn.setRequestProperty("User-Agent", "MeshChainCore/1.0");
            conn.setInstanceFollowRedirects(false); // don't follow to unexpected hosts
            if (conn.getResponseCode() != 200) return null;
            try (InputStream is = conn.getInputStream()) {
                return new String(readAllBytes(is), StandardCharsets.UTF_8);
            }
        } catch (Exception e) { return null; }
    }

    private static byte[] readAllBytes(InputStream is) throws IOException {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] chunk = new byte[8192]; int n;
        while ((n = is.read(chunk)) != -1) buf.write(chunk, 0, n);
        return buf.toByteArray();
    }

    // ----------------------------------------------------------------------------
    // FILE HELPERS
    // ----------------------------------------------------------------------------

    private List<String> loadServers() {
        File f = new File(serversFile);
        if (!f.exists()) return Collections.emptyList();
        List<String> out = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                if (!line.matches("(?i)https?://.*")) line = "http://" + line;
                // Strip trailing filename segment (e.g. index.php)
                line = deriveBaseUrl(line);
                out.add(line);
            }
        } catch (IOException e) { /* return partial list */ }
        return out;
    }

    private static String readUtf8(File f) throws IOException {
        try (FileInputStream fis = new FileInputStream(f)) {
            return new String(readAllBytes(fis), StandardCharsets.UTF_8);
        }
    }

    private static byte[] readBytes(File f) throws IOException {
        try (FileInputStream fis = new FileInputStream(f)) {
            return readAllBytes(fis);
        }
    }

    private static void writeUtf8(File f, String s) throws IOException {
        f.getParentFile().mkdirs();
        try (FileOutputStream fos = new FileOutputStream(f)) {
            fos.write(s.getBytes(StandardCharsets.UTF_8));
        }
    }

    // ----------------------------------------------------------------------------
    // STRING / JSON HELPERS (no external libs)
    // ----------------------------------------------------------------------------

    /** Majority vote: returns value with > 50 % share, or null. */
    static String majorityVote(List<String> votes) {
        if (votes == null || votes.isEmpty()) return null;
        Map<String, Integer> counts = new LinkedHashMap<>();
        for (String v : votes) {
            if (v != null && !v.isEmpty()) counts.merge(v, 1, Integer::sum);
        }
        int threshold = votes.size() / 2; // strict majority requires > half
        String best = null; int bestCount = 0;
        for (Map.Entry<String, Integer> e : counts.entrySet()) {
            if (e.getValue() > bestCount) { bestCount = e.getValue(); best = e.getKey(); }
        }
        return (bestCount > threshold) ? best : null;
    }

    /** Extract a string or primitive field value from a naive JSON string. */
    static String extractField(String json, String field) {
        if (json == null) return "";
        String search = "\"" + field + "\"";
        int idx = json.indexOf(search);
        if (idx < 0) return "";
        int colon = json.indexOf(':', idx + search.length());
        if (colon < 0) return "";
        int start = colon + 1;
        while (start < json.length() && Character.isWhitespace(json.charAt(start))) start++;
        if (start >= json.length()) return "";
        char first = json.charAt(start);
        if (first == '"') {
            StringBuilder sb = new StringBuilder();
            int i = start + 1;
            while (i < json.length()) {
                char c = json.charAt(i);
                if (c == '\\' && i + 1 < json.length()) {
                    char esc = json.charAt(i + 1);
                    switch (esc) {
                        case '"':  sb.append('"');  break;
                        case '\\': sb.append('\\'); break;
                        case 'n':  sb.append('\n'); break;
                        case 'r':  sb.append('\r'); break;
                        case 't':  sb.append('\t'); break;
                        default:   sb.append(esc);  break;
                    }
                    i += 2;
                } else if (c == '"') { break; }
                else { sb.append(c); i++; }
            }
            return sb.toString();
        } else {
            int end = start;
            while (end < json.length() &&
                   json.charAt(end) != ',' &&
                   json.charAt(end) != '}' &&
                   json.charAt(end) != ']') end++;
            return json.substring(start, end).trim();
        }
    }

    /**
     * Extract a JSON *object* value (returns the raw "{...}" string).
     * Used for the "metadata" field so modules can parse it themselves.
     */
    static String extractObjectField(String json, String field) {
        if (json == null) return "{}";
        String search = "\"" + field + "\"";
        int idx = json.indexOf(search);
        if (idx < 0) return "{}";
        int colon = json.indexOf(':', idx + search.length());
        if (colon < 0) return "{}";
        int start = colon + 1;
        while (start < json.length() && Character.isWhitespace(json.charAt(start))) start++;
        if (start >= json.length() || json.charAt(start) != '{') return "{}";
        // Scan to matching closing brace
        int depth = 0;
        int i = start;
        while (i < json.length()) {
            char c = json.charAt(i);
            if      (c == '{') depth++;
            else if (c == '}') { depth--; if (depth == 0) return json.substring(start, i + 1); }
            i++;
        }
        return "{}";
    }

    /** Strip file extension: "abc.jpg" ? "abc". */
    static String stripExtension(String name) {
        if (name == null) return "";
        int dot = name.lastIndexOf('.');
        return (dot > 0) ? name.substring(0, dot) : name;
    }

    /** Derive directory base URL (strip trailing filename, trailing slashes). */
    static String deriveBaseUrl(String raw) {
        String s = raw.replaceAll("/+$", "");
        int schemeEnd = s.indexOf("://");
        int pathStart = (schemeEnd >= 0) ? s.indexOf('/', schemeEnd + 3) : s.indexOf('/');
        if (pathStart < 0) return s;
        int lastSlash = s.lastIndexOf('/');
        if (lastSlash > pathStart) {
            String lastSeg = s.substring(lastSlash + 1);
            if (lastSeg.contains(".")) s = s.substring(0, lastSlash).replaceAll("/+$", "");
        }
        return s;
    }

    static long parseLong(String s) {
        if (s == null) return 0L;
        try { return Long.parseLong(s.trim()); } catch (NumberFormatException e) { return 0L; }
    }

    /** Null-safe; returns empty string instead of null. */
    private static String safe(String s) { return s == null ? "" : s; }

    /** JSON-escape a string (for embedding in JSON string values). */
    static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
    }

    // ----------------------------------------------------------------------------
    // SETTERS (configure before init())
    // ----------------------------------------------------------------------------

    public void setBlocksDir(String blocksDir)                          { this.blocksDir          = blocksDir; }
    public void setKeysDir(String keysDir)                              { this.keysDir            = keysDir; }
    public void setServersFile(String serversFile)                      { this.serversFile        = serversFile; }
    public void setConnectMs(int connectMs)                             { this.connectMs          = connectMs; }
    public void setReadMs(int readMs)                                   { this.readMs             = readMs; }
    public void setThreadPool(int threadPool)                           { this.threadPool         = threadPool; }
    public void setBlockStore(BlockStore blockStore)                    { this.blockStore         = blockStore; }
    public void setConsensusMechanism(ConsensusMechanism cm)            { this.consensusMechanism = cm; }
    public void setEventSink(EventSink eventSink)                       { this.eventSink          = eventSink; }

    // ----------------------------------------------------------------------------
    // GETTERS (for modules that need to read configuration)
    // ----------------------------------------------------------------------------

    public BlockStore         getBlockStore()          { return blockStore; }
    public ConsensusMechanism getConsensusMechanism()  { return consensusMechanism; }
    public EventSink          getEventSink()           { return eventSink; }

    // ----------------------------------------------------------------------------
    // STANDALONE ENTRY POINT (minimal smoke-test / demo � replace with your app)
    // ----------------------------------------------------------------------------

    /**
     * Minimal standalone runner.
     * Usage:  java MeshChainCore [fileRef]
     *
     * In real use this class is instantiated by Spring Boot / your DI container.
     * This main() exists only to verify the core compiles and runs correctly.
     */
    public static void main(String[] args) throws Exception {
        MeshChainCore core = new MeshChainCore();

        // -- optional: wire a custom consensus before init --
        // core.setConsensusMechanism(new MyPoStorageConsensus());
        // core.setBlockStore(new MyJpaBlockStore(entityManager));

        core.init();

        System.out.println("MeshChainCore ready.");
        System.out.println("Public key (truncated): " +
                core.myPublicKeyBase64().substring(0, 40) + "...");
        System.out.println("Blocks in store: " + core.getBlockStore().count());

        // Verify chain
        List<String> errors = core.verifyChain();
        if (errors.isEmpty()) {
            System.out.println("Chain integrity: OK");
        } else {
            System.out.println("Chain integrity ERRORS:");
            for (String e : errors) System.out.println("  " + e);
        }

        // Demo mint (pass a real fileRef from your mesh network)
        if (args.length > 0) {
            String fileRef = args[0];
            System.out.println("\nMinting block for: " + fileRef);
            Block b = core.mintBlock(fileRef, null);
            System.out.println("Block minted: " + b);
            System.out.println(b.toJson());
        } else {
            System.out.println("\nNo fileRef argument supplied � skipping demo mint.");
            System.out.println("Usage: java MeshChainCore <sha256hash.ext>");
        }
    }
}