# MeshBlockchain — Improvement Suggestions

Priorities are ordered from most critical to nice-to-have. Each item includes the reason it matters and a concrete direction for implementation.

---

## Priority 1 — Security

These issues can be exploited to forge blocks, steal rewards, or corrupt the chain. Fix before any production or public use.

### 1.1 Private key stored as raw bytes on disk
The private key is written to `keys/private.key` with no encryption. Anyone with file-system read access can steal it and forge blocks signed as you.

**Fix:** Encrypt the private key with AES-256-GCM using a passphrase entered at startup. Use PBKDF2WithHmacSHA256 (available in Java 8) to derive the encryption key from the passphrase and a random salt stored alongside the key file.

### 1.2 No replay protection on blocks
A valid block JSON can be copied and re-submitted if the target filename is ever deleted. The signature only covers content fields — it does not bind the block to a specific chain state beyond `previous_hash`.

**Fix:** Include a cryptographic nonce (random 32-byte value) in the signed data so each block has a unique identity independent of its filename.

### 1.3 JSON field extraction is naive and injection-prone
`extractJsonField` uses `indexOf` string search. A crafted server response with nested quotes or duplicate field names can cause it to read the wrong value silently.

**Fix:** Replace with a minimal recursive-descent JSON parser (still no external libraries needed, ~150 lines) that correctly handles nesting, arrays, and duplicate keys.

### 1.4 No TLS/certificate validation for server connections
All HTTP connections use `HttpURLConnection` with default settings. A man-in-the-middle can serve fraudulent `files.txt` or `info/*.json` content, causing the user to build blocks on false data.

**Fix:** Enforce HTTPS for all server URLs in `servers.txt`. Reject plain HTTP unless a `--allow-insecure` flag is explicitly passed. Optionally support pinned certificates per server.

### 1.5 No rate-limiting or timeout on total download size
A malicious server can serve an infinite stream to `fetchBytes`, filling disk or blocking indefinitely beyond the read timeout.

**Fix:** Cap each download at a configurable `MAX_FILE_BYTES` (e.g. 512 MB). Wrap the `InputStream` in a `LimitedInputStream` that throws once the limit is exceeded.

### 1.6 Chain is stored on a mutable local filesystem
Nothing prevents the user (or malware) from editing or deleting block files after the fact. `doVerifyChain` detects this, but only when explicitly run.

**Fix:** After writing each block, append a tamper-evident log (an append-only file storing block hashes and timestamps). Verify the log on every startup and warn on any discrepancy.

---

## Priority 2 — Reward System

These issues allow reward balances to be gamed or miscounted.

### 2.1 No consensus on reward amounts across nodes
The `REWARD_AMOUNT` constant is hardcoded. If different users run different versions with different reward values, balances computed from the chain will disagree.

**Fix:** Define reward rules in a genesis block (index 0) that all participants read. Include the reward schedule (initial amount, halving interval, halving factor) in the genesis block's signed data.

### 2.2 No halving or supply cap
50 coins are minted per block forever. Without a supply schedule, the total coin supply grows without limit, making early coins worth less over time.

**Fix:** Implement halving: reward = `INITIAL_REWARD >> (index / HALVING_INTERVAL)`. Add a `MAX_SUPPLY` constant; once reached, block rewards drop to zero and mining is incentivised only by future fee mechanisms.

### 2.3 Balance computed by re-reading all blocks on every query
`computeBalance` iterates every block file each time. With thousands of blocks this becomes slow.

**Fix:** Maintain an in-memory UTXO-style map (`publicKey → balance`) that is updated incrementally as each block is added. Persist a snapshot to disk (e.g. `cache/balances.json`) so it survives restarts without a full rescan.

### 2.4 No transaction support — only coinbase rewards
Users can earn coins but cannot transfer them to other public keys.

**Fix:** Add a `transactions` array to each block. Each transaction has `from`, `to`, `amount`, and a signature from the sender. Validate that `from` has sufficient balance before including the transaction. This is the foundation for a usable token economy.

---

## Priority 3 — Chain Integrity & Consensus

These issues affect agreement across multiple participants.

### 3.1 No peer-to-peer block propagation
Each user mines and stores blocks locally. There is no mechanism to share new blocks with others or discover blocks mined by peers.

**Fix:** Add a lightweight gossip layer: on startup, fetch `json_blocks/` index from each server in `servers.txt` (or a dedicated `blocks.txt` manifest), download any blocks the local node is missing, and verify them before adding to the local chain.

### 3.2 Fork resolution is undefined
If two users mine a block for the same filename simultaneously, both blocks are valid locally but differ in content. The chain can silently diverge across participants.

**Fix:** Adopt a longest-chain rule: the valid chain with the highest `index` wins. On conflict for the same filename, keep the block whose `block_hash` is numerically smallest (a simple deterministic tie-breaker). Document this rule in the genesis block.

### 3.3 Genesis block is implicit
The chain starts with `previous_hash` set to all zeros but there is no explicit block 0. This makes it impossible to verify that all participants started from the same initial state.

**Fix:** Create and commit a signed genesis block (index 0) with fixed content (network name, creation timestamp, reward schedule, protocol version). Reject any chain that does not start with the correct genesis hash.

### 3.4 Attestation is local-only — servers are not actually queried for user verification
The current "majority attestation" re-verifies the user's own cached files locally. It does not actually ask remote servers to confirm the user has stored the files.

**Fix:** Implement a challenge-response protocol: the client requests a random byte-range or a salted hash of a file from each server; the server responds; the client proves it can reproduce the same result from its local copy. This requires a small server-side endpoint but makes attestation genuinely remote.

---

## Priority 4 — Reliability & Robustness

These issues cause silent failures or data loss under normal operating conditions.

### 4.1 Partial downloads are cached as valid
If `fetchBytes` returns incomplete data due to a network error (no exception, just short read), it is SHA-256-checked and will fail — but the corrupt file may already be written to `cache/files/`.

**Fix:** Write downloads to a `.tmp` file first, verify the hash, then atomically rename to the final path. Delete the `.tmp` file on any failure.

### 4.2 No retry logic for transient network failures
A single timeout or 503 response marks a server as unreachable for the entire mining run.

**Fix:** Add exponential-backoff retry (3 attempts, 1s/2s/4s delays) per URL before giving up.

### 4.3 Thread pool errors are silently swallowed
In `downloadAllFiles`, exceptions from `Future.get()` are caught and discarded. A threading bug or OOM error can cause files to be silently skipped, leading to a failed attestation with no useful diagnostic.

**Fix:** Log the full stack trace for unexpected exceptions. Distinguish between expected failures (file not found on server) and unexpected ones (OOM, interrupted) and surface the latter to the user.

### 4.4 `getSortedBlocks` sorts by parsing JSON on every comparison
The comparator inside `getSortedBlocks` reads and parses each block file twice per comparison call. For N blocks this is O(N log N) file reads.

**Fix:** Read the `index` field of each block once into a `Map<File, Long>`, then sort using that map. This reduces file reads from O(N log N) to O(N).

---

## Priority 5 — Usability & Observability

These do not affect correctness but significantly improve day-to-day use.

### 5.1 No progress indicator during large downloads
Downloading hundreds of files with no feedback looks like a hang. Users have no way to know how far along the process is.

**Fix:** Print a progress line like `[12/47] Downloading abc123.jpg from node2.example.com...` by tracking a shared `AtomicInteger` counter across download threads.

### 5.2 No export of public key in a shareable format
The full Base64 public key is hard to share or embed in a QR code. There is no address format derived from the key.

**Fix:** Add a short "mesh address" derived as `Base58(SHA-256(publicKey)[0..19])` — a 27-character human-readable identifier analogous to a Bitcoin address.

### 5.3 `servers.txt` has no validation at load time
Malformed URLs (e.g. missing scheme, whitespace in middle) pass through silently and cause unhelpful errors later.

**Fix:** Validate each line against a URL regex at load time and print a clear warning with the line number for any malformed entry.

### 5.4 No logging to file
All output goes to stdout and is lost after the session. Diagnosing a failed mining run requires reproducing it.

**Fix:** Mirror all console output to `mesh.log` with ISO-8601 timestamps. Rotate the log when it exceeds a configurable size (default 10 MB).

### 5.5 Key fingerprint is not shown on startup
The truncated public key shown at startup is not a stable identifier — it changes meaning if the encoding ever changes.

**Fix:** Show a stable SHA-256 fingerprint of the public key bytes (first 16 hex chars) at startup, alongside the truncated Base64. This gives users a short, stable identity token.

---

## Priority 6 — Code Quality & Maintainability

These make the codebase easier to extend, test, and audit.

### 6.1 All logic is in one file with one public class
A ~500-line single-file structure is manageable now but will become hard to navigate as features are added.

**Fix:** Split into packages: `crypto` (keys, signing, hashing), `network` (fetch, retry, attestation), `chain` (block building, verification, balance), `cli` (menu, formatting). Keep a single entry-point class.

### 6.2 Magic constants are scattered through the code
Values like `50L` (reward), `2048` (RSA key size), `8192` (buffer size) appear inline with no central configuration.

**Fix:** Consolidate all tunables into a `Config` inner class or a `config.properties` file read at startup. Document the effect of each value.

### 6.3 No unit tests
There is no way to verify that `extractJsonField`, `deriveBaseUrl`, `sha256Hex`, or the block-building logic behave correctly after a change.

**Fix:** Add a `MeshBlockchainTest.java` using only `java.lang.AssertionError`-based assertions (no JUnit required for Java 8 compatibility). Cover at minimum: JSON extraction edge cases, URL normalisation, hash verification, block round-trip, and chain verification.

### 6.4 `extractJsonField` is duplicated from MeshRank
The same method appears verbatim in both files.

**Fix:** Extract shared utilities (JSON parsing, URL normalisation, SHA-256, Base64, HTTP fetch) into a `MeshUtils.java` file that both programs import.
