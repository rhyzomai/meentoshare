package com.meento.blocks;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.tabs.TabLayout;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_PERMISSIONS = 100;
    private static final int CHUNK_SIZE = 1000;

    // UI
    private TabLayout tabLayout;
    private LinearLayout tabConfig, tabFiles, tabServers, tabSend;

    // Config tab
    private EditText etPix, etPublicKey, etNodesInfo;

    // Files tab
    private ListView lvFiles;
    private Button btnAddFile;
    private List<String> selectedFileNames = new ArrayList<>();
    private List<Uri> selectedFileUris = new ArrayList<>();
    private ArrayAdapter<String> filesAdapter;

    // Servers tab
    private ListView lvServers;
    private Button btnAddServer;
    private List<String> serverList = new ArrayList<>();
    private ArrayAdapter<String> serversAdapter;

    // Send tab
    private Button btnSend;
    private ProgressBar progressBar;
    private TextView tvLog;
    private ScrollView scrollLog;

    private File appDir;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private Handler mainHandler = new Handler(Looper.getMainLooper());

    private ActivityResultLauncher<Intent> filePickerLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        appDir = getFilesDir();
        initDirs();
        initViews();
        setupFilePicker();
        loadSavedData();
        requestPermissions();
    }

    private void initDirs() {
        new File(appDir, "chunks").mkdirs();
        new File(appDir, "chunks_info").mkdirs();
    }

    private void initViews() {
        tabLayout = findViewById(R.id.tabLayout);
        tabConfig = findViewById(R.id.tabConfig);
        tabFiles = findViewById(R.id.tabFiles);
        tabServers = findViewById(R.id.tabServers);
        tabSend = findViewById(R.id.tabSend);

        // Config
        etPix = findViewById(R.id.etPix);
        etPublicKey = findViewById(R.id.etPublicKey);
        etNodesInfo = findViewById(R.id.etNodesInfo);
        Button btnSaveConfig = findViewById(R.id.btnSaveConfig);
        btnSaveConfig.setOnClickListener(v -> saveConfig());

        // Files
        lvFiles = findViewById(R.id.lvFiles);
        btnAddFile = findViewById(R.id.btnAddFile);
        filesAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, selectedFileNames);
        lvFiles.setAdapter(filesAdapter);
        btnAddFile.setOnClickListener(v -> openFilePicker());
        lvFiles.setOnItemLongClickListener((parent, view, position, id) -> {
            showRemoveFileDialog(position);
            return true;
        });

        // Servers
        lvServers = findViewById(R.id.lvServers);
        btnAddServer = findViewById(R.id.btnAddServer);
        serversAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, serverList);
        lvServers.setAdapter(serversAdapter);
        btnAddServer.setOnClickListener(v -> showAddServerDialog(-1, ""));
        lvServers.setOnItemClickListener((parent, view, position, id) ->
                showAddServerDialog(position, serverList.get(position)));
        lvServers.setOnItemLongClickListener((parent, view, position, id) -> {
            showRemoveServerDialog(position);
            return true;
        });

        // Send
        btnSend = findViewById(R.id.btnSend);
        progressBar = findViewById(R.id.progressBar);
        tvLog = findViewById(R.id.tvLog);
        scrollLog = findViewById(R.id.scrollLog);
        btnSend.setOnClickListener(v -> startSending());

        // Tabs
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override public void onTabSelected(TabLayout.Tab tab) { showTab(tab.getPosition()); }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });
        showTab(0);
    }

    private void showTab(int pos) {
        tabConfig.setVisibility(pos == 0 ? View.VISIBLE : View.GONE);
        tabFiles.setVisibility(pos == 1 ? View.VISIBLE : View.GONE);
        tabServers.setVisibility(pos == 2 ? View.VISIBLE : View.GONE);
        tabSend.setVisibility(pos == 3 ? View.VISIBLE : View.GONE);
    }

    private void setupFilePicker() {
        filePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        Uri uri = result.getData().getData();
                        if (uri != null) {
                            String name = getFileName(uri);
                            selectedFileUris.add(uri);
                            selectedFileNames.add(name);
                            filesAdapter.notifyDataSetChanged();
                        }
                    }
                });
    }

    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        filePickerLauncher.launch(Intent.createChooser(intent, "Selecionar arquivo"));
    }

    private String getFileName(Uri uri) {
        String name = "unknown";
        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
            if (idx >= 0) name = cursor.getString(idx);
            cursor.close();
        }
        return name;
    }

    private void showRemoveFileDialog(int position) {
        new AlertDialog.Builder(this)
                .setTitle("Remover arquivo")
                .setMessage("Remover \"" + selectedFileNames.get(position) + "\"?")
                .setPositiveButton("Remover", (d, w) -> {
                    selectedFileNames.remove(position);
                    selectedFileUris.remove(position);
                    filesAdapter.notifyDataSetChanged();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showAddServerDialog(int editPosition, String currentValue) {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_server, null);
        EditText etServer = view.findViewById(R.id.etServerUrl);
        if (!currentValue.isEmpty()) etServer.setText(currentValue);

        String title = editPosition >= 0 ? "Editar servidor" : "Adicionar servidor";
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(view)
                .setPositiveButton("Salvar", (d, w) -> {
                    String url = etServer.getText().toString().trim();
                    if (!url.isEmpty()) {
                        if (editPosition >= 0) {
                            serverList.set(editPosition, url);
                        } else {
                            serverList.add(url);
                        }
                        serversAdapter.notifyDataSetChanged();
                        saveServers();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showRemoveServerDialog(int position) {
        new AlertDialog.Builder(this)
                .setTitle("Remover servidor")
                .setMessage("Remover \"" + serverList.get(position) + "\"?")
                .setPositiveButton("Remover", (d, w) -> {
                    serverList.remove(position);
                    serversAdapter.notifyDataSetChanged();
                    saveServers();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ─── Persistence ─────────────────────────────────────────────────────────

    private void saveConfig() {
        writeFile("pix.txt", etPix.getText().toString().trim());
        writeFile("public_key.txt", etPublicKey.getText().toString().trim());
        writeFile("nodes_info.txt", etNodesInfo.getText().toString().trim());
        Toast.makeText(this, "Configurações salvas!", Toast.LENGTH_SHORT).show();
    }

    private void saveServers() {
        StringBuilder sb = new StringBuilder();
        for (String s : serverList) sb.append(s).append("\n");
        writeFile("servers.txt", sb.toString().trim());
    }

    private void loadSavedData() {
        etPix.setText(readFile("pix.txt"));
        etPublicKey.setText(readFile("public_key.txt"));
        etNodesInfo.setText(readFile("nodes_info.txt"));

        String serversRaw = readFile("servers.txt");
        serverList.clear();
        if (!serversRaw.isEmpty()) {
            serverList.addAll(Arrays.asList(serversRaw.split("\n")));
        }
        if (serverList.isEmpty()) {
            serverList.add("http://meento.atwebpages.com/blocks.php");
            saveServers();
        }
        serversAdapter.notifyDataSetChanged();
    }

    private void writeFile(String name, String content) {
        try (FileWriter fw = new FileWriter(new File(appDir, name))) {
            fw.write(content);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String readFile(String name) {
        File f = new File(appDir, name);
        if (!f.exists()) return "";
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f)))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append("\n");
            return sb.toString().trim();
        } catch (IOException e) {
            return "";
        }
    }

    // ─── Chunking ─────────────────────────────────────────────────────────────

    private String md5(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] hash = md.digest(data);
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "00000000000000000000000000000000";
        }
    }

    private List<String> processFile(Uri uri, String originalName) throws IOException {
        // Read full bytes
        InputStream is = getContentResolver().openInputStream(uri);
        byte[] allBytes = is.readAllBytes();
        is.close();

        // Encode to base64
        String b64 = Base64.encodeToString(allBytes, Base64.NO_WRAP);
        byte[] b64Bytes = b64.getBytes("UTF-8");

        // MD5 of original file
        String fileHash = md5(allBytes);

        File chunksDir = new File(appDir, "chunks");
        List<String> chunkNames = new ArrayList<>();

        int total = b64Bytes.length;
        int partNum = 1;

        for (int offset = 0; offset < total; offset += CHUNK_SIZE) {
            int end = Math.min(offset + CHUNK_SIZE, total);
            byte[] chunk = Arrays.copyOfRange(b64Bytes, offset, end);
            String chunkHash = md5(chunk);
            String chunkName = fileHash + "." + partNum + "." + chunkHash;

            File chunkFile = new File(chunksDir, chunkName);
            try (FileOutputStream fos = new FileOutputStream(chunkFile)) {
                fos.write(chunk);
            }

            chunkNames.add(chunkName);
            partNum++;
        }

        // Save chunks_info
        File chunksInfoDir = new File(appDir, "chunks_info");
        File infoFile = new File(chunksInfoDir, originalName);
        try (FileWriter fw = new FileWriter(infoFile)) {
            for (String cn : chunkNames) fw.write(cn + "\n");
        }

        return chunkNames;
    }

    // ─── Sending ──────────────────────────────────────────────────────────────

    private void startSending() {
        if (serverList.isEmpty()) {
            Toast.makeText(this, "Nenhum servidor configurado!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (selectedFileUris.isEmpty()) {
            Toast.makeText(this, "Nenhum arquivo selecionado!", Toast.LENGTH_SHORT).show();
            return;
        }

        saveConfig();

        btnSend.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);
        tvLog.setText("");

        executor.execute(() -> {
            try {
                log("🔄 Processando arquivos...");

                String pix = readFile("pix.txt");
                String publicKey = readFile("public_key.txt");

                // Process each file
                for (int i = 0; i < selectedFileUris.size(); i++) {
                    Uri uri = selectedFileUris.get(i);
                    String name = selectedFileNames.get(i);
                    log("📦 Dividindo: " + name);
                    List<String> chunkNames = processFile(uri, name);
                    log("   → " + chunkNames.size() + " pedaços gerados");
                }

                // Send chunks to all servers
                File chunksDir = new File(appDir, "chunks");
                File[] chunkFiles = chunksDir.listFiles();
                if (chunkFiles != null) {
                    log("\n📤 Enviando pedaços (" + chunkFiles.length + " arquivos)...");
                    for (File chunkFile : chunkFiles) {
                        String chunkContent = readRawFile(chunkFile);
                        for (String server : serverList) {
                            sendChunk(server, chunkFile.getName(), chunkContent, publicKey, pix);
                        }
                    }
                }

                // Send chunks_info to all servers
                File chunksInfoDir = new File(appDir, "chunks_info");
                File[] infoFiles = chunksInfoDir.listFiles();
                if (infoFiles != null) {
                    log("\n📋 Enviando metadados (" + infoFiles.length + " arquivos)...");
                    for (File infoFile : infoFiles) {
                        String infoContent = readRawFile(infoFile);
                        for (String server : serverList) {
                            sendChunksInfo(server, infoFile.getName(), infoContent, publicKey, pix);
                        }
                    }
                }

                log("\n✅ Envio concluído com sucesso!");

            } catch (Exception e) {
                log("\n❌ Erro: " + e.getMessage());
            }

            mainHandler.post(() -> {
                btnSend.setEnabled(true);
                progressBar.setVisibility(View.GONE);
            });
        });
    }

    private void sendChunk(String server, String chunkName, String chunkContent,
                           String publicKey, String pix) {
        try {
            String urlStr = server
                    + "?type=chunk"
                    + "&name=" + URLEncoder.encode(chunkName, "UTF-8")
                    + "&content=" + URLEncoder.encode(chunkContent, "UTF-8")
                    + "&public_key=" + URLEncoder.encode(publicKey, "UTF-8")
                    + "&pix=" + URLEncoder.encode(pix, "UTF-8");

            int code = doGetRequest(urlStr);
            log("  [chunk] " + chunkName + " → " + server + " [" + code + "]");
        } catch (Exception e) {
            log("  [chunk] ERRO: " + chunkName + " → " + server + ": " + e.getMessage());
        }
    }

    private void sendChunksInfo(String server, String infoName, String infoContent,
                                String publicKey, String pix) {
        try {
            String urlStr = server
                    + "?type=chunks_info"
                    + "&name=" + URLEncoder.encode(infoName, "UTF-8")
                    + "&content=" + URLEncoder.encode(infoContent, "UTF-8")
                    + "&public_key=" + URLEncoder.encode(publicKey, "UTF-8")
                    + "&pix=" + URLEncoder.encode(pix, "UTF-8");

            int code = doGetRequest(urlStr);
            log("  [info]  " + infoName + " → " + server + " [" + code + "]");
        } catch (Exception e) {
            log("  [info]  ERRO: " + infoName + " → " + server + ": " + e.getMessage());
        }
    }

    private int doGetRequest(String urlStr) throws IOException {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(15000);
        int code = conn.getResponseCode();
        conn.disconnect();
        return code;
    }

    private String readRawFile(File f) throws IOException {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f)))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append("\n");
            return sb.toString().trim();
        }
    }

    private void log(String msg) {
        mainHandler.post(() -> {
            tvLog.append(msg + "\n");
            scrollLog.post(() -> scrollLog.fullScroll(View.FOCUS_DOWN));
        });
    }

    // ─── Permissions ──────────────────────────────────────────────────────────

    private void requestPermissions() {
        List<String> perms = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED)
                perms.add(Manifest.permission.READ_MEDIA_IMAGES);
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED)
                perms.add(Manifest.permission.READ_MEDIA_VIDEO);
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED)
                perms.add(Manifest.permission.READ_MEDIA_AUDIO);
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                perms.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (!perms.isEmpty())
            ActivityCompat.requestPermissions(this, perms.toArray(new String[0]), REQUEST_PERMISSIONS);
    }
}
