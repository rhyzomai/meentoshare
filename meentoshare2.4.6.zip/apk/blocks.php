﻿<?php
/**
 * Meento Blocks — Server Receiver
 * PHP 7 compatible
 * Receives GET requests from the Android app and stores chunks, manifests, and metadata.
 */

// ── Configuration ────────────────────────────────────────────────────────────

define('DIR_CHUNKS',      __DIR__ . '/chunks');
define('DIR_CHUNKS_INFO', __DIR__ . '/chunks_info');
define('DIR_CHUNKS_JSON', __DIR__ . '/chunks_json');

// ── Bootstrap ─────────────────────────────────────────────────────────────────

foreach ([DIR_CHUNKS, DIR_CHUNKS_INFO, DIR_CHUNKS_JSON] as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
}

// ── Read and sanitize input ──────────────────────────────────────────────────

$type       = isset($_GET['type'])       ? trim($_GET['type'])       : '';
$name       = isset($_GET['name'])       ? trim($_GET['name'])       : '';
$content    = isset($_GET['content'])    ? $_GET['content']          : '';
$public_key = isset($_GET['public_key']) ? trim($_GET['public_key']) : '';
$pix        = isset($_GET['pix'])        ? trim($_GET['pix'])        : '';

// ── Validate required fields ─────────────────────────────────────────────────

if ($type === '' || $name === '' || $content === '') {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Missing required fields: type, name, content']);
    exit;
}

if (!in_array($type, ['chunk', 'chunks_info'], true)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid type. Must be "chunk" or "chunks_info"']);
    exit;
}

// ── Sanitize filename (allow only safe characters) ───────────────────────────

$safe_name = basename($name);
$safe_name = preg_replace('/[^a-zA-Z0-9._\-]/', '_', $safe_name);

if ($safe_name === '' || $safe_name === '.' || $safe_name === '..') {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid file name']);
    exit;
}

// ── Get caller IP ────────────────────────────────────────────────────────────

function get_client_ip() {
    $headers = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
    foreach ($headers as $h) {
        if (!empty($_SERVER[$h])) {
            $ip = trim(explode(',', $_SERVER[$h])[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
    }
    return '0.0.0.0';
}

// ── Handle chunk ─────────────────────────────────────────────────────────────

if ($type === 'chunk') {

    $file_path = DIR_CHUNKS . '/' . $safe_name;

    $fh = fopen($file_path, 'w');
    if ($fh === false) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Could not open chunk file for writing']);
        exit;
    }
    fwrite($fh, $content);
    fclose($fh);

    // Write JSON metadata if pix and public_key are provided
    if ($pix !== '' && $public_key !== '') {

        $ip_raw    = get_client_ip();
        $ip_hashed = hash('sha256', $ip_raw);

        $meta = [
            'chunk_name' => $safe_name,
            'pix'        => $pix,
            'public_key' => $public_key,
            'ip_sha256'  => $ip_hashed,
            'date'       => date('Y-m-d'),
            'time'       => date('H:i:s'),
            'datetime'   => date('Y-m-d H:i:s'),
            'timestamp'  => time(),
        ];

        $json_path = DIR_CHUNKS_JSON . '/' . $safe_name . '.json';
        $jh = fopen($json_path, 'w');
        if ($jh !== false) {
            fwrite($jh, json_encode($meta, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            fclose($jh);
        }
    }

    http_response_code(200);
    echo json_encode(['status' => 'ok', 'type' => 'chunk', 'name' => $safe_name]);
    exit;
}

// ── Handle chunks_info ────────────────────────────────────────────────────────

if ($type === 'chunks_info') {

    $file_path = DIR_CHUNKS_INFO . '/' . $safe_name;

    $fh = fopen($file_path, 'w');
    if ($fh === false) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Could not open chunks_info file for writing']);
        exit;
    }
    fwrite($fh, $content);
    fclose($fh);

    http_response_code(200);
    echo json_encode(['status' => 'ok', 'type' => 'chunks_info', 'name' => $safe_name]);
    exit;
}