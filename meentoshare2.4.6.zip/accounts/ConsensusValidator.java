import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.*;

/**
 * ConsensusValidator � Distributed file integrity & blockchain block producer
 *
 * Expected layout (relative to working directory):
 *   accounts/          � UserStore JSON files  (<userhash>.json)
 *   files/             � locally hosted files  (<sha256hash>.<ext>)
 *   servers.txt        � one server base-URL per line (e.g. http://node.example.com)
 *   block_files/       � produced blockchain blocks (JSON)
 *
 * Remote nodes are expected to expose:
 *   GET <server>/files/<hash>.<ext>   � raw file bytes
 *   GET <server>/info/<hash>.json     � JSON with at least {"public_key":"..."}
 *
 * Compatible with Java 8+, zero external dependencies.
 */
public class ConsensusValidator {

    // ------------------------------------------------------------------ //
    //  Configuration
    // ------------------------------------------------------------------ //
    private static final String ACCOUNTS_DIR   = "accounts";
    private static final String FILES_DIR      = "files";
    private static final String SERVERS_FILE   = "servers.txt";
    private static final String BLOCK_DIR      = "block_files";
    private static final int    CONNECT_TIMEOUT = 8_000;   // ms
    private static final int    READ_TIMEOUT    = 15_000;  // ms

    // ------------------------------------------------------------------ //
    //  Entry point
    // ------------------------------------------------------------------ //
    public static void main(String[] args) throws Exception {
        System.out.println("=== ConsensusValidator starting ===\n");

        // 1. Read global server list
        List<String> globalServers = loadServerList();
        System.out.println("[config] Global servers loaded: " + globalServers.size());

        // 2. Discover all account JSON files
        File accountsDir = new File(ACCOUNTS_DIR);
        if (!accountsDir.isDirectory()) {
            die("accounts/ directory not found.");
        }

        File[] accountFiles = accountsDir.listFiles(
                f -> f.isFile() && f.getName().endsWith(".json") && !f.getName().endsWith(".tmp"));
        if (accountFiles == null || accountFiles.length == 0) {
            System.out.println("No account files found. Exiting.");
            return;
        }

        // 3. Process each account
        for (File accountFile : accountFiles) {
            System.out.println("\n--- Processing account: " + accountFile.getName() + " ---");
            processAccount(accountFile, globalServers);
        }

        System.out.println("\n=== ConsensusValidator finished ===");
    }

    // ------------------------------------------------------------------ //
    //  Account processing
    // ------------------------------------------------------------------ //
    private static void processAccount(File accountFile, List<String> globalServers) throws Exception {
        Map<String, Object> account = parseJsonObject(readFile(accountFile));

        String username     = str(account, "username");
        String usernameHash = str(account, "username_hash");
        String userPublicKey= str(account, "public_key");

        @SuppressWarnings("unchecked")
        List<String> fileRefs = (List<String>) account.getOrDefault("files", Collections.emptyList());

        @SuppressWarnings("unchecked")
        Map<String, Object> serversMap = (Map<String, Object>) account.getOrDefault("servers", Collections.emptyMap());

        System.out.println("  User      : " + username + " (" + usernameHash + ")");
        System.out.println("  Files     : " + fileRefs.size());
        System.out.println("  Servers   : " + serversMap.size());

        // Combine declared servers with global list (deduplicated)
        Set<String> allServerUrls = new LinkedHashSet<>(globalServers);
        for (Object v : serversMap.values()) {
            allServerUrls.add(normalizeUrl(v.toString()));
        }

        // 4. For each file reference � validate locally, then via consensus
        for (String fileRef : fileRefs) {
            System.out.println("\n  [file] " + fileRef);
            processFileRef(fileRef, userPublicKey, usernameHash, new ArrayList<>(allServerUrls));
        }
    }

    // ------------------------------------------------------------------ //
    //  Per-file processing
    // ------------------------------------------------------------------ //
    private static void processFileRef(
            String fileRef,
            String userPublicKey,
            String usernameHash,
            List<String> servers) throws Exception {

        // fileRef format: "<sha256hash>.<ext>"
        int dotIdx = fileRef.lastIndexOf('.');
        if (dotIdx < 0) {
            System.out.println("    [skip] Cannot parse file ref: " + fileRef);
            return;
        }
        String expectedHash = fileRef.substring(0, dotIdx);
        String extension    = fileRef.substring(dotIdx + 1); // without dot

        // -- Step 1: Local integrity check -------------------------------- //
        File localFile = new File(FILES_DIR, fileRef);
        boolean localOk = false;
        if (localFile.exists()) {
            String actualHash = sha256Hex(readBytes(localFile));
            localOk = actualHash.equalsIgnoreCase(expectedHash);
            System.out.println("    [local] " + (localOk ? "OK" : "HASH MISMATCH") +
                               " (expected=" + expectedHash.substring(0, 12) + "�)");
        } else {
            System.out.println("    [local] File not found locally.");
        }

        // -- Step 2: Remote consensus check ------------------------------ //
        int totalServers    = servers.size();
        int validCount      = 0;
        int invalidCount    = 0;
        Map<String, Integer> publicKeyVotes = new LinkedHashMap<>();

        for (String serverBase : servers) {
            String fileUrl = serverBase + "/files/" + fileRef;
            String infoUrl = serverBase + "/info/"  + expectedHash + ".json";

            // Check file integrity on remote server
            boolean remoteFileOk = checkRemoteFile(fileUrl, expectedHash);

            // Fetch info JSON for public key
            String remotePublicKey = fetchRemotePublicKey(infoUrl);

            if (remoteFileOk) {
                validCount++;
                System.out.println("    [remote] " + serverBase + " -> OK" +
                        (remotePublicKey != null ? " | pubkey=" + remotePublicKey.substring(0, Math.min(16, remotePublicKey.length())) + "�" : ""));
            } else {
                invalidCount++;
                System.out.println("    [remote] " + serverBase + " -> FAIL or unreachable");
            }

            // Tally public key votes
            if (remotePublicKey != null && !remotePublicKey.isEmpty()) {
                publicKeyVotes.merge(remotePublicKey, 1, Integer::sum);
            }
        }

        System.out.println("    [consensus] " + validCount + "/" + totalServers + " servers validated the file.");

        // -- Step 3: Determine consensus public key ----------------------- //
        String consensusPublicKey = majorityKey(publicKeyVotes);
        boolean pubKeyMatch = consensusPublicKey != null && consensusPublicKey.equals(userPublicKey);
        System.out.println("    [consensus] Public key match: " + pubKeyMatch);

        // -- Step 4: Majority threshold (simple majority) ----------------- //
        boolean majority = totalServers > 0 && validCount > totalServers / 2;

        if (!majority) {
            System.out.println("    [block] Consensus NOT reached � block will NOT be produced.");
            return;
        }

        // -- Step 5: Produce block ---------------------------------------- //
        System.out.println("    [block] Consensus reached � producing block�");
        produceBlock(fileRef, expectedHash, extension, userPublicKey,
                     consensusPublicKey, validCount, totalServers, localOk);
    }

    // ------------------------------------------------------------------ //
    //  Remote helpers
    // ------------------------------------------------------------------ //

    /** Download remote file, verify SHA-256, return true if hash matches. */
    private static boolean checkRemoteFile(String url, String expectedHash) {
        try {
            byte[] data = httpGetBytes(url);
            if (data == null) return false;
            String actual = sha256Hex(data);
            return actual.equalsIgnoreCase(expectedHash);
        } catch (Exception e) {
            return false;
        }
    }

    /** Fetch remote info/<hash>.json and extract "public_key" field. */
    private static String fetchRemotePublicKey(String url) {
        try {
            String json = httpGetString(url);
            if (json == null) return null;
            Map<String, Object> info = parseJsonObject(json);
            return str(info, "public_key");
        } catch (Exception e) {
            return null;
        }
    }

    // ------------------------------------------------------------------ //
    //  Block production (blockchain-style)
    // ------------------------------------------------------------------ //
    private static void produceBlock(
            String fileRef,
            String fileHash,
            String extension,
            String userPublicKey,
            String consensusPublicKey,
            int validCount,
            int totalServers,
            boolean localIntact) throws Exception {

        File blockDir = new File(BLOCK_DIR);
        if (!blockDir.exists()) blockDir.mkdirs();

        // Block filename = fileHash + ".json" (no IP, no username � only hash)
        File blockFile = new File(blockDir, fileHash + ".json");

        // Previous hash: hash of last block in directory (or "0" * 64 for genesis)
        String previousHash = computePreviousBlockHash(blockDir, blockFile);

        // Block data
        String timestamp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")
                .format(new Date());

        // Build JSON manually (no external JSON lib)
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"version\": 1,\n");
        sb.append("  \"timestamp\": \"").append(timestamp).append("\",\n");
        sb.append("  \"file_ref\": \"").append(jsonEscape(fileRef)).append("\",\n");
        sb.append("  \"file_hash\": \"").append(jsonEscape(fileHash)).append("\",\n");
        sb.append("  \"file_extension\": \"").append(jsonEscape(extension)).append("\",\n");
        sb.append("  \"local_integrity\": ").append(localIntact).append(",\n");
        sb.append("  \"servers_validated\": ").append(validCount).append(",\n");
        sb.append("  \"servers_total\": ").append(totalServers).append(",\n");
        sb.append("  \"user_public_key\": \"").append(jsonEscape(userPublicKey)).append("\",\n");
        sb.append("  \"consensus_public_key\": \"").append(consensusPublicKey != null ? jsonEscape(consensusPublicKey) : "").append("\",\n");
        sb.append("  \"public_key_consensus\": ").append(userPublicKey.equals(consensusPublicKey)).append(",\n");
        sb.append("  \"previous_block_hash\": \"").append(previousHash).append("\",\n");

        // Block hash = sha256 of the content above (without itself)
        String blockContent = sb.toString();
        String blockHash = sha256Hex(blockContent.getBytes(StandardCharsets.UTF_8));
        sb.append("  \"block_hash\": \"").append(blockHash).append("\"\n");
        sb.append("}\n");

        String finalBlock = sb.toString();
        Files.write(blockFile.toPath(), finalBlock.getBytes(StandardCharsets.UTF_8));
        System.out.println("    [block] Written -> " + blockFile.getPath());
        System.out.println("    [block] Hash    -> " + blockHash);
    }

    /**
     * Compute "previous block hash": SHA-256 of the most recently modified
     * block file in the directory, or 64 zeros if no blocks exist yet.
     */
    private static String computePreviousBlockHash(File blockDir, File currentBlockFile) throws Exception {
        File[] existing = blockDir.listFiles(
                f -> f.isFile() && f.getName().endsWith(".json") && !f.equals(currentBlockFile));
        if (existing == null || existing.length == 0) {
            return "0000000000000000000000000000000000000000000000000000000000000000";
        }
        // Sort by last-modified descending, pick the newest
        Arrays.sort(existing, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        byte[] lastBlockBytes = readBytes(existing[0]);
        return sha256Hex(lastBlockBytes);
    }

    // ------------------------------------------------------------------ //
    //  Utility � file & network
    // ------------------------------------------------------------------ //

    private static List<String> loadServerList() throws IOException {
        File f = new File(SERVERS_FILE);
        if (!f.exists()) {
            System.out.println("[warn] " + SERVERS_FILE + " not found � no global servers loaded.");
            return Collections.emptyList();
        }
        List<String> list = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty() && !line.startsWith("#")) {
                    list.add(normalizeUrl(line));
                }
            }
        }
        return list;
    }

    private static String normalizeUrl(String raw) {
        // Strip trailing slashes and any trailing path after the host+port
        // e.g. "http://test.com/index.php" -> "http://test.com"
        //       "http://test.com/"          -> "http://test.com"
        try {
            URL u = new URL(raw);
            String base = u.getProtocol() + "://" + u.getHost();
            if (u.getPort() != -1 && u.getPort() != 80 && u.getPort() != 443) {
                base += ":" + u.getPort();
            }
            return base;
        } catch (MalformedURLException e) {
            // Return trimmed, no trailing slash
            return raw.replaceAll("/+$", "");
        }
    }

    private static byte[] httpGetBytes(String urlStr) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(CONNECT_TIMEOUT);
        conn.setReadTimeout(READ_TIMEOUT);
        conn.setRequestMethod("GET");
        conn.setRequestProperty("User-Agent", "ConsensusValidator/1.0");
        int status = conn.getResponseCode();
        if (status != 200) return null;
        try (InputStream is = conn.getInputStream()) {
            return toByteArray(is);
        } finally {
            conn.disconnect();
        }
    }

    private static String httpGetString(String urlStr) throws Exception {
        byte[] data = httpGetBytes(urlStr);
        return data != null ? new String(data, StandardCharsets.UTF_8) : null;
    }

    private static byte[] readBytes(File f) throws IOException {
        try (FileInputStream fis = new FileInputStream(f)) {
            return toByteArray(fis);
        }
    }

    private static String readFile(File f) throws IOException {
        return new String(readBytes(f), StandardCharsets.UTF_8);
    }

    private static byte[] toByteArray(InputStream is) throws IOException {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] tmp = new byte[8192];
        int n;
        while ((n = is.read(tmp)) != -1) buf.write(tmp, 0, n);
        return buf.toByteArray();
    }

    // ------------------------------------------------------------------ //
    //  Utility � crypto
    // ------------------------------------------------------------------ //

    private static String sha256Hex(byte[] data) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] digest = md.digest(data);
        StringBuilder sb = new StringBuilder(64);
        for (byte b : digest) sb.append(String.format("%02x", b & 0xff));
        return sb.toString();
    }

    // ------------------------------------------------------------------ //
    //  Utility � consensus
    // ------------------------------------------------------------------ //

    /** Return the key with the most votes, or null if map is empty. */
    private static String majorityKey(Map<String, Integer> votes) {
        if (votes.isEmpty()) return null;
        return votes.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);
    }

    // ------------------------------------------------------------------ //
    //  Utility � minimal JSON parser (objects & string/boolean/number vals)
    // ------------------------------------------------------------------ //

    /**
     * Hand-rolled JSON object parser.
     * Handles: string, number, boolean, null values, and nested objects/arrays
     * (arrays are returned as List<Object>; nested objects as Map<String,Object>).
     * Good enough for the flat-ish UserStore JSON structure.
     */
    static Map<String, Object> parseJsonObject(String json) {
        json = json.trim();
        if (!json.startsWith("{")) throw new IllegalArgumentException("Not a JSON object");
        ParseState ps = new ParseState(json, 1);
        return parseObject(ps);
    }

    private static Map<String, Object> parseObject(ParseState ps) {
        Map<String, Object> map = new LinkedHashMap<>();
        skipWs(ps);
        while (ps.pos < ps.src.length() && ps.src.charAt(ps.pos) != '}') {
            // key
            String key = parseString(ps);
            skipWs(ps);
            expect(ps, ':');
            skipWs(ps);
            Object value = parseValue(ps);
            map.put(key, value);
            skipWs(ps);
            if (ps.pos < ps.src.length() && ps.src.charAt(ps.pos) == ',') {
                ps.pos++;
                skipWs(ps);
            }
        }
        if (ps.pos < ps.src.length()) ps.pos++; // consume '}'
        return map;
    }

    private static List<Object> parseArray(ParseState ps) {
        List<Object> list = new ArrayList<>();
        skipWs(ps);
        while (ps.pos < ps.src.length() && ps.src.charAt(ps.pos) != ']') {
            list.add(parseValue(ps));
            skipWs(ps);
            if (ps.pos < ps.src.length() && ps.src.charAt(ps.pos) == ',') {
                ps.pos++;
                skipWs(ps);
            }
        }
        if (ps.pos < ps.src.length()) ps.pos++; // consume ']'
        return list;
    }

    private static Object parseValue(ParseState ps) {
        skipWs(ps);
        char c = ps.src.charAt(ps.pos);
        if (c == '"')  return parseString(ps);
        if (c == '{')  { ps.pos++; return parseObject(ps); }
        if (c == '[')  { ps.pos++; return parseArray(ps); }
        if (c == 't')  { ps.pos += 4; return Boolean.TRUE; }
        if (c == 'f')  { ps.pos += 5; return Boolean.FALSE; }
        if (c == 'n')  { ps.pos += 4; return null; }
        // number
        int start = ps.pos;
        while (ps.pos < ps.src.length() && "0123456789.-+eE".indexOf(ps.src.charAt(ps.pos)) >= 0) ps.pos++;
        String num = ps.src.substring(start, ps.pos);
        try { return Long.parseLong(num); }
        catch (NumberFormatException e) {
            try { return Double.parseDouble(num); }
            catch (NumberFormatException e2) { return num; }
        }
    }

    private static String parseString(ParseState ps) {
        expect(ps, '"');
        StringBuilder sb = new StringBuilder();
        while (ps.pos < ps.src.length()) {
            char c = ps.src.charAt(ps.pos++);
            if (c == '"') break;
            if (c == '\\') {
                char esc = ps.src.charAt(ps.pos++);
                switch (esc) {
                    case '"':  sb.append('"'); break;
                    case '\\': sb.append('\\'); break;
                    case '/':  sb.append('/'); break;
                    case 'n':  sb.append('\n'); break;
                    case 'r':  sb.append('\r'); break;
                    case 't':  sb.append('\t'); break;
                    case 'u': {
                        String hex = ps.src.substring(ps.pos, ps.pos + 4);
                        sb.append((char) Integer.parseInt(hex, 16));
                        ps.pos += 4;
                        break;
                    }
                    default: sb.append(esc);
                }
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private static void skipWs(ParseState ps) {
        while (ps.pos < ps.src.length() && Character.isWhitespace(ps.src.charAt(ps.pos))) ps.pos++;
    }

    private static void expect(ParseState ps, char ch) {
        if (ps.pos >= ps.src.length() || ps.src.charAt(ps.pos) != ch)
            throw new IllegalStateException("Expected '" + ch + "' at pos " + ps.pos);
        ps.pos++;
    }

    private static class ParseState {
        String src; int pos;
        ParseState(String src, int pos) { this.src = src; this.pos = pos; }
    }

    // ------------------------------------------------------------------ //
    //  Utility � JSON output escaping
    // ------------------------------------------------------------------ //
    private static String jsonEscape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    // ------------------------------------------------------------------ //
    //  Utility � map field accessors
    // ------------------------------------------------------------------ //
    private static String str(Map<String, Object> m, String key) {
        Object v = m.get(key);
        return v != null ? v.toString() : "";
    }

    private static void die(String msg) {
        System.err.println("[fatal] " + msg);
        System.exit(1);
    }
}