# Meshare

A single-file Java 8 GUI client for browsing and downloading files from a list
of HTTP servers that share the same simple file/JSON layout.

## Layout assumed on every server

```
<server>/files.txt          one filename per line, format: <sha256>.<ext>
<server>/files/<sha256>.<ext>   the binary file
<server>/info/<sha256>.json     metadata
```

The JSON in `info/<sha256>.json` is flat and may contain any of:

```json
{
    "filename": "...",
    "size": 12345,
    "extension": "png",
    "public_key": "...",
    "server_public_key": "...",
    "node_info": "...",
    "description": "...",
    "date": "2026-06-17T21:50:53+02:00"
}
```

Any extra fields are also shown. Every JSON field is truncated to 512 chars on
display; the truncation is also applied when the field is read from the server
so even a 1 MB description in a JSON won't waste memory.

## Local layout created by Meshare

```
files/                downloaded binaries (named <hash>.<ext from JSON>)
info/                 downloaded JSON metadata  (named <hash>.json)
log/                  one JSON file per successful download,
                      named <originalFilename>_<hash8>.log.json
servers.txt           your server list (you create / edit this)
files.txt             local mirror of what's in files/ (one <hash>.<ext> per line)
```

## Build & run

```bash
javac Meshare.java
java  Meshare
```

That's it — no external libraries. Tested with OpenJDK 8 / 11 / 17.

## Using the GUI

1. Drop your server URLs into `servers.txt` (one per line, `#` for comments).
2. Start Meshare. The "Servers: N" label at the top confirms how many were
   loaded.
3. Type a search term in the search field and hit **Search** (or Enter).
   Results stream in as the JSON files come back from each server. Up to 200
   matching entries are shown.
4. **Random tries per server** is unchecked by default. If you check it and
   set a number, Meshare will randomly sample that many `files.txt` entries
   from each server instead of processing all of them. Useful for browsing
   very large indexes.
5. A row that is already present locally (both `files/<hash>.<ext>` and
   `info/<hash>.json` exist) is shown immediately as **Downloaded** without
   re-fetching anything from the network.
6. Double-click a row, or select rows and click **Download Selected**, to
   download the binary + JSON of those entries. The binary is verified
   against the SHA-256 in its filename; on mismatch both files are deleted.
7. **Download Matching** downloads every entry in the current result set
   that isn't already present locally.
8. **Download All** walks every server, fetches every entry from each
   `files.txt` and downloads the binary + JSON for anything that isn't
   already on disk.
9. **View JSON** (or right-click → View JSON) pops up the raw JSON of the
   selected row. **Reveal in folder** opens the OS file manager at
   `files/`.

The progress bar appears during Download All. **Stop** cancels an in-flight
search or a Download All run; in-flight HTTP requests finish but no new
ones are started.

## Other notes

- All HTTP requests use a 10 s connect / 30 s read timeout.
- Servers with the same filenames (e.g. mirrored copies) are not
  de-duplicated — you'll see one row per server, which is what you want
  for tracking the source of each file.
- The on-disk binary is named `<hash>.<extension>` where the extension
  comes from the `extension` JSON field, not from the line in `files.txt`.
  This is what the user is supposed to see on the wire.
- Logs in `log/` are JSON; you can grep them or parse them however you like.
