﻿<?php
// ═══════════════════════════════════════════════════════════════════════════════
//  MESH NODE — file replication over HTTP/HTTPS
//  Single-file PHP 7+ application (Refined UI Edition)
// ═══════════════════════════════════════════════════════════════════════════════

// Remove this line to avoid creating duplicate files in the 'users' directory.
require __DIR__ . '/user_files.php';

define('FILES_DIR',     __DIR__ . '/files');
define('INFO_DIR',      __DIR__ . '/info');
define('FILES_INDEX',   __DIR__ . '/files.txt');
define('SERVERS_FILE',  __DIR__ . '/servers.txt');
define('PUB_KEY_FILE',  __DIR__ . '/public_key.txt');
define('NODE_INFO_FILE',__DIR__ . '/node_info.txt');
define('MAX_COMMENT',   1 * 1024);   // 1 KB
define('BLOCKED_EXT',   ['php','php3','php4','php5','php7','phtml','phar']);

// ── shared log writer ─────────────────────────────────────────────────────────

/**
 * Append the info record for $hash into the root data.json array (no erase),
 * and ensure the basename is in files.txt.
 * Entirely silent — never leaks output or exceptions.
 */
function appendFilesAndDataJson(string $hash): void
{
    ob_start();
    $prev = error_reporting(0);
    try {
        $infoPath = INFO_DIR . '/' . $hash . '.json';
        $raw      = @file_get_contents($infoPath);
        if ($raw === false) return;

        $info = json_decode($raw, true);
        if (!is_array($info)) return;

        // -- files.txt: ensure the filename line is present --
        $ext      = $info['extension'] ?? '';
        $baseName = $ext !== '' ? "{$hash}.{$ext}" : $hash;
        appendIndex($baseName);   // already deduplicates

        // -- data.json: append entry to JSON array --
        $entry    = array_merge(['hash' => $hash], $info);
        $dataJson = __DIR__ . '/data.json';

        if (!file_exists($dataJson)) {
            file_put_contents($dataJson, "[\n]", LOCK_EX);
        }

        $fp = @fopen($dataJson, 'c+');
        if ($fp === false) return;

        if (!flock($fp, LOCK_EX)) { fclose($fp); return; }

        $content    = rtrim((string) stream_get_contents($fp));
        $closingPos = strrpos($content, ']');
        $encoded    = json_encode($entry, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        $indented   = implode("\n", array_map(
            static fn(string $l) => '    ' . $l,
            explode("\n", $encoded)
        ));

        if ($closingPos === false) {
            $newContent = "[\n" . $indented . "\n]";
        } elseif (trim(substr($content, 1, $closingPos - 1)) === '') {
            $newContent = "[\n" . $indented . "\n]";
        } else {
            $newContent = rtrim(substr($content, 0, $closingPos)) . ",\n" . $indented . "\n]";
        }

        rewind($fp);
        ftruncate($fp, 0);
        fwrite($fp, $newContent);
        flock($fp, LOCK_UN);
        fclose($fp);
    } catch (\Throwable $e) {
        // silently discard
    } finally {
        error_reporting($prev);
        ob_end_clean();
    }
}

// ── bootstrap ─────────────────────────────────────────────────────────────────
foreach ([FILES_DIR, INFO_DIR] as $d) {
    if (!is_dir($d)) mkdir($d, 0755, true);
}
if (!file_exists(FILES_INDEX)) file_put_contents(FILES_INDEX, '');

// ── helpers ───────────────────────────────────────────────────────────────────

function blockedExt(string $ext): bool {
    return in_array(strtolower($ext), BLOCKED_EXT, true);
}

function safeExt(string $filename): string {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return preg_replace('/[^a-z0-9]/', '', $ext);
}

function jsonOut(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/** Returns true if a filename (basename) is protected and must never be written. */
function isProtectedFile(string $filename): bool {
    $base = strtolower(basename($filename));
    return in_array($base, ['files.txt', 'data.json'], true);
}

function appendIndex(string $entry): void {
    $lines = file_exists(FILES_INDEX)
        ? array_map('trim', file(FILES_INDEX, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES))
        : [];
    if (!in_array($entry, $lines, true)) {
        file_put_contents(FILES_INDEX, $entry . PHP_EOL, FILE_APPEND | LOCK_EX);
    }
}

function loadServers(): array {
    if (!file_exists(SERVERS_FILE)) return [];
    $lines = file(SERVERS_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $out = [];
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '') continue;
        if (!preg_match('#^https?://#i', $line)) $line = 'http://' . $line;
        $out[] = rtrim($line, '/');
    }
    return array_unique($out);
}

/** Read a local text file; return trimmed content or empty string if absent. */
function readOptionalFile(string $path): string {
    return file_exists($path) ? trim((string) file_get_contents($path)) : '';
}

/**
 * Store a file locally and write its structured info JSON.
 */
function storeLocally(
    string $tmpPath,
    string $originalName,
    string $description,
    string $publicKey,
    string $nodeInfo
): array {
    $ext = safeExt($originalName);
    if (blockedExt($ext)) return ['ok' => false, 'error' => 'PHP files are not accepted.'];

    $hash     = hash_file('sha256', $tmpPath);
    $baseName = $ext !== '' ? "{$hash}.{$ext}" : $hash;
    $destFile = FILES_DIR . '/' . $baseName;
    $destInfo = INFO_DIR  . '/' . $hash . '.json';

    $existed = file_exists($destFile);

    // ── save file only if new ──
    if (!$existed) {
        if (!copy($tmpPath, $destFile)) {
            return ['ok' => false, 'error' => 'Could not write file to disk.'];
        }
        appendIndex($baseName);
    }

    // ── save info JSON only if new — never overwrite ──
    if (!file_exists($destInfo)) {
        $info = [
            'original_filename' => $originalName,
            'size'              => (int) filesize($destFile),
            'extension'         => $ext,
            'public_key'        => $publicKey,
            'node_info'         => $nodeInfo,
            'description'       => $description,
        ];
        file_put_contents(
            $destInfo,
            json_encode($info, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
        );
    }

    return ['ok' => true, 'hash' => $hash, 'filename' => $baseName, 'existed' => $existed];
}

/**
 * Push a file + metadata fields to one remote peer via multipart/form-data POST.
 */
function pushToServer(
    string $server,
    string $filePath,
    string $filename,
    string $description,
    string $publicKey,
    string $nodeInfo
): array {
    $boundary = '----MeshBoundary' . bin2hex(random_bytes(12));
    $body = '';

    // ── file field ──
    $mime  = @mime_content_type($filePath) ?: 'application/octet-stream';
    $body .= "--{$boundary}\r\n";
    $body .= 'Content-Disposition: form-data; name="file"; filename="' . addslashes($filename) . "\"\r\n";
    $body .= "Content-Type: {$mime}\r\n\r\n";
    $body .= file_get_contents($filePath) . "\r\n";

    // ── text fields ──
    $fields = [
        'description' => $description,
        'public_key'  => $publicKey,
        'node_info'   => $nodeInfo,
        'peer_push'   => '1',
    ];
    foreach ($fields as $name => $value) {
        $body .= "--{$boundary}\r\n";
        $body .= "Content-Disposition: form-data; name=\"{$name}\"\r\n\r\n";
        $body .= $value . "\r\n";
    }
    $body .= "--{$boundary}--\r\n";

    $url = $server . '/' . basename(__FILE__);

    $ctx = stream_context_create([
        'http' => [
            'method'        => 'POST',
            'header'        => implode("\r\n", [
                "Content-Type: multipart/form-data; boundary={$boundary}",
                "Content-Length: " . strlen($body),
                "X-Mesh-Node: 1",
            ]),
            'content'       => $body,
            'timeout'       => 20,
            'ignore_errors' => true,
        ],
        'ssl'  => [
            'verify_peer'      => false,
            'verify_peer_name' => false,
        ],
    ]);

    $raw = @file_get_contents($url, false, $ctx);
    if ($raw === false) {
        return ['ok' => false, 'server' => $server, 'error' => 'Connection failed.'];
    }

    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        return ['ok' => false, 'server' => $server, 'error' => 'Bad response: ' . substr($raw, 0, 120)];
    }

    return array_merge($decoded, ['server' => $server]);
}

// ═══════════════════════════════════════════════════════════════════════════════
//  RECEIVE ENDPOINT  —  POST from a peer node  (peer_push = 1)
// ═══════════════════════════════════════════════════════════════════════════════
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_FILES['file'], $_POST['peer_push']) &&
    $_POST['peer_push'] === '1'
) {
    $upload = $_FILES['file'];

    if ($upload['error'] !== UPLOAD_ERR_OK) {
        jsonOut(['ok' => false, 'error' => 'Upload error ' . $upload['error']], 400);
    }

    if (blockedExt(safeExt($upload['name']))) {
        jsonOut(['ok' => false, 'error' => 'PHP files are not accepted.'], 400);
    }

    $description = isset($_POST['description']) ? substr(trim($_POST['description']), 0, MAX_COMMENT) : '';
    $publicKey   = isset($_POST['public_key'])   ? trim($_POST['public_key'])  : '';
    $nodeInfo    = isset($_POST['node_info'])     ? trim($_POST['node_info'])   : '';

    $result = storeLocally($upload['tmp_name'], $upload['name'], $description, $publicKey, $nodeInfo);

    if ($result['ok'] && !$result['existed']) {
        appendFilesAndDataJson($result['hash']);
    }

    jsonOut($result, $result['ok'] ? 200 : 500);
}

// ═══════════════════════════════════════════════════════════════════════════════
//  UPLOAD ENDPOINT  —  POST from the browser  (stores locally + propagates)
// ═══════════════════════════════════════════════════════════════════════════════
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_FILES['file']) &&
    !isset($_POST['peer_push'])
) {
    $upload = $_FILES['file'];

    if ($upload['error'] !== UPLOAD_ERR_OK) {
        jsonOut(['ok' => false, 'error' => 'Upload error ' . $upload['error']], 400);
    }

    if (blockedExt(safeExt($upload['name']))) {
        jsonOut(['ok' => false, 'error' => 'PHP files are not accepted.'], 400);
    }

    $description = isset($_POST['comment']) ? substr(trim($_POST['comment']), 0, MAX_COMMENT) : '';

    // Read own public_key.txt
    $publicKey = readOptionalFile(PUB_KEY_FILE);
    // If local file is absent or empty, dynamically accept the variable submitted by user without writing to disk
    if ($publicKey === '' && isset($_POST['public_key'])) {
        $publicKey = substr(trim($_POST['public_key']), 0, 512);
    }
    $nodeInfo  = readOptionalFile(NODE_INFO_FILE);

    // Store locally
    $local = storeLocally($upload['tmp_name'], $upload['name'], $description, $publicKey, $nodeInfo);

    if (!$local['ok']) jsonOut($local, 500);

    if ($local['existed']) {
        jsonOut([
            'ok'         => true,
            'hash'       => $local['hash'],
            'filename'   => $local['filename'],
            'existed'    => true,
            'public_key' => $publicKey !== '' ? '✓ included' : '— not found',
            'node_info'  => $nodeInfo  !== '' ? '✓ included' : '— not found',
            'peers'      => [],
        ]);
    }

    appendFilesAndDataJson($local['hash']);

    $servers    = loadServers();
    $storedPath = FILES_DIR . '/' . $local['filename'];

    $responsePayload = json_encode([
        'ok'          => true,
        'hash'        => $local['hash'],
        'filename'    => $local['filename'],
        'existed'     => $local['existed'],
        'public_key'  => $publicKey !== '' ? '✓ included' : '— not found',
        'node_info'   => $nodeInfo  !== '' ? '✓ included' : '— not found',
        'peers_total' => count($servers),
        'peers'       => [],
    ], JSON_UNESCAPED_UNICODE);

    http_response_code(200);
    header('Content-Type: application/json');
    header('Content-Length: ' . strlen($responsePayload));
    header('Connection: close');
    echo $responsePayload;

    if (ob_get_level()) ob_end_flush();
    flush();

    ignore_user_abort(true);
    foreach ($servers as $server) {
        pushToServer($server, $storedPath, $upload['name'], $description, $publicKey, $nodeInfo);
    }
    exit;
}

// ── lightweight JSON endpoints for the UI ─────────────────────────────────────
if (isset($_GET['node_status'])) {
    $pkContent = readOptionalFile(PUB_KEY_FILE);
    jsonOut([
        'public_key' => $pkContent !== '',
        'node_info'  => file_exists(NODE_INFO_FILE) && readOptionalFile(NODE_INFO_FILE) !== '',
        'peers'      => count(loadServers()),
    ]);
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Mesh Node Manager</title>
<style>
:root {
    --bg: #fafafa;
    --card-bg: #ffffff;
    --accent: #4f46e5;
    --accent-hover: #4338ca;
    --text: #18181b;
    --text-muted: #71717a;
    --border: #e4e4e7;
    --border-hover: #d4d4d8;
    --success: #16a34a;
    --success-bg: #f0fdf4;
    --danger: #dc2626;
    --danger-bg: #fef2f2;
    --radius: 8px;
    --shadow: 0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body {
    min-height: 100vh;
    background: var(--bg);
    color: var(--text);
    font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 3rem 1.5rem;
    -webkit-font-smoothing: antialiased;
}

.page { max-width: 38rem; width: 100%; }

header {
    margin-bottom: 2.5rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 1rem;
    border-bottom: 1px solid var(--border);
    padding-bottom: 1.5rem;
}
h1 { font-size: 1.6rem; font-weight: 800; letter-spacing: -0.03em; color: var(--text); }
h1 em { font-weight: 400; color: var(--text-muted); font-style: normal; }
.sub { font-size: 0.85rem; color: var(--text-muted); margin-top: 0.2rem; }

.head-nav { display: flex; gap: 1rem; align-items: center; }
.head-nav a {
    font-size: 0.85rem;
    color: var(--text-muted);
    text-decoration: none;
    font-weight: 600;
    padding: 0.4rem 0.75rem;
    border-radius: var(--radius);
    transition: all 0.2s;
}
.head-nav a:hover, .head-nav a.active { color: var(--accent); background: #f4f4f5; }

#node-bar { display: flex; gap: 0.6rem; flex-wrap: wrap; margin-bottom: 2rem; }
.nb-pill {
    display: flex;
    align-items: center;
    gap: 0.4rem;
    padding: 0.35rem 0.75rem;
    background: var(--card-bg);
    border-radius: 20px;
    border: 1px solid var(--border);
    font-size: 0.78rem;
    color: var(--text-muted);
    box-shadow: var(--shadow);
}
.nb-dot { width: 6px; height: 6px; border-radius: 50%; background: #d4d4d8; }
.nb-dot.ok { background: var(--success); box-shadow: 0 0 8px var(--success); }
.nb-dot.blue { background: var(--accent); box-shadow: 0 0 8px var(--accent); }
.nb-val { font-weight: 600; color: var(--text); }

#drop-zone {
    background: var(--card-bg);
    border: 2px dashed var(--border);
    border-radius: var(--radius);
    padding: 3rem 1.5rem;
    text-align: center;
    cursor: pointer;
    box-shadow: var(--shadow);
    transition: all 0.2s ease-in-out;
}
#drop-zone:hover, #drop-zone:focus { border-color: var(--text-muted); background: #fafafa; }
#drop-zone.over { border-color: var(--accent); background: #f5f3ff; }
.dz-icon { margin-bottom: 1rem; font-size: 2.2rem; opacity: 0.8; }
.dz-title { font-size: 1.05rem; font-weight: 600; margin-bottom: 0.4rem; }
.dz-sub { font-size: 0.82rem; color: var(--text-muted); line-height: 1.6; }
.dz-sub b { color: var(--accent); font-weight: 600; }
#file-input { display: none; }

#panel {
    display: none;
    margin-top: 1.5rem;
    background: var(--card-bg);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    box-shadow: var(--shadow);
    overflow: hidden;
    animation: fadeUp 0.3s cubic-bezier(0.16, 1, 0.3, 1);
}
.panel-top { display: flex; align-items: center; gap: 0.8rem; padding: 1rem 1.25rem; border-bottom: 1px solid var(--border); }
.f-icon { width: 2.2rem; height: 2.2rem; background: #e0e7ff; border-radius: 6px; display: grid; place-items: center; font-size: 1.1rem; color: var(--accent); }
#f-name { font-size: 0.95rem; font-weight: 600; flex: 1; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
#f-size { font-size: 0.82rem; color: var(--text-muted); font-weight: 500; }
.x-btn { background: none; border: none; cursor: pointer; font-size: 1.1rem; color: var(--text-muted); padding: 0.3rem; transition: color 0.15s; }
.x-btn:hover { color: var(--danger); }

.meta-pills { padding: 0.75rem 1.25rem; display: flex; gap: 0.5rem; flex-wrap: wrap; border-bottom: 1px solid var(--border); background: #fafafa; align-items: center; }
.mpill { font-size: 0.75rem; padding: 0.25rem 0.6rem; border-radius: 4px; border: 1px solid var(--border); color: var(--text-muted); background: var(--card-bg); display: flex; align-items: center; gap: 0.3rem; font-weight: 500; }
.mpill.has { border-color: #bbf7d0; color: var(--success); background: var(--success-bg); }
.mpill svg { width: 0.85rem; height: 0.85rem; stroke: currentColor; fill: none; stroke-width: 2.5; stroke-linecap: round; stroke-linejoin: round; }

#pk-wrapper { width: 100%; display: flex; flex-direction: column; gap: 0.4rem; padding: 0.25rem 0; margin-top: 0.25rem; }
.pk-input-container { display: flex; width: 100%; gap: 0.5rem; align-items: center; }
input#pk-inline {
    flex: 1;
    padding: 0.5rem 0.75rem;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    font-size: 0.8rem;
    outline: none;
    background: var(--card-bg);
    color: var(--text);
    transition: all 0.2s;
}
input#pk-inline:focus { border-color: var(--accent); box-shadow: 0 0 0 2px #e0e7ff; }

.panel-mid { padding: 1.25rem; }
.fl { display: block; font-size: 0.8rem; font-weight: 600; color: var(--text-muted); margin-bottom: 0.5rem; }
textarea#comment-box { width: 100%; min-height: 5.5rem; padding: 0.75rem; border: 1px solid var(--border); border-radius: var(--radius); font-family: inherit; font-size: 0.9rem; resize: vertical; outline: none; transition: all 0.2s; }
textarea#comment-box:focus { border-color: var(--accent); box-shadow: 0 0 0 2px #e0e7ff; }
.cmeta { display: flex; justify-content: space-between; margin-top: 0.5rem; font-size: 0.78rem; color: var(--text-muted); }
.ccount.over { color: var(--danger); font-weight: 600; }

.panel-bot { padding: 1rem 1.25rem; border-top: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; gap: 0.8rem; background: #fafafa; }
.peer-info { font-size: 0.82rem; color: var(--text-muted); }
.peer-info b { color: var(--text); font-weight: 600; }
.btn-send { padding: 0.6rem 1.4rem; background: var(--accent); color: #fff; border: none; border-radius: var(--radius); font-weight: 600; font-size: 0.85rem; cursor: pointer; transition: background 0.2s; display: flex; align-items: center; gap: 0.5rem; box-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05); }
.btn-send:hover { background: var(--accent-hover); }
.btn-send.busy { background: #93c5fd; pointer-events: none; }
.btn-send svg { width: 0.95rem; height: 0.95rem; stroke: #fff; stroke-width: 2.5; fill: none; stroke-linecap: round; stroke-linejoin: round; }

#prog-wrap { height: 4px; background: var(--border); overflow: hidden; display: none; margin-top: 1.5rem; border-radius: 2px; }
#prog-bar { height: 100%; width: 0%; background: var(--accent); transition: width 0.1s linear; }

#status { display: none; margin-top: 1.5rem; padding: 1rem 1.25rem; border-radius: var(--radius); font-size: 0.9rem; line-height: 1.5; animation: fadeUp 0.25s ease; box-shadow: var(--shadow); }
#status.ok { background: var(--success-bg); border: 1px solid #bbf7d0; color: var(--success); }
#status.fail { background: var(--danger-bg); border: 1px solid #fecaca; color: var(--danger); }
.hash-line { margin-top: 0.75rem; }
.file-link { display: inline-flex; align-items: center; gap: 0.4rem; padding: 0.5rem 1.2rem; font-size: 0.85rem; font-weight: 600; text-decoration: none; color: var(--accent); border: 1px solid var(--accent); border-radius: var(--radius); background: #fff; transition: all 0.15s; }
.file-link:hover { background: #f5f3ff; }
.file-link svg { width: 0.9rem; height: 0.9rem; stroke: currentColor; stroke-width: 2.2; fill: none; stroke-linecap: round; stroke-linejoin: round; }

.json-preview { margin-top: 2.5rem; border: 1px solid var(--border); border-radius: var(--radius); overflow: hidden; box-shadow: var(--shadow); }
.json-preview-head { padding: 0.6rem 1rem; border-bottom: 1px solid var(--border); font-size: 0.78rem; font-weight: 600; color: var(--text-muted); background: #fafafa; display: flex; align-items: center; gap: 0.4rem; }
.json-preview-head svg { width: 0.9rem; height: 0.9rem; stroke: var(--text-muted); fill: none; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }
pre#json-schema { padding: 1.25rem; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; font-size: 0.8rem; line-height: 1.6; color: #27272a; background: var(--card-bg); overflow-x: auto; margin: 0; }
.jk { color: #2563eb; } .js { color: #16a34a; } .jn { color: #ea580c; }

footer { border-top: 1px solid var(--border); padding-top: 1.5rem; margin-top: 3rem; display: flex; justify-content: space-between; flex-wrap: wrap; gap: 0.5rem; font-size: 0.78rem; color: var(--text-muted); font-weight: 500; width: 100%; }

@keyframes fadeUp { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
</style>
</head>
<body>
<div class="page">

<header>
  <div>
    <h1>Mesh <em>Node</em></h1>
    <p class="sub">Peer replication · Cryptographic SHA-256 storage engine</p>
  </div>
  <nav class="head-nav">
    <a href="index.php" class="active">Upload</a>
    <a href="view.php">Search</a>
    <a href="user_files.php">Users</a>
    <a href="servers.php">Servers</a>
    <a href="panel.php">Panel</a>
    <a href="ip_limit.php">Spam</a>
  </nav>
</header>

<div id="node-bar">
  <div class="nb-pill">
    <span class="nb-dot blue"></span>
    peers <span class="nb-val" id="nb-peers">…</span>
  </div>
  <div class="nb-pill">
    <span class="nb-dot" id="nb-pk-dot"></span>
    public_key.txt <span class="nb-val" id="nb-pk">…</span>
  </div>
  <div class="nb-pill">
    <span class="nb-dot" id="nb-ni-dot"></span>
    node_info.txt <span class="nb-val" id="nb-ni">…</span>
  </div>
</div>

<div id="drop-zone" tabindex="0" role="button" aria-label="Drop zone file input">
  <div class="dz-icon">⚡</div>
  <p class="dz-title">Drop your file here or click to browse</p>
  <p class="dz-sub">Automated replication across mesh topology · Executable extensions strictly blocked</p>
</div>
<input type="file" id="file-input">

<div id="panel">
  <div class="panel-top">
    <div class="f-icon">📦</div>
    <span id="f-name">—</span>
    <span id="f-size"></span>
    <button class="x-btn" id="x-btn" aria-label="Cancel file deployment">✕</button>
  </div>

  <div class="meta-pills">
    <div class="mpill" id="mpill-pk">
      <svg viewBox="0 0 24 24"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.778 7.778 5.5 5.5 0 017.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>
      Server Public Key Configured
    </div>
    
    <div id="pk-wrapper" style="display:none;">
       <label class="fl" style="margin-bottom:0.2rem;">Public Key Parameter <span style="font-weight:400;color:var(--text-muted);">(Optional; file missing on node)</span></label>
       <div class="pk-input-container">
          <input type="text" id="pk-inline" maxlength="512" placeholder="Paste structural public key string to propagate...">
       </div>
    </div>

    <div class="mpill" id="mpill-ni">
      <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
      node_info
    </div>
    <div class="mpill has">
      <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
      Immutable Metadata Standard Fields Included
    </div>
  </div>

  <div class="panel-mid">
    <label class="fl" for="comment-box">Node Manifest Description <span style="font-weight:400;color:var(--text-muted);">(optional · up to 1 KB)</span></label>
    <textarea id="comment-box" placeholder="Provide operational context or descriptions tracking this payload asset..."></textarea>
    <div class="cmeta">
      <span>Appended directly to payload index scheme</span>
      <span class="ccount" id="ccount">0 / 1,000</span>
    </div>
  </div>

  <div class="panel-bot">
    <span class="peer-info">Target Topology Routing: <b id="peer-count">…</b> system targets</span>
    <button class="btn-send" id="send-btn">
      <svg viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
      Propagate to Mesh
    </button>
  </div>
</div>

<div id="prog-wrap"><div id="prog-bar"></div></div>
<div id="status"></div>

<div class="json-preview">
  <div class="json-preview-head">
    <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
    info/&lt;hash&gt;.json — Manifest Layout Specification
  </div>
  <pre id="json-schema">{
  <span class="jk">"original_filename"</span>: <span class="js">"photo.jpg"</span>,
  <span class="jk">"size"</span>:              <span class="jn">204800</span>,
  <span class="jk">"extension"</span>:        <span class="js">"jpg"</span>,
  <span class="jk">"public_key"</span>:       <span class="js">"&lt;contents of public_key.txt or browser custom parameter&gt;"</span>,
  <span class="jk">"node_info"</span>:        <span class="js">"&lt;contents of node_info.txt or empty string&gt;"</span>,
  <span class="jk">"description"</span>:      <span class="js">"&lt;user comment manifest or empty string&gt;"</span>
}</pre>
</div>

</div>

<footer class="page">
  <p>Standard System Protocol · SHA256 Data Integrity Verifier</p>
  <p>PHP Environment Instance: <?php echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION; ?></p>
</footer>

<script>
(function(){
'use strict';

const dz       = document.getElementById('drop-zone');
const fi       = document.getElementById('file-input');
const panel    = document.getElementById('panel');
const fName    = document.getElementById('f-name');
const fSize    = document.getElementById('f-size');
const xBtn     = document.getElementById('x-btn');
const commentB = document.getElementById('comment-box');
const ccount   = document.getElementById('ccount');
const sendBtn  = document.getElementById('send-btn');
const peerCnt  = document.getElementById('peer-count');
const status   = document.getElementById('status');
const progWrap = document.getElementById('prog-wrap');
const progBar  = document.getElementById('prog-bar');
const mpillPk  = document.getElementById('mpill-pk');
const mpillNi  = document.getElementById('mpill-ni');
const pkWrapper = document.getElementById('pk-wrapper');
const pkInline = document.getElementById('pk-inline');

const MAX     = 1000;
const BLOCKED = ['php','php3','php4','php5','php7','phtml','phar'];
let file = null;
let ns   = { public_key: false, node_info: false, peers: 0 };

// ── Pull current infrastructure status ──────────────────────────────────────────
fetch(window.location.href + '?node_status=1')
  .then(r => r.json())
  .then(d => {
    ns = d;
    document.getElementById('nb-peers').textContent = d.peers;
    peerCnt.textContent = d.peers;

    const dot = (id, ok) => {
      const el = document.getElementById(id);
      if(el) el.className = 'nb-dot ' + (ok ? 'ok' : '');
    };
    dot('nb-pk-dot', d.public_key);
    dot('nb-ni-dot', d.node_info);
    document.getElementById('nb-pk').textContent = d.public_key ? 'Active' : 'Missing/Empty';
    document.getElementById('nb-ni').textContent = d.node_info  ? 'Active' : 'Missing/Empty';
    updatePills();
  })
  .catch(() => {
    ['nb-peers','nb-pk','nb-ni'].forEach(id => {
      const el = document.getElementById(id); if(el) el.textContent='?';
    });
    peerCnt.textContent = '?';
  });

function updatePills(){
  const hasPk = ns.public_key;
  // If true (file exists), show verified pill status and hide user input interface entirely
  mpillPk.style.display = hasPk ? '' : 'none';
  pkWrapper.style.display = hasPk ? 'none' : 'block';
  mpillNi.className = 'mpill ' + (ns.node_info  ? 'has' : '');
}

function fmt(b){
  if(b<1024) return b+' B';
  if(b<1048576) return (b/1024).toFixed(1)+' KB';
  return (b/1048576).toFixed(2)+' MB';
}

function extOf(n){ return n.split('.').pop().toLowerCase(); }

function setFile(f){
  if(!f) return;
  if(BLOCKED.includes(extOf(f.name))){ show('fail','Validation Rejected: Executable files are not accepted on mesh clusters.'); return; }
  file = f;
  fName.textContent = f.name;
  fSize.textContent = fmt(f.size);
  panel.style.display = 'block';
  commentB.value = '';
  updateCount();
  updatePills();
  hide();
}

function clear(){
  file = null; fi.value = '';
  panel.style.display = 'none';
  commentB.value = '';
  pkInline.value = '';
}

dz.addEventListener('click', () => fi.click());
dz.addEventListener('keydown', e => { if(e.key==='Enter'||e.key===' ') fi.click(); });
fi.addEventListener('change', () => { if(fi.files[0]) setFile(fi.files[0]); });
xBtn.addEventListener('click', clear);

['dragenter','dragover'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.add('over'); }));
['dragleave','drop'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.remove('over'); }));
dz.addEventListener('drop', e => { if(e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]); });

function updateCount(){
  const len = new TextEncoder().encode(commentB.value).length;
  ccount.textContent = len.toLocaleString()+' / '+MAX.toLocaleString();
  ccount.classList.toggle('over', len > MAX);
}
commentB.addEventListener('input', updateCount);

function show(type, html){ status.className=type; status.innerHTML=html; status.style.display='block'; }
function hide(){ status.style.display='none'; }

sendBtn.addEventListener('click', () => {
  if(!file) return;
  if(new TextEncoder().encode(commentB.value).length > MAX){
    show('fail','Description constraint check failed: content exceeds 1 KB limit.'); return;
  }

  const fd = new FormData();
  fd.append('file', file);
  fd.append('comment', commentB.value);
  if (!ns.public_key && pkInline.value.trim() !== '') {
    fd.append('public_key', pkInline.value.trim().slice(0, 512));
  }

  const xhr = new XMLHttpRequest();
  sendBtn.classList.add('busy');
  sendBtn.innerHTML = '<svg class="animate-spin" viewBox="0 0 24 24" style="animation: spin 1s linear infinite;"><circle style="opacity: 0.25;" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path style="opacity: 0.75;" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Transmitting Packet...';
  progWrap.style.display = 'block';
  progBar.style.width = '0%';
  hide();

  xhr.upload.addEventListener('progress', e => {
    if(e.lengthComputable) progBar.style.width = Math.round(e.loaded/e.total*100)+'%';
  });

  xhr.addEventListener('load', () => {
    sendBtn.classList.remove('busy');
    sendBtn.innerHTML = '<svg viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> Propagate to Mesh';
    progBar.style.width = '100%';
    setTimeout(() => { progWrap.style.display='none'; progBar.style.width='0%'; }, 700);

    let res;
    try {
      const raw = xhr.responseText.replace(/^[\s\S]*?(\{)/, '$1');
      res = JSON.parse(raw);
    } catch(e){
      const m = xhr.responseText.match(/"filename"\s*:\s*"([^"]+)"/);
      if(m){
        showLink(m[1], false);
        clear(); return;
      }
      show('fail','Server execution returned unexpected non-structural tracking data.'); return;
    }
    if(!res.ok){ show('fail','✗ Execution error: '+(res.error||'Unspecified infrastructure failure')); return; }

    showLink(res.filename, !!res.existed);
    clear();
  });

  xhr.addEventListener('error', () => {
    sendBtn.classList.remove('busy');
    sendBtn.innerHTML = '<svg viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> Propagate to Mesh';
    show('fail','✗ Fatal transport error: Connection disrupted.'); progWrap.style.display='none';
  });

  xhr.open('POST', window.location.href);
  xhr.send(fd);
});

function showLink(filename, existed){
  const fileUrl = 'files/' + esc(filename);
  const note    = existed ? ' <span style="opacity:0.7; font-weight:400;">(Cached Asset — Duplication Skipped)</span>' : '';
  show('ok',
    '<div style="font-weight:600;">✓ Payload Synchronized Successfully' + note + '</div>' +
    '<div class="hash-line">' +
      '<a class="file-link" href="' + fileUrl + '" target="_blank" rel="noopener noreferrer">' +
        '<svg viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>' +
        'Examine Live File Object' +
      '</a>' +
    '</div>'
  );
}

function esc(s){
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

})();
</script>
<style>@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }</style>
</body>
</html>